package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.court.PreCourtWork;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.numerator.NumeratorService;
import io.jmix.core.DeletePolicy;
import io.jmix.core.Messages;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDelete;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_B_COURT_CASE", indexes = {
        @Index(name = "IDX_PRXBCOURTCAS_CONSOLIDATEW", columnList = "CONSOLIDATE_WITH_CASE_ID"),
        @Index(name = "IDX_PRXBCOURTCASE_CASECATEGORY", columnList = "CASE_CATEGORY_ID"),
        @Index(name = "IDX_PRX_B_COURT_CASE_LAWAYER", columnList = "LAWAYER_ID")
})
@Entity(name = "prx_BCourtCase")
public class BCourtCase implements BaseUuidEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "CASE_NUMBER", nullable = false, length = 60)
    @NotNull
    private String caseNumber;

    @JoinColumn(name = "CONSOLIDATE_WITH_CASE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private BCourtCase consolidateWithCase;

    @Column(name = "CASE_STATUS")
    private String caseStatus;

    @Column(name = "STATUS_DATE")
    private LocalDate statusDate;

    @Column(name = "DEAD_LINE_DATE")
    private LocalDate deadLineDate;

    @Column(name = "CASE_NUMBER_FIRST_INSTANS", length = 60)
    private String caseNumberFirstInstans;

    @Column(name = "CASE_NUMBER_APPEAL", length = 60)
    private String caseNumberAppeal;

    @Column(name = "CASE_NUMBER_CASSATION", length = 60)
    private String caseNumberCassation;

    @Column(name = "CASE_NUMBER_ENFORCEMENT", length = 60)
    private String caseNumberEnforcement;

    @NotNull
    @Column(name = "CASE_TYPE", nullable = false, length = 60)
    private String caseType;

    @Column(name = "CLAIMANT_NAME")
    private String claimantName;

    @Column(name = "DEFENDANT_NAME")
    private String defendantName;

    @Column(name = "THIRD_PARTY_NAME")
    private String thirdPartyName;

    @JoinColumn(name = "CASE_CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtSessionCategory caseCategory;

    @Column(name = "CLAIM_SUBJECT")
    @Lob
    private String claimSubject;

    @Column(name = "CLAIM_AMOUNT", precision = 19, scale = 2)
    private BigDecimal claimAmount;

    @Column(name = "TOTAL_CLAIM_AMOUNT", precision = 19, scale = 2)
    private BigDecimal totalClaimAmount;

    @Column(name = "POSITION_TELMICO")
    @Lob
    private String positionTelmico;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "LAWAYER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtLawyer lawayer;

    @Column(name = "NOTE")
    @Lob
    private String note;

    @OnDeleteInverse(DeletePolicy.UNLINK)
    @OnDelete(DeletePolicy.DENY)
    @Composition
    @OneToMany(mappedBy = "courtCase")
    private List<BCourtCaseEventTable> caseEvent;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public BigDecimal getTotalClaimAmount() {
        return totalClaimAmount;
    }

    public void setTotalClaimAmount(BigDecimal totalClaimAmount) {
        this.totalClaimAmount = totalClaimAmount;
    }

    public List<BCourtCaseEventTable> getCaseEvent() {
        return caseEvent;
    }

    public void setCaseEvent(List<BCourtCaseEventTable> caseEvent) {
        this.caseEvent = caseEvent;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public CCourtLawyer getLawayer() {
        return lawayer;
    }

    public void setLawayer(CCourtLawyer lawayer) {
        this.lawayer = lawayer;
    }

    public String getPositionTelmico() {
        return positionTelmico;
    }

    public void setPositionTelmico(String positionTelmico) {
        this.positionTelmico = positionTelmico;
    }

    public BigDecimal getClaimAmount() {
        return claimAmount;
    }

    public void setClaimAmount(BigDecimal claimAmount) {
        this.claimAmount = claimAmount;
    }

    public String getClaimSubject() {
        return claimSubject;
    }

    public void setClaimSubject(String claimSubject) {
        this.claimSubject = claimSubject;
    }

    public CCourtSessionCategory getCaseCategory() {
        return caseCategory;
    }

    public void setCaseCategory(CCourtSessionCategory caseCategory) {
        this.caseCategory = caseCategory;
    }

    public String getThirdPartyName() {
        return thirdPartyName;
    }

    public void setThirdPartyName(String thirdPartyName) {
        this.thirdPartyName = thirdPartyName;
    }

    public String getDefendantName() {
        return defendantName;
    }

    public void setDefendantName(String defendantName) {
        this.defendantName = defendantName;
    }

    public String getClaimantName() {
        return claimantName;
    }

    public void setClaimantName(String claimantName) {
        this.claimantName = claimantName;
    }

    public BCourtCaseType getCaseType() {
        return caseType == null ? null : BCourtCaseType.fromId(caseType);
    }

    public void setCaseType(BCourtCaseType caseType) {
        this.caseType = caseType == null ? null : caseType.getId();
    }

    public String getCaseNumberEnforcement() {
        return caseNumberEnforcement;
    }

    public void setCaseNumberEnforcement(String caseNumberEnforcement) {
        this.caseNumberEnforcement = caseNumberEnforcement;
    }

    public String getCaseNumberCassation() {
        return caseNumberCassation;
    }

    public void setCaseNumberCassation(String caseNumberCassation) {
        this.caseNumberCassation = caseNumberCassation;
    }

    public String getCaseNumberAppeal() {
        return caseNumberAppeal;
    }

    public void setCaseNumberAppeal(String caseNumberAppeal) {
        this.caseNumberAppeal = caseNumberAppeal;
    }

    public String getCaseNumberFirstInstans() {
        return caseNumberFirstInstans;
    }

    public void setCaseNumberFirstInstans(String caseNumberFirstInstans) {
        this.caseNumberFirstInstans = caseNumberFirstInstans;
    }

    public LocalDate getDeadLineDate() {
        return deadLineDate;
    }

    public void setDeadLineDate(LocalDate deadLineDate) {
        this.deadLineDate = deadLineDate;
    }

    public LocalDate getStatusDate() {
        return statusDate;
    }

    public void setStatusDate(LocalDate statusDate) {
        this.statusDate = statusDate;
    }

    public CCourtCaseStage getCaseStatus() {
        return caseStatus == null ? null : CCourtCaseStage.fromId(caseStatus);
    }

    public void setCaseStatus(CCourtCaseStage caseStatus) {
        this.caseStatus = caseStatus == null ? null : caseStatus.getId();
    }

    public BCourtCase getConsolidateWithCase() {
        return consolidateWithCase;
    }

    public void setConsolidateWithCase(BCourtCase consolidateWithCase) {
        this.consolidateWithCase = consolidateWithCase;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"caseNumber", "caseStatus", "caseType"})
    public String getInstanceName() {
        Messages  messages= AppBeans.getBean(Messages.class);

        return String.format("%s %s %s", caseNumber, messages.getMessage(getCaseStatus()), messages.getMessage(getCaseType()));
    }

    @PostConstruct
    public void postConstruct() {
        NumeratorService numeratorService = AppBeans.getBean(NumeratorService.class);
        if(getCaseNumber()==null) {
            setCaseNumber(
                    numeratorService.getNumSeq(PreCourtWork.class)
            );
        }
    }
}