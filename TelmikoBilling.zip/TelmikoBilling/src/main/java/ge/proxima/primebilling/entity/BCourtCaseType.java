package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum BCourtCaseType implements EnumClass<String> {

    INCOME("INCOME"),
    OUTGOING("OUTGOING");

    private String id;

    BCourtCaseType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static BCourtCaseType fromId(String id) {
        for (BCourtCaseType at : BCourtCaseType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}