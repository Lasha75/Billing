package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.enums.CCourtAppealResultType;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.PrePersist;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

@JmixEntity
@Entity(name = "prx_BCourtCassationProceedings")
public class BCourtCassationProceedings extends BCourtCaseEventTable implements BaseUuidEntity {
    @Column(name = "CASE_NUMBER_CASSATION", nullable = false, length = 60)
    @NotNull
    private String caseNumberCassation;

    @Column(name = "LAST_STATUS")
    private String lastStatus;

    @Column(name = "LAST_STATUS_DATE")
    private LocalDate lastStatusDate;

    @Column(name = "INITIATOR_TYPE", length = 60)
    private String initiatorType;

    @Column(name = "SUBJECT_OF_APPEAL_TYPE", length = 60)
    private String subjectOfAppealType;

    @Column(name = "DATE_SENT_APPEAL")
    private LocalDate dateSentAppeal;

    @Column(name = "REGISTER_DATE")
    private LocalDate registerDate;

    @Column(name = "RESULT_TYPE", length = 60)
    private String resultType;

    @Column(name = "CONSIDERATION_DATE")
    private LocalDate considerationDate;

    @Column(name = "AMOUNT_CASSATION_DUTY", precision = 19, scale = 2)
    private BigDecimal amountCassationDuty;

    @Column(name = "NOTE")
    @Lob
    private String note;

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public BigDecimal getAmountCassationDuty() {
        return amountCassationDuty;
    }

    public void setAmountCassationDuty(BigDecimal amountCassationDuty) {
        this.amountCassationDuty = amountCassationDuty;
    }

    public LocalDate getConsiderationDate() {
        return considerationDate;
    }

    public void setConsiderationDate(LocalDate considerationDate) {
        this.considerationDate = considerationDate;
    }

    public CCourtAppealResultType getResultType() {
        return resultType == null ? null : CCourtAppealResultType.fromId(resultType);
    }

    public void setResultType(CCourtAppealResultType resultType) {
        this.resultType = resultType == null ? null : resultType.getId();
    }

    public LocalDate getRegisterDate() {
        return registerDate;
    }

    public void setRegisterDate(LocalDate registerDate) {
        this.registerDate = registerDate;
    }

    public LocalDate getDateSentAppeal() {
        return dateSentAppeal;
    }

    public void setDateSentAppeal(LocalDate dateSentAppeal) {
        this.dateSentAppeal = dateSentAppeal;
    }

    public CCourtAppealResultType getSubjectOfAppealType() {
        return subjectOfAppealType == null ? null : CCourtAppealResultType.fromId(subjectOfAppealType);
    }

    public void setSubjectOfAppealType(CCourtAppealResultType subjectOfAppealType) {
        this.subjectOfAppealType = subjectOfAppealType == null ? null : subjectOfAppealType.getId();
    }

    public CCourtInitiator getInitiatorType() {
        return initiatorType == null ? null : CCourtInitiator.fromId(initiatorType);
    }

    public void setInitiatorType(CCourtInitiator initiatorType) {
        this.initiatorType = initiatorType == null ? null : initiatorType.getId();
    }

    public LocalDate getLastStatusDate() {
        return lastStatusDate;
    }

    public void setLastStatusDate(LocalDate lastStatusDate) {
        this.lastStatusDate = lastStatusDate;
    }

    public CCourtCaseStage getLastStatus() {
        return lastStatus == null ? null : CCourtCaseStage.fromId(lastStatus);
    }

    public void setLastStatus(CCourtCaseStage lastStatus) {
        this.lastStatus = lastStatus == null ? null : lastStatus.getId();
    }

    public String getCaseNumberCassation() {
        return caseNumberCassation;
    }

    public void setCaseNumberCassation(String caseNumberCassation) {
        this.caseNumberCassation = caseNumberCassation;
    }

    @PrePersist
    public void prePersist() {
        setLastStatus(getCourtCase().getCaseStatus());
        setLastStatusDate(getCourtCase().getStatusDate());
    }
}