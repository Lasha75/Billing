package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrePersist;
import java.time.LocalDate;

@JmixEntity
@Entity(name = "prx_BCourtConsiderFirstInstance")
public class BCourtConsiderFirstInstance extends BCourtCaseEventTable implements BaseUuidEntity {
    @Column(name = "CASE_NUMBER_FIRST_INSTANS", length = 60)
    private String caseNumberFirstInstans;

    @Column(name = "LAST_STATUS")
    private String lastStatus;

    @Column(name = "LAST_STATUS_DATE")
    private LocalDate lastStatusDate;

    @Column(name = "REGISTRATION_DATE")
    private LocalDate registrationDate;

    @Column(name = "JUDGE_NAME", length = 60)
    private String judgeName;

    @Column(name = "DEFANDANT_NAME")
    private String defandantName;

    @Column(name = "LOGIN_USER", length = 60)
    private String loginUser;

    @Column(name = "LOGIN_PASSWORD", length = 60)
    private String loginPassword;

    @Column(name = "RESULT_STATUS", length = 60)
    private String resultStatus;

    public CCourtFirstResults getResultStatus() {
        return resultStatus == null ? null : CCourtFirstResults.fromId(resultStatus);
    }

    public void setResultStatus(CCourtFirstResults resultStatus) {
        this.resultStatus = resultStatus == null ? null : resultStatus.getId();
    }

    public String getLoginPassword() {
        return loginPassword;
    }

    public void setLoginPassword(String loginPassword) {
        this.loginPassword = loginPassword;
    }

    public String getLoginUser() {
        return loginUser;
    }

    public void setLoginUser(String loginUser) {
        this.loginUser = loginUser;
    }

    public String getDefandantName() {
        return defandantName;
    }

    public void setDefandantName(String defandantName) {
        this.defandantName = defandantName;
    }

    public String getJudgeName() {
        return judgeName;
    }

    public void setJudgeName(String judgeName) {
        this.judgeName = judgeName;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDate registrationDate) {
        this.registrationDate = registrationDate;
    }

    public LocalDate getLastStatusDate() {
        return lastStatusDate;
    }

    public void setLastStatusDate(LocalDate lastStatusDate) {
        this.lastStatusDate = lastStatusDate;
    }

    public CCourtCaseStage getLastStatus() {
        return lastStatus == null ? null : CCourtCaseStage.fromId(lastStatus);
    }

    public void setLastStatus(CCourtCaseStage lastStatus) {
        this.lastStatus = lastStatus == null ? null : lastStatus.getId();
    }

    public String getCaseNumberFirstInstans() {
        return caseNumberFirstInstans;
    }

    public void setCaseNumberFirstInstans(String caseNumberFirstInstans) {
        this.caseNumberFirstInstans = caseNumberFirstInstans;
    }

    @PrePersist
    public void prePersist() {
        setLastStatus(getCourtCase().getCaseStatus());
        setLastStatusDate(getCourtCase().getStatusDate());
    }
}