package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@JmixEntity
@Entity(name = "prx_BCourtConsolidatedCases")
public class BCourtConsolidatedCases extends BCourtCaseEventTable implements BaseUuidEntity {
    @JoinColumn(name = "CONSOLIDATE_WITH_CASE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private BCourtCase consolidateWithCase;

    @Column(name = "LAST_STATUS")
    private String lastStatus;

    @Column(name = "LAST_STATUS_DATE")
    private LocalDate lastStatusDate;

    @Column(name = "CONSOLIDATION_NOTE")
    @Lob
    private String consolidationNote;

    @Column(name = "FINAL_SUBJECT")
    @Lob
    private String finalSubject;

    @Column(name = "TOTAL_DEBT", precision = 19, scale = 2)
    private BigDecimal totalDebt;

    @Column(name = "NOTE")
    @Lob
    private String note;

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public BigDecimal getTotalDebt() {
        return totalDebt;
    }

    public void setTotalDebt(BigDecimal totalDebt) {
        this.totalDebt = totalDebt;
    }

    public String getFinalSubject() {
        return finalSubject;
    }

    public void setFinalSubject(String finalSubject) {
        this.finalSubject = finalSubject;
    }

    public String getConsolidationNote() {
        return consolidationNote;
    }

    public void setConsolidationNote(String consolidationNote) {
        this.consolidationNote = consolidationNote;
    }

    public LocalDate getLastStatusDate() {
        return lastStatusDate;
    }

    public void setLastStatusDate(LocalDate lastStatusDate) {
        this.lastStatusDate = lastStatusDate;
    }

    public CCourtCaseStage getLastStatus() {
        return lastStatus == null ? null : CCourtCaseStage.fromId(lastStatus);
    }

    public void setLastStatus(CCourtCaseStage lastStatus) {
        this.lastStatus = lastStatus == null ? null : lastStatus.getId();
    }

    public BCourtCase getConsolidateWithCase() {
        return consolidateWithCase;
    }

    public void setConsolidateWithCase(BCourtCase consolidateWithCase) {
        this.consolidateWithCase = consolidateWithCase;
    }

    @PrePersist
    public void prePersist() {
        setLastStatus(getCourtCase().getCaseStatus());
        setLastStatusDate(getCourtCase().getStatusDate());
    }
}