package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.core.DeletePolicy;
import io.jmix.core.entity.annotation.OnDelete;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@JmixEntity
@Entity(name = "prx_BCourtDocumentPreparation")
public class BCourtDocumentPreparation extends BCourtCaseEventTable implements BaseUuidEntity {
    @Column(name = "DOCUMENT_TEMPLATE", length = 100)
    private String documentTemplate;

    @Column(name = "LAST_STATUS")
    private String lastStatus;

    @Column(name = "LAST_STATUS_DATE")
    private LocalDate lastStatusDate;

    @Column(name = "COURT_NAME")
    private String courtName;

    @Column(name = "COURT_ADDRESS")
    private String courtAddress;

    @JoinColumn(name = "SIGNATORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtLawyer signatory;

    @JoinColumn(name = "CONTACT_PERSON_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtLawyer contactPerson;

    @Column(name = "APPENDICES_NAME")
    @Lob
    private String appendicesName;

    @Column(name = "DOC_NUM_TELDOC", length = 60)
    private String docNumTeldoc;

    @Column(name = "SENT_DATE_TO_COURT")
    private LocalDate sentDateToCourt;

    @OnDelete(DeletePolicy.CASCADE)
    @Composition
    @OneToMany(mappedBy = "bCourtDocumentPreparation")
    private List<BCourtDocumentPreparationParty> line;

    public List<BCourtDocumentPreparationParty> getLine() {
        return line;
    }

    public void setLine(List<BCourtDocumentPreparationParty> line) {
        this.line = line;
    }

    public LocalDate getSentDateToCourt() {
        return sentDateToCourt;
    }

    public void setSentDateToCourt(LocalDate sentDateToCourt) {
        this.sentDateToCourt = sentDateToCourt;
    }

    public String getDocNumTeldoc() {
        return docNumTeldoc;
    }

    public void setDocNumTeldoc(String docNumTeldoc) {
        this.docNumTeldoc = docNumTeldoc;
    }

    public String getAppendicesName() {
        return appendicesName;
    }

    public void setAppendicesName(String appendicesName) {
        this.appendicesName = appendicesName;
    }

    public CCourtLawyer getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(CCourtLawyer contactPerson) {
        this.contactPerson = contactPerson;
    }

    public CCourtLawyer getSignatory() {
        return signatory;
    }

    public void setSignatory(CCourtLawyer signatory) {
        this.signatory = signatory;
    }

    public String getCourtAddress() {
        return courtAddress;
    }

    public void setCourtAddress(String courtAddress) {
        this.courtAddress = courtAddress;
    }

    public String getCourtName() {
        return courtName;
    }

    public void setCourtName(String courtName) {
        this.courtName = courtName;
    }

    public LocalDate getLastStatusDate() {
        return lastStatusDate;
    }

    public void setLastStatusDate(LocalDate lastStatusDate) {
        this.lastStatusDate = lastStatusDate;
    }

    public CCourtCaseStage getLastStatus() {
        return lastStatus == null ? null : CCourtCaseStage.fromId(lastStatus);
    }

    public void setLastStatus(CCourtCaseStage lastStatus) {
        this.lastStatus = lastStatus == null ? null : lastStatus.getId();
    }

    public CCourtDocumentTemplate getDocumentTemplate() {
        return documentTemplate == null ? null : CCourtDocumentTemplate.fromId(documentTemplate);
    }

    public void setDocumentTemplate(CCourtDocumentTemplate documentTemplate) {
        this.documentTemplate = documentTemplate == null ? null : documentTemplate.getId();
    }

    @PrePersist
    public void prePersist() {
        setLastStatus(getCourtCase().getCaseStatus());
        setLastStatusDate(getCourtCase().getStatusDate());
    }
}