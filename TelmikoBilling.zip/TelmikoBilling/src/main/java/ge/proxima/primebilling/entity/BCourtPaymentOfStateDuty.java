package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@JmixEntity
@Entity(name = "prx_BCourtPaymentOfStateDuty")
public class BCourtPaymentOfStateDuty extends BCourtCaseEventTable implements BaseUuidEntity {
    @JoinColumn(name = "TRANSACTION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtCaseDutyTransactions transaction;

    @Column(name = "LAST_STATUS")
    private String lastStatus;

    @Column(name = "LAST_STATUS_DATE")
    private LocalDate lastStatusDate;

    @Column(name = "TRANSACTION_OTHER_NOTE")
    private String transactionOtherNote;

    @Column(name = "PAYER_NAME")
    private String payerName;

    @Column(name = "DEFENDANT_NAME")
    private String defendantName;

    @Column(name = "DEFENDANT_NUMBER", length = 60)
    private String defendantNumber;

    @Column(name = "CLAIM_AMOUNT", precision = 19, scale = 2)
    private BigDecimal claimAmount;

    @Column(name = "DUTY_AMOUNT", precision = 19, scale = 2)
    private BigDecimal dutyAmount;

    @Column(name = "PAYMENT_STATUS")
    private String paymentStatus;

    public void setPaymentStatus(CCourtPayStatus paymentStatus) {
        this.paymentStatus = paymentStatus == null ? null : paymentStatus.getId();
    }

    public CCourtPayStatus getPaymentStatus() {
        return paymentStatus == null ? null : CCourtPayStatus.fromId(paymentStatus);
    }

    public BigDecimal getDutyAmount() {
        return dutyAmount;
    }

    public void setDutyAmount(BigDecimal dutyAmount) {
        this.dutyAmount = dutyAmount;
    }

    public BigDecimal getClaimAmount() {
        return claimAmount;
    }

    public void setClaimAmount(BigDecimal claimAmount) {
        this.claimAmount = claimAmount;
    }

    public String getDefendantNumber() {
        return defendantNumber;
    }

    public void setDefendantNumber(String defendantNumber) {
        this.defendantNumber = defendantNumber;
    }

    public String getDefendantName() {
        return defendantName;
    }

    public void setDefendantName(String defendantName) {
        this.defendantName = defendantName;
    }

    public String getPayerName() {
        return payerName;
    }

    public void setPayerName(String payerName) {
        this.payerName = payerName;
    }

    public String getTransactionOtherNote() {
        return transactionOtherNote;
    }

    public void setTransactionOtherNote(String transactionOtherNote) {
        this.transactionOtherNote = transactionOtherNote;
    }

    public LocalDate getLastStatusDate() {
        return lastStatusDate;
    }

    public void setLastStatusDate(LocalDate lastStatusDate) {
        this.lastStatusDate = lastStatusDate;
    }

    public CCourtCaseStage getLastStatus() {
        return lastStatus == null ? null : CCourtCaseStage.fromId(lastStatus);
    }

    public void setLastStatus(CCourtCaseStage lastStatus) {
        this.lastStatus = lastStatus == null ? null : lastStatus.getId();
    }

    public CCourtCaseDutyTransactions getTransaction() {
        return transaction;
    }

    public void setTransaction(CCourtCaseDutyTransactions transaction) {
        this.transaction = transaction;
    }

    @PrePersist
    public void prePersist() {
        setLastStatus(getCourtCase().getCaseStatus());
        setLastStatusDate(getCourtCase().getStatusDate());
    }
}