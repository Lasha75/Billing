package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.PrePersist;
import java.time.LocalDate;

@JmixEntity
@Entity(name = "prx_BCourtPrivateComplaint")
public class BCourtPrivateComplaint extends BCourtCaseEventTable implements BaseUuidEntity {
    @Column(name = "DATE_SUBMISSION")
    private LocalDate dateSubmission;

    @Column(name = "LAST_STATUS")
    private String lastStatus;

    @Column(name = "LAST_STATUS_DATE")
    private LocalDate lastStatusDate;

    @Column(name = "DATE_REGISTRATION")
    private LocalDate dateRegistration;

    @Column(name = "DECISION_WHICH_APPEALED")
    @Lob
    private String decisionWhichAppealed;

    @Column(name = "SUBJECT_OF_APPEAL")
    @Lob
    private String subjectOfAppeal;

    @Column(name = "RESULT_OF_APPEAL")
    @Lob
    private String resultOfAppeal;

    @Column(name = "NOTE")
    @Lob
    private String note;

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getResultOfAppeal() {
        return resultOfAppeal;
    }

    public void setResultOfAppeal(String resultOfAppeal) {
        this.resultOfAppeal = resultOfAppeal;
    }

    public String getSubjectOfAppeal() {
        return subjectOfAppeal;
    }

    public void setSubjectOfAppeal(String subjectOfAppeal) {
        this.subjectOfAppeal = subjectOfAppeal;
    }

    public String getDecisionWhichAppealed() {
        return decisionWhichAppealed;
    }

    public void setDecisionWhichAppealed(String decisionWhichAppealed) {
        this.decisionWhichAppealed = decisionWhichAppealed;
    }

    public LocalDate getDateRegistration() {
        return dateRegistration;
    }

    public void setDateRegistration(LocalDate dateRegistration) {
        this.dateRegistration = dateRegistration;
    }

    public LocalDate getLastStatusDate() {
        return lastStatusDate;
    }

    public void setLastStatusDate(LocalDate lastStatusDate) {
        this.lastStatusDate = lastStatusDate;
    }

    public CCourtCaseStage getLastStatus() {
        return lastStatus == null ? null : CCourtCaseStage.fromId(lastStatus);
    }

    public void setLastStatus(CCourtCaseStage lastStatus) {
        this.lastStatus = lastStatus == null ? null : lastStatus.getId();
    }

    public LocalDate getDateSubmission() {
        return dateSubmission;
    }

    public void setDateSubmission(LocalDate dateSubmission) {
        this.dateSubmission = dateSubmission;
    }

    @PrePersist
    public void prePersist() {
        setLastStatus(getCourtCase().getCaseStatus());
        setLastStatusDate(getCourtCase().getStatusDate());
    }
}