package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.deposit.BankGuarantee;
import io.jmix.audit.snapshot.EntitySnapshotManager;
import io.jmix.core.event.EntityChangedEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

@Component("prx_BankGuaranteeEventListener")
public class BankGuaranteeEventListener {


    @EventListener
    public void onBankGuaranteeChangedBeforeCommit(EntityChangedEvent<BankGuarantee> event) {

    }

    @TransactionalEventListener
    public void onBankGuaranteeChangedAfterCommit(EntityChangedEvent<BankGuarantee> event) {

    }
}