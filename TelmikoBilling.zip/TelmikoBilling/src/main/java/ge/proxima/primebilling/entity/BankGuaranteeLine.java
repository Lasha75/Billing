package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.deposit.BankGuarantee;
import ge.proxima.primebilling.entity.transactions.Transaction;
import io.jmix.core.DeletePolicy;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDelete;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_BANK_GUARANTEE_LINE", indexes = {
        @Index(name = "IDX_PRX_BANK_GUARANTEE_LINE_CUSTOMER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRX_BANK_GUARANTEE_LINE_BANK_GUARANTEE", columnList = "BANK_GUARANTEE_ID"),
        @Index(name = "IDX_PRX_BANK_GUARANTEE_LINE_TRANSACTION", columnList = "TRANSACTION_ID")
})
@Entity(name = "prx_BankGuaranteeLine")
public class BankGuaranteeLine {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @NotNull
    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @OnDeleteInverse(DeletePolicy.CASCADE)
    @JoinColumn(name = "BANK_GUARANTEE_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private BankGuarantee bankGuarantee;

    @OnDelete(DeletePolicy.DENY)
    @JoinColumn(name = "TRANSACTION_ID")
    @OneToOne(fetch = FetchType.LAZY)
    private Transaction transaction;

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public BankGuarantee getBankGuarantee() {
        return bankGuarantee;
    }

    public void setBankGuarantee(BankGuarantee bankGuarantee) {
        this.bankGuarantee = bankGuarantee;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"bankGuarantee", "customer", "amount"})
    public String getInstanceName() {
        return String.format("%s %s %s", bankGuarantee, customer.getInstanceName(), amount);
    }

}