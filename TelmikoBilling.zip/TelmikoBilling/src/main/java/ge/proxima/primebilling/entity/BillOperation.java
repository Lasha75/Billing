package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.counter.Counter;
import ge.proxima.primebilling.entity.customer.Customer;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_BILL_OPERATION", indexes = {
        @Index(name = "IDX_PRXBILLOPERATION_CUSTOMER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRX_BILL_OPERATION_COUNTER", columnList = "COUNTER_ID")
})
@Entity(name = "prx_BillOperation")
public class BillOperation {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "ORDER_LEVEL")
    private Integer orderLevel;

    @JoinColumn(name = "COUNTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Counter counter;

    @Column(name = "IN_TEL_DOC")
    private Boolean inTelDoc;

    @Column(name = "GENERATION_ID", length = 100)
    private String generationId;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "COUNTER_NUMBER", length = 30)
    private String counterNumber;

    @Column(name = "OPERATION_TEXT", length = 100)
    private String operationText;

    @Column(name = "OPERATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date operationDate;

    @Column(name = "COUNTER_READING", precision = 19, scale = 2)
    private BigDecimal counterReading;

    @Column(name = "KWT", precision = 19, scale = 2)
    private BigDecimal kwt;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "IS_SUM")
    private Boolean isSum;

    @Column(name = "CANCELED")
    private Boolean canceled;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    public Integer getOrderLevel() {
        return orderLevel;
    }

    public void setOrderLevel(Integer orderLevel) {
        this.orderLevel = orderLevel;
    }

    public Counter getCounter() {
        return counter;
    }

    public void setCounter(Counter counter) {
        this.counter = counter;
    }

    public Boolean getInTelDoc() {
        return inTelDoc;
    }

    public void setInTelDoc(Boolean inTelDoc) {
        this.inTelDoc = inTelDoc;
    }

    public Boolean getCanceled() {
        return canceled;
    }

    public void setCanceled(Boolean canceled) {
        this.canceled = canceled;
    }

    public Boolean getIsSum() {
        return isSum;
    }

    public void setIsSum(Boolean isSum) {
        this.isSum = isSum;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getKwt() {
        return kwt;
    }

    public void setKwt(BigDecimal kwt) {
        this.kwt = kwt;
    }

    public BigDecimal getCounterReading() {
        return counterReading;
    }

    public void setCounterReading(BigDecimal counterReading) {
        this.counterReading = counterReading;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public String getOperationText() {
        return operationText;
    }

    public void setOperationText(String operationText) {
        this.operationText = operationText;
    }

    public String getCounterNumber() {
        return counterNumber;
    }

    public void setCounterNumber(String counterNumber) {
        this.counterNumber = counterNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getGenerationId() {
        return generationId;
    }

    public void setGenerationId(String generationId) {
        this.generationId = generationId;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}