package ge.proxima.primebilling.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.NumberFormat;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_BILL_TARIFF_LINE", indexes = {
        @Index(name = "IDX_PRXBILLTARIFFLI_BILLTARIFF", columnList = "BILL_TARIFF_ID")
})
@Entity(name = "prx_BillTariffLine")
public class BillTariffLine {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "TARIFF_TYPE")
    private String tariffType;

    @JoinColumn(name = "BILL_TARIFF_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private BillTariff billTariff;

    @Column(name = "START_KILOWATT", precision = 19, scale = 8)
    private BigDecimal startKilowatt;

    @Column(name = "END_KILOWATT", precision = 19, scale = 8)
    private BigDecimal endKilowatt;

    @NumberFormat(pattern = "#,##0.0000000", decimalSeparator = ".", groupingSeparator = ",")
    @Column(name = "VALUE_", precision = 19, scale = 8)
    private BigDecimal value;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    public BillTariffType getTariffType() {
        return tariffType == null ? null : BillTariffType.fromId(tariffType);
    }

    public void setTariffType(BillTariffType tariffType) {
        this.tariffType = tariffType == null ? null : tariffType.getId();
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public BigDecimal getEndKilowatt() {
        return endKilowatt;
    }

    public void setEndKilowatt(BigDecimal endKilowatt) {
        this.endKilowatt = endKilowatt;
    }

    public BigDecimal getStartKilowatt() {
        return startKilowatt;
    }

    public void setStartKilowatt(BigDecimal startKilowatt) {
        this.startKilowatt = startKilowatt;
    }

    public BillTariff getBillTariff() {
        return billTariff;
    }

    public void setBillTariff(BillTariff billTariff) {
        this.billTariff = billTariff;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}