package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum BillTariffType implements EnumClass<String> {

    DELIVERY("DELIVERY"),
    DISTRIBUTION("DISTRIBUTION"),
    TRANSFER("TRANSFER");

    private String id;

    BillTariffType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static BillTariffType fromId(String id) {
        for (BillTariffType at : BillTariffType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}