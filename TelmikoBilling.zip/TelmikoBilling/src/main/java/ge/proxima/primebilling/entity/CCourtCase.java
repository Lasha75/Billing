package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.court.PreCourtWork;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.customer.setup.GiveType;
import ge.proxima.primebilling.entity.reftables.Activity;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.numerator.NumeratorService;
import io.jmix.core.DeletePolicy;
import io.jmix.core.Messages;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDelete;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.UUID;


@JmixEntity
@Table(name = "PRX_C_COURT_CASE", indexes = {
        @Index(name = "IDX_PRX_C_COURT_CASE_ASSIGNE_TO", columnList = "ASSIGNE_TO_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_CUSTOMER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_CATEGORY", columnList = "CATEGORY_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_ACTIVITY", columnList = "ACTIVITY_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_SUPPLY_TYPE", columnList = "SUPPLY_TYPE_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_LAWAYER", columnList = "LAWAYER_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_CONSOLIDATE_WITH_CASE", columnList = "CONSOLIDATE_WITH_CASE_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE", columnList = "CASE_NUMBER, DELETED_DATE, ID")
})
@Entity(name = "prx_CCourtCase")
public class CCourtCase implements BaseUuidEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @Column(name = "CASE_NUMBER", nullable = false, length = 60)
    @NotNull
    private String caseNumber;

    @JoinColumn(name = "CONSOLIDATE_WITH_CASE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtCase consolidateWithCase;

    @Column(name = "CASE_STATUS")
    private String caseStatus;

    @Column(name = "STATUS_DATE")
    private LocalDate statusDate;

    @Column(name = "DEAD_LINE_DATE")
    private LocalDate deadLineDate;

    @Column(name = "CASE_NUMBER_FIRST_INSTANS", length = 60)
    private String caseNumberFirstInstans;

    @Column(name = "CASE_NUMBER_APPEAL", length = 60)
    private String caseNumberAppeal;

    @Column(name = "CASE_NUMBER_CASSATION", length = 60)
    private String caseNumberCassation;

    @Column(name = "CASE_NUMBER_ENFORCEMENT", length = 60)
    private String caseNumberEnforcement;

    @Column(name = "DEBT", precision = 19, scale = 2)
    private BigDecimal debt;

    @Column(name = "DEBT_PERIOD", length = 60)
    private String debtPeriod;

    @Column(name = "CURRENT_DEBT", precision = 19, scale = 2)
    private BigDecimal currentDebt;

    @Column(name = "EFFECTIVE_DATE")
    private LocalDate effectiveDate;

    @JoinColumn(name = "ASSIGNE_TO_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private User assigneTo;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "LAWAYER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtLawyer lawayer;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory category;

    @JoinColumn(name = "ACTIVITY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Activity activity;

    @JoinColumn(name = "SUPPLY_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private GiveType supplyType;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "IDENTIFICATION_NUMBER", length = 60)
    private String identificationNumber;

    @Column(name = "CADASTRAL_CODE", length = 100)
    private String cadastralCode;

    @Column(name = "IS_RESTRUCTURISATION")
    private Boolean isRestructurisation;

    @Column(name = "TOTAL_DEBT", precision = 19, scale = 2)
    private BigDecimal totalDebt;

    @Column(name = "TOTAL_DEBT_PERIOD")
    private String totalDebtPeriod;

    @OnDeleteInverse(DeletePolicy.UNLINK)
    @OnDelete(DeletePolicy.DENY)
    @Composition
    @OneToMany(mappedBy = "courtCase")
    private List<CCourtCaseEventTable> caseEvent;

    @Column(name = "NOTE")
    private String note;

    public String getTotalDebtPeriod() {
        return totalDebtPeriod;
    }

    public void setTotalDebtPeriod(String totalDebtPeriod) {
        this.totalDebtPeriod = totalDebtPeriod;
    }

    public BigDecimal getTotalDebt() {
        return totalDebt;
    }

    public void setTotalDebt(BigDecimal totalDebt) {
        this.totalDebt = totalDebt;
    }

    public CCourtCase getConsolidateWithCase() {
        return consolidateWithCase;
    }

    public void setConsolidateWithCase(CCourtCase consolidateWithCase) {
        this.consolidateWithCase = consolidateWithCase;
    }

    public CCourtLawyer getLawayer() {
        return lawayer;
    }

    public void setLawayer(CCourtLawyer lawayer) {
        this.lawayer = lawayer;
    }

    public String getCaseNumberEnforcement() {
        return caseNumberEnforcement;
    }

    public void setCaseNumberEnforcement(String caseNumberEnforcement) {
        this.caseNumberEnforcement = caseNumberEnforcement;
    }

    public List<CCourtCaseEventTable> getCaseEvent() {
        return caseEvent;
    }

    public void setCaseEvent(List<CCourtCaseEventTable> caseEvent) {
        this.caseEvent = caseEvent;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Boolean getIsRestructurisation() {
        return isRestructurisation;
    }

    public void setIsRestructurisation(Boolean isRestructurisation) {
        this.isRestructurisation = isRestructurisation;
    }

    public String getCadastralCode() {
        return cadastralCode;
    }

    public void setCadastralCode(String cadastralCode) {
        this.cadastralCode = cadastralCode;
    }

    public String getIdentificationNumber() {
        return identificationNumber;
    }

    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public GiveType getSupplyType() {
        return supplyType;
    }

    public void setSupplyType(GiveType supplyType) {
        this.supplyType = supplyType;
    }

    public Activity getActivity() {
        return activity;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public CustomerCategory getCategory() {
        return category;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public User getAssigneTo() {
        return assigneTo;
    }

    public void setAssigneTo(User assigneTo) {
        this.assigneTo = assigneTo;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public BigDecimal getCurrentDebt() {
        return currentDebt;
    }

    public void setCurrentDebt(BigDecimal currentDebt) {
        this.currentDebt = currentDebt;
    }

    public String getDebtPeriod() {
        return debtPeriod;
    }

    public void setDebtPeriod(String debtPeriod) {
        this.debtPeriod = debtPeriod;
    }

    public BigDecimal getDebt() {
        return debt;
    }

    public void setDebt(BigDecimal debt) {
        this.debt = debt;
    }

    public String getCaseNumberCassation() {
        return caseNumberCassation;
    }

    public void setCaseNumberCassation(String caseNumberCassation) {
        this.caseNumberCassation = caseNumberCassation;
    }

    public String getCaseNumberAppeal() {
        return caseNumberAppeal;
    }

    public void setCaseNumberAppeal(String caseNumberAppeal) {
        this.caseNumberAppeal = caseNumberAppeal;
    }

    public String getCaseNumberFirstInstans() {
        return caseNumberFirstInstans;
    }

    public void setCaseNumberFirstInstans(String caseNumberFirstInstans) {
        this.caseNumberFirstInstans = caseNumberFirstInstans;
    }

    public LocalDate getDeadLineDate() {
        return deadLineDate;
    }

    public void setDeadLineDate(LocalDate deadLineDate) {
        this.deadLineDate = deadLineDate;
    }

    public LocalDate getStatusDate() {
        return statusDate;
    }

    public void setStatusDate(LocalDate statusDate) {
        this.statusDate = statusDate;
    }

    public CCourtCaseStage getCaseStatus() {
        return caseStatus == null ? null : CCourtCaseStage.fromId(caseStatus);
    }

    public void setCaseStatus(CCourtCaseStage caseStatus) {
        this.caseStatus = caseStatus == null ? null : caseStatus.getId();
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"caseNumber", "caseStatus", "customer"})
    public String getInstanceName() {
        Messages  messages= AppBeans.getBean(Messages.class);
        return String.format("%s %s %s", caseNumber, messages.getMessage(getCaseStatus()), customer.getCustomerNumber());
    }

    @PostConstruct
    public void postConstruct() {
        NumeratorService numeratorService = AppBeans.getBean(NumeratorService.class);
        if(getCaseNumber()==null) {
            setCaseNumber(
                    numeratorService.getNumSeq(PreCourtWork.class)
            );
        }
    }
}