package ge.proxima.primebilling.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_C_COURT_CASE_DUTY_TRANSACTIONS")
@Entity(name = "prx_CCourtCaseDutyTransactions")
public class CCourtCaseDutyTransactions {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @InstanceName
    @Column(name = "NAME", nullable = false)
    @NotNull
    private String name;

    @Column(name = "MIN_AMOUNT", precision = 19, scale = 2)
    private BigDecimal minAmount;

    @Column(name = "MAX_AMOUNT", precision = 19, scale = 2)
    private BigDecimal maxAmount;

    @Column(name = "MULTIPLY_BY", precision = 19, scale = 2)
    private BigDecimal multiplyBy;

    @Column(name = "ADDITIONAL_NOTE")
    private Boolean additionalNote;

    public Boolean getAdditionalNote() {
        return additionalNote;
    }

    public void setAdditionalNote(Boolean additionalNote) {
        this.additionalNote = additionalNote;
    }

    public BigDecimal getMultiplyBy() {
        return multiplyBy;
    }

    public void setMultiplyBy(BigDecimal multiplyBy) {
        this.multiplyBy = multiplyBy;
    }

    public BigDecimal getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(BigDecimal maxAmount) {
        this.maxAmount = maxAmount;
    }

    public BigDecimal getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(BigDecimal minAmount) {
        this.minAmount = minAmount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}