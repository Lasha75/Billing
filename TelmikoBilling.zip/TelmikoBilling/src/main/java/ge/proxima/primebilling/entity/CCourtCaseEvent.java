package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtCaseEvent implements EnumClass<String> {

    RETURNPRETRIALPROCEEDINGS("ReturnPreTrialProceedings"),
    PAYMENTOFSTATEDUTY("PaymentOfStateDuty"),
    PREPARATIONDOCUMENTSFORSUBMISSION("PreparationDocumentsForsubmission"),
    CONSOLIDATEDCASES("ConsolidatedCases"),
    CONSIDERATIONFIRSTINSTANCE("ConsiderationFirstInstance"),
    COURTSESSION("CourtSession"),
    RESOLUTIONISSUEDFIRSTINSTANCE("ResolutionIssuedFirstInstance"),
    APPEALPROCEEDINGS("AppealProceedings"),
    DECISIONAPPEAL("DecisionAppeal"),
    CASSATIONPROCEEDINGS("CassationProceedings"),
    DECISIONCASSATION("DecisionCassation"),
    ENFORCEMENTPROCEEDINGS("EnforcementProceedings"),
    PRIVATECOMPLAINT("PrivateComplaint");

    private String id;

    CCourtCaseEvent(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtCaseEvent fromId(String id) {
        for (CCourtCaseEvent at : CCourtCaseEvent.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}