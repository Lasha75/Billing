package ge.proxima.primebilling.entity;

import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_C_COURT_CASE_EVENT_TABLE", indexes = {
        @Index(name = "IDX_PRX_C_COURT_CASE_EVENT_TABLE_COURT_CASE", columnList = "COURT_CASE_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_EVENT_TABLE_TRANSACTION", columnList = "TRANSACTION_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_EVENT_TABLE_CUSTOMER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_EVENT_TABLE_RESULT", columnList = "RESULT_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_EVENT_TABLE_SIGNATORY", columnList = "SIGNATORY_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_EVENT_TABLE_CONTACT_PERSON", columnList = "CONTACT_PERSON_ID"),
        @Index(name = "IDX_PRX_C_COURT_CASE_EVENT_TABLE_CONSOLIDATE_WITH_CASE", columnList = "CONSOLIDATE_WITH_CASE_ID"),
        @Index(name = "IDX_PRXCCOURTCASEEVENTT_STATUS", columnList = "STATUS_ID"),
        @Index(name = "IDX_PRXCCOURTCASEEVEN_CATEGORY", columnList = "CATEGORY_ID")
})
@Entity(name = "prx_CCourtCaseEventTable")
public class CCourtCaseEventTable {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @Column(name = "EVENT", length = 100)
    private String event;

    @JoinColumn(name = "COURT_CASE_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private CCourtCase courtCase;

    public CCourtCase getCourtCase() {
        return courtCase;
    }

    public void setCourtCase(CCourtCase courtCase) {
        this.courtCase = courtCase;
    }

    public CCourtCaseEvent getEvent() {
        return event == null ? null : CCourtCaseEvent.fromId(event);
    }

    public void setEvent(CCourtCaseEvent event) {
        this.event = event == null ? null : event.getId();
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}