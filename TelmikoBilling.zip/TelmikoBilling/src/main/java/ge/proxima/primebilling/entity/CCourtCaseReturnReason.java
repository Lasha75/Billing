package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtCaseReturnReason implements EnumClass<String> {

    INCOMPLETEDOCUMENTATION("IncompleteDocumentation"),
    NOTIDENTIFIED("NotIdentified"),
    LESSTHAN300GEL("LessThan300GEL"),
    DEBTPAIDBEFORE("DebtPaidBefore"),
    OTHER("Other");

    private String id;

    CCourtCaseReturnReason(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtCaseReturnReason fromId(String id) {
        for (CCourtCaseReturnReason at : CCourtCaseReturnReason.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}