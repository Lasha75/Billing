package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtCaseStage implements EnumClass<String> {

    NEW("New"),
    INPROGRESS("InProgress"),
    CASESENTTOCOURT("CaseSentToCourt"),
    CONSIDERATIONFIRSTINSTANCE("ConsiderationFirstInstance"),
    RESOLUTIONISSUEDFIRSTINSTANCE("ResolutionIssuedFirstInstance"),
    RESOLUTIONISSUED("ResolutionIssued"),
    APPEALPROCEEDINGS("AppealProceedings"),
    RESOLUTIONISSUEDAPPEAL("ResolutionIssuedAppeal"),
    CASSATIONPROCEEDING("CassationProceeding"),
    RESOLUTIONISSUEDCASSATION("ResolutionIssuedCassation"),
    ENFORCEMENTPROCEEDINGS("EnforcementProceedings"),
    RETURNPRETRIALPROCEEDINGS("ReturnPreTrialProceedings"),
    CONSOLIDATEDCASES("ConsolidatedCases");

    private String id;

    CCourtCaseStage(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtCaseStage fromId(String id) {
        for (CCourtCaseStage at : CCourtCaseStage.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}