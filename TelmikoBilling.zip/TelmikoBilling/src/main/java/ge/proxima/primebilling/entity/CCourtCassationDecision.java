package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@JmixEntity
@Entity(name = "prx_CCourtCassationDecision")
public class CCourtCassationDecision extends CCourtCaseEventTable implements BaseUuidEntity {
    @Column(name = "CASE_NUMBER_CASSATION", length = 60)
    private String caseNumberCassation;

    @Column(name = "LAST_STATUS")
    private String lastStatus;

    @Column(name = "LAST_STATUS_DATE")
    private LocalDate lastStatusDate;

    @Column(name = "RESOLUTION_DATE")
    private LocalDate resolutionDate;

    @Column(name = "RESOLUTION_TYPE", length = 60)
    private String resolutionType;

    @JoinColumn(name = "RESULT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtResolutionMapping result;

    @Column(name = "OTHER_RESULT")
    @Lob
    private String otherResult;

    @Column(name = "DEBT_BY_ACT", precision = 19, scale = 2)
    private BigDecimal debtByAct;

    @Column(name = "DUTY_BY_ACT", precision = 19, scale = 2)
    private BigDecimal dutyByAct;

    @Column(name = "MAIN_AMOUNT_REJECTED", precision = 19, scale = 2)
    private BigDecimal mainAmountRejected;

    @Column(name = "DUTY_AMOUNT_REJECTED", precision = 19, scale = 2)
    private BigDecimal dutyAmountRejected;

    @Column(name = "EFFECTIVE_DATE")
    private LocalDate effectiveDate;

    @Column(name = "NOTE")
    private String note;

    public String getOtherResult() {
        return otherResult;
    }

    public void setOtherResult(String otherResult) {
        this.otherResult = otherResult;
    }

    public LocalDate getLastStatusDate() {
        return lastStatusDate;
    }

    public void setLastStatusDate(LocalDate lastStatusDate) {
        this.lastStatusDate = lastStatusDate;
    }

    public CCourtCaseStage getLastStatus() {
        return lastStatus == null ? null : CCourtCaseStage.fromId(lastStatus);
    }

    public void setLastStatus(CCourtCaseStage lastStatus) {
        this.lastStatus = lastStatus == null ? null : lastStatus.getId();
    }

    public void setResolutionType(CCourtResolutionType resolutionType) {
        this.resolutionType = resolutionType == null ? null : resolutionType.getId();
    }

    public CCourtResolutionType getResolutionType() {
        return resolutionType == null ? null : CCourtResolutionType.fromId(resolutionType);
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public BigDecimal getDutyAmountRejected() {
        return dutyAmountRejected;
    }

    public void setDutyAmountRejected(BigDecimal dutyAmountRejected) {
        this.dutyAmountRejected = dutyAmountRejected;
    }

    public BigDecimal getMainAmountRejected() {
        return mainAmountRejected;
    }

    public void setMainAmountRejected(BigDecimal mainAmountRejected) {
        this.mainAmountRejected = mainAmountRejected;
    }

    public BigDecimal getDutyByAct() {
        return dutyByAct;
    }

    public void setDutyByAct(BigDecimal dutyByAct) {
        this.dutyByAct = dutyByAct;
    }

    public BigDecimal getDebtByAct() {
        return debtByAct;
    }

    public void setDebtByAct(BigDecimal debtByAct) {
        this.debtByAct = debtByAct;
    }

    public CCourtResolutionMapping getResult() {
        return result;
    }

    public void setResult(CCourtResolutionMapping result) {
        this.result = result;
    }

    public LocalDate getResolutionDate() {
        return resolutionDate;
    }

    public void setResolutionDate(LocalDate resolutionDate) {
        this.resolutionDate = resolutionDate;
    }

    public String getCaseNumberCassation() {
        return caseNumberCassation;
    }

    public void setCaseNumberCassation(String caseNumberCassation) {
        this.caseNumberCassation = caseNumberCassation;
    }

    @PrePersist
    public void prePersist() {
        setLastStatus(getCourtCase().getCaseStatus());
        setLastStatusDate(getCourtCase().getStatusDate());
    }
}