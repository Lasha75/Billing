package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtDocumentTemplate implements EnumClass<String> {

    CLAIMSTATEMENT("CLAIMSTATEMENT"),
    APPELLATECOMPLAINT("APPELLATECOMPLAINT"),
    CASSATIONCOMPLAINT("CASSATIONCOMPLAINT"),
    EXECUTIONREQUEST("EXECUTIONREQUEST"),
    INTERIMMEASURES("INTERIMMEASURES"),
    FREEAPPLICATIONFORM("FREEAPPLICATIONFORM");




    private String id;

    CCourtDocumentTemplate(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtDocumentTemplate fromId(String id) {
        for (CCourtDocumentTemplate at : CCourtDocumentTemplate.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}