package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtDutyPayStatus implements EnumClass<String> {

    ;

    private String id;

    CCourtDutyPayStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtDutyPayStatus fromId(String id) {
        for (CCourtDutyPayStatus at : CCourtDutyPayStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}