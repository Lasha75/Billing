package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.PrePersist;
import java.math.BigDecimal;
import java.time.LocalDate;

@JmixEntity
@Entity(name = "prx_CCourtEnforceProceedings")
public class CCourtEnforceProceedings extends CCourtCaseEventTable implements BaseUuidEntity {
    @Column(name = "CASE_NUMBER_ENFORCE")
    private String caseNumberEnforce;

    @Column(name = "REQUEST_DATE")
    private LocalDate requestDate;

    @Column(name = "LAST_STATUS")
    private String lastStatus;

    @Column(name = "LAST_STATUS_DATE")
    private LocalDate lastStatusDate;

    @Column(name = "RECEIPT_DATE")
    private LocalDate receiptDate;

    @Column(name = "DEBT_BY_ACT", precision = 19, scale = 2)
    private BigDecimal debtByAct;

    @Column(name = "DUTY_BY_ACT", precision = 19, scale = 2)
    private BigDecimal dutyByAct;

    @Column(name = "SENDING_DATE")
    private LocalDate sendingDate;

    @Column(name = "EXECUTION_FEE_AMOUNT", precision = 19, scale = 2)
    private BigDecimal executionFeeAmount;

    @Column(name = "PROCEEDINGS_START_DATE")
    private LocalDate proceedingsStartDate;

    @Column(name = "DEBT_DISTRIBUTION")
    private Boolean debtDistribution;

    @Column(name = "DEBT_DISTRIBUTION_DATE")
    private LocalDate debtDistributionDate;

    @Column(name = "WITHDRAW_DATE")
    private LocalDate withdrawDate;

    @Lob
    @Column(name = "WITHDRAW_REASON")
    private String withdrawReason;

    @Column(name = "TERMINATION_DATE")
    private LocalDate terminationDate;

    @Column(name = "EXECUTION_RESULT", length = 60)
    private String executionResult;

    @Column(name = "PARTIALLY_EXECUTED_AMOUNT", precision = 19, scale = 2)
    private BigDecimal partiallyExecutedAmount;

    @Column(name = "NOT_EXECUTED_NOTE")
    private String notExecutedNote;

    @Column(name = "NOTE")
    private String note;

    public String getCaseNumberEnforce() {
        return caseNumberEnforce;
    }

    public void setCaseNumberEnforce(String caseNumberEnforce) {
        this.caseNumberEnforce = caseNumberEnforce;
    }

    public LocalDate getLastStatusDate() {
        return lastStatusDate;
    }

    public void setLastStatusDate(LocalDate lastStatusDate) {
        this.lastStatusDate = lastStatusDate;
    }

    public CCourtCaseStage getLastStatus() {
        return lastStatus == null ? null : CCourtCaseStage.fromId(lastStatus);
    }

    public void setLastStatus(CCourtCaseStage lastStatus) {
        this.lastStatus = lastStatus == null ? null : lastStatus.getId();
    }

    public void setWithdrawDate(LocalDate withdrawDate) {
        this.withdrawDate = withdrawDate;
    }

    public LocalDate getWithdrawDate() {
        return withdrawDate;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getNotExecutedNote() {
        return notExecutedNote;
    }

    public void setNotExecutedNote(String notExecutedNote) {
        this.notExecutedNote = notExecutedNote;
    }

    public BigDecimal getPartiallyExecutedAmount() {
        return partiallyExecutedAmount;
    }

    public void setPartiallyExecutedAmount(BigDecimal partiallyExecutedAmount) {
        this.partiallyExecutedAmount = partiallyExecutedAmount;
    }

    public CCourtEnforcesexecutionResult getExecutionResult() {
        return executionResult == null ? null : CCourtEnforcesexecutionResult.fromId(executionResult);
    }

    public void setExecutionResult(CCourtEnforcesexecutionResult executionResult) {
        this.executionResult = executionResult == null ? null : executionResult.getId();
    }

    public LocalDate getTerminationDate() {
        return terminationDate;
    }

    public void setTerminationDate(LocalDate terminationDate) {
        this.terminationDate = terminationDate;
    }

    public String getWithdrawReason() {
        return withdrawReason;
    }

    public void setWithdrawReason(String withdrawReason) {
        this.withdrawReason = withdrawReason;
    }

    public LocalDate getDebtDistributionDate() {
        return debtDistributionDate;
    }

    public void setDebtDistributionDate(LocalDate debtDistributionDate) {
        this.debtDistributionDate = debtDistributionDate;
    }

    public Boolean getDebtDistribution() {
        return debtDistribution;
    }

    public void setDebtDistribution(Boolean debtDistribution) {
        this.debtDistribution = debtDistribution;
    }

    public LocalDate getProceedingsStartDate() {
        return proceedingsStartDate;
    }

    public void setProceedingsStartDate(LocalDate proceedingsStartDate) {
        this.proceedingsStartDate = proceedingsStartDate;
    }

    public BigDecimal getExecutionFeeAmount() {
        return executionFeeAmount;
    }

    public void setExecutionFeeAmount(BigDecimal executionFeeAmount) {
        this.executionFeeAmount = executionFeeAmount;
    }

    public LocalDate getSendingDate() {
        return sendingDate;
    }

    public void setSendingDate(LocalDate sendingDate) {
        this.sendingDate = sendingDate;
    }

    public BigDecimal getDutyByAct() {
        return dutyByAct;
    }

    public void setDutyByAct(BigDecimal dutyByAct) {
        this.dutyByAct = dutyByAct;
    }

    public BigDecimal getDebtByAct() {
        return debtByAct;
    }

    public void setDebtByAct(BigDecimal debtByAct) {
        this.debtByAct = debtByAct;
    }

    public LocalDate getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(LocalDate receiptDate) {
        this.receiptDate = receiptDate;
    }

    public LocalDate getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(LocalDate requestDate) {
        this.requestDate = requestDate;
    }

    @PrePersist
    public void prePersist() {
        setLastStatus(getCourtCase().getCaseStatus());
        setLastStatusDate(getCourtCase().getStatusDate());
    }
}