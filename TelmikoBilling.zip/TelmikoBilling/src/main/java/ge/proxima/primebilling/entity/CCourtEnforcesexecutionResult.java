package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtEnforcesexecutionResult implements EnumClass<String> {

    SENTTOBUREAU("SENTTOBUREAU"),
    EXECUTED("EXECUTED"),
    PARTIALLYEXECUTED("PARTIALLYEXECUTED"),
    NOTEXECUTED("NOTEXECUTED");


    private String id;

    CCourtEnforcesexecutionResult(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtEnforcesexecutionResult fromId(String id) {
        for (CCourtEnforcesexecutionResult at : CCourtEnforcesexecutionResult.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}