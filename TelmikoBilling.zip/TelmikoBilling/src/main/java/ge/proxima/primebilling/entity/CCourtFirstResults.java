package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtFirstResults implements EnumClass<String> {

    ACCEPTED("ACCEPTED"),
    REJECTED("REJECTED");

    private String id;

    CCourtFirstResults(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtFirstResults fromId(String id) {
        for (CCourtFirstResults at : CCourtFirstResults.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}