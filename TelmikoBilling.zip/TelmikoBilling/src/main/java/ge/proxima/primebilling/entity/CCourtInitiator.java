package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtInitiator implements EnumClass<String> {

    TELMICO("Telmico"),
    CUSTOMER("Customer"),
    THIRDPARTY("ThirdParty");

    private String id;

    CCourtInitiator(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtInitiator fromId(String id) {
        for (CCourtInitiator at : CCourtInitiator.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}