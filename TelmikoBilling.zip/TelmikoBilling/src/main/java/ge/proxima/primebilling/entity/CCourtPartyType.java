package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtPartyType implements EnumClass<String> {

    CLAIMANT("CLAIMANT"),
    DEFENDANT("DEFENDANT"),
    THIRDPARTY("THIRDPARTY");

    private String id;

    CCourtPartyType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtPartyType fromId(String id) {
        for (CCourtPartyType at : CCourtPartyType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}