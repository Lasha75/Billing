package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtPayStatus implements EnumClass<String> {

    SENTTOPAY("SENTTOPAY"),
    PAID("PAID"),
    RETURNED("RETURNED");

    private String id;

    CCourtPayStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtPayStatus fromId(String id) {
        for (CCourtPayStatus at : CCourtPayStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}