package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@JmixEntity
@Entity(name = "prx_CCourtPaymentOfStateDuty")
public class CCourtPaymentOfStateDuty extends CCourtCaseEventTable implements BaseUuidEntity {

    @JoinColumn(name = "TRANSACTION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtCaseDutyTransactions transaction;

    @Column(name = "LAST_STATUS")
    private String lastStatus;

    @Column(name = "LAST_STATUS_DATE")
    private LocalDate lastStatusDate;

    @Column(name = "TRANSACTION_OTHER_NOTE", length = 100)
    private String transactionOtherNote;

    @Column(name = "PAYER_NAME")
    private String payerName;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "CLAIM_AMOUNT", precision = 19, scale = 2)
    private BigDecimal claimAmount;

    @Column(name = "DUTY_AMOUNT", precision = 19, scale = 2)
    private BigDecimal dutyAmount;

    @Column(name = "PAYMENT_STATUS", length = 60)
    private String paymentStatus;

    public LocalDate getLastStatusDate() {
        return lastStatusDate;
    }

    public void setLastStatusDate(LocalDate lastStatusDate) {
        this.lastStatusDate = lastStatusDate;
    }

    public CCourtCaseStage getLastStatus() {
        return lastStatus == null ? null : CCourtCaseStage.fromId(lastStatus);
    }

    public void setLastStatus(CCourtCaseStage lastStatus) {
        this.lastStatus = lastStatus == null ? null : lastStatus.getId();
    }

    public void setPaymentStatus(CCourtPayStatus paymentStatus) {
        this.paymentStatus = paymentStatus == null ? null : paymentStatus.getId();
    }

    public CCourtPayStatus getPaymentStatus() {
        return paymentStatus == null ? null : CCourtPayStatus.fromId(paymentStatus);
    }

    public String getTransactionOtherNote() {
        return transactionOtherNote;
    }

    public void setTransactionOtherNote(String transactionOtherNote) {
        this.transactionOtherNote = transactionOtherNote;
    }

    public BigDecimal getDutyAmount() {
        return dutyAmount;
    }

    public void setDutyAmount(BigDecimal dutyAmount) {
        this.dutyAmount = dutyAmount;
    }

    public BigDecimal getClaimAmount() {
        return claimAmount;
    }

    public void setClaimAmount(BigDecimal claimAmount) {
        this.claimAmount = claimAmount;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public CCourtCaseDutyTransactions getTransaction() {
        return transaction;
    }

    public void setTransaction(CCourtCaseDutyTransactions transaction) {
        this.transaction = transaction;
    }

    public String getPayerName() {
        return payerName;
    }

    public void setPayerName(String payerName) {
        this.payerName = payerName;
    }

    @PrePersist
    public void prePersist() {
        setLastStatus(getCourtCase().getCaseStatus());
        setLastStatusDate(getCourtCase().getStatusDate());
    }
}