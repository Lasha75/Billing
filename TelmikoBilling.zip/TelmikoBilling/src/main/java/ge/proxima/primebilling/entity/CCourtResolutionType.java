package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtResolutionType implements EnumClass<String> {

    DECISION("Decision"),
    DEFINITION("Definition"),
    ABSENTIA("Absentia"),
    NEWDECISION("NewDecision");

    private String id;

    CCourtResolutionType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtResolutionType fromId(String id) {
        for (CCourtResolutionType at : CCourtResolutionType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}