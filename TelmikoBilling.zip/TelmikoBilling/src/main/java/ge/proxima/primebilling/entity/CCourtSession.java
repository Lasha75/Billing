package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.entity.transactions.CCourtSessionInstance;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.time.LocalDate;

@JmixEntity
@Entity(name = "prx_CCourtSession")
public class CCourtSession extends CCourtCaseEventTable implements BaseUuidEntity {
    @Column(name = "SESSION_DATE")
    private LocalDate sessionDate;

    @Column(name = "LAST_STATUS")
    private String lastStatus;

    @Column(name = "LAST_STATUS_DATE")
    private LocalDate lastStatusDate;

    @JoinColumn(name = "STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtSessionStatus status;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CCourtSessionCategory category;

    @Column(name = "SESSION_TYPE", length = 60)
    private String sessionType;

    @Column(name = "SESSION_INSTANCE", length = 60)
    private String sessionInstance;

    @Lob
    @Column(name = "NOTE")
    private String note;

    public LocalDate getLastStatusDate() {
        return lastStatusDate;
    }

    public void setLastStatusDate(LocalDate lastStatusDate) {
        this.lastStatusDate = lastStatusDate;
    }

    public CCourtCaseStage getLastStatus() {
        return lastStatus == null ? null : CCourtCaseStage.fromId(lastStatus);
    }

    public void setLastStatus(CCourtCaseStage lastStatus) {
        this.lastStatus = lastStatus == null ? null : lastStatus.getId();
    }

    public CCourtSessionCategory getCategory() {
        return category;
    }

    public void setCategory(CCourtSessionCategory category) {
        this.category = category;
    }

    public CCourtSessionStatus getStatus() {
        return status;
    }

    public void setStatus(CCourtSessionStatus status) {
        this.status = status;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public CCourtSessionInstance getSessionInstance() {
        return sessionInstance == null ? null : CCourtSessionInstance.fromId(sessionInstance);
    }

    public void setSessionInstance(CCourtSessionInstance sessionInstance) {
        this.sessionInstance = sessionInstance == null ? null : sessionInstance.getId();
    }

    public CCourtSessionType getSessionType() {
        return sessionType == null ? null : CCourtSessionType.fromId(sessionType);
    }

    public void setSessionType(CCourtSessionType sessionType) {
        this.sessionType = sessionType == null ? null : sessionType.getId();
    }

    public LocalDate getSessionDate() {
        return sessionDate;
    }

    public void setSessionDate(LocalDate sessionDate) {
        this.sessionDate = sessionDate;
    }
}