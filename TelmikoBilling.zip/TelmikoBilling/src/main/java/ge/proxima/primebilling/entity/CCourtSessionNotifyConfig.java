package ge.proxima.primebilling.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_C_COURT_SESSION_NOTIFY_CONFIG")
@Entity(name = "prx_CCourtSessionNotifyConfig")
public class CCourtSessionNotifyConfig {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "NOTIFY_BEFOR_DAY")
    private Integer notifyBeforDay;

    public Integer getNotifyBeforDay() {
        return notifyBeforDay;
    }

    public void setNotifyBeforDay(Integer notifyBeforDay) {
        this.notifyBeforDay = notifyBeforDay;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}