package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtSessionType implements EnumClass<String> {

    MAIN("Main"),
    PREPARATORY("Preparatory");

    private String id;

    CCourtSessionType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtSessionType fromId(String id) {
        for (CCourtSessionType at : CCourtSessionType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}