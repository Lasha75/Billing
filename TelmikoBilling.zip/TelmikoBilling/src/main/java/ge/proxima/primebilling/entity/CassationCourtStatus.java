package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CassationCourtStatus implements EnumClass<String> {

    SATISFIED("SATISFIED"),
    NON_SATISFIED("NON_SATISFIED"),
    VERDICT("VERDICT");

    private String id;

    CassationCourtStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CassationCourtStatus fromId(String id) {
        for (CassationCourtStatus at : CassationCourtStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}