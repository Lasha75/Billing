package ge.proxima.primebilling.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CCOURT_EVENT_STAGE", indexes = {
        @Index(name = "IDX_PRX_CCOURT_EVENT_STAGE_UNQ", columnList = "CASE_EVENT", unique = true)
})
@Entity(name = "prx_CcourtEventStage")
public class CcourtEventStage {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "CASE_EVENT", nullable = false)
    @NotNull
    private String caseEvent;

    @Column(name = "STAGE", nullable = false)
    @NotNull
    private String stage;

    public CCourtCaseStage getStage() {
        return stage == null ? null : CCourtCaseStage.fromId(stage);
    }

    public void setStage(CCourtCaseStage stage) {
        this.stage = stage == null ? null : stage.getId();
    }

    public CCourtCaseEvent getCaseEvent() {
        return caseEvent == null ? null : CCourtCaseEvent.fromId(caseEvent);
    }

    public void setCaseEvent(CCourtCaseEvent caseEvent) {
        this.caseEvent = caseEvent == null ? null : caseEvent.getId();
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}