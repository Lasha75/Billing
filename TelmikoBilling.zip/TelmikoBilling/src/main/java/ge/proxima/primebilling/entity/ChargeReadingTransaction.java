package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CHARGE_READING_TRANSACTION", indexes = {
        @Index(name = "IDX_PRX_CHARGE_READING_TRANSACTION_TRANS_TYPE_COMBINATION", columnList = "TRANS_TYPE_COMBINATION_ID")
})
@Entity(name = "prx_ChargeReadingTransaction")
public class ChargeReadingTransaction {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "WITH_READING")
    private Boolean withReading;

    @JoinColumn(name = "TRANS_TYPE_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination transTypeCombination;

    public Boolean getWithReading() {
        return withReading;
    }

    public void setWithReading(Boolean withReading) {
        this.withReading = withReading;
    }

    public TransactionTypeCombination getTransTypeCombination() {
        return transTypeCombination;
    }

    public void setTransTypeCombination(TransactionTypeCombination transTypeCombination) {
        this.transTypeCombination = transTypeCombination;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}