package ge.proxima.primebilling.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import java.util.UUID;

@JmixEntity(name = "prx_ChiledCustomer")
public class ChiledCustomer {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private String customerNumber;

    private String customerName;

    private String counterCode;

    private String counterSerialNumber;

    private String telasiAccountId;

    public String getTelasiAccountId() {
        return telasiAccountId;
    }

    public void setTelasiAccountId(String telasiAccountId) {
        this.telasiAccountId = telasiAccountId;
    }

    public String getCounterSerialNumber() {
        return counterSerialNumber;
    }

    public void setCounterSerialNumber(String counterSerialNumber) {
        this.counterSerialNumber = counterSerialNumber;
    }

    public String getCounterCode() {
        return counterCode;
    }

    public void setCounterCode(String counterCode) {
        this.counterCode = counterCode;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}