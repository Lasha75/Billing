package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CorrectionType implements EnumClass<String> {

    NONE("NONE"),
    ACT("ACT"),
    VOUCHER("VOUCHER");

    private String id;

    CorrectionType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CorrectionType fromId(String id) {
        for (CorrectionType at : CorrectionType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}