package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.counter.Counter;
import ge.proxima.primebilling.entity.counter.HatchLocation;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.numerator.NumeratorService;
import io.jmix.core.DeletePolicy;
import io.jmix.core.Messages;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_COUNTER_HATCH", indexes = {
        @Index(name = "IDX_COUNTERHATCH_STATUS_ID", columnList = "STATUS_ID"),
        @Index(name = "IDX_COUNTERHATCH_LOCATION_ID", columnList = "LOCATION_ID"),
        @Index(name = "IDX_COUNTERHATCH_COUNTER_ID", columnList = "COUNTER_ID"),
        @Index(name = "IDX_PRX_COUNTER_HATCH_UNQ", columnList = "CODE", unique = true),
        @Index(name = "IDX_PRX_COUNTER_HATCH_UNQ_1", columnList = "NUMBER_", unique = true),
        @Index(name = "IDX_COUNTERHATCH_CUSTOMER_ID", columnList = "CUSTOMER_ID")
})
@Entity(name = "prx_CounterHatch")
public class CounterHatch {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @InstanceName
    @Column(name = "NUMBER_", nullable = false, length = 50)
    @NotNull
    private String number;

    @Column(name = "CODE", nullable = false, length = 30)
    @NotNull
    private String code;

    @Column(name = "CONDITION_")
    private String condition;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status status;

    @Column(name = "INSTALL_DOCUMENT_NUMBER", length = 50)
    private String installDocumentNumber;

    @NotNull
    @Column(name = "INSTALL_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date installDate;

    @Column(name = "REMOVE_DOCUMENT_NUMBER", length = 50)
    private String removeDocumentNumber;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "REMOVE_DATE")
    private Date removeDate;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "LOCATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private HatchLocation location;

    @JoinColumn(name = "COUNTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Counter counter;

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setRemoveDate(Date removeDate) {
        this.removeDate = removeDate;
    }

    public Date getRemoveDate() {
        return removeDate;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Counter getCounter() {
        return counter;
    }

    public void setCounter(Counter counter) {
        this.counter = counter;
    }

    public HatchLocation getLocation() {
        return location;
    }

    public void setLocation(HatchLocation location) {
        this.location = location;
    }

    public String getRemoveDocumentNumber() {
        return removeDocumentNumber;
    }

    public void setRemoveDocumentNumber(String removeDocumentNumber) {
        this.removeDocumentNumber = removeDocumentNumber;
    }

    public Date getInstallDate() {
        return installDate;
    }

    public void setInstallDate(Date installDate) {
        this.installDate = installDate;
    }

    public String getInstallDocumentNumber() {
        return installDocumentNumber;
    }

    public void setInstallDocumentNumber(String installDocumentNumber) {
        this.installDocumentNumber = installDocumentNumber;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PostConstruct
    public void postConstruct() {
        NumeratorService numeratorService = AppBeans.getBean(NumeratorService.class);
        setCode(
                numeratorService.getNumSeq(this.getClass())
        );
    }

    private void checkRemoveDate() {
        Messages messages = AppBeans.getBean(Messages.class);
        if(removeDocumentNumber != null && !removeDocumentNumber.isEmpty() && removeDate == null) {
            throw new RuntimeException(messages.getMessage(this.getClass(), "removeDateIsMandatory"));
        }
    }

    @PrePersist
    public void prePersist() {
        checkRemoveDate();
    }

    @PreUpdate
    public void preUpdate() {
        checkRemoveDate();
    }
}