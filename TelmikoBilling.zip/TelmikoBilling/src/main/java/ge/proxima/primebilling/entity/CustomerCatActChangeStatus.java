package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CustomerCatActChangeStatus implements EnumClass<String> {

    DRAFT("DRAFT"),
    ACTIVE("ACTIVE");

    private String id;

    CustomerCatActChangeStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CustomerCatActChangeStatus fromId(String id) {
        for (CustomerCatActChangeStatus at : CustomerCatActChangeStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}