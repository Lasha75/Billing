package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.customer.setup.CustomerCategoryActivityChangeLine;
import ge.proxima.primebilling.entity.reftables.Activity;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_CATEGORY_ACTIVITY", indexes = {
        @Index(name = "IDX_PRXCUSTOMERCATEGO_CUSTOMER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRXCUSTOMERC_CURRENTCATEG", columnList = "CURRENT_CATEGORY_ID"),
        @Index(name = "IDX_PRXCUSTOMERCA_NEXTCATEGORY", columnList = "NEXT_CATEGORY_ID"),
        @Index(name = "IDX_PRXCUSTOMERC_CURRENTACTIV", columnList = "CURRENT_ACTIVITY_ID"),
        @Index(name = "IDX_PRXCUSTOMERCA_NEXTACTIVITY", columnList = "NEXT_ACTIVITY_ID")
})
@Entity(name = "prx_CustomerCategoryActivityChange")
public class CustomerCategoryActivityChange implements BaseUuidEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "STATUS")
    private String status;

    @NotNull
    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @NotNull
    @Column(name = "ACTIVATION_DATE", nullable = false)
    private LocalDate activationDate;

    @JoinColumn(name = "CURRENT_CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory currentCategory;

    @JoinColumn(name = "CURRENT_ACTIVITY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Activity currentActivity;

    @JoinColumn(name = "NEXT_ACTIVITY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Activity nextActivity;

    @JoinColumn(name = "NEXT_CATEGORY_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private CustomerCategory nextCategory;

    @Column(name = "REASON")
    private String reason;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @Composition
    @OneToMany(mappedBy = "customerCategoryActivityChange")
    private List<CustomerCategoryActivityChangeLine> line;

    public void setActivationDate(LocalDate activationDate) {
        this.activationDate = activationDate;
    }

    public LocalDate getActivationDate() {
        return activationDate;
    }

    public CustomerCatActChangeStatus getStatus() {
        return status == null ? null : CustomerCatActChangeStatus.fromId(status);
    }

    public void setStatus(CustomerCatActChangeStatus status) {
        this.status = status == null ? CustomerCatActChangeStatus.DRAFT.getId() : status.getId();
    }

    public List<CustomerCategoryActivityChangeLine> getLine() {
        return line;
    }

    public void setLine(List<CustomerCategoryActivityChangeLine> line) {
        this.line = line;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Activity getNextActivity() {
        return nextActivity;
    }

    public void setNextActivity(Activity nextActivity) {
        this.nextActivity = nextActivity;
    }

    public Activity getCurrentActivity() {
        return currentActivity;
    }

    public void setCurrentActivity(Activity currentActivity) {
        this.currentActivity = currentActivity;
    }

    public CustomerCategory getNextCategory() {
        return nextCategory;
    }

    public void setNextCategory(CustomerCategory nextCategory) {
        this.nextCategory = nextCategory;
    }

    public CustomerCategory getCurrentCategory() {
        return currentCategory;
    }

    public void setCurrentCategory(CustomerCategory currentCategory) {
        this.currentCategory = currentCategory;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"customer", "status"})
    public String getInstanceName() {
        return String.format("%s %s", customer, status);
    }

    @PostConstruct
    public void postConstruct() {
        if(getStatus()==null)
        {
            setStatus(CustomerCatActChangeStatus.DRAFT);
        }
    }
}