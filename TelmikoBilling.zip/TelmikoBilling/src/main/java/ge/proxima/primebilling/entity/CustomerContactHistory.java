package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.CustomerContactType;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_CONTACT_HISTORY", indexes = {
        @Index(name = "IDX_PRXCUSTOMERCONTAC_CUSTOMER", columnList = "CUSTOMER_ID")
})
@Entity(name = "prx_CustomerContactHistory")
public class CustomerContactHistory {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "CONTACT_TYPE")
    private String contactType;

    @Column(name = "CONTACT_INFO", length = 100)
    private String contactInfo;

    @Column(name = "CREATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public CustomerContactType getContactType() {
        return contactType == null ? null : CustomerContactType.fromId(contactType);
    }

    public void setContactType(CustomerContactType contactType) {
        this.contactType = contactType == null ? null : contactType.getId();
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}