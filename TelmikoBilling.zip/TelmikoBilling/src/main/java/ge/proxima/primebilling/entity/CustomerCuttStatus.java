package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CustomerCuttStatus implements EnumClass<String> {

    NONE("NONE"),
    CUT("CUT"),
    CONNECT("CONNECT"),
    FORCUT("FORCUT"),
    FORRECONNECT("FORRECONNECT"),
    NOCUT("NOCUT"),
    NORECCONECT("NORECCONECT");

    private String id;

    CustomerCuttStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CustomerCuttStatus fromId(String id) {
        for (CustomerCuttStatus at : CustomerCuttStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}