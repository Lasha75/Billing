package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_LOG_IMPORT", indexes = {
        @Index(name = "IDX_PRXCUSTOMERLOGIMP_CUSTOMER", columnList = "CUSTOMER_ID")
})
@Entity(name = "prx_CustomerLogImport")
public class CustomerLogImport {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "ACC_NUMB", length = 30)
    private String accNumb;

    @Column(name = "ADMIN_OPER_ID", precision = 19, scale = 2)
    private BigDecimal adminOperId;

    @Column(name = "USER_NAME", length = 50)
    private String userName;

    @Column(name = "OPER_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date operTime;

    @Column(name = "OPER_TYPE", length = 50)
    private String operType;

    @Column(name = "OPER_OBJECT", length = 50)
    private String operObject;

    @Column(name = "OBJECT_FIELD", length = 50)
    private String objectField;

    @Column(name = "VALUE_BEFORE", length = 2000)
    private String valueBefore;

    @Column(name = "VALUE_AFTER", length = 2000)
    private String valueAfter;

    @Column(name = "RECORD_KEY", precision = 19, scale = 2)
    private BigDecimal recordKey;

    @Column(name = "CUST_KEY", precision = 19, scale = 0)
    private BigDecimal custKey;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public BigDecimal getCustKey() {
        return custKey;
    }

    public void setCustKey(BigDecimal custKey) {
        this.custKey = custKey;
    }

    public BigDecimal getRecordKey() {
        return recordKey;
    }

    public void setRecordKey(BigDecimal recordKey) {
        this.recordKey = recordKey;
    }

    public String getValueAfter() {
        return valueAfter;
    }

    public void setValueAfter(String valueAfter) {
        this.valueAfter = valueAfter;
    }

    public String getValueBefore() {
        return valueBefore;
    }

    public void setValueBefore(String valueBefore) {
        this.valueBefore = valueBefore;
    }

    public String getObjectField() {
        return objectField;
    }

    public void setObjectField(String objectField) {
        this.objectField = objectField;
    }

    public String getOperObject() {
        return operObject;
    }

    public void setOperObject(String operObject) {
        this.operObject = operObject;
    }

    public String getOperType() {
        return operType;
    }

    public void setOperType(String operType) {
        this.operType = operType;
    }

    public Date getOperTime() {
        return operTime;
    }

    public void setOperTime(Date operTime) {
        this.operTime = operTime;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public BigDecimal getAdminOperId() {
        return adminOperId;
    }

    public void setAdminOperId(BigDecimal adminOperId) {
        this.adminOperId = adminOperId;
    }

    public String getAccNumb() {
        return accNumb;
    }

    public void setAccNumb(String accNumb) {
        this.accNumb = accNumb;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}