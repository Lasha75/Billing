package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.SocialScore;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_MAYORS_SUBSIDY", indexes = {
        @Index(name = "IDX_CUSTOMERMAYORSSUBSIDY", columnList = "CUSTOMER_ID")
})
@Entity(name = "prx_CustomerMayorsSubsidy")
public class CustomerMayorsSubsidy {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @Column(name = "DATE_")
    @Temporal(TemporalType.DATE)
    private Date date;

    @Column(name = "MAYORS_LIMIT", precision = 19, scale = 2)
    private BigDecimal mayorsLimit;

    @Column(name = "GWP_AMOUNT", precision = 19, scale = 2)
    private BigDecimal gwpAmount;

    @Column(name = "CLEANUP_AMOUNT", precision = 19, scale = 2)
    private BigDecimal cleanupAmount;

    @Column(name = "ELECTRICITY_LIMIT", precision = 19, scale = 2)
    private BigDecimal electricityLimit;

    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @Column(name = "SOCIAL_SCORE")
    private String socialScore;

    @Column(name = "MULTICHILD_LIMIT", precision = 19, scale = 2)
    private BigDecimal multichildLimit;

    public BigDecimal getMultichildLimit() {
        return multichildLimit;
    }

    public void setMultichildLimit(BigDecimal multichildLimit) {
        this.multichildLimit = multichildLimit;
    }

    public SocialScore getSocialScore() {
        return socialScore == null ? null : SocialScore.fromId(socialScore);
    }

    public void setSocialScore(SocialScore socialScore) {
        this.socialScore = socialScore == null ? null : socialScore.getId();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public BigDecimal getElectricityLimit() {
        return electricityLimit;
    }

    public void setElectricityLimit(BigDecimal electricityLimit) {
        this.electricityLimit = electricityLimit;
    }

    public BigDecimal getCleanupAmount() {
        return cleanupAmount;
    }

    public void setCleanupAmount(BigDecimal cleanupAmount) {
        this.cleanupAmount = cleanupAmount;
    }

    public BigDecimal getGwpAmount() {
        return gwpAmount;
    }

    public void setGwpAmount(BigDecimal gwpAmount) {
        this.gwpAmount = gwpAmount;
    }

    public BigDecimal getMayorsLimit() {
        return mayorsLimit;
    }

    public void setMayorsLimit(BigDecimal mayorsLimit) {
        this.mayorsLimit = mayorsLimit;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}