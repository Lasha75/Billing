package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUT_HISTORY", indexes = {
        @Index(name = "IDX_PRX_CUT_HISTORY_CUSTOMER", columnList = "CUSTOMER_ID")
})
@Entity(name = "prx_CutHistory")
public class CutHistory {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "TL_CR_KEY", precision = 12, scale = 0)
    private BigDecimal tlCRKey;

    @Column(name = "TL_ACC_KEY", precision = 8, scale = 0)
    private BigDecimal tlAccKey;

    @Column(name = "TL_MARK_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlMarkDate;

    @Column(name = "TL_OPER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlOperDate;

    @Column(name = "OPER_CODE", precision = 19, scale = 0)
    private BigDecimal operCode;

    @Column(name = "TL_READING", precision = 19, scale = 4)
    private BigDecimal tlReading;

    @Column(name = "TL_DISC_REQ_STATUS", precision = 19, scale = 0)
    private BigDecimal tlDiscReqStatus;

    @Column(name = "TL_ENTER_DATE_INSP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlEnterDateInsp;

    @Column(name = "TL_ENTER_DATE_OPER")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlEnterDateOper;

    @Column(name = "TL_MARK_CODE", precision = 1, scale = 0)
    private BigDecimal tlMarkCode;

    @Column(name = "TL_STAT_EL", precision = 1, scale = 0)
    private BigDecimal tlStatEl;

    @Column(name = "TL_STAT_TR", precision = 1, scale = 0)
    private BigDecimal tlStatTR;

    @Column(name = "TL_STAT_W", precision = 1, scale = 0)
    private BigDecimal tlStatW;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "TYPE_")
    private String type;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "DISC_REQ_NAME", length = 900)
    private String discReqName;

    @Column(name = "TL_CUST_KEY", precision = 8, scale = 0)
    private BigDecimal tlCustKey;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    public BigDecimal getOperCode() {
        return operCode;
    }

    public void setOperCode(BigDecimal operCode) {
        this.operCode = operCode;
    }

    public Date getTlOperDate() {
        return tlOperDate;
    }

    public void setTlOperDate(Date tlOperDate) {
        this.tlOperDate = tlOperDate;
    }

    public BigDecimal getTlCRKey() {
        return tlCRKey;
    }

    public void setTlCRKey(BigDecimal tlCRKey) {
        this.tlCRKey = tlCRKey;
    }

    public String getDiscReqName() {
        return discReqName;
    }

    public void setDiscReqName(String discReqName) {
        this.discReqName = discReqName;
    }

    public CutHistoryStatus getStatus() {
        return status == null ? null : CutHistoryStatus.fromId(status);
    }

    public void setStatus(CutHistoryStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public CutHistoryType getType() {
        return type == null ? null : CutHistoryType.fromId(type);
    }

    public void setType(CutHistoryType type) {
        this.type = type == null ? null : type.getId();
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public BigDecimal getTlStatW() {
        return tlStatW;
    }

    public void setTlStatW(BigDecimal tlStatW) {
        this.tlStatW = tlStatW;
    }

    public BigDecimal getTlStatTR() {
        return tlStatTR;
    }

    public void setTlStatTR(BigDecimal tlStatTR) {
        this.tlStatTR = tlStatTR;
    }

    public BigDecimal getTlStatEl() {
        return tlStatEl;
    }

    public void setTlStatEl(BigDecimal tlStatEl) {
        this.tlStatEl = tlStatEl;
    }

    public BigDecimal getTlMarkCode() {
        return tlMarkCode;
    }

    public void setTlMarkCode(BigDecimal tlMarkCode) {
        this.tlMarkCode = tlMarkCode;
    }

    public Date getTlEnterDateOper() {
        return tlEnterDateOper;
    }

    public void setTlEnterDateOper(Date tlEnterDateOper) {
        this.tlEnterDateOper = tlEnterDateOper;
    }

    public Date getTlEnterDateInsp() {
        return tlEnterDateInsp;
    }

    public void setTlEnterDateInsp(Date tlEnterDateInsp) {
        this.tlEnterDateInsp = tlEnterDateInsp;
    }

    public BigDecimal getTlDiscReqStatus() {
        return tlDiscReqStatus;
    }

    public void setTlDiscReqStatus(BigDecimal tlDiscReqStatus) {
        this.tlDiscReqStatus = tlDiscReqStatus;
    }

    public BigDecimal getTlReading() {
        return tlReading;
    }

    public void setTlReading(BigDecimal tlReading) {
        this.tlReading = tlReading;
    }

    public Date getTlMarkDate() {
        return tlMarkDate;
    }

    public void setTlMarkDate(Date tlMarkDate) {
        this.tlMarkDate = tlMarkDate;
    }

    public BigDecimal getTlAccKey() {
        return tlAccKey;
    }

    public void setTlAccKey(BigDecimal tlAccKey) {
        this.tlAccKey = tlAccKey;
    }

    public BigDecimal getTlCustKey() {
        return tlCustKey;
    }

    public void setTlCustKey(BigDecimal tlCustKey) {
        this.tlCustKey = tlCustKey;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}