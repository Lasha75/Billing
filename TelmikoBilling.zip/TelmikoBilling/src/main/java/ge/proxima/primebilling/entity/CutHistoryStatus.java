package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CutHistoryStatus implements EnumClass<String> {

    NONE("NONE"),
    FORCUT("FORCUT"),
    CUT("CUT"),
    FORREC("FORREC"),
    REC("REC"),
    NOCUT("NOCUT"),
    NOCONNECT("NOCONNECT");

    private String id;

    CutHistoryStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CutHistoryStatus fromId(String id) {
        for (CutHistoryStatus at : CutHistoryStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}