package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CuttOffStatus implements EnumClass<String> {

    INTELASI("INTELASI"),
    CUTED("CUTED"),
    NOTCUTED("NOTCUTED");

    private String id;

    CuttOffStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CuttOffStatus fromId(String id) {
        for (CuttOffStatus at : CuttOffStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}