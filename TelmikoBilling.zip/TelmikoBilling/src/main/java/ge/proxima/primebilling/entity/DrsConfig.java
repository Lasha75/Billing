package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.report.drs.DrsGroup;
import ge.proxima.primebilling.entity.report.drs.category.DrsCategory;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_DRS_CONFIG", indexes = {
        @Index(name = "IDX_PRX_DRS_CONFIG_GROUP", columnList = "GROUP_ID"),
        @Index(name = "IDX_PRX_DRS_CONFIG_CATEGORY", columnList = "CATEGORY_ID"),
        @Index(name = "IDX_PRX_DRS_CONFIG_TRANS_TYPE", columnList = "TRANS_TYPE_ID")
})
@Entity(name = "prx_DrsConfig")
public class DrsConfig {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "GROUP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DrsGroup group;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DrsCategory category;

    @JoinColumn(name = "TRANS_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination transType;

    public void setCategory(DrsCategory category) {
        this.category = category;
    }

    public DrsCategory getCategory() {
        return category;
    }

    public TransactionTypeCombination getTransType() {
        return transType;
    }

    public void setTransType(TransactionTypeCombination transType) {
        this.transType = transType;
    }

    public DrsGroup getGroup() {
        return group;
    }

    public void setGroup(DrsGroup group) {
        this.group = group;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}