package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ImportDataType implements EnumClass<String> {

    STRING("STRING"),
    INT("INT"),
    DECIMAL("DECIMAL"),
    ASSOCIATION("ASSOCIATION"),
    ENUM("ENUM");

    private String id;

    ImportDataType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ImportDataType fromId(String id) {
        for (ImportDataType at : ImportDataType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}