package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.counter.Counter;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_MP_ITEM", indexes = {
        @Index(name = "IDX_PRX_MP_ITEM_CUSTOMER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRX_MP_ITEM_COUNTER", columnList = "COUNTER_ID"),
        @Index(name = "IDX_PRXMPITEM_TRANSACTIONTYPE", columnList = "TRANSACTION_TYPE_ID")
})
@Entity(name = "prx_MPItem")
public class MPItem {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "KWT", precision = 19, scale = 2)
    private BigDecimal kwt;

    @Column(name = "STATUS")
    private String status;

    @JoinColumn(name = "TRANSACTION_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination transactionType;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "CUST_KEY", precision = 8, scale = 0)
    private BigDecimal custKey;

    @Column(name = "ACCKEY", precision = 8, scale = 0)
    private BigDecimal acckey;

    @Column(name = "ITEM_DATE")
    @Temporal(TemporalType.DATE)
    private Date itemDate;

    @Column(name = "READING", precision = 19, scale = 2)
    private BigDecimal reading;

    @Column(name = "ENTER_DATE")
    @Temporal(TemporalType.DATE)
    private Date enterDate;

    @Column(name = "ENTER_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date enterDateTime;

    @JoinColumn(name = "COUNTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Counter counter;

    @Column(name = "HASH_CODE", length = 200)
    private String hashCode;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    public BigDecimal getKwt() {
        return kwt;
    }

    public void setKwt(BigDecimal kwt) {
        this.kwt = kwt;
    }

    public MPItemChargeStatus getStatus() {
        return status == null ? null : MPItemChargeStatus.fromId(status);
    }

    public void setStatus(MPItemChargeStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public Date getEnterDateTime() {
        return enterDateTime;
    }

    public void setEnterDateTime(Date enterDateTime) {
        this.enterDateTime = enterDateTime;
    }

    public TransactionTypeCombination getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionTypeCombination transactionType) {
        this.transactionType = transactionType;
    }

    public Counter getCounter() {
        return counter;
    }

    public void setCounter(Counter counter) {
        this.counter = counter;
    }

    public String getHashCode() {
        return hashCode;
    }

    public void setHashCode(String hashCode) {
        this.hashCode = hashCode;
    }

    public Date getEnterDate() {
        return enterDate;
    }

    public void setEnterDate(Date enterDate) {
        this.enterDate = enterDate;
    }

    public BigDecimal getReading() {
        return reading;
    }

    public void setReading(BigDecimal reading) {
        this.reading = reading;
    }

    public Date getItemDate() {
        return itemDate;
    }

    public void setItemDate(Date itemDate) {
        this.itemDate = itemDate;
    }

    public BigDecimal getAcckey() {
        return acckey;
    }

    public void setAcckey(BigDecimal acckey) {
        this.acckey = acckey;
    }

    public BigDecimal getCustKey() {
        return custKey;
    }

    public void setCustKey(BigDecimal custKey) {
        this.custKey = custKey;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}