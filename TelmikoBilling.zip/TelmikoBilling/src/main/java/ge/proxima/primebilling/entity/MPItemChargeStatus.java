package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum MPItemChargeStatus implements EnumClass<String> {

    NEW("NEW"),
    CHARGED("CHARGED");

    private String id;

    MPItemChargeStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static MPItemChargeStatus fromId(String id) {
        for (MPItemChargeStatus at : MPItemChargeStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}