package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum MPItemDevideType implements EnumClass<String> {

    PERCENT("PERCENT"),
    EXPENSE("EXPENSE"),
    OVER("OVER"),
    CURRENTOVER("CURRENTOVER");

    private String id;

    MPItemDevideType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static MPItemDevideType fromId(String id) {
        for (MPItemDevideType at : MPItemDevideType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}