package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum MessageTemplateFor implements EnumClass<String> {

    EMAIL("EMAIL"),
    PHONE("PHONE");

    private String id;

    MessageTemplateFor(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static MessageTemplateFor fromId(String id) {
        for (MessageTemplateFor at : MessageTemplateFor.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}