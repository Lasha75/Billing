package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum NonCircularAccrualStatus implements EnumClass<String> {

    CHARGED("CHARGED"),
    TO_BE_CHARGED("TO_BE_CHARGED");

    private String id;

    NonCircularAccrualStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static NonCircularAccrualStatus fromId(String id) {
        for (NonCircularAccrualStatus at : NonCircularAccrualStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}