package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum NonCircularTransactionStatus implements EnumClass<String> {

    NEW("NEW"),
    ACCRUABLE("ACCRUABLE"),
    ACCRUED("ACCRUED"),
    CANCELED("CANCELED"),
    RETURNED_TO_TELASI("RETURNED_TO_TELASI"),
    PROBLEMATIC("PROBLEMATIC"),
    USED("USED");

    private String id;

    NonCircularTransactionStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static NonCircularTransactionStatus fromId(String id) {
        for (NonCircularTransactionStatus at : NonCircularTransactionStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}