package ge.proxima.primebilling.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import java.math.BigDecimal;
import java.util.UUID;

@JmixEntity(name = "prx_OneCAccountTMP")
public class OneCAccountTMP {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private BigDecimal operationKey;


    private String operationName;

    private BigDecimal kvt;

    private Integer period;


    private BigDecimal amount;

    private String category;

    private Integer year;

    private String debitAccount;

    private String creditAmount;

    private String vatCode;

    private String newCatgory;

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCategory() {
        return category;
    }

    public String getOperationName() {
        return operationName;
    }

    public void setOperationName(String operationName) {
        this.operationName = operationName;
    }

    public String getNewCatgory() {
        return newCatgory;
    }

    public void setNewCatgory(String newCatgory) {
        this.newCatgory = newCatgory;
    }

    public String getVatCode() {
        return vatCode;
    }

    public void setVatCode(String vatCode) {
        this.vatCode = vatCode;
    }

    public String getCreditAmount() {
        return creditAmount;
    }

    public void setCreditAmount(String creditAmount) {
        this.creditAmount = creditAmount;
    }

    public String getDebitAccount() {
        return debitAccount;
    }

    public void setDebitAccount(String debitAccount) {
        this.debitAccount = debitAccount;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Integer getPeriod() {
        return period;
    }

    public void setPeriod(Integer period) {
        this.period = period;
    }

    public BigDecimal getKvt() {
        return kvt;
    }

    public void setKvt(BigDecimal kvt) {
        this.kvt = kvt;
    }

    public BigDecimal getOperationKey() {
        return operationKey;
    }

    public void setOperationKey(BigDecimal operationKey) {
        this.operationKey = operationKey;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}