package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum OverdueDepositNotificationStatus implements EnumClass<String> {

    NEW("NEW"),
    SENT("SENT"),
    CANCELED("CANCELED");

    private String id;

    OverdueDepositNotificationStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static OverdueDepositNotificationStatus fromId(String id) {
        for (OverdueDepositNotificationStatus at : OverdueDepositNotificationStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}