package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.DepositNotificationType;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_OVERDUE_DEPOSIT_NOTIFICATIONS", indexes = {
        @Index(name = "IDX_PRX_OVERDUE_DEPOSIT_NOTIFICATIONS_CUST_NUMBER", columnList = "CUST_NUMBER_ID")
})
@Entity(name = "prx_OverdueDepositNotifications")
public class OverdueDepositNotifications {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "CUST_NUMBER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer custNumber;

    @Column(name = "OVERDUE_DATE")
    @Temporal(TemporalType.DATE)
    private Date overdueDate;

    @Column(name = "OPERATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date operationDate;

    @Column(name = "SMS_TEXT_GEO", length = 500)
    private String smsTextGEO;

    @Column(name = "SMS_TEXT_ENG", length = 500)
    private String smsTextENG;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "PHONE_NUMBER")
    private String phoneNumber;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "TYPE_")
    private String type;

    public DepositNotificationType getType() {
        return type == null ? null : DepositNotificationType.fromId(type);
    }

    public void setType(DepositNotificationType type) {
        this.type = type == null ? null : type.getId();
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Date getOverdueDate() {
        return overdueDate;
    }

    public void setOverdueDate(Date overdueDate) {
        this.overdueDate = overdueDate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public OverdueDepositNotificationStatus getStatus() {
        return status == null ? null : OverdueDepositNotificationStatus.fromId(status);
    }

    public void setStatus(OverdueDepositNotificationStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public String getSmsTextENG() {
        return smsTextENG;
    }

    public void setSmsTextENG(String smsTextENG) {
        this.smsTextENG = smsTextENG;
    }

    public String getSmsTextGEO() {
        return smsTextGEO;
    }

    public void setSmsTextGEO(String smsTextGEO) {
        this.smsTextGEO = smsTextGEO;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public Customer getCustNumber() {
        return custNumber;
    }

    public void setCustNumber(Customer custNumber) {
        this.custNumber = custNumber;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}