package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_PAYMENT", indexes = {
        @Index(name = "IDX_PAYMENT_CUSTOMER_ID", columnList = "CUSTOMER_ID")
})
@Entity(name = "prx_Payment")
public class Payment {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "COMMENT_", length = 1023)
    private String comment;

    @Column(name = "IMPORTED_NUMBER", length = 40)
    private String importedNumber;

    @Column(name = "TELASI_SETTLE")
    private Boolean telasiSettle;

    @Column(name = "TELASI_SETTLE_DONE")
    private Boolean telasiSettleDone;

    @Column(name = "IN_TELASI")
    private Boolean inTelasi;

    @Column(name = "TELASI_STATUS")
    private Boolean telasiStatus;

    @Column(name = "PAYMENT_CREATE_TIME")
    private LocalDateTime paymentCreateTime;

    @Column(name = "IS_ONLINE")
    private Boolean isOnline;

    @Column(name = "IS_SPLIT")
    private Boolean isSplit;

    @Column(name = "IS_TRANSACTION")
    private Boolean isTransaction;

    @Column(name = "SETTLEMENT_RUNED")
    private Boolean settlementRuned;

    @Column(name = "INTERNAL_BANK_ID", length = 50)
    private String internalBankId;

    @Column(name = "AMOUNT_RETURN_DATE")
    @Temporal(TemporalType.DATE)
    private Date amountReturnDate;

    @Column(name = "ACCOUNTANT_APPROVE_DATE")
    @Temporal(TemporalType.DATE)
    private Date accountantApproveDate;


    @Column(name = "APPROVED_RETURN")
    private Boolean approvedReturn;

    @Column(name = "CUSTOMER_NUMBER", length = 30)
    private String customerNumber;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "PAYMENT_DATE")
    @Temporal(TemporalType.DATE)
    private Date paymentDate;

    @Column(name = "PAYMENT_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date paymentDateTime;

    @Column(name = "SENDER_NAME", length = 100)
    private String senderName;

    @Column(name = "SENDER_IDENTIFICATION", length = 30)
    private String senderIdentification;

    @Column(name = "CREATE_DATE")
    @Temporal(TemporalType.DATE)
    private Date createDate;

    @Column(name = "CREATE_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDateTime;

    @Column(name = "AVISO_DATE")
    @Temporal(TemporalType.DATE)
    private Date avisoDate;

    @Column(name = "SENDER_BANK_ACCOUNT", length = 100)
    private String senderBankAccount;

    @Column(name = "SENDER_BANK_CODE", length = 40)
    private String senderBankCode;

    @Column(name = "SENDER_BANK_NAME", length = 50)
    private String senderBankName;

    @Column(name = "TRANFER_PURPOSE", length = 500)
    private String tranferPurpose;

    @Column(name = "ADDITIONAL_INFO", length = 300)
    private String additionalInfo;

    @Column(name = "BANK_ID", length = 100)
    private String bankId;

    @Column(name = "CHANNEL_ID", length = 100)
    private String channelId;

    @Column(name = "PAYMENT_ID", length = 100)
    private String paymentId;

    @Column(name = "TRANSACTION_ID", length = 30)
    private String transactionId;

    @Column(name = "DOCUMENT_ID", length = 30)
    private String documentId;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "TELASI_AMOUNT", precision = 19, scale = 2)
    private BigDecimal telasiAmount;

    @Column(name = "TELMICO_AMOUNT", precision = 19, scale = 2)
    private BigDecimal telmicoAmount;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "BANK_ACCOUNT")
    private String bankAccount;

    public Boolean getTelasiStatus() {
        return telasiStatus;
    }

    public void setTelasiStatus(Boolean telasiStatus) {
        this.telasiStatus = telasiStatus;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Boolean getTelasiSettleDone() {
        return telasiSettleDone;
    }

    public void setTelasiSettleDone(Boolean telasiSettleDone) {
        this.telasiSettleDone = telasiSettleDone;
    }

    public Boolean getTelasiSettle() {
        return telasiSettle;
    }

    public void setTelasiSettle(Boolean telasiSettle) {
        this.telasiSettle = telasiSettle;
    }

    public String getImportedNumber() {
        return importedNumber;
    }

    public void setImportedNumber(String importedNumber) {
        this.importedNumber = importedNumber;
    }

    public Boolean getInTelasi() {
        return inTelasi;
    }

    public void setInTelasi(Boolean inTelasi) {
        this.inTelasi = inTelasi;
    }

    public LocalDateTime getPaymentCreateTime() {
        return paymentCreateTime;
    }

    public void setPaymentCreateTime(LocalDateTime paymentCreateTime) {
        this.paymentCreateTime = paymentCreateTime;
    }

    public Boolean getIsOnline() {
        return isOnline;
    }

    public void setIsOnline(Boolean isOnline) {
        this.isOnline = isOnline;
    }

    public Boolean getIsTransaction() {
        return isTransaction;
    }

    public void setIsTransaction(Boolean isTransaction) {
        this.isTransaction = isTransaction;
    }

    public Boolean getIsSplit() {
        return isSplit;
    }

    public void setIsSplit(Boolean isSplit) {
        this.isSplit = isSplit;
    }

    public Boolean getSettlementRuned() {
        return settlementRuned;
    }

    public void setSettlementRuned(Boolean settlementRuned) {
        this.settlementRuned = settlementRuned;
    }

    public Date getCreateDateTime() {
        return createDateTime;
    }

    public void setCreateDateTime(Date createDateTime) {
        this.createDateTime = createDateTime;
    }

    public Date getPaymentDateTime() {
        return paymentDateTime;
    }

    public void setPaymentDateTime(Date paymentDateTime) {
        this.paymentDateTime = paymentDateTime;
    }

    public Date getAvisoDate() {
        return avisoDate;
    }

    public void setAvisoDate(Date avisoDate) {
        this.avisoDate = avisoDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Boolean getApprovedReturn() {
        return approvedReturn;
    }

    public void setApprovedReturn(Boolean approvedReturn) {
        this.approvedReturn = approvedReturn;
    }

    public Date getAccountantApproveDate() {
        return accountantApproveDate;
    }

    public void setAccountantApproveDate(Date accountantApproveDate) {
        this.accountantApproveDate = accountantApproveDate;
    }

    public Date getAmountReturnDate() {
        return amountReturnDate;
    }

    public void setAmountReturnDate(Date amountReturnDate) {
        this.amountReturnDate = amountReturnDate;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getTranferPurpose() {
        return tranferPurpose;
    }

    public void setTranferPurpose(String tranferPurpose) {
        this.tranferPurpose = tranferPurpose;
    }

    public String getSenderBankName() {
        return senderBankName;
    }

    public void setSenderBankName(String senderBankName) {
        this.senderBankName = senderBankName;
    }

    public String getSenderBankCode() {
        return senderBankCode;
    }

    public void setSenderBankCode(String senderBankCode) {
        this.senderBankCode = senderBankCode;
    }

    public String getSenderBankAccount() {
        return senderBankAccount;
    }

    public void setSenderBankAccount(String senderBankAccount) {
        this.senderBankAccount = senderBankAccount;
    }

    public String getSenderIdentification() {
        return senderIdentification;
    }

    public void setSenderIdentification(String senderIdentification) {
        this.senderIdentification = senderIdentification;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public BigDecimal getTelmicoAmount() {
        return telmicoAmount;
    }

    public void setTelmicoAmount(BigDecimal telmicoAmount) {
        this.telmicoAmount = telmicoAmount;
    }

    public BigDecimal getTelasiAmount() {
        return telasiAmount;
    }

    public void setTelasiAmount(BigDecimal telasiAmount) {
        this.telasiAmount = telasiAmount;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getInternalBankId() {
        return internalBankId;
    }

    public void setInternalBankId(String internalBankId) {
        this.internalBankId = internalBankId;
    }

    public PaymentStatus getStatus() {
        return status == null ? null : PaymentStatus.fromId(status);
    }

    public void setStatus(PaymentStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"amount", "senderName"})
    public String getInstanceName() {
        return String.format("%s %s", amount, senderName);
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }
}