package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerContractType;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_PAYMENT_DETAIL", indexes = {
        @Index(name = "IDX_PRXPAYMENTDETAIL_CUSTOMER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRX_PAYMENT_DETAIL_PAYMENT", columnList = "PAYMENT_ID"),
        @Index(name = "IDX_PRXPAYMENTDETA_ACCOUNTTYPE", columnList = "ACCOUNT_TYPE_ID"),
        @Index(name = "IDX_PRXPAYMENTDE_TRANSTYPECOM", columnList = "TRANS_TYPE_COMBINATION_ID")
})
@Entity(name = "prx_PaymentDetail")
public class PaymentDetail {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "SETTLE_DATE")
    @Temporal(TemporalType.DATE)
    private Date settleDate;

    @Column(name = "CONNECTED_ID")
    private UUID connectedId;

    @Column(name = "OPEN_TRANS_ID")
    private UUID openTransId;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @JoinColumn(name = "PAYMENT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Payment payment;

    @JoinColumn(name = "ACCOUNT_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType accountType;

    @JoinColumn(name = "TRANS_TYPE_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination transTypeCombination;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    public UUID getOpenTransId() {
        return openTransId;
    }

    public void setOpenTransId(UUID openTransId) {
        this.openTransId = openTransId;
    }

    public UUID getConnectedId() {
        return connectedId;
    }

    public void setConnectedId(UUID connectedId) {
        this.connectedId = connectedId;
    }

    public Date getSettleDate() {
        return settleDate;
    }

    public void setSettleDate(Date settleDate) {
        this.settleDate = settleDate;
    }

    public TransactionTypeCombination getTransTypeCombination() {
        return transTypeCombination;
    }

    public void setTransTypeCombination(TransactionTypeCombination transTypeCombination) {
        this.transTypeCombination = transTypeCombination;
    }

    public CustomerContractType getAccountType() {
        return accountType;
    }

    public void setAccountType(CustomerContractType accountType) {
        this.accountType = accountType;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}