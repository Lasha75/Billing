package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum PaymentStatus implements EnumClass<String> {

    SHADOW("SHADOW"),
    APPROVED("APPROVED"),
    CANCELED("CANCELED"),
    UNCERTAIN("UNCERTAIN"),
    DELETED("DELETED"),
    RETURNED("RETURNED");

    private String id;

    PaymentStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static PaymentStatus fromId(String id) {
        for (PaymentStatus at : PaymentStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}