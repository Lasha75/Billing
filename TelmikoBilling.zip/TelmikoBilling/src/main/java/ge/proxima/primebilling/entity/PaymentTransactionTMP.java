package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_PaymentTransactionTMP")
public class PaymentTransactionTMP {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private String paymentDocumentNumber;

    @NotNull
    private Customer customer;

    @JmixProperty(mandatory = true)
    @NotNull
    private BigDecimal amount;

    private String note;

    @Temporal(TemporalType.DATE)
    @NotNull
    @JmixProperty(mandatory = true)
    private Date operationDate;

    public String getPaymentDocumentNumber() {
        return paymentDocumentNumber;
    }

    public void setPaymentDocumentNumber(String paymentDocumentNumber) {
        this.paymentDocumentNumber = paymentDocumentNumber;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Customer getCustomer() {
        return customer;
    }


    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}