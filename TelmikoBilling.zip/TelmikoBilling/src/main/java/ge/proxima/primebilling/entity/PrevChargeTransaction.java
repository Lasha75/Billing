package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_PREV_CHARGE_TRANSACTION", indexes = {
        @Index(name = "IDX_PRX_PREV_CHARGE_TRANSACTION_TRANS_TYPE_COMBINATION", columnList = "TRANS_TYPE_COMBINATION_ID")
})
@Entity(name = "prx_PrevChargeTransaction")
public class PrevChargeTransaction {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "TRANS_TYPE_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination transTypeCombination;

    public TransactionTypeCombination getTransTypeCombination() {
        return transTypeCombination;
    }

    public void setTransTypeCombination(TransactionTypeCombination transTypeCombination) {
        this.transTypeCombination = transTypeCombination;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}