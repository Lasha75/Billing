package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum RectMessageEmailStatus implements EnumClass<String> {

    DRAFT("DRAFT"),
    SENDED("SENDED"),
    ERROR("ERROR");

    private String id;

    RectMessageEmailStatus(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static RectMessageEmailStatus fromId(String id) {
        for (RectMessageEmailStatus at : RectMessageEmailStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}