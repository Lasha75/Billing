package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_REP_CON_TURN_OVER_BY_MONTH", indexes = {
        @Index(name = "IDX_PRXREPCONTURNO_COMBINATION", columnList = "COMBINATION_ID")
})
@Entity(name = "prx_RepConTurnOverByMonth")
public class RepConTurnOverByMonth {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "COMBINATION_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private TransactionTypeCombination combination;

    @Column(name = "GROUP_CODE")
    private String groupCode;

    @Column(name = "USE_MAIN_REPORT")
    private Boolean useMainReport;

    @Column(name = "USE_ADD29")
    private Boolean useAdd29;

    @Column(name = "USE_ADD30")
    private Boolean useAdd30;

    @Column(name = "USE_ADD31")
    private Boolean useAdd31;

    @Column(name = "USE_ADD32")
    private Boolean useAdd32;

    @Column(name = "USE_ADD33")
    private Boolean useAdd33;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public void setUseAdd30(Boolean useAdd30) {
        this.useAdd30 = useAdd30;
    }

    public Boolean getUseAdd30() {
        return useAdd30;
    }

    public Boolean getUseAdd33() {
        return useAdd33;
    }

    public void setUseAdd33(Boolean useAdd33) {
        this.useAdd33 = useAdd33;
    }

    public Boolean getUseAdd32() {
        return useAdd32;
    }

    public void setUseAdd32(Boolean useAdd32) {
        this.useAdd32 = useAdd32;
    }

    public Boolean getUseAdd31() {
        return useAdd31;
    }

    public void setUseAdd31(Boolean useAdd31) {
        this.useAdd31 = useAdd31;
    }

    public Boolean getUseAdd29() {
        return useAdd29;
    }

    public void setUseAdd29(Boolean useAdd29) {
        this.useAdd29 = useAdd29;
    }

    public Boolean getUseMainReport() {
        return useMainReport;
    }

    public void setUseMainReport(Boolean useMainReport) {
        this.useMainReport = useMainReport;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public TransactionTypeCombination getCombination() {
        return combination;
    }

    public void setCombination(TransactionTypeCombination combination) {
        this.combination = combination;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}