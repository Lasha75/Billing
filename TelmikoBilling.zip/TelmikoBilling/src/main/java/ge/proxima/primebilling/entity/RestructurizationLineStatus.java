package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum RestructurizationLineStatus implements EnumClass<String> {

    ACTIVE("ACTIVE"),
    FINISHED("FINISHED"),
    NON_ACTIVE("NON_ACTIVE");

    private String id;

    RestructurizationLineStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static RestructurizationLineStatus fromId(String id) {
        for (RestructurizationLineStatus at : RestructurizationLineStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}