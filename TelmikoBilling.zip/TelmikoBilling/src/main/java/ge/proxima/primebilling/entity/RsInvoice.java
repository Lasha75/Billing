package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.InvoiceType;
import ge.proxima.primebilling.entity.invoice.InvoiceStatus;
import io.jmix.core.DeletePolicy;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDelete;
import io.jmix.core.metamodel.annotation.*;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_RS_INVOICE", indexes = {
        @Index(name = "IDX_PRX_RS_INVOICE_CUSTOMER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRX_RS_INVOICE_STATUS", columnList = "STATUS_ID"),
        @Index(name = "IDX_PRX_RS_INVOICE", columnList = "AMOUNT, INVOICE_ID"),
        @Index(name = "IDX_PRX_RS_INVOICE_1", columnList = "INVOICE_YEAR")
})
@Entity(name = "prx_RsInvoice")
public class RsInvoice {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @NotNull
    @Column(name = "CODE", nullable = false)
    private String code;

    @NotNull
    @Column(name = "INVOICE_DATE", nullable = false)
    private LocalDate invoiceDate;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "IDENTIFICATION_NUMBER", length = 20)
    private String identificationNumber;

    @Column(name = "NAME")
    private String name;

    @NotNull
    @JoinColumn(name = "STATUS_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private InvoiceStatus status;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "TYPE_", length = 60)
    private String type;

    @Column(name = "INVOICE_SERIAS", length = 20)
    private String invoiceSerias;

    @Column(name = "INVOICE_NUMBER", length = 20)
    private String invoiceNumber;

    @NotNull
    @NumberFormat(pattern = "###########")
    @Column(name = "INVOICE_ID", nullable = false)
    private Long invoiceId;

    @OnDelete(DeletePolicy.CASCADE)
    @Composition
    @OneToMany(mappedBy = "rsInvoice")
    private List<RsInvoiceTransaction> rsInvoiceTransaction;

    @OnDelete(DeletePolicy.CASCADE)
    @Composition
    @OneToMany(mappedBy = "rsInvoiceHeader")
    private List<RsInvoiceLine> lines;

    @Column(name = "NUMBER_", length = 20)
    private String number;

    @NumberFormat(pattern = "#")
    @Column(name = "SEQUENCE")
    private Integer sequence;

    @NotNull
    @NumberFormat(pattern = "####")
    @Column(name = "INVOICE_YEAR", nullable = false)
    private Integer invoiceYear;

    @NotNull
    @NumberFormat(pattern = "##")
    @Column(name = "INVOICE_MONTH", nullable = false)
    private Integer invoiceMonth;

    @NumberFormat(pattern = "###########")
    @Column(name = "CORRECTION_OF_INVOICE_ID")
    private Long correctionOfInvoiceId;

    @Column(name = "RS_COMMENT")
    @Lob
    private String rsComment;

    @Column(name = "RS_STATUS")
    private Boolean rsStatus;

    @Column(name = "IS_CLOSED")
    private Boolean isClosed;

    @Column(name = "IS_PROCESSED")
    private Boolean isProcessed;

    @Column(name = "K_TYPE")
    private Integer kType;

    @Column(name = "K_ID")
    private Integer kId;

    @Column(name = "REG_DATE")
    @Temporal(TemporalType.DATE)
    private Date regDate;

    @Column(name = "OPERATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date operationDate;

    @Column(name = "DEC_SATUS")
    private Integer decSatus;

    @Column(name = "DEC_NUMBER")
    private String decNumber;

    @Column(name = "RS_INVOICE_QTY_IN_PERIOD")
    private Integer rsInvoiceQtyInPeriod;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdentificationNumber() {
        return identificationNumber;
    }

    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }

    public Integer getRsInvoiceQtyInPeriod() {
        return rsInvoiceQtyInPeriod;
    }

    public void setRsInvoiceQtyInPeriod(Integer rsInvoiceQtyInPeriod) {
        this.rsInvoiceQtyInPeriod = rsInvoiceQtyInPeriod;
    }

    public String getDecNumber() {
        return decNumber;
    }

    public void setDecNumber(String decNumber) {
        this.decNumber = decNumber;
    }

    public Integer getDecSatus() {
        return decSatus;
    }

    public void setDecSatus(Integer decSatus) {
        this.decSatus = decSatus;
    }

    public Boolean getIsProcessed() {
        return isProcessed;
    }

    public void setIsProcessed(Boolean isProcessed) {
        this.isProcessed = isProcessed;
    }

    public Integer getKId() {
        return kId;
    }

    public void setKId(Integer kId) {
        this.kId = kId;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }

    public Integer getKType() {
        return kType;
    }

    public void setKType(Integer kType) {
        this.kType = kType;
    }

    public Boolean getIsClosed() {
        return isClosed;
    }

    public void setIsClosed(Boolean isClosed) {
        this.isClosed = isClosed;
    }

    public Boolean getRsStatus() {
        return rsStatus;
    }

    public void setRsStatus(Boolean rsStatus) {
        this.rsStatus = rsStatus;
    }

    public String getRsComment() {
        return rsComment;
    }

    public void setRsComment(String rsComment) {
        this.rsComment = rsComment;
    }

    public Long getCorrectionOfInvoiceId() {
        return correctionOfInvoiceId;
    }

    public void setCorrectionOfInvoiceId(Long correctionOfInvoiceId) {
        this.correctionOfInvoiceId = correctionOfInvoiceId;
    }

    public Integer getInvoiceMonth() {
        return invoiceMonth;
    }

    public void setInvoiceMonth(Integer invoiceMonth) {
        this.invoiceMonth = invoiceMonth;
    }

    public Integer getInvoiceYear() {
        return invoiceYear;
    }

    public void setInvoiceYear(Integer invoiceYear) {
        this.invoiceYear = invoiceYear;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public List<RsInvoiceLine> getLines() {
        return lines;
    }

    public void setLines(List<RsInvoiceLine> lines) {
        this.lines = lines;
    }

    public List<RsInvoiceTransaction> getRsInvoiceTransaction() {
        return rsInvoiceTransaction;
    }

    public void setRsInvoiceTransaction(List<RsInvoiceTransaction> rsInvoiceTransaction) {
        this.rsInvoiceTransaction = rsInvoiceTransaction;
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public String getInvoiceSerias() {
        return invoiceSerias;
    }

    public void setInvoiceSerias(String invoiceSerias) {
        this.invoiceSerias = invoiceSerias;
    }

    public InvoiceType getType() {
        return type == null ? null : InvoiceType.fromId(type);
    }

    public void setType(InvoiceType type) {
        this.type = type == null ? null : type.getId();
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public InvoiceStatus getStatus() {
        return status;
    }

    public void setStatus(InvoiceStatus status) {
        this.status = status;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public LocalDate getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(LocalDate invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PostConstruct
    public void postConstruct() {
        setIsClosed(false);
        setRsStatus(false);
        setIsProcessed(false);
        setInvoiceId(0L);
    }

    @InstanceName
    @DependsOnProperties({"code", "invoiceSerias", "invoiceYear"})
    public String getInstanceName() {
        return String.format("%s %s %s", code, invoiceSerias, invoiceYear);
    }
}