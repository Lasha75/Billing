package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.NumberFormat;
import io.jmix.data.DbView;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.UUID;

@DbView
@JmixEntity
@Table(name = "PRX_RS_INVOICE_CALC", indexes = {
        @Index(name = "IDX_PRXRSINVOICECALC_CUSTOMER", columnList = "CUSTOMER_ID")
})
@Entity(name = "prx_RsInvoiceCalc")
public class RsInvoiceCalc {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "NUMBER", length = 20)
    private String number;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "KILOWATHOUR", precision = 19, scale = 2)
    private BigDecimal kilowathour;

    @Column(name = "INVOICEYEAR")
    private Integer invoiceyear;

    @NumberFormat(pattern = "####")
    @Column(name = "INVOICEMONTH")
    private Integer invoicemonth;

    @Column(name = "EXSISTRSINVOICE")
    private Boolean exsistrsinvoice;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Boolean getExsistrsinvoice() {
        return exsistrsinvoice;
    }

    public void setExsistrsinvoice(Boolean existrsinvoice) {
        this.exsistrsinvoice = existrsinvoice;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Integer getInvoicemonth() {
        return invoicemonth;
    }

    public void setInvoicemonth(Integer invoicemonth) {
        this.invoicemonth = invoicemonth;
    }

    public BigDecimal getKilowathour() {
        return kilowathour;
    }

    public void setKilowathour(BigDecimal kilowathour) {
        this.kilowathour = kilowathour;
    }

    public Integer getInvoiceyear() {
        return invoiceyear;
    }

    public void setInvoiceyear(Integer invoiceyear) {
        this.invoiceyear = invoiceyear;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

}