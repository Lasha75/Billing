package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum RsInvoiceTempCategory implements EnumClass<String> {

    INDIVIDUAL("INDIVIDUAL"),
    SUMMARY("SUMMARY");

    private String id;

    RsInvoiceTempCategory(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static RsInvoiceTempCategory fromId(String id) {
        for (RsInvoiceTempCategory at : RsInvoiceTempCategory.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}