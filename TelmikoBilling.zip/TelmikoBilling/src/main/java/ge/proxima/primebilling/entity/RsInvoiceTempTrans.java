package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.transactions.Transaction;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.NumberFormat;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_RS_INVOICE_TEMP_TRANS", indexes = {
        @Index(name = "IDX_PRXRSINVOICETE_TRANSACTION", columnList = "TRANSACTION_ID"),
        @Index(name = "IDX_PRXRSINVOICETEMPT_CUSTOMER", columnList = "CUSTOMER_ID")
})
@Entity(name = "prx_RsInvoiceTempTrans")
public class RsInvoiceTempTrans {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "TRANSACTION_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Transaction transaction;

    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @NumberFormat(pattern = "####")
    @Column(name = "YEAR_")
    private Integer year;

    @NumberFormat(pattern = "####")
    @Column(name = "MONTH_")
    private Integer month;

    @Column(name = "INVOICE_DATE")
    private LocalDate invoiceDate;

    @Column(name = "OPERATION_DATE")
    private LocalDate operationDate;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "KILOWATT_HOUR", precision = 19, scale = 2)
    private BigDecimal kilowattHour;

    @Column(name = "TRANSACTION_TYPE")
    private String transactionType;

    @Column(name = "CATEGORY")
    private String category;

    public RsInvoiceTempCategory getCategory() {
        return category == null ? null : RsInvoiceTempCategory.fromId(category);
    }

    public void setCategory(RsInvoiceTempCategory category) {
        this.category = category == null ? null : category.getId();
    }

    public RsInvoiceTempType getTransactionType() {
        return transactionType == null ? null : RsInvoiceTempType.fromId(transactionType);
    }

    public void setTransactionType(RsInvoiceTempType transactionType) {
        this.transactionType = transactionType == null ? null : transactionType.getId();
    }

    public BigDecimal getKilowattHour() {
        return kilowattHour;
    }

    public void setKilowattHour(BigDecimal kilowattHour) {
        this.kilowattHour = kilowattHour;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public LocalDate getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(LocalDate operationDate) {
        this.operationDate = operationDate;
    }

    public LocalDate getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(LocalDate invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}