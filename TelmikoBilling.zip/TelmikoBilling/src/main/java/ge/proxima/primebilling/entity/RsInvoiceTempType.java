package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum RsInvoiceTempType implements EnumClass<String> {

    CORRECTION("CORRECTION"),
    STANDARD("STANDARD");

    private String id;

    RsInvoiceTempType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static RsInvoiceTempType fromId(String id) {
        for (RsInvoiceTempType at : RsInvoiceTempType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}