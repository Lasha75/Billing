package ge.proxima.primebilling.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_RS_SELLER_INVOICE")
@Entity(name = "prx_RsSellerInvoice")
public class RsSellerInvoice {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "RS_ID")
    private String rsId;

    @Column(name = "F_SERIES")
    private String f_series;

    @Column(name = "F_NUMBER")
    private String f_number;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "SEQ_NUM_S")
    private String seq_num_s;

    @Column(name = "WAS_REF")
    private String was_ref;

    @Column(name = "REG_DT")
    private String reg_dt;

    @Column(name = "OPERATION_DT")
    private String operation_dt;

    @Column(name = "S_USER_ID")
    private String s_user_id;

    @Column(name = "SA_IDENT_NO")
    private String sa_ident_no;

    @Column(name = "DOC_MOS_NOM_S")
    private String doc_mos_nom_s;

    @Column(name = "ORG_NAME")
    private String org_name;

    @Column(name = "NOTES")
    private String notes;

    @Column(name = "TANXA")
    private String tanxa;

    @Column(name = "VAT")
    private String vat;

    @Column(name = "AGREE_DATE")
    private String agree_date;

    @Column(name = "AGREE_S_USER_ID")
    private String agree_s_user_id;

    @Column(name = "REF_DATE")
    private String ref_date;

    @Column(name = "REF_S_USER_ID")
    private String ref_s_user_id;

    @Column(name = "BUYER_UN_ID")
    private String buyer_un_id;

    public String getRsId() {
        return rsId;
    }

    public void setRsId(String rsId) {
        this.rsId = rsId;
    }

    public String getBuyer_un_id() {
        return buyer_un_id;
    }

    public void setBuyer_un_id(String buyer_un_id) {
        this.buyer_un_id = buyer_un_id;
    }

    public String getRef_s_user_id() {
        return ref_s_user_id;
    }

    public void setRef_s_user_id(String ref_s_user_id) {
        this.ref_s_user_id = ref_s_user_id;
    }

    public String getRef_date() {
        return ref_date;
    }

    public void setRef_date(String ref_date) {
        this.ref_date = ref_date;
    }

    public String getAgree_s_user_id() {
        return agree_s_user_id;
    }

    public void setAgree_s_user_id(String agree_s_user_id) {
        this.agree_s_user_id = agree_s_user_id;
    }

    public String getAgree_date() {
        return agree_date;
    }

    public void setAgree_date(String agree_date) {
        this.agree_date = agree_date;
    }

    public String getVat() {
        return vat;
    }

    public void setVat(String vat) {
        this.vat = vat;
    }

    public String getTanxa() {
        return tanxa;
    }

    public void setTanxa(String tanxa) {
        this.tanxa = tanxa;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getOrg_name() {
        return org_name;
    }

    public void setOrg_name(String org_name) {
        this.org_name = org_name;
    }

    public String getDoc_mos_nom_s() {
        return doc_mos_nom_s;
    }

    public void setDoc_mos_nom_s(String doc_mos_nom_s) {
        this.doc_mos_nom_s = doc_mos_nom_s;
    }

    public String getSa_ident_no() {
        return sa_ident_no;
    }

    public void setSa_ident_no(String sa_ident_no) {
        this.sa_ident_no = sa_ident_no;
    }

    public String getS_user_id() {
        return s_user_id;
    }

    public void setS_user_id(String s_user_id) {
        this.s_user_id = s_user_id;
    }

    public String getOperation_dt() {
        return operation_dt;
    }

    public void setOperation_dt(String operation_dt) {
        this.operation_dt = operation_dt;
    }

    public String getReg_dt() {
        return reg_dt;
    }

    public void setReg_dt(String reg_dt) {
        this.reg_dt = reg_dt;
    }

    public String getF_number() {
        return f_number;
    }

    public void setF_number(String f_number) {
        this.f_number = f_number;
    }

    public String getF_series() {
        return f_series;
    }

    public void setF_series(String f_series) {
        this.f_series = f_series;
    }

    public String getWas_ref() {
        return was_ref;
    }

    public void setWas_ref(String was_ref) {
        this.was_ref = was_ref;
    }

    public String getSeq_num_s() {
        return seq_num_s;
    }

    public void setSeq_num_s(String seq_num_s) {
        this.seq_num_s = seq_num_s;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}