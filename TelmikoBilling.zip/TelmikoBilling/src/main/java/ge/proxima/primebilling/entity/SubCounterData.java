package ge.proxima.primebilling.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import java.util.UUID;

@JmixEntity(name = "prx_SubCounterData")
public class SubCounterData {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private String customerNumber;

    private String custName;

    private String serialNumber;

    private String telasiAccId;

    public String getTelasiAccId() {
        return telasiAccId;
    }

    public void setTelasiAccId(String telasiAccId) {
        this.telasiAccId = telasiAccId;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}