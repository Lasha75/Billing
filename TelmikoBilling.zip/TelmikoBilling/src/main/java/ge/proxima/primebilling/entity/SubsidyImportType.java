package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum SubsidyImportType implements EnumClass<String> {

    SOCIAL_X7000("SOCIAL_X7000"),
    SOCIAL_X15000("SOCIAL_X15000"),
    MULTI_CHILD("MULTI_CHILD"),
    SUBSIDY_GWP("SUBSIDY_GWP"),
    SUBSIDY_CLEANUP("SUBSIDY_CLEANUP"),
    SUBSIDY_MAYOR("SUBSIDY_MAYOR");

    private String id;

    SubsidyImportType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static SubsidyImportType fromId(String id) {
        for (SubsidyImportType at : SubsidyImportType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}