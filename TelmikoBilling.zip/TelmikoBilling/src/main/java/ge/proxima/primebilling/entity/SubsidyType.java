package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum SubsidyType implements EnumClass<String> {

    SOCIAL("SOCIAL"),
    MULTI_CHILD("MULTI_CHILD"),
    MAYOR("MAYOR");

    private String id;

    SubsidyType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static SubsidyType fromId(String id) {
        for (SubsidyType at : SubsidyType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}