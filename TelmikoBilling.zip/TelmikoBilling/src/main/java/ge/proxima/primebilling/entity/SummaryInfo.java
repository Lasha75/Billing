package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.Customer;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_SUMMARY_INFO")
@Entity(name = "prx_SummaryInfo")
public class SummaryInfo {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "START_BAL", precision = 19, scale = 2)
    private BigDecimal startBal;

    @Column(name = "END_BAL", precision = 19, scale = 2)
    private BigDecimal endBal;

    @Column(name = "KWT", precision = 19, scale = 2)
    private BigDecimal kwt;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "GADAXDA", precision = 19, scale = 2)
    private BigDecimal gadaxda;

    @Column(name = "GADAXDA_CO", precision = 19, scale = 2)
    private BigDecimal gadaxdaCo;

    @Column(name = "SEGAVATI", precision = 19, scale = 2)
    private BigDecimal segavati;

    @Column(name = "SERVISI", precision = 19, scale = 2)
    private BigDecimal servisi;

    @Column(name = "KOMPENSACIA", precision = 19, scale = 2)
    private BigDecimal kompensacia;

    @Column(name = "VALIS_CODE", precision = 19, scale = 2)
    private BigDecimal valisCode;

    @Column(name = "TRANZ_KWT", precision = 19, scale = 2)
    private BigDecimal tranzKwt;

    @Column(name = "TRANZ_AMOUNT", precision = 19, scale = 2)
    private BigDecimal tranzAmount;

    @Column(name = "QSEL_AMOUNT", precision = 19, scale = 2)
    private BigDecimal qselAmount;

    @Column(name = "SUMMARY_DATE")
    @Temporal(TemporalType.DATE)
    private Date summaryDate;

    public Date getSummaryDate() {
        return summaryDate;
    }

    public void setSummaryDate(Date summaryDate) {
        this.summaryDate = summaryDate;
    }

    public BigDecimal getQselAmount() {
        return qselAmount;
    }

    public void setQselAmount(BigDecimal qselAmount) {
        this.qselAmount = qselAmount;
    }

    public BigDecimal getTranzAmount() {
        return tranzAmount;
    }

    public void setTranzAmount(BigDecimal tranzAmount) {
        this.tranzAmount = tranzAmount;
    }

    public BigDecimal getTranzKwt() {
        return tranzKwt;
    }

    public void setTranzKwt(BigDecimal tranzKwt) {
        this.tranzKwt = tranzKwt;
    }

    public BigDecimal getValisCode() {
        return valisCode;
    }

    public void setValisCode(BigDecimal valisCode) {
        this.valisCode = valisCode;
    }

    public BigDecimal getKompensacia() {
        return kompensacia;
    }

    public void setKompensacia(BigDecimal kompensacia) {
        this.kompensacia = kompensacia;
    }

    public BigDecimal getServisi() {
        return servisi;
    }

    public void setServisi(BigDecimal servisi) {
        this.servisi = servisi;
    }

    public BigDecimal getSegavati() {
        return segavati;
    }

    public void setSegavati(BigDecimal segavati) {
        this.segavati = segavati;
    }

    public BigDecimal getGadaxdaCo() {
        return gadaxdaCo;
    }

    public void setGadaxdaCo(BigDecimal gadaxdaCo) {
        this.gadaxdaCo = gadaxdaCo;
    }

    public BigDecimal getGadaxda() {
        return gadaxda;
    }

    public void setGadaxda(BigDecimal gadaxda) {
        this.gadaxda = gadaxda;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getKwt() {
        return kwt;
    }

    public void setKwt(BigDecimal kwt) {
        this.kwt = kwt;
    }

    public BigDecimal getEndBal() {
        return endBal;
    }

    public void setEndBal(BigDecimal endBal) {
        this.endBal = endBal;
    }

    public BigDecimal getStartBal() {
        return startBal;
    }

    public void setStartBal(BigDecimal startBal) {
        this.startBal = startBal;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}