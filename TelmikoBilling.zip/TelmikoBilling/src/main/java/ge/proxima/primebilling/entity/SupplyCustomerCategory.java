package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum SupplyCustomerCategory implements EnumClass<String> {

    SAKOFACKHOVREBO("SAKOFACKHOVREBO"),
    ARASAKOFACKHOVREBO("ARASAKOFACKHOVREBO");

    private String id;

    SupplyCustomerCategory(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static SupplyCustomerCategory fromId(String id) {
        for (SupplyCustomerCategory at : SupplyCustomerCategory.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}