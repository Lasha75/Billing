package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum SupplyOwnership implements EnumClass<String> {

    OWNER("OWNER"),
    TEMPORARYUSE("TEMPORARYUSE");

    private String id;

    SupplyOwnership(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static SupplyOwnership fromId(String id) {
        for (SupplyOwnership at : SupplyOwnership.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}