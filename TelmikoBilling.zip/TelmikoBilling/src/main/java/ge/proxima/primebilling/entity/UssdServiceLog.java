package ge.proxima.primebilling.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_USSD_SERVICE_LOG")
@Entity(name = "prx_UssdServiceLog")
public class UssdServiceLog {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name = "REQUEST")
    private String request;

    @Column(name = "REQUEST_CUSTOMER_NUMBER", length = 30)
    private String requestCustomerNumber;

    @Column(name = "REQUEST_MOBILE", length = 30)
    private String requestMobile;

    @Column(name = "RESPONSE")
    private String response;

    @Column(name = "RESPONSE_DATE")
    @Temporal(TemporalType.DATE)
    private Date responseDate;

    @Column(name = "RESPONSE_BALANCE", precision = 19, scale = 2)
    private BigDecimal responseBalance;

    @Column(name = "ERROR_TEXT", length = 511)
    private String errorText;

    @Column(name = "RESPONSE_MESSAGE")
    @Lob
    private String responseMessage;

    @Column(name = "SUCCESS")
    private Boolean success;

    @Column(name = "METHOD_", length = 20)
    private String method;

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public String getErrorText() {
        return errorText;
    }

    public void setErrorText(String errorText) {
        this.errorText = errorText;
    }

    public BigDecimal getResponseBalance() {
        return responseBalance;
    }

    public void setResponseBalance(BigDecimal responseBalance) {
        this.responseBalance = responseBalance;
    }

    public Date getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(Date responseDate) {
        this.responseDate = responseDate;
    }

    public String getRequestMobile() {
        return requestMobile;
    }

    public void setRequestMobile(String requestMobile) {
        this.requestMobile = requestMobile;
    }

    public String getRequestCustomerNumber() {
        return requestCustomerNumber;
    }

    public void setRequestCustomerNumber(String requestCustomerNumber) {
        this.requestCustomerNumber = requestCustomerNumber;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}