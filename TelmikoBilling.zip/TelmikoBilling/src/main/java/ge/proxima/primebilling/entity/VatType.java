package ge.proxima.primebilling.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum VatType implements EnumClass<String> {

    VAT18("VAT 18%"),
    VAT0("VAT 0%"),
    VATEXEMPT("VAT Exempt");

    private String id;

    VatType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static VatType fromId(String id) {
        for (VatType at : VatType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}