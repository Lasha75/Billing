package ge.proxima.primebilling.entity;

import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.transactions.Transaction;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_VIEW_DETAIL_TRANSACTION", indexes = {
        @Index(name = "IDX_PRXVIEWDETAILT_TRANSACTION", columnList = "TRANSACTION_ID"),
        @Index(name = "IDX_PRXVIEWDETAILTRAN_CATEGORY", columnList = "CATEGORY_ID")
})
@Entity(name = "prx_ViewDetailTransaction")
public class ViewDetailTransaction {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "TARIFF_VALUE", precision = 19, scale = 7)
    private BigDecimal tariffValue;

    @Column(name = "VOLTAGE", length = 30)
    private String voltage;

    @Column(name = "KWT", precision = 19, scale = 2)
    private BigDecimal kwt;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "STEP")
    private Integer step;

    @JoinColumn(name = "TRANSACTION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Transaction transaction;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory category;

    public CustomerCategory getCategory() {
        return category;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public Integer getStep() {
        return step;
    }

    public void setStep(Integer step) {
        this.step = step;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getKwt() {
        return kwt;
    }

    public void setKwt(BigDecimal kwt) {
        this.kwt = kwt;
    }

    public String getVoltage() {
        return voltage;
    }

    public void setVoltage(String voltage) {
        this.voltage = voltage;
    }

    public BigDecimal getTariffValue() {
        return tariffValue;
    }

    public void setTariffValue(BigDecimal tariffValue) {
        this.tariffValue = tariffValue;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}