package ge.proxima.primebilling.entity.bill;

import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.counter.Counter;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.reftables.BusinessCenter;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_BILL", indexes = {
        @Index(name = "IDX_PRX_BILL_COUNTER", columnList = "COUNTER_ID"),
        @Index(name = "IDX_PRX_BILL_CUSTOMER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRX_BILL_BLOCK", columnList = "BLOCK_ID"),
        @Index(name = "IDX_PRX_BILL_prev", columnList = "CUSTOMER_ID, COUNTER_ID, BILL_CREATION_DATE"),
        @Index(name = "IDX_PRX_BILL_BUSINESS_CENTER", columnList = "BUSINESS_CENTER_ID"),
        @Index(name = "IDX_PRX_BILL", columnList = "CUSTOMER_ID, IN_TEL_DOC, GENERATION_ID")
})
@Entity(name = "prx_Bill")
public class Bill {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "DEPOSIT_TYPE", length = 100)
    private String depositType;

    @Column(name = "PREV_READING", precision = 19, scale = 2)
    private BigDecimal prevReading;

    @Column(name = "PREV_READING_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevReadingDate;

    @Column(name = "CURR_READING", precision = 19, scale = 2)
    private BigDecimal currReading;

    @Column(name = "CURR_KWT", precision = 19, scale = 2)
    private BigDecimal currKwt;

    @Column(name = "CURR_READING_DATE")
    private String currReadingDate;

    @Column(name = "CANCELED")
    private Boolean canceled;

    @Column(name = "GENERATION_ID", length = 100)
    private String generationId;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @Column(name = "MOVED_IN_TELASI_FOLDER")
    private Boolean movedInTelasiFolder;

    @Column(name = "BILL_PATH")
    private String billPath;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @Column(name = "PAYMENT_DATE")
    @Temporal(TemporalType.DATE)
    private Date paymentDate;

    @Column(name = "BILL_NUMBER")
    private String billNumber;

    @Temporal(TemporalType.DATE)
    @Column(name = "BILL_CREATION_DATE")
    private Date billCreationDate;

    @Column(name = "CUSTOMER_NUMBER", length = 30)
    private String customerNumber;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "PREV_BILL_ID")
    private UUID prevBillId;

    @Column(name = "CUSTOMER_FULL_NAME")
    private String customerFullName;

    @Column(name = "CUSTOMER_ADDRESS")
    private String customerAddress;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "ILLEGAL_USE_CHARGE_AMOUNT", precision = 19, scale = 2)
    private BigDecimal illegalUseChargeAmount;

    @Column(name = "RECORDING_KNOT_CHECK", precision = 19, scale = 2)
    private BigDecimal recordingKnotCheck;

    @JoinColumn(name = "COUNTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Counter counter;

    @Column(name = "ADVANCE_PAID_AMOUNT", precision = 19, scale = 2)
    private BigDecimal advancePaidAmount;

    @Column(name = "CURRENT_ACCRUAL", precision = 19, scale = 2)
    private BigDecimal currentAccrual;

    @Column(name = "PREVIOUS_AMOUNT", precision = 19, scale = 2)
    private BigDecimal previousAmount;

    @Column(name = "PREV_BILL_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevBillDate;

    @Column(name = "DEPOSIT_AMOUNT", precision = 19, scale = 2)
    private BigDecimal depositAmount;

    @Column(name = "CORRECTION_AMOUNT", precision = 19, scale = 2)
    private BigDecimal correctionAmount;

    @Column(name = "COUNTER_SERIAL_NUMBER", length = 30)
    private String counterSerialNumber;

    @Column(name = "COEFFICIENT", precision = 19, scale = 2)
    private BigDecimal coefficient;

    @Column(name = "TARIFF_VALUE", precision = 19, scale = 8)
    private BigDecimal tariffValue;

    @Column(name = "DATE_")
    @Temporal(TemporalType.DATE)
    private Date date;

    @Column(name = "READING_TYPE", length = 30)
    private String readingType;

    @Column(name = "READING", precision = 19, scale = 2)
    private BigDecimal reading;

    @Column(name = "KILOWATT", precision = 19, scale = 2)
    private BigDecimal kilowatt;

    @Column(name = "EXPENSE_AMOUNT_GEL", precision = 19, scale = 2)
    private BigDecimal expenseAmountGel;

    @Column(name = "PAYED_AMOUNT", precision = 19, scale = 2)
    private BigDecimal payedAmount;

    @Column(name = "SUPPLY_SERVICE_AMOUNT", precision = 19, scale = 2)
    private BigDecimal supplyServiceAmount;

    @Column(name = "DISTRIBUTION_SERVICE_AMOUNT", precision = 19, scale = 2)
    private BigDecimal distributionServiceAmount;

    @Column(name = "TRANSMISSION_SERVICE_AMOUNT")
    private String transmissionServiceAmount;

    @Column(name = "TRANSFER_SERVICE_AMOUNT", precision = 19, scale = 2)
    private BigDecimal transferServiceAmount;

    @Column(name = "PRINT_BILL")
    private Boolean printBill;

    @Column(name = "SUPPLY_RENEWAL_AMOUNT", precision = 19, scale = 2)
    private BigDecimal supplyRenewalAmount;

    @Column(name = "VAT", precision = 19, scale = 2)
    private BigDecimal vat;

    @Column(name = "SERVICE_QUALITY_COMPENSATION", precision = 19, scale = 2)
    private BigDecimal serviceQualityCompensation;

    @Column(name = "TELASI_SERVICE_QUALITY", precision = 19, scale = 2)
    private BigDecimal telasiServiceQuality;

    @Column(name = "REQUESTED_DEPOSIT", precision = 19, scale = 2)
    private BigDecimal requestedDeposit;

    @Column(name = "RESTRUCTURED_DEBT", precision = 19, scale = 2)
    private BigDecimal restructuredDebt;

    @Column(name = "CONTRACT_PENALTY", precision = 19, scale = 2)
    private BigDecimal contractPenalty;

    @Column(name = "HIGHLAND_SETTLEMENTS_SUBSIDY", precision = 19, scale = 2)
    private BigDecimal highlandSettlementsSubsidy;

    @Column(name = "TARIFF_SUBSIDY", precision = 19, scale = 2)
    private BigDecimal tariffSubsidy;

    @Column(name = "MULTICHILD_SUBSIDY", precision = 19, scale = 2)
    private BigDecimal multichildSubsidy;

    @Column(name = "OTHER", precision = 19, scale = 2)
    private BigDecimal other;

    @Column(name = "PREVIOUS_BILL_LEFT_AMOUNT", precision = 19, scale = 2)
    private BigDecimal previousBillLeftAmount;

    @Column(name = "NETWORK_DELIVERED_KILOWATT", precision = 19, scale = 2)
    private BigDecimal networkDeliveredKilowatt;

    @Column(name = "NETWORK_ACCESSION", precision = 19, scale = 2)
    private BigDecimal networkAccession;

    @Column(name = "DEDUCTED_KILOWATT", precision = 19, scale = 2)
    private BigDecimal deductedKilowatt;

    @Column(name = "IN_TEL_DOC")
    private Boolean inTelDoc;

    @Column(name = "POSITIVE_BALANCE_KILOWATT", precision = 19, scale = 2)
    private BigDecimal positiveBalanceKilowatt;

    @Column(name = "PURCHASED_ELECTRICITY_AMOUNT", precision = 19, scale = 2)
    private BigDecimal purchasedElectricityAmount;

    @Column(name = "DISPUTED_DEBT", precision = 19, scale = 2)
    private BigDecimal disputedDebt;

    @Column(name = "RESTRUCTURED_AMOUNT_LEFT", precision = 19, scale = 2)
    private BigDecimal restructuredAmountLeft;

    @Column(name = "LEFT_OLD_AMOUNT", precision = 19, scale = 2)
    private BigDecimal leftOldAmount;

    @Column(name = "OPERATOR_RESTRUCTURED_AMOUNT_LEFT", precision = 19, scale = 2)
    private BigDecimal operatorRestructuredAmountLeft;

    @Column(name = "OPERATOR_POWER_BALANCE", precision = 19, scale = 2)
    private BigDecimal operatorPowerBalance;

    @Column(name = "OPERATOR_CORRECTION_BALANCE", precision = 19, scale = 2)
    private BigDecimal operatorCorrectionBalance;

    @Column(name = "OPERATOR_COMPENSATION_BALANCE", precision = 19, scale = 2)
    private BigDecimal operatorCompensationBalance;

    @Column(name = "OPERATOR_ILLEGAL_BALANCE", precision = 19, scale = 2)
    private BigDecimal operatorIllegalBalance;

    @Column(name = "OPERATOR_COUNTER_CHECK_BALANCE", precision = 19, scale = 2)
    private BigDecimal operatorCounterCheckBalance;

    @Column(name = "OPERATOR_RESTRUCTURED_DEFT", precision = 19, scale = 2)
    private BigDecimal operatorRestructuredDeft;

    @Column(name = "OPERATOR_RESTRUCTURED_AMOUNT_LEFT_OLD", precision = 19, scale = 2)
    private BigDecimal operatorRestructuredAmountLeftOld;

    @Column(name = "OPERATOR_OLD_AMOUNT", precision = 19, scale = 2)
    private BigDecimal operatorOldAmount;

    @Column(name = "AVAILABLE_DEPOSIT", precision = 19, scale = 2)
    private BigDecimal availableDeposit;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @Column(name = "CATEGORY_AVG_KWT", precision = 19, scale = 2)
    private BigDecimal categoryAvgKwt;

    @Column(name = "CATEGORY_AVG_AMOUNT", precision = 19, scale = 2)
    private BigDecimal categoryAvgAmount;

    @Column(name = "SUPPLIER_NAME")
    private String supplierName;

    @Column(name = "SERVICE_CENTER_ADDRESS")
    private String serviceCenterAddress;

    @Column(name = "IDENTIFICATION_NUMBER", length = 30)
    private String identificationNumber;

    @Column(name = "WEBPAGE")
    private String webpage;

    @Column(name = "EMAIL", length = 30)
    private String email;

    @Column(name = "CALLCENTER")
    private String callcenter;

    @Column(name = "SUPPLIER_ACCOUNT_NUMBER")
    private String supplierAccountNumber;

    @Column(name = "SOCIAL_COMMISSIO_COMMENT", length = 511)
    private String socialCommissioComment;

    @Column(name = "COMMISSIO_COMMENT", length = 511)
    private String commissioComment;

    @Column(name = "AMOUNT_WITH_VAT", precision = 19, scale = 2)
    private BigDecimal amountWithVat;

    @Column(name = "KITOWATT_HOUR", precision = 19, scale = 2)
    private BigDecimal kitowattHour;

    @Column(name = "PREVIOUS_YEAR_AMOUNT_WITH_VAT", precision = 19, scale = 2)
    private BigDecimal previousYearAmountWithVat;

    @Column(name = "PREVIOUS_YEAR_KILIWATT_HOUR", precision = 19, scale = 2)
    private BigDecimal previousYearKiliwattHour;

    @JoinColumn(name = "BUSINESS_CENTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private BusinessCenter businessCenter;

    public String getDepositType() {
        return depositType;
    }

    public void setDepositType(String depositType) {
        this.depositType = depositType;
    }

    public BusinessCenter getBusinessCenter() {
        return businessCenter;
    }

    public void setBusinessCenter(BusinessCenter businessCenter) {
        this.businessCenter = businessCenter;
    }

    public String getBillPath() {
        return billPath;
    }

    public void setBillPath(String billPath) {
        this.billPath = billPath;
    }

    public Boolean getMovedInTelasiFolder() {
        return movedInTelasiFolder;
    }

    public void setMovedInTelasiFolder(Boolean movedInTelasiFolder) {
        this.movedInTelasiFolder = movedInTelasiFolder;
    }

    public BigDecimal getTelasiServiceQuality() {
        return telasiServiceQuality;
    }

    public void setTelasiServiceQuality(BigDecimal telasiServiceQuality) {
        this.telasiServiceQuality = telasiServiceQuality;
    }

    public BigDecimal getOperatorCounterCheckBalance() {
        return operatorCounterCheckBalance;
    }

    public void setOperatorCounterCheckBalance(BigDecimal operatorCounterCheckBalance) {
        this.operatorCounterCheckBalance = operatorCounterCheckBalance;
    }

    public BigDecimal getOperatorIllegalBalance() {
        return operatorIllegalBalance;
    }

    public void setOperatorIllegalBalance(BigDecimal operatorIllegalBalance) {
        this.operatorIllegalBalance = operatorIllegalBalance;
    }

    public BigDecimal getOperatorCompensationBalance() {
        return operatorCompensationBalance;
    }

    public void setOperatorCompensationBalance(BigDecimal operatorCompensationBalance) {
        this.operatorCompensationBalance = operatorCompensationBalance;
    }

    public BigDecimal getOperatorCorrectionBalance() {
        return operatorCorrectionBalance;
    }

    public void setOperatorCorrectionBalance(BigDecimal operatorCorrectionBalance) {
        this.operatorCorrectionBalance = operatorCorrectionBalance;
    }

    public BigDecimal getOperatorPowerBalance() {
        return operatorPowerBalance;
    }

    public void setOperatorPowerBalance(BigDecimal operatorPowerBalance) {
        this.operatorPowerBalance = operatorPowerBalance;
    }

    public BigDecimal getOperatorOldAmount() {
        return operatorOldAmount;
    }

    public void setOperatorOldAmount(BigDecimal operatorOldAmount) {
        this.operatorOldAmount = operatorOldAmount;
    }

    public BigDecimal getOperatorRestructuredDeft() {
        return operatorRestructuredDeft;
    }

    public void setOperatorRestructuredDeft(BigDecimal operatorRestructuredDeft) {
        this.operatorRestructuredDeft = operatorRestructuredDeft;
    }

    public Boolean getInTelDoc() {
        return inTelDoc;
    }

    public void setInTelDoc(Boolean inTelDoc) {
        this.inTelDoc = inTelDoc;
    }

    public Boolean getPrintBill() {
        return printBill;
    }

    public void setPrintBill(Boolean printBill) {
        this.printBill = printBill;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public Date getPrevReadingDate() {
        return prevReadingDate;
    }

    public void setPrevReadingDate(Date prevReadingDate) {
        this.prevReadingDate = prevReadingDate;
    }

    public String getCurrReadingDate() {
        return currReadingDate;
    }

    public void setCurrReadingDate(String currReadingDate) {
        this.currReadingDate = currReadingDate;
    }

    public BigDecimal getCurrKwt() {
        return currKwt;
    }

    public void setCurrKwt(BigDecimal currKwt) {
        this.currKwt = currKwt;
    }

    public BigDecimal getCurrReading() {
        return currReading;
    }

    public void setCurrReading(BigDecimal currReading) {
        this.currReading = currReading;
    }

    public BigDecimal getPrevReading() {
        return prevReading;
    }

    public void setPrevReading(BigDecimal prevReading) {
        this.prevReading = prevReading;
    }

    public BigDecimal getTransferServiceAmount() {
        return transferServiceAmount;
    }

    public void setTransferServiceAmount(BigDecimal transferServiceAmount) {
        this.transferServiceAmount = transferServiceAmount;
    }

    public Date getPrevBillDate() {
        return prevBillDate;
    }

    public void setPrevBillDate(Date prevBillDate) {
        this.prevBillDate = prevBillDate;
    }

    public BigDecimal getCategoryAvgAmount() {
        return categoryAvgAmount;
    }

    public void setCategoryAvgAmount(BigDecimal categoryAvgAmount) {
        this.categoryAvgAmount = categoryAvgAmount;
    }

    public BigDecimal getCategoryAvgKwt() {
        return categoryAvgKwt;
    }

    public void setCategoryAvgKwt(BigDecimal categoryAvgKwt) {
        this.categoryAvgKwt = categoryAvgKwt;
    }

    public String getGenerationId() {
        return generationId;
    }

    public void setGenerationId(String generationId) {
        this.generationId = generationId;
    }

    public Boolean getCanceled() {
        return canceled;
    }

    public void setCanceled(Boolean canceled) {
        this.canceled = canceled;
    }

    public UUID getPrevBillId() {
        return prevBillId;
    }

    public void setPrevBillId(UUID prevBillId) {
        this.prevBillId = prevBillId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Counter getCounter() {
        return counter;
    }

    public void setCounter(Counter counter) {
        this.counter = counter;
    }

    public BigDecimal getRecordingKnotCheck() {
        return recordingKnotCheck;
    }

    public void setRecordingKnotCheck(BigDecimal recordingKnotCheck) {
        this.recordingKnotCheck = recordingKnotCheck;
    }

    public BigDecimal getIllegalUseChargeAmount() {
        return illegalUseChargeAmount;
    }

    public void setIllegalUseChargeAmount(BigDecimal illegalUseChargeAmount) {
        this.illegalUseChargeAmount = illegalUseChargeAmount;
    }

    public BigDecimal getSupplyRenewalAmount() {
        return supplyRenewalAmount;
    }

    public void setSupplyRenewalAmount(BigDecimal supplyRenewalAmount) {
        this.supplyRenewalAmount = supplyRenewalAmount;
    }

    public BigDecimal getNetworkAccession() {
        return networkAccession;
    }

    public void setNetworkAccession(BigDecimal networkAccession) {
        this.networkAccession = networkAccession;
    }

    public BigDecimal getPayedAmount() {
        return payedAmount;
    }

    public void setPayedAmount(BigDecimal payedAmount) {
        this.payedAmount = payedAmount;
    }

    public BigDecimal getPreviousYearKiliwattHour() {
        return previousYearKiliwattHour;
    }

    public void setPreviousYearKiliwattHour(BigDecimal previousYearKiliwattHour) {
        this.previousYearKiliwattHour = previousYearKiliwattHour;
    }

    public BigDecimal getPreviousYearAmountWithVat() {
        return previousYearAmountWithVat;
    }

    public void setPreviousYearAmountWithVat(BigDecimal previousYearAmountWithVat) {
        this.previousYearAmountWithVat = previousYearAmountWithVat;
    }

    public BigDecimal getKitowattHour() {
        return kitowattHour;
    }

    public void setKitowattHour(BigDecimal kitowattHour) {
        this.kitowattHour = kitowattHour;
    }

    public BigDecimal getAmountWithVat() {
        return amountWithVat;
    }

    public void setAmountWithVat(BigDecimal amountWithVat) {
        this.amountWithVat = amountWithVat;
    }

    public String getCommissioComment() {
        return commissioComment;
    }

    public void setCommissioComment(String commissioComment) {
        this.commissioComment = commissioComment;
    }

    public String getSocialCommissioComment() {
        return socialCommissioComment;
    }

    public void setSocialCommissioComment(String socialCommissioComment) {
        this.socialCommissioComment = socialCommissioComment;
    }

    public String getSupplierAccountNumber() {
        return supplierAccountNumber;
    }

    public void setSupplierAccountNumber(String supplierAccountNumber) {
        this.supplierAccountNumber = supplierAccountNumber;
    }

    public String getCallcenter() {
        return callcenter;
    }

    public void setCallcenter(String callcenter) {
        this.callcenter = callcenter;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWebpage() {
        return webpage;
    }

    public void setWebpage(String webpage) {
        this.webpage = webpage;
    }

    public String getIdentificationNumber() {
        return identificationNumber;
    }

    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }

    public String getServiceCenterAddress() {
        return serviceCenterAddress;
    }

    public void setServiceCenterAddress(String serviceCenterAddress) {
        this.serviceCenterAddress = serviceCenterAddress;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public BigDecimal getAvailableDeposit() {
        return availableDeposit;
    }

    public void setAvailableDeposit(BigDecimal availableDeposit) {
        this.availableDeposit = availableDeposit;
    }

    public BigDecimal getOperatorRestructuredAmountLeftOld() {
        return operatorRestructuredAmountLeftOld;
    }

    public void setOperatorRestructuredAmountLeftOld(BigDecimal operatorRestructuredAmountLeftOld) {
        this.operatorRestructuredAmountLeftOld = operatorRestructuredAmountLeftOld;
    }

    public BigDecimal getOperatorRestructuredAmountLeft() {
        return operatorRestructuredAmountLeft;
    }

    public void setOperatorRestructuredAmountLeft(BigDecimal operatorRestructuredAmountLeft) {
        this.operatorRestructuredAmountLeft = operatorRestructuredAmountLeft;
    }

    public BigDecimal getLeftOldAmount() {
        return leftOldAmount;
    }

    public void setLeftOldAmount(BigDecimal leftOldAmount) {
        this.leftOldAmount = leftOldAmount;
    }

    public BigDecimal getRestructuredAmountLeft() {
        return restructuredAmountLeft;
    }

    public void setRestructuredAmountLeft(BigDecimal restructuredAmountLeft) {
        this.restructuredAmountLeft = restructuredAmountLeft;
    }

    public BigDecimal getDisputedDebt() {
        return disputedDebt;
    }

    public void setDisputedDebt(BigDecimal disputedDebt) {
        this.disputedDebt = disputedDebt;
    }

    public BigDecimal getPurchasedElectricityAmount() {
        return purchasedElectricityAmount;
    }

    public void setPurchasedElectricityAmount(BigDecimal purchasedElectricityAmount) {
        this.purchasedElectricityAmount = purchasedElectricityAmount;
    }

    public BigDecimal getPositiveBalanceKilowatt() {
        return positiveBalanceKilowatt;
    }

    public void setPositiveBalanceKilowatt(BigDecimal positiveBalanceKilowatt) {
        this.positiveBalanceKilowatt = positiveBalanceKilowatt;
    }

    public BigDecimal getDeductedKilowatt() {
        return deductedKilowatt;
    }

    public void setDeductedKilowatt(BigDecimal deductedKilowatt) {
        this.deductedKilowatt = deductedKilowatt;
    }

    public BigDecimal getNetworkDeliveredKilowatt() {
        return networkDeliveredKilowatt;
    }

    public void setNetworkDeliveredKilowatt(BigDecimal networkDeliveredKilowatt) {
        this.networkDeliveredKilowatt = networkDeliveredKilowatt;
    }

    public BigDecimal getPreviousBillLeftAmount() {
        return previousBillLeftAmount;
    }

    public void setPreviousBillLeftAmount(BigDecimal previousBillLeftAmount) {
        this.previousBillLeftAmount = previousBillLeftAmount;
    }

    public BigDecimal getOther() {
        return other;
    }

    public void setOther(BigDecimal other) {
        this.other = other;
    }

    public BigDecimal getMultichildSubsidy() {
        return multichildSubsidy;
    }

    public void setMultichildSubsidy(BigDecimal multichildSubsidy) {
        this.multichildSubsidy = multichildSubsidy;
    }

    public BigDecimal getTariffSubsidy() {
        return tariffSubsidy;
    }

    public void setTariffSubsidy(BigDecimal tariffSubsidy) {
        this.tariffSubsidy = tariffSubsidy;
    }

    public BigDecimal getHighlandSettlementsSubsidy() {
        return highlandSettlementsSubsidy;
    }

    public void setHighlandSettlementsSubsidy(BigDecimal highlandSettlementsSubsidy) {
        this.highlandSettlementsSubsidy = highlandSettlementsSubsidy;
    }

    public BigDecimal getContractPenalty() {
        return contractPenalty;
    }

    public void setContractPenalty(BigDecimal contractPenalty) {
        this.contractPenalty = contractPenalty;
    }

    public BigDecimal getRestructuredDebt() {
        return restructuredDebt;
    }

    public void setRestructuredDebt(BigDecimal restructuredDebt) {
        this.restructuredDebt = restructuredDebt;
    }

    public BigDecimal getRequestedDeposit() {
        return requestedDeposit;
    }

    public void setRequestedDeposit(BigDecimal requestedDeposit) {
        this.requestedDeposit = requestedDeposit;
    }

    public BigDecimal getServiceQualityCompensation() {
        return serviceQualityCompensation;
    }

    public void setServiceQualityCompensation(BigDecimal serviceQualityCompensation) {
        this.serviceQualityCompensation = serviceQualityCompensation;
    }

    public BigDecimal getVat() {
        return vat;
    }

    public void setVat(BigDecimal vat) {
        this.vat = vat;
    }

    public String getTransmissionServiceAmount() {
        return transmissionServiceAmount;
    }

    public void setTransmissionServiceAmount(String transmissionServiceAmount) {
        this.transmissionServiceAmount = transmissionServiceAmount;
    }

    public BigDecimal getDistributionServiceAmount() {
        return distributionServiceAmount;
    }

    public void setDistributionServiceAmount(BigDecimal distributionServiceAmount) {
        this.distributionServiceAmount = distributionServiceAmount;
    }

    public BigDecimal getSupplyServiceAmount() {
        return supplyServiceAmount;
    }

    public void setSupplyServiceAmount(BigDecimal supplyServiceAmount) {
        this.supplyServiceAmount = supplyServiceAmount;
    }

    public BigDecimal getExpenseAmountGel() {
        return expenseAmountGel;
    }

    public void setExpenseAmountGel(BigDecimal expenseAmountGel) {
        this.expenseAmountGel = expenseAmountGel;
    }

    public BigDecimal getKilowatt() {
        return kilowatt;
    }

    public void setKilowatt(BigDecimal kilowatt) {
        this.kilowatt = kilowatt;
    }

    public BigDecimal getReading() {
        return reading;
    }

    public void setReading(BigDecimal reading) {
        this.reading = reading;
    }

    public String getReadingType() {
        return readingType;
    }

    public void setReadingType(String readingType) {
        this.readingType = readingType;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public BigDecimal getTariffValue() {
        return tariffValue;
    }

    public void setTariffValue(BigDecimal tariffValue) {
        this.tariffValue = tariffValue;
    }

    public BigDecimal getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(BigDecimal coefficient) {
        this.coefficient = coefficient;
    }

    public String getCounterSerialNumber() {
        return counterSerialNumber;
    }

    public void setCounterSerialNumber(String counterSerialNumber) {
        this.counterSerialNumber = counterSerialNumber;
    }

    public BigDecimal getCorrectionAmount() {
        return correctionAmount;
    }

    public void setCorrectionAmount(BigDecimal correctionAmount) {
        this.correctionAmount = correctionAmount;
    }

    public BigDecimal getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(BigDecimal depositAmount) {
        this.depositAmount = depositAmount;
    }

    public BigDecimal getPreviousAmount() {
        return previousAmount;
    }

    public void setPreviousAmount(BigDecimal previousAmount) {
        this.previousAmount = previousAmount;
    }

    public BigDecimal getCurrentAccrual() {
        return currentAccrual;
    }

    public void setCurrentAccrual(BigDecimal currentAccrual) {
        this.currentAccrual = currentAccrual;
    }

    public BigDecimal getAdvancePaidAmount() {
        return advancePaidAmount;
    }

    public void setAdvancePaidAmount(BigDecimal advancePaidAmount) {
        this.advancePaidAmount = advancePaidAmount;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getCustomerFullName() {
        return customerFullName;
    }

    public void setCustomerFullName(String customerFullName) {
        this.customerFullName = customerFullName;
    }

    public void setBillCreationDate(Date billCreationDate) {
        this.billCreationDate = billCreationDate;
    }

    public Date getBillCreationDate() {
        return billCreationDate;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getBillNumber() {
        return billNumber;
    }

    public void setBillNumber(String billNumber) {
        this.billNumber = billNumber;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}