package ge.proxima.primebilling.entity.block;

import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_BLOCK_SCHEDULE", indexes = {
        @Index(name = "IDX_BLOCKSCHEDULE_BLOCK_ID_ID", columnList = "BLOCK_ID_ID"),
        @Index(name = "IDX_PRX_BLOCK_SCHEDULE_UNiq", columnList = "BLOCK_ID_ID, YEAR_, MONTH_", unique = true)
})
@Entity(name = "prx_BlockSchedule")
public class BlockSchedule {

    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "BLOCK_ID_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Block block;

    @Column(name = "YEAR_")
    private Integer year;

    @Column(name = "MONTH_")
    private Integer month;

    @Column(name = "DAY_")
    private Integer day;

    @NotNull
    @Column(name = "OPERATION_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date operationDate;

    @Column(name = "READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date readDate;

    @Column(name = "CYCLE_DAY", precision = 4, scale = 0)
    private BigDecimal cycleDay;

    @Column(name = "ENTERING_DATA_INTO_DATABASE_DATE")
    @Temporal(TemporalType.DATE)
    private Date enteringDataIntoDatabaseDate;

    @Column(name = "BILL_FORMATION_AND_SMS_SEND_DATE")
    @Temporal(TemporalType.DATE)
    private Date billFormationAndSmsSendDate;

    @Column(name = "BILL_DISTRIBUTION_DATE")
    @Temporal(TemporalType.DATE)
    private Date billDistributionDate;

    @Column(name = "BILL_DUE_DATE")
    @Temporal(TemporalType.DATE)
    private Date billDueDate;

    @Column(name = "BILL_DUE_DATE_CALENDAR_DAY")
    private Integer billDueDateCalendarDay;

    @Column(name = "BILL_DUE_DATE_PENSION")
    @Temporal(TemporalType.DATE)
    private Date billDueDatePension;

    @Column(name = "BILL_DUE_DATE_SOCIAL")
    @Temporal(TemporalType.DATE)
    private Date billDueDateSocial;

    @Column(name = "WARNING_DUE_DATE")
    @Temporal(TemporalType.DATE)
    private Date warningDueDate;

    @Column(name = "WARNING_DUE_DATE_PENSION")
    @Temporal(TemporalType.DATE)
    private Date warningDueDatePension;

    @Column(name = "WARNING_DUE_DATE_SOCIAL")
    @Temporal(TemporalType.DATE)
    private Date warningDueDateSocial;

    @Column(name = "CUTOFF_DATE")
    @Temporal(TemporalType.DATE)
    private Date cutoffDate;

    @Column(name = "CUTOFF_DATE_PENSION")
    @Temporal(TemporalType.DATE)
    private Date cutoffDatePension;

    @Column(name = "CUTOFF_DATE_SOCIAL")
    @Temporal(TemporalType.DATE)
    private Date cutoffDateSocial;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public Date getReadDate() {
        return readDate;
    }

    public void setReadDate(Date readDate) {
        this.readDate = readDate;
    }

    public BigDecimal getCycleDay() {
        return cycleDay;
    }

    public void setCycleDay(BigDecimal cycleDay) {
        this.cycleDay = cycleDay;
    }

    public Date getEnteringDataIntoDatabaseDate() {
        return enteringDataIntoDatabaseDate;
    }

    public void setEnteringDataIntoDatabaseDate(Date enteringDataIntoDatabaseDate) {
        this.enteringDataIntoDatabaseDate = enteringDataIntoDatabaseDate;
    }

    public Date getCutoffDateSocial() {
        return cutoffDateSocial;
    }

    public void setCutoffDateSocial(Date cutoffDateSocial) {
        this.cutoffDateSocial = cutoffDateSocial;
    }

    public Date getCutoffDatePension() {
        return cutoffDatePension;
    }

    public void setCutoffDatePension(Date cutoffDatePension) {
        this.cutoffDatePension = cutoffDatePension;
    }

    public Date getWarningDueDateSocial() {
        return warningDueDateSocial;
    }

    public void setWarningDueDateSocial(Date warningDueDateSocial) {
        this.warningDueDateSocial = warningDueDateSocial;
    }

    public Date getWarningDueDatePension() {
        return warningDueDatePension;
    }

    public void setWarningDueDatePension(Date warningDueDatePension) {
        this.warningDueDatePension = warningDueDatePension;
    }

    public Date getWarningDueDate() {
        return warningDueDate;
    }

    public void setWarningDueDate(Date warningDueDate) {
        this.warningDueDate = warningDueDate;
    }

    public Date getBillDueDateSocial() {
        return billDueDateSocial;
    }

    public void setBillDueDateSocial(Date billDueDateSocial) {
        this.billDueDateSocial = billDueDateSocial;
    }

    public Date getBillDueDatePension() {
        return billDueDatePension;
    }

    public void setBillDueDatePension(Date billDueDatePension) {
        this.billDueDatePension = billDueDatePension;
    }

    public Integer getBillDueDateCalendarDay() {
        return billDueDateCalendarDay;
    }

    public void setBillDueDateCalendarDay(Integer billDueDateCalendarDay) {
        this.billDueDateCalendarDay = billDueDateCalendarDay;
    }

    public Date getBillDueDate() {
        return billDueDate;
    }

    public void setBillDueDate(Date billDueDate) {
        this.billDueDate = billDueDate;
    }

    public Date getBillDistributionDate() {
        return billDistributionDate;
    }

    public void setBillDistributionDate(Date billDistributionDate) {
        this.billDistributionDate = billDistributionDate;
    }

    public Date getBillFormationAndSmsSendDate() {
        return billFormationAndSmsSendDate;
    }

    public void setBillFormationAndSmsSendDate(Date billFormationAndSmsSendDate) {
        this.billFormationAndSmsSendDate = billFormationAndSmsSendDate;
    }

    public Date getCutoffDate() {
        return cutoffDate;
    }

    public void setCutoffDate(Date cutoffDate) {
        this.cutoffDate = cutoffDate;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public Integer getDay() {
        return day;
    }

    public void setDay(Integer day) {
        this.day = day;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"block"})
    public String getInstanceName() {
        return String.format("%s", block);
    }

    @PrePersist
    public void prePersist() {
        this.validateReadDate();
    }

    @PreUpdate
    public void preUpdate() {
        this.validateReadDate();
    }


    private void validateReadDate(){
        int readYear = 0;
        int readMonth = 0;

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(this.getReadDate());

        if(this.getYear() != calendar.get(Calendar.YEAR) || (this.getMonth() != calendar.get(Calendar.MONTH) + 1))
        {
            throw new RuntimeException("Incorrect read date");
        }


    }



}