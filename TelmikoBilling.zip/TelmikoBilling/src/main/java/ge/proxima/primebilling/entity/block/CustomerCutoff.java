package ge.proxima.primebilling.entity.block;

import ge.proxima.primebilling.entity.CuttOffStatus;
import ge.proxima.primebilling.entity.counter.Counter;
import ge.proxima.primebilling.entity.counter.CounterAdress;
import ge.proxima.primebilling.entity.customer.Customer;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_CUTOFF", indexes = {
        @Index(name = "IDX_CUSTOMERCUTOFF", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_CUSTOMERCUTOFF", columnList = "CUTOFF_STATUS_ID"),
        @Index(name = "IDX_CUSTOMERCUTOFF_BLOCK_ID", columnList = "BLOCK_ID"),
        @Index(name = "IDX_CUSTOMERCUTOFF_ADDRESS_ID", columnList = "ADDRESS_ID"),
        @Index(name = "IDX_PRXCUSTOMERCUTOFF_COUNTER", columnList = "COUNTER_ID")
})
@Entity(name = "prx_CustomerCutoff")
public class CustomerCutoff {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "TL_OPER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlOperDate;

    @Column(name = "TL_OPER_CODE", precision = 1, scale = 0)
    private BigDecimal tlOperCode;

    @Column(name = "TL_READING", precision = 14, scale = 6)
    private BigDecimal tlReading;

    @Column(name = "TELASI_STATUS_IMP")
    private String telasiStatusImp;

    @Column(name = "TELASI_NOTE_IMP")
    private String telasiNoteImp;

    @Column(name = "NOTE")
    private String note;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @JoinColumn(name = "COUNTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Counter counter;

    @Column(name = "AMOUNT_TELMICO")
    private BigDecimal amountTelmico;

    @Column(name = "AMOUNT_DEPOSIT", precision = 19, scale = 2)
    private BigDecimal amountDeposit;

    @Column(name = "AMOUNT_TELASI", precision = 19, scale = 2)
    private BigDecimal amountTelasi;

    @Column(name = "AMOUNT_PENALTY", precision = 19, scale = 2)
    private BigDecimal amountPenalty;

    @Column(name = "DEBT", precision = 19, scale = 2)
    private BigDecimal debt;

    @Column(name = "DOC_NUM")
    private String docNum;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "DATE_")
    @Temporal(TemporalType.DATE)
    private Date date;

    @Column(name = "TELASI_SENT_DATE")
    @Temporal(TemporalType.DATE)
    private Date telasiSentDate;

    @Column(name = "TASK_CLOSE_DATE")
    @Temporal(TemporalType.DATE)
    private Date taskCloseDate;

    @Column(name = "VALUE_", precision = 19, scale = 2)
    private BigDecimal value;

    @JoinColumn(name = "CUTOFF_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CutoffStatus cutoffStatus;

    @Column(name = "CUT_STATUS")
    private String cutStatus;

    @Column(name = "RESTORED")
    private Boolean restored;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @JoinColumn(name = "ADDRESS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CounterAdress address;

    @Column(name = "CUSTOMER_ADDRESS")
    private String customerAddress;

    @Column(name = "GENERATION_ID", length = 100)
    private String generationId;

    @Column(name = "TELASI_STATUS", length = 100)
    private String telasiStatus;

    @Column(name = "TL_CUT_OFF_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlCutOffTime;

    @Column(name = "TL_ENTER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlEnterDate;

    @Column(name = "TL_MARK_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlMarkTime;

    @Column(name = "SERIAL_NUMBER", length = 50)
    private String serialNumber;

    @Column(name = "TL_DISC_REC_STATUS_ID", precision = 8, scale = 0)
    private BigDecimal tlDiscRecStatusId;

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public BigDecimal getTlDiscRecStatusId() {
        return tlDiscRecStatusId;
    }

    public void setTlDiscRecStatusId(BigDecimal tlDiscRecStatusId) {
        this.tlDiscRecStatusId = tlDiscRecStatusId;
    }

    public Date getTlMarkTime() {
        return tlMarkTime;
    }

    public void setTlMarkTime(Date tlMarkTime) {
        this.tlMarkTime = tlMarkTime;
    }

    public Date getTlEnterDate() {
        return tlEnterDate;
    }

    public void setTlEnterDate(Date tlEnterDate) {
        this.tlEnterDate = tlEnterDate;
    }

    public Date getTlCutOffTime() {
        return tlCutOffTime;
    }

    public void setTlCutOffTime(Date tlCutOffTime) {
        this.tlCutOffTime = tlCutOffTime;
    }

    public BigDecimal getTlReading() {
        return tlReading;
    }

    public void setTlReading(BigDecimal tlReading) {
        this.tlReading = tlReading;
    }

    public BigDecimal getTlOperCode() {
        return tlOperCode;
    }

    public void setTlOperCode(BigDecimal tlOperCode) {
        this.tlOperCode = tlOperCode;
    }

    public Date getTlOperDate() {
        return tlOperDate;
    }

    public void setTlOperDate(Date tlOperDate) {
        this.tlOperDate = tlOperDate;
    }

    public Boolean getRestored() {
        return restored;
    }

    public void setRestored(Boolean restored) {
        this.restored = restored;
    }

    public CuttOffStatus getCutStatus() {
        return cutStatus == null ? null : CuttOffStatus.fromId(cutStatus);
    }

    public void setCutStatus(CuttOffStatus cutStatus) {
        this.cutStatus = cutStatus == null ? null : cutStatus.getId();
    }

    public String getTelasiNoteImp() {
        return telasiNoteImp;
    }

    public void setTelasiNoteImp(String telasiNoteImp) {
        this.telasiNoteImp = telasiNoteImp;
    }

    public String getTelasiStatusImp() {
        return telasiStatusImp;
    }

    public void setTelasiStatusImp(String telasiStatusImp) {
        this.telasiStatusImp = telasiStatusImp;
    }

    public String getGenerationId() {
        return generationId;
    }

    public void setGenerationId(String generationId) {
        this.generationId = generationId;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public Counter getCounter() {
        return counter;
    }

    public void setCounter(Counter counter) {
        this.counter = counter;
    }

    public String getTelasiStatus() {
        return telasiStatus;
    }

    public void setTelasiStatus(String telasiStatus) {
        this.telasiStatus = telasiStatus;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public CounterAdress getAddress() {
        return address;
    }

    public void setAddress(CounterAdress address) {
        this.address = address;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public CutoffStatus getCutoffStatus() {
        return cutoffStatus;
    }

    public void setCutoffStatus(CutoffStatus cutoffStatus) {
        this.cutoffStatus = cutoffStatus;
    }

    public void setAmountTelmico(BigDecimal amountTelmico) {
        this.amountTelmico = amountTelmico;
    }

    public BigDecimal getAmountTelmico() {
        return amountTelmico;
    }

    public BigDecimal getDebt() {
        return debt;
    }

    public void setDebt(BigDecimal debt) {
        this.debt = debt;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public Date getTaskCloseDate() {
        return taskCloseDate;
    }

    public void setTaskCloseDate(Date taskCloseDate) {
        this.taskCloseDate = taskCloseDate;
    }

    public Date getTelasiSentDate() {
        return telasiSentDate;
    }

    public void setTelasiSentDate(Date telasiSentDate) {
        this.telasiSentDate = telasiSentDate;
    }

    public BigDecimal getAmountPenalty() {
        return amountPenalty;
    }

    public void setAmountPenalty(BigDecimal amountPenalty) {
        this.amountPenalty = amountPenalty;
    }

    public BigDecimal getAmountTelasi() {
        return amountTelasi;
    }

    public void setAmountTelasi(BigDecimal amountTelasi) {
        this.amountTelasi = amountTelasi;
    }

    public BigDecimal getAmountDeposit() {
        return amountDeposit;
    }

    public void setAmountDeposit(BigDecimal amountDeposit) {
        this.amountDeposit = amountDeposit;
    }

    public String getDocNum() {
        return docNum;
    }

    public void setDocNum(String docNum) {
        this.docNum = docNum;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}