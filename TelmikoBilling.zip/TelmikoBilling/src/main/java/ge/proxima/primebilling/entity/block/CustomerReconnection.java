package ge.proxima.primebilling.entity.block;

import ge.proxima.primebilling.entity.RestoreStatus;
import ge.proxima.primebilling.entity.counter.Counter;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.ReconnectionType;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_RECONNECTION", indexes = {
        @Index(name = "IDX_CUSTOMERRECONNECTION", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRXCUSTOMERRECON_COUNTERID", columnList = "COUNTER_ID_ID")
})
@Entity(name = "prx_CustomerReconnection")
public class CustomerReconnection {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "DEBT", precision = 19, scale = 2)
    private BigDecimal debt;

    @Column(name = "NOTE")
    private String note;

    @Column(name = "SERIAL_NUMBER")
    private String serialNumber;

    @Column(name = "LAST_PAYE_DATE")
    @Temporal(TemporalType.DATE)
    private Date lastPayeDate;

    @Column(name = "LAST_PAY_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastPayDateTime;

    @Column(name = "LAST_PAYED_AMOUNT", precision = 19, scale = 2)
    private BigDecimal lastPayedAmount;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @Column(name = "TELMIKO_AMOUNT", precision = 19, scale = 2)
    private BigDecimal telmikoAmount;

    @Column(name = "TELASI_AMOUNT", precision = 19, scale = 2)
    private BigDecimal telasiAmount;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @JoinColumn(name = "RECONNECT_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CutoffStatus reconnectStatus;

    @Column(name = "TELASI_STATUS", length = 50)
    private String telasi_status;

    @Column(name = "RECONNECT_DATE")
    @Temporal(TemporalType.DATE)
    private Date reconnectDate;

    @Column(name = "RECONNECT_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date reconnectTime;

    @Column(name = "TL_OPER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlOperDate;

    @Column(name = "TL_MARK_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlMarkDate;

    @Column(name = "TL_OPER_CODE", precision = 8, scale = 0)
    private BigDecimal tlOperCode;

    @Column(name = "TL_READING", precision = 14, scale = 6)
    private BigDecimal tlReading;

    @Column(name = "DISC_REC_STATUS_KEY", precision = 10, scale = 0)
    private BigDecimal discRecStatusKey;

    @Column(name = "TL_ENTER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlEnterDate;

    @Column(name = "TL_RESTORE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlRestoreTime;

    @Column(name = "TL_MARK_CODE", precision = 19, scale = 2)
    private BigDecimal tlMarkCode;

    @Column(name = "RESTORE_STATUS")
    private String restoreStatus;

    @Column(name = "RECONNECTION_TYPE")
    private String reconnectionType;

    @JoinColumn(name = "COUNTER_ID_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Counter counterId;

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public BigDecimal getDebt() {
        return debt;
    }

    public void setDebt(BigDecimal debt) {
        this.debt = debt;
    }

    public Date getLastPayDateTime() {
        return lastPayDateTime;
    }

    public void setLastPayDateTime(Date lastPayDateTime) {
        this.lastPayDateTime = lastPayDateTime;
    }

    public Counter getCounterId() {
        return counterId;
    }

    public void setCounterId(Counter counterId) {
        this.counterId = counterId;
    }

    public RestoreStatus getRestoreStatus() {
        return restoreStatus == null ? null : RestoreStatus.fromId(restoreStatus);
    }

    public void setRestoreStatus(RestoreStatus restoreStatus) {
        this.restoreStatus = restoreStatus == null ? null : restoreStatus.getId();
    }

    public BigDecimal getTlMarkCode() {
        return tlMarkCode;
    }

    public void setTlMarkCode(BigDecimal tlMarkCode) {
        this.tlMarkCode = tlMarkCode;
    }

    public Date getTlRestoreTime() {
        return tlRestoreTime;
    }

    public void setTlRestoreTime(Date tlRestoreTime) {
        this.tlRestoreTime = tlRestoreTime;
    }

    public Date getTlEnterDate() {
        return tlEnterDate;
    }

    public void setTlEnterDate(Date tlEnterDate) {
        this.tlEnterDate = tlEnterDate;
    }

    public BigDecimal getDiscRecStatusKey() {
        return discRecStatusKey;
    }

    public void setDiscRecStatusKey(BigDecimal discRecStatusKey) {
        this.discRecStatusKey = discRecStatusKey;
    }

    public BigDecimal getTlReading() {
        return tlReading;
    }

    public void setTlReading(BigDecimal tlReading) {
        this.tlReading = tlReading;
    }

    public BigDecimal getTlOperCode() {
        return tlOperCode;
    }

    public void setTlOperCode(BigDecimal tlOperCode) {
        this.tlOperCode = tlOperCode;
    }

    public Date getTlMarkDate() {
        return tlMarkDate;
    }

    public void setTlMarkDate(Date tlMarkDate) {
        this.tlMarkDate = tlMarkDate;
    }

    public Date getTlOperDate() {
        return tlOperDate;
    }

    public void setTlOperDate(Date tlOperDate) {
        this.tlOperDate = tlOperDate;
    }

    public Date getReconnectTime() {
        return reconnectTime;
    }

    public void setReconnectTime(Date reconnectTime) {
        this.reconnectTime = reconnectTime;
    }

    public BigDecimal getTelasiAmount() {
        return telasiAmount;
    }

    public void setTelasiAmount(BigDecimal telasiAmount) {
        this.telasiAmount = telasiAmount;
    }

    public BigDecimal getTelmikoAmount() {
        return telmikoAmount;
    }

    public void setTelmikoAmount(BigDecimal telmikoAmount) {
        this.telmikoAmount = telmikoAmount;
    }

    public String getTelasi_status() {
        return telasi_status;
    }

    public void setTelasi_status(String telasi_status) {
        this.telasi_status = telasi_status;
    }

    public BigDecimal getLastPayedAmount() {
        return lastPayedAmount;
    }

    public void setLastPayedAmount(BigDecimal lastPayedAmount) {
        this.lastPayedAmount = lastPayedAmount;
    }

    public Date getLastPayeDate() {
        return lastPayeDate;
    }

    public void setLastPayeDate(Date lastPayeDate) {
        this.lastPayeDate = lastPayeDate;
    }

    public ReconnectionType getReconnectionType() {
        return reconnectionType == null ? null : ReconnectionType.fromId(reconnectionType);
    }

    public void setReconnectionType(ReconnectionType reconnectionType) {
        this.reconnectionType = reconnectionType == null ? null : reconnectionType.getId();
    }

    public Date getReconnectDate() {
        return reconnectDate;
    }

    public void setReconnectDate(Date reconnectDate) {
        this.reconnectDate = reconnectDate;
    }

    public void setReconnectStatus(CutoffStatus reconnectStatus) {
        this.reconnectStatus = reconnectStatus;
    }

    public CutoffStatus getReconnectStatus() {
        return reconnectStatus;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}