package ge.proxima.primebilling.entity.block;

import ge.proxima.primebilling.entity.CuttOffStatus;
import ge.proxima.primebilling.entity.counter.CounterAdress;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.ReconnectionType;
import ge.proxima.primebilling.entity.system.TelasiStatus;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_CutoffHistory")
public class CutoffHistory {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private Customer customer;

    private BigDecimal amountTelmico;

    private BigDecimal amountDeposit;

    private BigDecimal amountTelasi;

    private BigDecimal amountPenalty;

    private BigDecimal debt;

    @Temporal(TemporalType.DATE)
    private Date date;

    @Temporal(TemporalType.DATE)
    private Date telasiSentDate;

    @Temporal(TemporalType.DATE)
    private Date taskCloseDate;

    private BigDecimal value;

    private CutoffStatus status;

    private String cutStatus;

    private String documentNumber;

    @Temporal(TemporalType.DATE)
    private Date sentDate;

    private TelasiStatus telasiStatus;

    private String telasiStatusImp;

    private String telasiNoteImp;

    private String importStatus;

    @Temporal(TemporalType.DATE)
    private Date reconnectionDate;

    private String reconnectionType;

    @Temporal(TemporalType.TIMESTAMP)
    private Date createTs;

    private Block block;

    private CounterAdress address;

    public CuttOffStatus getCutStatus() {
        return cutStatus == null ? null : CuttOffStatus.fromId(cutStatus);
    }

    public void setCutStatus(CuttOffStatus cutStatus) {
        this.cutStatus = cutStatus == null ? null : cutStatus.getId();
    }

    public String getImportStatus() {
        return importStatus;
    }

    public void setImportStatus(String importStatus) {
        this.importStatus = importStatus;
    }

    public String getTelasiNoteImp() {
        return telasiNoteImp;
    }

    public void setTelasiNoteImp(String telasiNoteImp) {
        this.telasiNoteImp = telasiNoteImp;
    }

    public String getTelasiStatusImp() {
        return telasiStatusImp;
    }

    public void setTelasiStatusImp(String telasiStatusImp) {
        this.telasiStatusImp = telasiStatusImp;
    }

    public CounterAdress getAddress() {
        return address;
    }

    public void setAddress(CounterAdress address) {
        this.address = address;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public void setReconnectionType(ReconnectionType reconnectionType) {
        this.reconnectionType = reconnectionType == null ? null : reconnectionType.getId();
    }

    public ReconnectionType getReconnectionType() {
        return reconnectionType == null ? null : ReconnectionType.fromId(reconnectionType);
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Date getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public BigDecimal getAmountTelmico() {
        return amountTelmico;
    }

    public void setAmountTelmico(BigDecimal amountTelmico) {
        this.amountTelmico = amountTelmico;
    }

    public BigDecimal getAmountDeposit() {
        return amountDeposit;
    }

    public void setAmountDeposit(BigDecimal amountDeposit) {
        this.amountDeposit = amountDeposit;
    }

    public BigDecimal getAmountTelasi() {
        return amountTelasi;
    }

    public void setAmountTelasi(BigDecimal amountTelasi) {
        this.amountTelasi = amountTelasi;
    }

    public BigDecimal getAmountPenalty() {
        return amountPenalty;
    }

    public void setAmountPenalty(BigDecimal amountPenalty) {
        this.amountPenalty = amountPenalty;
    }

    public BigDecimal getDebt() {
        return debt;
    }

    public void setDebt(BigDecimal debt) {
        this.debt = debt;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Date getTelasiSentDate() {
        return telasiSentDate;
    }

    public void setTelasiSentDate(Date telasiSentDate) {
        this.telasiSentDate = telasiSentDate;
    }

    public Date getTaskCloseDate() {
        return taskCloseDate;
    }

    public void setTaskCloseDate(Date taskCloseDate) {
        this.taskCloseDate = taskCloseDate;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public CutoffStatus getStatus() {
        return status;
    }

    public void setStatus(CutoffStatus status) {
        this.status = status;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    public TelasiStatus getTelasiStatus() {
        return telasiStatus;
    }

    public void setTelasiStatus(TelasiStatus telasiStatus) {
        this.telasiStatus = telasiStatus;
    }

    public Date getReconnectionDate() {
        return reconnectionDate;
    }

    public void setReconnectionDate(Date reconnectionDate) {
        this.reconnectionDate = reconnectionDate;
    }

}