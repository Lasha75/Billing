package ge.proxima.primebilling.entity.block;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CutoffStatusType implements EnumClass<String> {

    CUTOFF("CUTOFF"),
    RECONNECT("RECONNECT");

    private String id;

    CutoffStatusType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CutoffStatusType fromId(String id) {
        for (CutoffStatusType at : CutoffStatusType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}