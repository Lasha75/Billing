package ge.proxima.primebilling.entity.block;

import ge.proxima.primebilling.entity.CustomerCuttStatus;
import ge.proxima.primebilling.entity.CuttOffStatus;
import ge.proxima.primebilling.entity.counter.CounterAdress;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.system.TelasiStatus;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_INDIVIDUAL_CUTOFF", indexes = {
        @Index(name = "IDX_INDIVIDUALCUTOFF", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_INDIVIDUALCUTOFF", columnList = "TELASI_STATUS_ID"),
        @Index(name = "IDX_INDIVIDUALCUTOFF_BLOCK_ID", columnList = "BLOCK_ID"),
        @Index(name = "IDX_INDIVIDUALCUTOFF", columnList = "ADDRESS_ID")
})
@Entity(name = "prx_IndividualCutoff")
public class IndividualCutoff {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "CUT_OFF_TYPE")
    private String cutOffType;

    @Column(name = "IS_SENT")
    private Boolean isSent;

    @Column(name = "TL_MARK_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlMarkDate;

    @Column(name = "TL_OPER_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tlOperDate;

    @Column(name = "TELASI_STATUS_IMP")
    private String telasiStatusImp;

    @Column(name = "TELASI_NOTE_IMP")
    private String telasiNoteImp;

    @Column(name = "NOTE")
    private String note;

    @Column(name = "TL_READING", precision = 19, scale = 2)
    private BigDecimal tlReading;

    @Column(name = "SERIAL_NUMBER", length = 50)
    private String serialNumber;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @JoinColumn(name = "CUTOFF_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CutoffStatus cutoffStatus;

    @Column(name = "CUT_STATUS")
    private String cutStatus;

    @Column(name = "DOCUMENT_NUMBER", length = 30)
    private String documentNumber;

    @Column(name = "DATE_")
    @Temporal(TemporalType.DATE)
    private Date date;

    @Column(name = "SENT_DATE")
    @Temporal(TemporalType.DATE)
    private Date sentDate;

    @JoinColumn(name = "TELASI_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TelasiStatus telasiStatus;

    @Column(name = "TASK_CLOSE_DATE")
    @Temporal(TemporalType.DATE)
    private Date taskCloseDate;

    @Column(name = "VALUE_", precision = 19, scale = 2)
    private BigDecimal value;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @JoinColumn(name = "ADDRESS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CounterAdress address;

    public Boolean getIsSent() {
        return isSent;
    }

    public void setIsSent(Boolean isSent) {
        this.isSent = isSent;
    }

    public CustomerCuttStatus getCutOffType() {
        return cutOffType == null ? null : CustomerCuttStatus.fromId(cutOffType);
    }

    public void setCutOffType(CustomerCuttStatus cutOffType) {
        this.cutOffType = cutOffType == null ? null : cutOffType.getId();
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public BigDecimal getTlReading() {
        return tlReading;
    }

    public void setTlReading(BigDecimal tlReading) {
        this.tlReading = tlReading;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getTelasiNoteImp() {
        return telasiNoteImp;
    }

    public void setTelasiNoteImp(String telasiNoteImp) {
        this.telasiNoteImp = telasiNoteImp;
    }

    public String getTelasiStatusImp() {
        return telasiStatusImp;
    }

    public void setTelasiStatusImp(String telasiStatusImp) {
        this.telasiStatusImp = telasiStatusImp;
    }

    public Date getTlOperDate() {
        return tlOperDate;
    }

    public void setTlOperDate(Date tlOperDate) {
        this.tlOperDate = tlOperDate;
    }

    public Date getTlMarkDate() {
        return tlMarkDate;
    }

    public void setTlMarkDate(Date tlMarkDate) {
        this.tlMarkDate = tlMarkDate;
    }

    public CuttOffStatus getCutStatus() {
        return cutStatus == null ? null : CuttOffStatus.fromId(cutStatus);
    }

    public void setCutStatus(CuttOffStatus cutStatus) {
        this.cutStatus = cutStatus == null ? null : cutStatus.getId();
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public Block getBlock() {
        return block;
    }

    public CounterAdress getAddress() {
        return address;
    }

    public void setAddress(CounterAdress address) {
        this.address = address;
    }

    public void setCutoffStatus(CutoffStatus cutoffStatus) {
        this.cutoffStatus = cutoffStatus;
    }

    public CutoffStatus getCutoffStatus() {
        return cutoffStatus;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public Date getTaskCloseDate() {
        return taskCloseDate;
    }

    public void setTaskCloseDate(Date taskCloseDate) {
        this.taskCloseDate = taskCloseDate;
    }

    public TelasiStatus getTelasiStatus() {
        return telasiStatus;
    }

    public void setTelasiStatus(TelasiStatus telasiStatus) {
        this.telasiStatus = telasiStatus;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }


}