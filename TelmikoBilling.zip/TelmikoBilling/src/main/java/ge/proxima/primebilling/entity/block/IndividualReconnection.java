package ge.proxima.primebilling.entity.block;

import ge.proxima.primebilling.entity.CustomerCuttStatus;
import ge.proxima.primebilling.entity.counter.CounterAdress;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.ReconnectionType;
import ge.proxima.primebilling.entity.system.TelasiStatus;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.reconnection.CustomerReconnection;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_INDIVIDUAL_RECONNECTION", indexes = {
        @Index(name = "IDX_INDIVIDUALRECONNECTION", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_INDIVIDUALRECONNECTION", columnList = "TELASI_STATUS_ID"),
        @Index(name = "IDX_INDIVIDUALRECONNECTION", columnList = "RECONNECT_STATUS_ID"),
        @Index(name = "IDX_INDIVIDUALRECONNECTION", columnList = "BLOCK_ID"),
        @Index(name = "IDX_INDIVIDUALRECONNECTION", columnList = "ADDRESS_ID")
})
@Entity(name = "prx_IndividualReconnection")
public class IndividualReconnection {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "CUT_OFF_TYPE")
    private String cutOffType;

    @Column(name = "IS_SENT")
    private Boolean isSent;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @Column(name = "RECONNECTION_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date reconnectionTime;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "TELASI_SENT_DATE")
    @Temporal(TemporalType.DATE)
    private Date telasiSentDate;

    @JoinColumn(name = "TELASI_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TelasiStatus telasiStatus;

    @Column(name = "RECONNECTION_DATE")
    @Temporal(TemporalType.DATE)
    private Date reconnectionDate;

    @Column(name = "RECONNECTION_TYPE")
    private String reconnectionType;

    @JoinColumn(name = "RECONNECT_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CutoffStatus reconnectStatus;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @JoinColumn(name = "ADDRESS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CounterAdress address;

    @Column(name = "LETTER_NUMBER", length = 30)
    private String letterNumber;

    @Column(name = "DATE_")
    @Temporal(TemporalType.DATE)
    private Date date;

    public Boolean getIsSent() {
        return isSent;
    }

    public void setIsSent(Boolean isSent) {
        this.isSent = isSent;
    }

    public CustomerCuttStatus getCutOffType() {
        return cutOffType == null ? null : CustomerCuttStatus.fromId(cutOffType);
    }

    public void setCutOffType(CustomerCuttStatus cutOffType) {
        this.cutOffType = cutOffType == null ? null : cutOffType.getId();
    }

    public Date getReconnectionTime() {
        return reconnectionTime;
    }

    public void setReconnectionTime(Date reconnectionTime) {
        this.reconnectionTime = reconnectionTime;
    }

    public Date getTelasiSentDate() {
        return telasiSentDate;
    }

    public void setTelasiSentDate(Date telasiSentDate) {
        this.telasiSentDate = telasiSentDate;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getLetterNumber() {
        return letterNumber;
    }

    public void setLetterNumber(String letterNumber) {
        this.letterNumber = letterNumber;
    }

    public CounterAdress getAddress() {
        return address;
    }

    public void setAddress(CounterAdress address) {
        this.address = address;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public CutoffStatus getReconnectStatus() {
        return reconnectStatus;
    }

    public void setReconnectStatus(CutoffStatus reconnectStatus) {
        this.reconnectStatus = reconnectStatus;
    }

    public ReconnectionType getReconnectionType() {
        return reconnectionType == null ? null : ReconnectionType.fromId(reconnectionType);
    }

    public void setReconnectionType(ReconnectionType reconnectionType) {
        this.reconnectionType = reconnectionType == null ? null : reconnectionType.getId();
    }

    public Date getReconnectionDate() {
        return reconnectionDate;
    }

    public void setReconnectionDate(Date reconnectionDate) {
        this.reconnectionDate = reconnectionDate;
    }

    public TelasiStatus getTelasiStatus() {
        return telasiStatus;
    }

    public void setTelasiStatus(TelasiStatus telasiStatus) {
        this.telasiStatus = telasiStatus;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }


    @PrePersist
    public void prePersist() {
        CustomerReconnection reconn = AppBeans.getBean(CustomerReconnection.class);
        this.reconnectionTime = reconn.getReconnectionTime(this.getCreatedDate());
    }
}