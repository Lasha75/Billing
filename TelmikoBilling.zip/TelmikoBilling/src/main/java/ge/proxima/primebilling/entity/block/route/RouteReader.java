package ge.proxima.primebilling.entity.block.route;

import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import io.jmix.core.Messages;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.ui.Notifications;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_ROUTE_READER", indexes = {
        @Index(name = "IDX_ROUTEREADER_ROUTE_ID", columnList = "ROUTE_ID")
})
@Entity(name = "prx_RouteReader")
public class RouteReader {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @NotNull
    @JoinColumn(name = "READER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Reader reader;

    @NotNull
    @Column(name = "FROM_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date fromDate;

    @Column(name = "LAST_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastDate;

    @NotNull
    @JoinColumn(name = "ROUTE_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Route route;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public void setReader(Reader reader) {
        this.reader = reader;
    }

    public Reader getReader() {
        return reader;
    }

    public Route getRoute() {
        return route;
    }

    public void setRoute(Route route) {
        this.route = route;
    }

    public Date getLastDate() {
        return lastDate;
    }

    public void setLastDate(Date lastDate) {
        this.lastDate = lastDate;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PrePersist
    public void prePersist() {
        checkDates();
        checkUniqueness();
    }

    @PreUpdate
    public void preUpdate() {
        checkDates();
        checkUniqueness();
    }

    private void checkUniqueness() {
        DataManager dataManager = AppBeans.getBean(DataManager.class);
        RouteReader routeReader = dataManager.load(RouteReader.class)
                .query("select e from prx_RouteReader e where e.route.id = :routeId and (" +
                        "(e.fromDate >= :fromDate and e.fromDate <= :lastDate) or " +
                        "(e.lastDate >= :fromDate and e.lastDate <= :lastDate))")
                .parameter("routeId", getRoute().getId())
                .parameter("fromDate", getFromDate())
                .parameter("lastDate", getLastDate())
                .optional().orElse(null);

        if (routeReader != null && !routeReader.getId().equals(getId())) {
            Messages messages = AppBeans.getBean(Messages.class);

            throw new RuntimeException(messages.getMessage(this.getClass(),  "periodError"));
        }
    }
    private void checkDates() {
        Date activationDate = getFromDate();
        Date deactivationDate = getLastDate();
        Messages messages = AppBeans.getBean(Messages.class);

        if (deactivationDate.before(activationDate))
            throw new RuntimeException(messages.formatMessage(this.getClass(), "incorrectDates"));
    }
}