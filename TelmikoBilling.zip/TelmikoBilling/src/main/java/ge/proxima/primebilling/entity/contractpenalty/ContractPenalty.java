package ge.proxima.primebilling.entity.contractpenalty;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.setup.SupplyContract;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_ContractPenalty")
public class ContractPenalty {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    @JmixProperty(mandatory = true)
    @NotNull
    private Customer customer;

    private SupplyContract supplyContract;

    private String customerName;

    @Temporal(TemporalType.DATE)
    private Date paymentDate;

    @Temporal(TemporalType.DATE)
    private Date realPaymentDate;

    private BigDecimal debt;

    private Double percent;

    private Integer overdueDays;

    private Integer alreadyChargedDays;

    private BigDecimal counterPenaltyAmount;

    private Integer respectfulDays;

    public SupplyContract getSupplyContract() {
        return supplyContract;
    }

    public void setSupplyContract(SupplyContract supplyContract) {
        this.supplyContract = supplyContract;
    }

    public Integer getRespectfulDays() {
        return respectfulDays;
    }

    public void setRespectfulDays(Integer respectfulDays) {
        this.respectfulDays = respectfulDays;
    }

    public void setPercent(Double percent) {
        this.percent = percent;
    }

    public Double getPercent() {
        return percent;
    }

    public BigDecimal getCounterPenaltyAmount() {
        return counterPenaltyAmount;
    }

    public void setCounterPenaltyAmount(BigDecimal counterPenaltyAmount) {
        this.counterPenaltyAmount = counterPenaltyAmount;
    }

    public Integer getAlreadyChargedDays() {
        return alreadyChargedDays;
    }

    public void setAlreadyChargedDays(Integer alreadyChargedDays) {
        this.alreadyChargedDays = alreadyChargedDays;
    }

    public Integer getOverdueDays() {
        return overdueDays;
    }

    public void setOverdueDays(Integer overdueDays) {
        this.overdueDays = overdueDays;
    }

    public BigDecimal getDebt() {
        return debt;
    }

    public void setDebt(BigDecimal debt) {
        this.debt = debt;
    }

    public Date getRealPaymentDate() {
        return realPaymentDate;
    }

    public void setRealPaymentDate(Date realPaymentDate) {
        this.realPaymentDate = realPaymentDate;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}