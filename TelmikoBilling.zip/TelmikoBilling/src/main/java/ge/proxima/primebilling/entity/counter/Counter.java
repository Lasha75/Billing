package ge.proxima.primebilling.entity.counter;

import ge.proxima.primebilling.entity.CounterHatch;
import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.block.route.Route;
import ge.proxima.primebilling.entity.customer.CustomerContract;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.entity.tariff.Tariff;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.numerator.NumeratorService;
import io.jmix.core.DeletePolicy;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDelete;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_COUNTER", indexes = {
        @Index(name = "IDX_COUNTER_TYPE_ID", columnList = "TYPE_ID"),
        @Index(name = "IDX_COUNTER_LOCATION_ID", columnList = "LOCATION_ID"),
        @Index(name = "IDX_COUNTER_PARENT_COUNTER_ID", columnList = "PARENT_COUNTER_ID"),
        @Index(name = "IDX_COUNTER_STATUS_ID", columnList = "STATUS_ID"),
        @Index(name = "IDX_COUNTER_COEFFICIENT_ID", columnList = "COEFFICIENT_ID"),
        @Index(name = "IDX_COUNTER_ROUTE_ID", columnList = "ROUTE_ID"),
        @Index(name = "IDX_COUNTER_CONTRACT_ID", columnList = "CONTRACT_ID"),
        @Index(name = "IDX_COUNTER_POSITION_ID", columnList = "POSITION_ID"),
        @Index(name = "IDX_COUNTER_BLOCK_ID", columnList = "BLOCK_ID"),
        @Index(name = "IDX_COUNTER_TARIFF_ID", columnList = "TARIFF_ID")
})
@Entity(name = "prx_Counter")
public class Counter implements BaseUuidEntity {

    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VOLTAGE_START_DATE")
    @Temporal(TemporalType.DATE)
    private Date voltageStartDate;

    @Column(name = "TELASI_MT_TPKEY", precision = 8, scale = 0)
    private BigDecimal telasiMtTpkey;

    @Column(name = "TELASI_ACC_ID", length = 40)
    private String telasiAccId;

    @Column(name = "CODE", nullable = false, length = 20)
    @NotNull
    private String code;

    @OneToMany(mappedBy = "counter")
    private Collection<CounterAdress> addresses;

    @InstanceName
    @Column(name = "SERIAL_NUMBER", length = 50)
    private String serialNumber;

    @Column(name = "INSTALL_DATE")
    @Temporal(TemporalType.DATE)
    private Date installDate;

    @Column(name = "CREATE_DATE")
    @Temporal(TemporalType.DATE)
    private Date createDate;

    @Column(name = "CLOSE_DATE")
    @Temporal(TemporalType.DATE)
    private Date closeDate;

    @Column(name = "TELASI_ACC_KEY", precision = 19, scale = 2)
    private BigDecimal telasiAccKey;

    @Column(name = "VOLTAGE", length = 30)
    private String voltage;

    @Column(name = "CUST_KEY", precision = 8, scale = 0)
    private BigDecimal custKey;

    @Column(name = "TELASI_IS_SMART", precision = 19, scale = 2)
    private BigDecimal telasiIsSmart;

    @Column(name = "HASH_CODE", length = 200)
    private String hashCode;

    @JoinColumn(name = "ROUTE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Route route;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @NotNull
    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "CONTRACT_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private CustomerContract contract;

    @OneToMany(mappedBy = "counter")
    private List<CounterHatch> hatches;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CounterType type;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "LOCATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CounterLocation location;

    @JoinColumn(name = "POSITION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CounterPosition position;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @JoinColumn(name = "TARIFF_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Tariff tariff;

    @Column(name = "INSTALL_CP", precision = 19, scale = 2)
    private BigDecimal installCp;

    @Column(name = "REQ_CP", precision = 19, scale = 2)
    private BigDecimal reqCp;

    @Column(name = "INSTALL_REGISTRATION_NUMBER", length = 50)
    private String installRegistrationNumber;

    @Column(name = "REMOVE_REGISTRATION_NUMBER", length = 50)
    private String removeRegistrationNumber;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "PARENT_COUNTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Counter parentCounter;

    @Column(name = "PRIMARY_")
    private Boolean primary = false;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "STATUS_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Status status;

    @NotNull
    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "COEFFICIENT_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private CounterCoefficient coefficient;

    @Column(name = "LONGITUDE")
    private Double longitude;

    @Column(name = "LATITUDE")
    private Double latitude;

    @Column(name = "COMMENT_", length = 400)
    private String comment;

    @OnDelete(DeletePolicy.CASCADE)
    @Composition
    @OneToMany(mappedBy = "counter")
    private List<CounterComment> comments;

    public Date getVoltageStartDate() {
        return voltageStartDate;
    }

    public void setVoltageStartDate(Date voltageStartDate) {
        this.voltageStartDate = voltageStartDate;
    }

    public BigDecimal getTelasiMtTpkey() {
        return telasiMtTpkey;
    }

    public void setTelasiMtTpkey(BigDecimal telasiMtTpkey) {
        this.telasiMtTpkey = telasiMtTpkey;
    }

    public BigDecimal getCustKey() {
        return custKey;
    }

    public void setCustKey(BigDecimal custKey) {
        this.custKey = custKey;
    }

    public String getVoltage() {
        return voltage;
    }

    public void setVoltage(String voltage) {
        this.voltage = voltage;
    }

    public void setAddresses(Collection<CounterAdress> addresses) {
        this.addresses = addresses;
    }

    public Collection<CounterAdress> getAddresses() {
        return addresses;
    }

    public String getHashCode() {
        return hashCode;
    }

    public void setHashCode(String hashCode) {
        this.hashCode = hashCode;
    }

    public BigDecimal getTelasiIsSmart() {
        return telasiIsSmart;
    }

    public void setTelasiIsSmart(BigDecimal telasiIsSmart) {
        this.telasiIsSmart = telasiIsSmart;
    }

    public BigDecimal getTelasiAccKey() {
        return telasiAccKey;
    }

    public void setTelasiAccKey(BigDecimal telasiAccKey) {
        this.telasiAccKey = telasiAccKey;
    }

    public Date getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(Date closeDate) {
        this.closeDate = closeDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getTelasiAccId() {
        return telasiAccId;
    }

    public void setTelasiAccId(String telasiAccId) {
        this.telasiAccId = telasiAccId;
    }

    public Tariff getTariff() {
        return tariff;
    }

    public void setTariff(Tariff tariff) {
        this.tariff = tariff;
    }

    public BigDecimal getReqCp() {
        return reqCp;
    }

    public void setReqCp(BigDecimal reqCp) {
        this.reqCp = reqCp;
    }

    public BigDecimal getInstallCp() {
        return installCp;
    }

    public void setInstallCp(BigDecimal installCp) {
        this.installCp = installCp;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public CounterPosition getPosition() {
        return position;
    }

    public void setPosition(CounterPosition position) {
        this.position = position;
    }

    public Date getInstallDate() {
        return installDate;
    }

    public void setInstallDate(Date installDate) {
        this.installDate = installDate;
    }

    public Route getRoute() {
        return route;
    }

    public void setRoute(Route route) {
        this.route = route;
    }

    public CustomerContract getContract() {
        return contract;
    }

    public void setContract(CustomerContract contract) {
        this.contract = contract;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<CounterComment> getComments() {
        return comments;
    }

    public void setComments(List<CounterComment> comments) {
        this.comments = comments;
    }

    public List<CounterHatch> getHatches() {
        return hatches;
    }

    public void setHatches(List<CounterHatch> hatches) {
        this.hatches = hatches;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public CounterCoefficient getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(CounterCoefficient coefficient) {
        this.coefficient = coefficient;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Boolean getPrimary() {
        return primary;
    }

    public void setPrimary(Boolean primary) {
        this.primary = primary;
    }

    public Counter getParentCounter() {
        return parentCounter;
    }

    public void setParentCounter(Counter parentCounter) {
        this.parentCounter = parentCounter;
    }

    public String getRemoveRegistrationNumber() {
        return removeRegistrationNumber;
    }

    public void setRemoveRegistrationNumber(String removeRegistrationNumber) {
        this.removeRegistrationNumber = removeRegistrationNumber;
    }

    public String getInstallRegistrationNumber() {
        return installRegistrationNumber;
    }

    public void setInstallRegistrationNumber(String installRegistrationNumber) {
        this.installRegistrationNumber = installRegistrationNumber;
    }

    public CounterLocation getLocation() {
        return location;
    }

    public void setLocation(CounterLocation location) {
        this.location = location;
    }

    public CounterType getType() {
        return type;
    }

    public void setType(CounterType type) {
        this.type = type;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @DependsOnProperties({"code"})
    public String getInstanceName() {
        return String.format("%s", code);
    }

    @PrePersist
    public void prePersist() {
        checkSerialNum();
    }

    @PreUpdate
    public void preUpdate() {
        checkSerialNum();
    }

    @PostConstruct
    public void postConstruct() {
        if(getCode() == null || getCode() == "") {
            NumeratorService numeratorService = AppBeans.getBean(NumeratorService.class);
            setCode(
                    numeratorService.getNumSeq(this.getClass())
            );
        }
    }

    public void checkSerialNum() {
      /*  DataManager dataManager = AppBeans.getBean(DataManager.class);
        Messa
        ges messages = AppBeans.getBean(Messages.class);
        Counter counter = dataManager.load(Counter.class)
                .query("select e from prx_Counter e where e.serialNumber = :serialNumber and e.type = :type and e.id <> :id")
                .parameter("serialNumber", serialNumber)
                .parameter("type", type)
                .parameter("id", id)
                .optional().orElse(null);
        if(counter != null) {
            throw new RuntimeException(messages.formatMessage(this.getClass(),"serialNumberAlreadyExists", type.getName(), serialNumber));
        }

       */
    }


}