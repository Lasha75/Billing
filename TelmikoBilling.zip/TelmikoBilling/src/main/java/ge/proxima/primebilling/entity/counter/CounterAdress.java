package ge.proxima.primebilling.entity.counter;

import ge.proxima.primebilling.entity.customer.CustomerContract;
import ge.proxima.primebilling.entity.reftables.setup.BuildingType;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_COUNTER_ADRESS", indexes = {
        @Index(name = "IDX_COUNTERADRESS_COUNTER_ID", columnList = "COUNTER_ID"),
        @Index(name = "IDX_COUNTERADRESS_CONTRACT_ID", columnList = "CONTRACT_ID"),
        @Index(name = "IDX_COUNTERADRESS", columnList = "BUILDING_TYPE_ID")
})
@Entity(name = "prx_CounterAdress")
public class CounterAdress {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "ADRESS", length = 350)
    private String address;

    @NotNull
    @JoinColumn(name = "COUNTER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Counter counter;

    @NotNull
    @JoinColumn(name = "CONTRACT_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private CustomerContract contract;

    @Column(name = "STREET")
    private String street;

    @Column(name = "HOUSE")
    private String house;

    @Column(name = "BUILDING")
    private String building;

    @Column(name = "PORCH")
    private String porch;

    @Column(name = "FLATE")
    private String flate;

    @Column(name = "POST_INDEX")
    private String postIndex;

    @JoinColumn(name = "BUILDING_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private BuildingType buildingType;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public BuildingType getBuildingType() {
        return buildingType;
    }

    public void setBuildingType(BuildingType buildingType) {
        this.buildingType = buildingType;
    }

    public String getPostIndex() {
        return postIndex;
    }

    public void setPostIndex(String postIndex) {
        this.postIndex = postIndex;
    }

    public String getFlate() {
        return flate;
    }

    public void setFlate(String flate) {
        this.flate = flate;
    }

    public String getPorch() {
        return porch;
    }

    public void setPorch(String porch) {
        this.porch = porch;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public CustomerContract getContract() {
        return contract;
    }

    public void setContract(CustomerContract contract) {
        this.contract = contract;
    }

    public Counter getCounter() {
        return counter;
    }

    public void setCounter(Counter counter) {
        this.counter = counter;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    private void constructAddress() {
        if (getAddress() != null) return;
        String res = getStreet() != null ? getStreet() + ", " : "";
        res += getHouse() != null ? getHouse() + ", " : "";
        res += getBuilding() != null ? getBuilding() + ", " : "";
        res += getPorch() != null ? getPorch() + ", " : "";
        res += getFlate() != null ? getFlate() + "." : ".";
        setAddress(res);
    }

    @PreUpdate
    public void preUpdate() {
        constructAddress();
    }

    @PrePersist
    public void prePersist() {
        constructAddress();
    }

    @InstanceName
    @DependsOnProperties({"address"})
    public String getInstanceName() {
        return String.format("%s", address);
    }
}