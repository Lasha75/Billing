package ge.proxima.primebilling.entity.counter;

import ge.proxima.primebilling.entity.customer.CustomerContract;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_POWER_INFORMATION", indexes = {
        @Index(name = "IDX_POWERINFORMATION", columnList = "CONTRACT_ID"),
        @Index(name = "IDX_POWERINFORMATION", columnList = "COUNTER_ID")
})
@Entity(name = "prx_PowerInformation")
public class PowerInformation {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @NotNull
    @JoinColumn(name = "CONTRACT_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private CustomerContract contract;

    @NotNull
    @JoinColumn(name = "COUNTER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Counter counter;

    @Column(name = "LICENSED_CP", precision = 19, scale = 2)
    private BigDecimal licensedCp;

    @Column(name = "INST_CP", precision = 19, scale = 2)
    private BigDecimal instCp;

    @Column(name = "TECH_SPEC_VALUE")
    private String techSpecValue;

    @Temporal(TemporalType.DATE)
    @Column(name = "TECH_SPEC_DATE")
    private Date techSpecDate;

    @Column(name = "LICENSED_CP_SUMMARY", precision = 19, scale = 2)
    private BigDecimal licensedCpSummary;

    @Column(name = "ACT_NUMBER")
    private String actNumber;

    @Column(name = "ACT_DATE")
    @Temporal(TemporalType.DATE)
    private Date actDate;

    @Column(name = "PROTOCOL_NUMBER")
    private String protocolNumber;

    @Column(name = "PROTOCOL_DATE")
    @Temporal(TemporalType.DATE)
    private Date protocolDate;

    @Column(name = "METER_ORDER_NUMBER")
    private String meterOrderNumber;

    @Column(name = "WORK_HOURS")
    private Integer workHours;

    @Column(name = "COMMENT_")
    @Lob
    private String comment;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public void setTechSpecDate(Date techSpecDate) {
        this.techSpecDate = techSpecDate;
    }

    public Date getTechSpecDate() {
        return techSpecDate;
    }

    public void setWorkHours(Integer workHours) {
        this.workHours = workHours;
    }

    public Integer getWorkHours() {
        return workHours;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getMeterOrderNumber() {
        return meterOrderNumber;
    }

    public void setMeterOrderNumber(String meterOrderNumber) {
        this.meterOrderNumber = meterOrderNumber;
    }

    public Date getProtocolDate() {
        return protocolDate;
    }

    public void setProtocolDate(Date protocolDate) {
        this.protocolDate = protocolDate;
    }

    public String getProtocolNumber() {
        return protocolNumber;
    }

    public void setProtocolNumber(String protocolNumber) {
        this.protocolNumber = protocolNumber;
    }

    public Date getActDate() {
        return actDate;
    }

    public void setActDate(Date actDate) {
        this.actDate = actDate;
    }

    public String getActNumber() {
        return actNumber;
    }

    public void setActNumber(String actNumber) {
        this.actNumber = actNumber;
    }

    public BigDecimal getLicensedCpSummary() {
        return licensedCpSummary;
    }

    public void setLicensedCpSummary(BigDecimal licensedCpSummary) {
        this.licensedCpSummary = licensedCpSummary;
    }

    public String getTechSpecValue() {
        return techSpecValue;
    }

    public void setTechSpecValue(String techSpecValue) {
        this.techSpecValue = techSpecValue;
    }

    public BigDecimal getInstCp() {
        return instCp;
    }

    public void setInstCp(BigDecimal instCp) {
        this.instCp = instCp;
    }

    public BigDecimal getLicensedCp() {
        return licensedCp;
    }

    public void setLicensedCp(BigDecimal licensedCp) {
        this.licensedCp = licensedCp;
    }

    public Counter getCounter() {
        return counter;
    }

    public void setCounter(Counter counter) {
        this.counter = counter;
    }

    public CustomerContract getContract() {
        return contract;
    }

    public void setContract(CustomerContract contract) {
        this.contract = contract;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}