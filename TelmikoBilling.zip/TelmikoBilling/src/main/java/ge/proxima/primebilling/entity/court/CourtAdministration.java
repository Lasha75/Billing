package ge.proxima.primebilling.entity.court;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.customer.setup.Category;
import ge.proxima.primebilling.entity.customer.setup.CustomerAddress;
import ge.proxima.primebilling.entity.customer.setup.GiveType;
import ge.proxima.primebilling.entity.enums.CourtCaseCategory;
import ge.proxima.primebilling.entity.reftables.Activity;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.numerator.NumeratorService;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_COURT_ADMINISTRATION", indexes = {
        @Index(name = "IDX_COURTADMINISTRATION", columnList = "CUSTOMER_CATEGORY_ID"),
        @Index(name = "IDX_COURTADMINISTRATION", columnList = "CATEGORY_ID"),
        @Index(name = "IDX_COURTADMINISTRATION", columnList = "GIVE_TYPE_ID"),
        @Index(name = "IDX_COURTADMINISTRATION", columnList = "CUSTOMER_ADDRESS_ID"),
        @Index(name = "IDX_COURTADMINISTRATION", columnList = "LAWYER_ID"),
        @Index(name = "IDX_COURTADMINISTRATION", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_COURTADMINISTRATION", columnList = "STATUS_ID"),
        @Index(name = "IDX_COURTADMINISTRATION", columnList = "PRE_COURT_WORK_ID")
})
@Entity(name = "prx_CourtAdministration")
public class CourtAdministration implements BaseUuidEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @InstanceName
    @Column(name = "NUMBER_")
    private String number;

    @JoinColumn(name = "PRE_COURT_WORK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private PreCourtWork preCourtWork;

    @JoinColumn(name = "LAWYER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Lawyer lawyer;

    @Column(name = "CATEGORY")
    private String category;

    @Column(name = "CASE_NUMBER")
    private String caseNumber;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @JoinColumn(name = "STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status status;

    @Column(name = "CUSTOMER_NAME")
    private String customerName;

    @JoinColumn(name = "CUSTOMER_CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory customerCategory;

    @JoinColumn(name = "CUSTOMER_ACTIVITY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Activity customerActivity;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Category consumerCategory;

    @JoinColumn(name = "GIVE_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private GiveType customerGiveType;

    @JoinColumn(name = "CUSTOMER_ADDRESS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerAddress customerAddress;

    @Column(name = "CUSTOMER_IDENTIFICATION_NUMBER")
    private String customerIdentificationNumber;

    @Column(name = "CUSTOMER_DEBT", precision = 19, scale = 2)
    private BigDecimal customerDebt;

    @Column(name = "CUSTOMER_CADASTRAL_CODE")
    private String customerCadastralCode;

    @Column(name = "ENERGY_DISTRIBUTED")
    private Boolean energyDebtDistributed = false;

    public PreCourtWork getPreCourtWork() {
        return preCourtWork;
    }

    public void setPreCourtWork(PreCourtWork preCourtWork) {
        this.preCourtWork = preCourtWork;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getNumber() {
        return number;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public CourtCaseCategory getCategory() {
        return category == null ? null : CourtCaseCategory.fromId(category);
    }

    public void setCategory(CourtCaseCategory category) {
        this.category = category == null ? null : category.getId();
    }

    public Lawyer getLawyer() {
        return lawyer;
    }

    public void setLawyer(Lawyer lawyer) {
        this.lawyer = lawyer;
    }

    public Boolean getEnergyDebtDistributed() {
        return energyDebtDistributed;
    }

    public void setEnergyDebtDistributed(Boolean energyDebtDistributed) {
        this.energyDebtDistributed = energyDebtDistributed;
    }

    public String getCustomerCadastralCode() {
        return customerCadastralCode;
    }

    public void setCustomerCadastralCode(String customerCadastralCode) {
        this.customerCadastralCode = customerCadastralCode;
    }

    public BigDecimal getCustomerDebt() {
        return customerDebt;
    }

    public void setCustomerDebt(BigDecimal customerDebt) {
        this.customerDebt = customerDebt;
    }

    public String getCustomerIdentificationNumber() {
        return customerIdentificationNumber;
    }

    public void setCustomerIdentificationNumber(String customerIdentificationNumber) {
        this.customerIdentificationNumber = customerIdentificationNumber;
    }

    public CustomerAddress getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(CustomerAddress customerAddress) {
        this.customerAddress = customerAddress;
    }

    public GiveType getCustomerGiveType() {
        return customerGiveType;
    }

    public void setCustomerGiveType(GiveType customerGiveType) {
        this.customerGiveType = customerGiveType;
    }

    public Category getConsumerCategory() {
        return consumerCategory;
    }

    public void setConsumerCategory(Category consumerCategory) {
        this.consumerCategory = consumerCategory;
    }

    public Activity getCustomerActivity() {
        return customerActivity;
    }

    public void setCustomerActivity(Activity customerActivity) {
        this.customerActivity = customerActivity;
    }

    public CustomerCategory getCustomerCategory() {
        return customerCategory;
    }

    public void setCustomerCategory(CustomerCategory customerCategory) {
        this.customerCategory = customerCategory;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PostConstruct
    public void postConstruct() {
        NumeratorService numeratorService = AppBeans.getBean(NumeratorService.class);
        setNumber(
                numeratorService.getNumSeq(this.getClass())
        );
    }
}