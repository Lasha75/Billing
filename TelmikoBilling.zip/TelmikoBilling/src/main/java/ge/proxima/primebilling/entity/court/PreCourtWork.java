package ge.proxima.primebilling.entity.court;

import ge.proxima.primebilling.entity.User;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.enums.PreCourtWorkStatus;
import ge.proxima.primebilling.entity.reftables.BusinessCenter;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.entitylogger.VersionControlKey;
import ge.proxima.primebilling.java.entitylogger.VersionControlledEntity;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.numerator.NumeratorService;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_PRE_COURT_WORK", indexes = {
        @Index(name = "IDX_PRECOURTWORK_CUSTOMER_ID", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRECOURTWORK_CATEGORY_ID", columnList = "CATEGORY_ID"),
        @Index(name = "IDX_PRECOURTWORK", columnList = "BUSINESS_CENTER_ID"),
        @Index(name = "IDX_PRECOURTWORK", columnList = "RESPONSIBLE_USER_ID"),
        @Index(name = "IDX_PRECOURTWORK", columnList = "ENERGY_SUPPLY_STATUS_ID")
})
@Entity(name = "prx_PreCourtWork")
public class PreCourtWork extends VersionControlledEntity implements BaseUuidEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @VersionControlKey
    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "LIMIT_DATE")
    @Temporal(TemporalType.DATE)
    private Date limitDate;

    @VersionControlKey
    @Column(name = "PASSED_TO_CUT_OFF")
    private Boolean passedToCutOff = false;

    @VersionControlKey
    @Column(name = "PASSED_TO_SCURITY")
    private Boolean passedToSecurity = false;

    @VersionControlKey
    @Column(name = "SECURITY_COMMENT")
    @Lob
    private String securityComment;

    @VersionControlKey
    @Column(name = "STATUS")
    private String status;

    @VersionControlKey
    @JoinColumn(name = "RESPONSIBLE_USER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private User responsibleUser;

    @Column(name = "REMARK")
    @Lob
    private String remark;

    @VersionControlKey
    @JoinColumn(name = "ENERGY_SUPPLY_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status energySupplyStatus;

    @OneToMany(mappedBy = "preCourtWork")
    private List<PreCourtWorkLine> lines;

    @VersionControlKey
    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory category;

    @VersionControlKey
    @JoinColumn(name = "BUSINESS_CENTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private BusinessCenter businessCenter;

    @VersionControlKey
    @Column(name = "CASE_ID")
    private String caseId;

    @VersionControlKey
    @Column(name = "LIMIT_")
    private Integer limit;

    @VersionControlKey
    @Column(name = "TOTAL_DEBT", precision = 19, scale = 5)
    private BigDecimal totalDebt;

    @Column(name = "TOTAL_DEBT_PERIOD")
    private String totalDebtPeriod;

    public String getTotalDebtPeriod() {
        return totalDebtPeriod;
    }

    public void setTotalDebtPeriod(String totalDebtPeriod) {
        this.totalDebtPeriod = totalDebtPeriod;
    }

    public Date getLimitDate() {
        return limitDate;
    }

    public void setLimitDate(Date limitDate) {
        this.limitDate = limitDate;
    }

    public Boolean getPassedToCutOff() {
        return passedToCutOff;
    }

    public void setPassedToCutOff(Boolean passedToCutOff) {
        this.passedToCutOff = passedToCutOff;
    }

    public String getSecurityComment() {
        return securityComment;
    }

    public void setSecurityComment(String securityComment) {
        this.securityComment = securityComment;
    }

    public Boolean getPassedToSecurity() {
        return passedToSecurity;
    }

    public void setPassedToSecurity(Boolean passedToSecurity) {
        this.passedToSecurity = passedToSecurity;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public PreCourtWorkStatus getStatus() {
        return status == null ? null : PreCourtWorkStatus.fromId(status);
    }

    public void setStatus(PreCourtWorkStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public Status getEnergySupplyStatus() {
        return energySupplyStatus;
    }

    public void setEnergySupplyStatus(Status energySupplyStatus) {
        this.energySupplyStatus = energySupplyStatus;
    }

    public User getResponsibleUser() {
        return responsibleUser;
    }

    public void setResponsibleUser(User responsibleUser) {
        this.responsibleUser = responsibleUser;
    }

    public List<PreCourtWorkLine> getLines() {
        return lines;
    }

    public void setLines(List<PreCourtWorkLine> lines) {
        this.lines = lines;
    }

    public BigDecimal getTotalDebt() {
        return totalDebt;
    }

    public void setTotalDebt(BigDecimal totalDebt) {
        this.totalDebt = totalDebt;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public BusinessCenter getBusinessCenter() {
        return businessCenter;
    }

    public void setBusinessCenter(BusinessCenter businessCenter) {
        this.businessCenter = businessCenter;
    }

    public CustomerCategory getCategory() {
        return category;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"customer", "totalDebt"})
    public String getInstanceName() {
        return String.format("%s %s", status, totalDebt);
    }

    @PostUpdate
    public void postUpdate() {
        super.postUpdate();
    }

    @PostLoad
    public void postLoad() {
        super.postLoad();
    }

    public Object reflect(Field field) {
        try {
            return field.get(this);
        } catch (Exception e) {
            return null;
        }
    }

    @PostConstruct
    public void postConstruct() {
        NumeratorService numeratorService = AppBeans.getBean(NumeratorService.class);
        setCaseId(
                numeratorService.getNumSeq(this.getClass())
        );
    }
}