package ge.proxima.primebilling.entity.court;

import ge.proxima.primebilling.entity.User;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.enums.PreCourtWorkStatus;
import ge.proxima.primebilling.entity.reftables.BusinessCenter;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.java.entitylogger.LogEntity;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_PRE_COURT_WORK_LOG", indexes = {
        @Index(name = "IDX_PRECOURTWORKLOG", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRECOURTWORKLOG", columnList = "RESPONSIBLE_USER_ID"),
        @Index(name = "IDX_PRECOURTWORKLOG", columnList = "ENERGY_SUPPLY_STATUS_ID"),
        @Index(name = "IDX_PRECOURTWORKLOG", columnList = "CATEGORY_ID"),
        @Index(name = "IDX_PRECOURTWORKLOG", columnList = "BUSINESS_CENTER_ID")
})
@Entity(name = "prx_PreCourtWorkLog")
public class PreCourtWorkLog implements LogEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "PASSED_TO_CUT_OFF")
    private Boolean passedToCutOff;

    @Column(name = "PASSED_TO_SECURITY")
    private Boolean passedToSecurity;

    @Column(name = "SECURITY_COMMENT")
    @Lob
    private String securityComment;

    @Column(name = "STATUS")
    private String status;

    @JoinColumn(name = "RESPONSIBLE_USER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private User responsibleUser;

    @JoinColumn(name = "ENERGY_SUPPLY_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status energySupplyStatus;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory category;

    @JoinColumn(name = "BUSINESS_CENTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private BusinessCenter businessCenter;

    @Column(name = "CASE_ID")
    private String caseId;

    @Column(name = "LIMIT_")
    private Integer limit;

    @InstanceName
    @Column(name = "TOTAL_DEBT", precision = 19, scale = 2)
    private BigDecimal totalDebt;

    @Column(name = "FROM_DATE")
    @Temporal(TemporalType.DATE)
    private Date fromDate;

    @Column(name = "TO_DATE")
    @Temporal(TemporalType.DATE)
    private Date toDate;

    @Column(name = "ENTITY_ID")
    private UUID entityId;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public String getSecurityComment() {
        return securityComment;
    }

    public void setSecurityComment(String securityComment) {
        this.securityComment = securityComment;
    }

    public Boolean getPassedToSecurity() {
        return passedToSecurity;
    }

    public void setPassedToSecurity(Boolean passedToSecurity) {
        this.passedToSecurity = passedToSecurity;
    }

    public Boolean getPassedToCutOff() {
        return passedToCutOff;
    }

    public void setPassedToCutOff(Boolean passedToCutOff) {
        this.passedToCutOff = passedToCutOff;
    }

    public UUID getEntityId() {
        return entityId;
    }

    public void setEntityId(UUID entityId) {
        this.entityId = entityId;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public BigDecimal getTotalDebt() {
        return totalDebt;
    }

    public void setTotalDebt(BigDecimal totalDebt) {
        this.totalDebt = totalDebt;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public BusinessCenter getBusinessCenter() {
        return businessCenter;
    }

    public void setBusinessCenter(BusinessCenter businessCenter) {
        this.businessCenter = businessCenter;
    }

    public CustomerCategory getCategory() {
        return category;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public Status getEnergySupplyStatus() {
        return energySupplyStatus;
    }

    public void setEnergySupplyStatus(Status energySupplyStatus) {
        this.energySupplyStatus = energySupplyStatus;
    }

    public User getResponsibleUser() {
        return responsibleUser;
    }

    public void setResponsibleUser(User responsibleUser) {
        this.responsibleUser = responsibleUser;
    }

    public PreCourtWorkStatus getStatus() {
        return status == null ? null : PreCourtWorkStatus.fromId(status);
    }

    public void setStatus(PreCourtWorkStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}