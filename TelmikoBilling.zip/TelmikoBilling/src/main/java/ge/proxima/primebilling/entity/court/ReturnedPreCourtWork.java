package ge.proxima.primebilling.entity.court;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.customer.setup.Category;
import ge.proxima.primebilling.entity.customer.setup.CustomerAddress;
import ge.proxima.primebilling.entity.customer.setup.GiveType;
import ge.proxima.primebilling.entity.enums.CourtCaseCategory;
import ge.proxima.primebilling.entity.reftables.Activity;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_RETURNED_PRE_COURT_WORK", indexes = {
        @Index(name = "IDX_RETURNEDPRECOURTWORK", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_RETURNEDPRECOURTWORK", columnList = "CUSTOMER_ADDRESS_ID"),
        @Index(name = "IDX_RETURNEDPRECOURTWORK", columnList = "CUSTOMER_CATEGORY_ID"),
        @Index(name = "IDX_RETURNEDPRECOURTWORK", columnList = "CONSUMER_CATEGORY_ID"),
        @Index(name = "IDX_RETURNEDPRECOURTWORK", columnList = "CUSTOMER_GIVE_TYPE_ID"),
        @Index(name = "IDX_RETURNEDPRECOURTWORK", columnList = "LAWYER_ID"),
        @Index(name = "IDX_RETURNEDPRECOURTWORK", columnList = "COURT_ADMINISTRATION_ID")
})
@Entity(name = "prx_ReturnedPreCourtWork")
public class ReturnedPreCourtWork {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @JoinColumn(name = "COURT_ADMINISTRATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CourtAdministration courtAdministration;

    @Column(name = "CUSTOMER_NAME")
    private String customerName;

    @JoinColumn(name = "CUSTOMER_ADDRESS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerAddress customerAddress;

    @JoinColumn(name = "CUSTOMER_CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory customerCategory;

    @JoinColumn(name = "CUSTOMER_ACTIVITY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Activity customerActivity;

    @JoinColumn(name = "CONSUMER_CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Category consumerCategory;

    @JoinColumn(name = "CUSTOMER_GIVE_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private GiveType customerGiveType;

    @Column(name = "CUSTOMER_IDENTIFICATION_NUMBER")
    private String customerIdentificationNumber;

    @Column(name = "CUSTOMER_DEBT")
    private BigDecimal customerDebt;

    @Column(name = "CUSTOMER_CADASTRAL_CODE")
    private String customerCadastralCode;

    @Column(name = "CATEGORY")
    private String category;

    @JoinColumn(name = "LAWYER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Lawyer lawyer;

    public CourtAdministration getCourtAdministration() {
        return courtAdministration;
    }

    public void setCourtAdministration(CourtAdministration courtAdministration) {
        this.courtAdministration = courtAdministration;
    }

    public void setCustomerDebt(BigDecimal customerDebt) {
        this.customerDebt = customerDebt;
    }

    public BigDecimal getCustomerDebt() {
        return customerDebt;
    }

    public Lawyer getLawyer() {
        return lawyer;
    }

    public void setLawyer(Lawyer lawyer) {
        this.lawyer = lawyer;
    }

    public CourtCaseCategory getCategory() {
        return category == null ? null : CourtCaseCategory.fromId(category);
    }

    public void setCategory(CourtCaseCategory category) {
        this.category = category == null ? null : category.getId();
    }

    public String getCustomerCadastralCode() {
        return customerCadastralCode;
    }

    public void setCustomerCadastralCode(String customerCadastralCode) {
        this.customerCadastralCode = customerCadastralCode;
    }

    public String getCustomerIdentificationNumber() {
        return customerIdentificationNumber;
    }

    public void setCustomerIdentificationNumber(String customerIdentificationNumber) {
        this.customerIdentificationNumber = customerIdentificationNumber;
    }

    public GiveType getCustomerGiveType() {
        return customerGiveType;
    }

    public void setCustomerGiveType(GiveType customerGiveType) {
        this.customerGiveType = customerGiveType;
    }

    public Category getConsumerCategory() {
        return consumerCategory;
    }

    public void setConsumerCategory(Category consumerCategory) {
        this.consumerCategory = consumerCategory;
    }

    public Activity getCustomerActivity() {
        return customerActivity;
    }

    public void setCustomerActivity(Activity customerActivity) {
        this.customerActivity = customerActivity;
    }

    public CustomerCategory getCustomerCategory() {
        return customerCategory;
    }

    public void setCustomerCategory(CustomerCategory customerCategory) {
        this.customerCategory = customerCategory;
    }

    public CustomerAddress getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(CustomerAddress customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}