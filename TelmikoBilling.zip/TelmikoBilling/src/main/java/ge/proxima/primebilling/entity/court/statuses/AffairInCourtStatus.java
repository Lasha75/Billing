package ge.proxima.primebilling.entity.court.statuses;

import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_AFFAIR_IN_COURT_STATUS")
@Entity(name = "prx_AffairInCourtStatus")
public class AffairInCourtStatus {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @InstanceName
    @Column(name = "NUMBER_")
    private String number;

    @Column(name = "REGISTRATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date registrationDate;

    @Column(name = "JUDGE")
    private String judge;

    @Column(name = "REGISTRATION_CART_CUSTOMER_NUMBER")
    private String registrationCartCustomerNumber;

    @Column(name = "REGISTRATION_CARD_PASSWORD")
    private String registrationCardPassword;

    @Column(name = "INITIAL_MEETING_DATE")
    @Temporal(TemporalType.DATE)
    private Date initialMeetingDate;

    @Column(name = "COURT_STATUS")
    private String courtStatus;

    @Column(name = "SUIT_PRICE", precision = 19, scale = 2)
    private BigDecimal suitPrice;

    @Column(name = "REMARK")
    @Lob
    private String remark;

    public String getNumber() {
        return number;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public BigDecimal getSuitPrice() {
        return suitPrice;
    }

    public void setSuitPrice(BigDecimal suitPrice) {
        this.suitPrice = suitPrice;
    }

    public ge.proxima.primebilling.entity.enums.AffairInCourtStatus getCourtStatus() {
        return courtStatus == null ? null : ge.proxima.primebilling.entity.enums.AffairInCourtStatus.fromId(courtStatus);
    }

    public void setCourtStatus(ge.proxima.primebilling.entity.enums.AffairInCourtStatus courtStatus) {
        this.courtStatus = courtStatus == null ? null : courtStatus.getId();
    }

    public Date getInitialMeetingDate() {
        return initialMeetingDate;
    }

    public void setInitialMeetingDate(Date initialMeetingDate) {
        this.initialMeetingDate = initialMeetingDate;
    }

    public String getRegistrationCardPassword() {
        return registrationCardPassword;
    }

    public void setRegistrationCardPassword(String registrationCardPassword) {
        this.registrationCardPassword = registrationCardPassword;
    }

    public String getRegistrationCartCustomerNumber() {
        return registrationCartCustomerNumber;
    }

    public void setRegistrationCartCustomerNumber(String registrationCartCustomerNumber) {
        this.registrationCartCustomerNumber = registrationCartCustomerNumber;
    }

    public String getJudge() {
        return judge;
    }

    public void setJudge(String judge) {
        this.judge = judge;
    }

    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}