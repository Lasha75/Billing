package ge.proxima.primebilling.entity.court.statuses;

import ge.proxima.primebilling.entity.enums.CourtVerdictStatus;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_APPEAL_TO_COURT_STATUS")
@Entity(name = "prx_AppealToCourtStatus")
public class AppealToCourtStatus {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @Column(name = "CASE_NUMBER")
    private String number;

    @Column(name = "LAWYER_NAME")
    private String lawyerName;

    @Column(name = "APPEAL_COMPLAINT_ORDER_DATE")
    private String appealComplaintOrderDate;

    @Column(name = "APPEAL_STATUS")
    private String appealStatus;

    @Column(name = "REGISTRATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date registrationDate;

    @Column(name = "APPEAL_ACCEPT_DATE")
    @Temporal(TemporalType.DATE)
    private Date appealAcceptDate;

    @Column(name = "JUDJE")
    private String judge;

    @Column(name = "VERDICT_STATUS")
    private String verdictStatus;

    @Column(name = "VERDICT_DATE")
    @Temporal(TemporalType.DATE)
    private Date verdictDate;

    @Column(name = "EXCISE_AMOUNT", precision = 19, scale = 2)
    private BigDecimal exciseAmount;

    @Column(name = "REMARK")
    @Lob
    private String remark;

    public Date getAppealAcceptDate() {
        return appealAcceptDate;
    }

    public void setAppealAcceptDate(Date appealAcceptDate) {
        this.appealAcceptDate = appealAcceptDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public BigDecimal getExciseAmount() {
        return exciseAmount;
    }

    public void setExciseAmount(BigDecimal exciseAmount) {
        this.exciseAmount = exciseAmount;
    }

    public Date getVerdictDate() {
        return verdictDate;
    }

    public void setVerdictDate(Date verdictDate) {
        this.verdictDate = verdictDate;
    }

    public CourtVerdictStatus getVerdictStatus() {
        return verdictStatus == null ? null : CourtVerdictStatus.fromId(verdictStatus);
    }

    public void setVerdictStatus(CourtVerdictStatus verdictStatus) {
        this.verdictStatus = verdictStatus == null ? null : verdictStatus.getId();
    }

    public ge.proxima.primebilling.entity.enums.AppealToCourtStatus getAppealStatus() {
        return appealStatus == null ? null : ge.proxima.primebilling.entity.enums.AppealToCourtStatus.fromId(appealStatus);
    }

    public void setAppealStatus(ge.proxima.primebilling.entity.enums.AppealToCourtStatus appealStatus) {
        this.appealStatus = appealStatus == null ? null : appealStatus.getId();
    }

    public String getAppealComplaintOrderDate() {
        return appealComplaintOrderDate;
    }

    public void setAppealComplaintOrderDate(String appealComplaintOrderDate) {
        this.appealComplaintOrderDate = appealComplaintOrderDate;
    }

    public String getLawyerName() {
        return lawyerName;
    }

    public void setLawyerName(String lawyerName) {
        this.lawyerName = lawyerName;
    }

    public String getJudge() {
        return judge;
    }

    public void setJudge(String judge) {
        this.judge = judge;
    }

    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"number"})
    public String getInstanceName() {
        return String.format("%s", number);
    }
}