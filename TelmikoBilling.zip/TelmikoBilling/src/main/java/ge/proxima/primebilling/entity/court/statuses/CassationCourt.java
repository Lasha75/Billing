package ge.proxima.primebilling.entity.court.statuses;

import ge.proxima.primebilling.entity.CassationCourtStatus;
import ge.proxima.primebilling.entity.enums.CourtVerdictStatus;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CASSATION_COURT")
@Entity(name = "prx_CassationCourt")
public class CassationCourt {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @Column(name = "NUMBER_")
    private String number;

    @Column(name = "REGISTRATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date registrationDate;

    @Column(name = "JUDGE")
    private String judge;

    @Column(name = "LAWYER_NAME")
    private String lawyerName;

    @Column(name = "CASSATION_ACCEPT_DATE")
    @Temporal(TemporalType.DATE)
    private Date cassationAcceptDate;

    @Column(name = "CASSATION_STATUS")
    private String cassationStatus;

    @Column(name = "VERDICT_STATUS")
    private String verdictStatus;

    @Column(name = "VERDICT_MAKE_DATE")
    @Temporal(TemporalType.DATE)
    private Date verdictMakeDate;

    @Column(name = "EXCISE_AMOUNT", precision = 19, scale = 2)
    private BigDecimal exciseAmount;

    public BigDecimal getExciseAmount() {
        return exciseAmount;
    }

    public void setExciseAmount(BigDecimal exciseAmount) {
        this.exciseAmount = exciseAmount;
    }

    public Date getVerdictMakeDate() {
        return verdictMakeDate;
    }

    public void setVerdictMakeDate(Date verdictMakeDate) {
        this.verdictMakeDate = verdictMakeDate;
    }

    public CourtVerdictStatus getVerdictStatus() {
        return verdictStatus == null ? null : CourtVerdictStatus.fromId(verdictStatus);
    }

    public void setVerdictStatus(CourtVerdictStatus verdictStatus) {
        this.verdictStatus = verdictStatus == null ? null : verdictStatus.getId();
    }

    public CassationCourtStatus getCassationStatus() {
        return cassationStatus == null ? null : CassationCourtStatus.fromId(cassationStatus);
    }

    public void setCassationStatus(CassationCourtStatus cassationStatus) {
        this.cassationStatus = cassationStatus == null ? null : cassationStatus.getId();
    }

    public Date getCassationAcceptDate() {
        return cassationAcceptDate;
    }

    public void setCassationAcceptDate(Date cassationAcceptDate) {
        this.cassationAcceptDate = cassationAcceptDate;
    }

    public String getLawyerName() {
        return lawyerName;
    }

    public void setLawyerName(String lawyerName) {
        this.lawyerName = lawyerName;
    }

    public String getJudge() {
        return judge;
    }

    public void setJudge(String judge) {
        this.judge = judge;
    }

    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}