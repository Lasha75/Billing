package ge.proxima.primebilling.entity.court.statuses;

import ge.proxima.primebilling.entity.enums.CourtExecutiveStatus;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_COURT_EXECUTIVE_PRODUCTION")
@Entity(name = "prx_CourtExecutiveProduction")
public class CourtExecutiveProduction {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @Column(name = "DECISION_AND_EXECUTIVE_ORDER_REQUEST")
    @Temporal(TemporalType.DATE)
    private Date decisionAndExecutiveOrderRequest;

    @Column(name = "DECISION_AND_EXECUTIVE_ORDER_RECEIPT")
    @Temporal(TemporalType.DATE)
    private Date decisionAndExecutiveOrderReceipt;

    @Column(name = "EXECUTIVE_ORDER_SENT_TO_EXECUTE")
    @Temporal(TemporalType.DATE)
    private Date executiveOrderSentToExecute;

    @Column(name = "EXECUTIVE_EXCISE_AMOUNT", precision = 19, scale = 2)
    private BigDecimal executiveExciseAmount;

    @Column(name = "EXECUTIVE_MAKE_START")
    @Temporal(TemporalType.DATE)
    private Date executiveMakeStart;

    @Column(name = "DEBT_DIVIDING_IN_EXECUTIVE")
    @Temporal(TemporalType.DATE)
    private Date debtDividingInExecutive;

    @Column(name = "EXECUTIVE_ORDER_WITHDRAWAL")
    @Temporal(TemporalType.DATE)
    private Date executiveOrderWithdrawal;

    @Column(name = "EXECUTIVE_WORK_END")
    @Temporal(TemporalType.DATE)
    private Date executiveWorkEnd;

    @Column(name = "EXECUTION_STATUS")
    private String executionStatus;

    @Column(name = "PARTIALLY_FULLFILED_AMOUNT", precision = 19, scale = 2)
    private BigDecimal partiallyFullfiledAmount;

    @Column(name = "NOT_FULFILLED_REASON")
    @Lob
    private String notFulfilledReason;

    @Column(name = "REMARK")
    @Lob
    private String remark;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getNotFulfilledReason() {
        return notFulfilledReason;
    }

    public void setNotFulfilledReason(String notFulfilledReason) {
        this.notFulfilledReason = notFulfilledReason;
    }

    public BigDecimal getPartiallyFullfiledAmount() {
        return partiallyFullfiledAmount;
    }

    public void setPartiallyFullfiledAmount(BigDecimal partiallyFullfiledAmount) {
        this.partiallyFullfiledAmount = partiallyFullfiledAmount;
    }

    public CourtExecutiveStatus getExecutionStatus() {
        return executionStatus == null ? null : CourtExecutiveStatus.fromId(executionStatus);
    }

    public void setExecutionStatus(CourtExecutiveStatus executionStatus) {
        this.executionStatus = executionStatus == null ? null : executionStatus.getId();
    }

    public Date getExecutiveWorkEnd() {
        return executiveWorkEnd;
    }

    public void setExecutiveWorkEnd(Date executiveWorkEnd) {
        this.executiveWorkEnd = executiveWorkEnd;
    }

    public Date getExecutiveOrderWithdrawal() {
        return executiveOrderWithdrawal;
    }

    public void setExecutiveOrderWithdrawal(Date executiveOrderWithdrawal) {
        this.executiveOrderWithdrawal = executiveOrderWithdrawal;
    }

    public Date getDebtDividingInExecutive() {
        return debtDividingInExecutive;
    }

    public void setDebtDividingInExecutive(Date debtDividingInExecutive) {
        this.debtDividingInExecutive = debtDividingInExecutive;
    }

    public Date getExecutiveMakeStart() {
        return executiveMakeStart;
    }

    public void setExecutiveMakeStart(Date executiveMakeStart) {
        this.executiveMakeStart = executiveMakeStart;
    }

    public BigDecimal getExecutiveExciseAmount() {
        return executiveExciseAmount;
    }

    public void setExecutiveExciseAmount(BigDecimal executiveExciseAmount) {
        this.executiveExciseAmount = executiveExciseAmount;
    }

    public Date getExecutiveOrderSentToExecute() {
        return executiveOrderSentToExecute;
    }

    public void setExecutiveOrderSentToExecute(Date executiveOrderSentToExecute) {
        this.executiveOrderSentToExecute = executiveOrderSentToExecute;
    }

    public Date getDecisionAndExecutiveOrderReceipt() {
        return decisionAndExecutiveOrderReceipt;
    }

    public void setDecisionAndExecutiveOrderReceipt(Date decisionAndExecutiveOrderReceipt) {
        this.decisionAndExecutiveOrderReceipt = decisionAndExecutiveOrderReceipt;
    }

    public Date getDecisionAndExecutiveOrderRequest() {
        return decisionAndExecutiveOrderRequest;
    }

    public void setDecisionAndExecutiveOrderRequest(Date decisionAndExecutiveOrderRequest) {
        this.decisionAndExecutiveOrderRequest = decisionAndExecutiveOrderRequest;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}