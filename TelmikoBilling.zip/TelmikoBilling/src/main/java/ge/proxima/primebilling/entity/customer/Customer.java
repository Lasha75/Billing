package ge.proxima.primebilling.entity.customer;

import ge.proxima.primebilling.entity.CustomerCuttStatus;
import ge.proxima.primebilling.entity.CustomerMayorsSubsidy;
import ge.proxima.primebilling.entity.block.IndividualCutoff;
import ge.proxima.primebilling.entity.block.IndividualReconnection;
import ge.proxima.primebilling.entity.customer.setup.*;
import ge.proxima.primebilling.entity.deposit.CustomerMessage;
import ge.proxima.primebilling.entity.enums.DelayerCustomerStatus;
import ge.proxima.primebilling.entity.enums.SocialScore;
import ge.proxima.primebilling.entity.enums.SubsidyUpdateType;
import ge.proxima.primebilling.entity.reftables.Activity;
import ge.proxima.primebilling.entity.reftables.BusinessCenter;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.reftables.setup.BuildingType;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.entitylogger.VersionControlKey;
import ge.proxima.primebilling.java.entitylogger.VersionControlledEntity;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.numerator.NumeratorService;
import io.jmix.core.DataManager;
import io.jmix.core.DeletePolicy;
import io.jmix.core.Messages;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.*;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Table(name = "PRX_CUSTOMER", indexes = {
        @Index(name = "IDX_CUSTOMER_STATUS_ID", columnList = "STATUS_ID"),
        @Index(name = "IDX_CUSTOMER_CATEGORY_ID", columnList = "CUST_CATEGORY_ID"),
        @Index(name = "IDX_CUSTOMER", columnList = "BUSINESS_CENTER_ID"),
        @Index(name = "IDX_CUSTOMER_ACTIVITY_ID", columnList = "ACTIVITY_ID"),
        @Index(name = "IDX_CUSTOMER", columnList = "PAYER_CUSTOMER_ID"),
        @Index(name = "IDX_CUSTOMER", columnList = "PARENT_CUSTOMER_ID"),
        @Index(name = "IDX_PRX_CUSTOMER_UNQ", columnList = "CUSTOMER_CODE", unique = true),
        @Index(name = "IDX_PRX_CUSTOMER_UNQ_1", columnList = "CUSTOMER_NUMBER", unique = true),
        @Index(name = "IDX_PRX_CUSTOMER_UNQ_2", columnList = "COMMUNAL_COMPANY_NUMBER", unique = true),
        @Index(name = "IDX_CUSTOMER_GIVE_TYPE_ID", columnList = "GIVE_TYPE_ID"),
        @Index(name = "IDX_CUSTOMER_DEBET_STATUS_ID", columnList = "DEBET_STATUS_ID"),
        @Index(name = "IDX_CUSTOMER", columnList = "PROPRIETOR_INFORMATION_ID"),
        @Index(name = "IDX_CUSTOMER", columnList = "BENEFICIARY_INFORMATION_ID"),
        @Index(name = "IDX_CUSTOMER_CUST_CATEGORY_ID", columnList = "CUST_CATEGORY_ID"),
        @Index(name = "IDX_PRX_CUSTOMER_SOCIAL_SCORE", columnList = "SOCIAL_SCORE"),
        @Index(name = "IDX_PRX_CUSTOMER_id_cratedate", columnList = "ID, CREATE_DATE, DELETED_DATE"),
        @Index(name = "IDX_PRX_CUSTOMER_Custkey", columnList = "CUST_KEY"),
        @Index(name = "IDX_PRXCUSTOMER_PUMPPARENTCUST", columnList = "PUMP_PARENT_CUSTOMER_ID"),
        @Index(name = "IDX_PRX_CUSTOMER_BUILDING_TYPE", columnList = "BUILDING_TYPE_ID")
})
@JmixEntity
@Entity(name = "prx_Customer")
public class Customer extends VersionControlledEntity implements BaseUuidEntity {

    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "PUMP_PARENT_CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer pumpParentCustomer;

    @Column(name = "IS_PUMP")
    private Boolean isPump;

    @Column(name = "DISPUTED_DEBT", precision = 19, scale = 2)
    private BigDecimal disputedDebt;

    @Column(name = "CUST_KEY", precision = 8, scale = 0)
    private BigDecimal custKey;

    @Column(name = "DELAYER_STATUS")
    private String delayerStatus;

    @Column(name = "HASH_CODE", length = 200)
    private String hashCode;

    @JoinColumn(name = "CUST_CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Category custCategory;

    //@VersionControlKey
    @Column(name = "SUBSIDY_MULTI_CHILD_AMOUNT", precision = 19, scale = 2)
    private BigDecimal subsidyMultiChildAmount;

    @OneToMany(mappedBy = "customer")
    private List<IndividualCutoff> individualCutoffs;

    @OneToMany(mappedBy = "customer")
    private List<IndividualReconnection> individualReconnections;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @Column(name = "DELETED_BY")
    private String deletedBy;

    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @NotNull
    @Column(name = "CUSTOMER_CODE", nullable = false, length = 30)
    private String customerCode;

    @Column(name = "MORTGAGE")
    private Boolean mortgage = false;

    @OneToMany(mappedBy = "customer")
    private List<CustomerContract> contracts;

    @NotNull
    @Column(name = "CUSTOMER_NUMBER", nullable = false, length = 30)
    @VersionControlKey
    private String customerNumber;

    @Column(name = "COMMUNAL_COMPANY_NUMBER", length = 30)
    private String communalCompanyNumber;

    @JoinColumn(name = "STATUS_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @VersionControlKey
    private Status status;

    @NotNull
    @JoinColumn(name = "CATEGORY_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private CustomerCategory category;

    @JoinColumn(name = "BUSINESS_CENTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private BusinessCenter businessCenter;

    @Column(name = "WITHOUT_VAT")
    @VersionControlKey
    private Boolean withoutVat = false;

    @Column(name = "IS_SPECIAL")
    private Boolean isSpecial = false;

    @Column(name = "WITH_CONTRACT")
    private Boolean withContract = false;

    @Column(name = "PAYMENT_INTERVAL")
    private Integer paymentInterval;

    @Column(name = "CUT")
    private Boolean cut = false;

    @Column(name = "CUT_OFF_TYPE")
    private String cutOffType;

    @Column(name = "CUT_STATUS_TELASI")
    private String cutStatusTelasi;

    @Column(name = "CUT_OF_TYPE_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date cutOfTypeDateTime;

    @Column(name = "CUT_OFF_TELASI_DEBT", precision = 19, scale = 2)
    private BigDecimal cutOffTelasiDebt;

    @Column(name = "CUT_OFF_TELMICO_DEBT", precision = 19, scale = 2)
    private BigDecimal cutOffTelmicoDebt;

    @Column(name = "CUT_OFFIS_PAYED")
    private Boolean cutOffisPayed;

    @Column(name = "TRASH", precision = 19, scale = 2)
    private BigDecimal trash;

    @Column(name = "WATER", precision = 19, scale = 2)
    private BigDecimal water;

    @Column(name = "TRASH_EXCEPTION")
    private Boolean trashException = false;

    @JoinColumn(name = "GIVE_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private GiveType giveType;

    @Column(name = "SMS_BILL")
    private Boolean smsBill = false;

    @Column(name = "EMAIL_BILL")
    private Boolean emailBill = false;

    @JoinColumn(name = "DEBET_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DebetStatus debetStatus;

    @JoinColumn(name = "PROPRIETOR_INFORMATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ProprietorInformation proprietorInformation;

    @JoinColumn(name = "BENEFICIARY_INFORMATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private BeneficiaryInformation beneficiaryInformation;

    @Column(name = "WATER_EXCEPTION")
    private Boolean waterException = false;

    @Column(name = "CLOSE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date closeDate;

    @Column(name = "CREATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;

    @Column(name = "NEEDS_EL_BILL")
    private Boolean needsElBill = false;

    @Column(name = "CUT_FOR_WATER")
    private Boolean cutForWater;

    @Column(name = "CUT_FOR_GARBAGE")
    private Boolean cutForGarbage;

    @Column(name = "CUT_FOR_ELECTRICITY")
    private Boolean cutForElectricity;

    @Column(name = "NAME", length = 100)
    private String name;

    @Column(name = "LASTNAME", length = 50)
    private String lastname;

    @Column(name = "MIDDLE_NAME", length = 50)
    private String middleName;

    @NotNull
    @Column(name = "FULL_NAME", nullable = false)
    @VersionControlKey
    private String fullName;

    @Column(name = "IDENTIFICATION_NUMBER", length = 20)
    @VersionControlKey
    private String identificationNumber;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "ACTIVITY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Activity activity;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "PAYER_CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer payerCustomer;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "PARENT_CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer parentCustomer;

    @Column(name = "NOTE", length = 200)
    private String note;

    @Column(name = "NEEDS_EVAT")
    private Boolean needsEvat = false;

    @Column(name = "NEEDS_SUM_EVAT")
    private Boolean needsSumEvat = false;

    @Column(name = "EVAT_START_DATE")
    @Temporal(TemporalType.DATE)
    private Date evatStartDate;

    @Composition
    @OneToMany(mappedBy = "customer")
    private List<CustomerContact> contacts;

    @Composition
    @OneToMany(mappedBy = "customer")
    private List<CustomerComment> comments;

    @OneToMany(mappedBy = "customer")
    private List<CustomerMessage> messages;

    //@VersionControlKey
    @Column(name = "SOCIAL_CATEGORY_SOCIALLY_UNSECURED")
    private Boolean socialCategorySociallyUnsecured = false;

    @Column(name = "SOCIAL_MUNICIPALITY")
    private Boolean socialMunicipality;

    //@VersionControlKey
    @Column(name = "SOCIAL_SCORE")
    private String socialScore;

    //@VersionControlKey
    @Column(name = "MAYORS_LIMIT", precision = 19, scale = 2)
    private BigDecimal mayorsLimit;

    //@VersionControlKey
    @Column(name = "LIMIT_LEFT", precision = 19, scale = 2)
    private BigDecimal limitLeft;

    //@VersionControlKey
    @Column(name = "SOCIAL_CATEGORY_PENSIONER")
    private Boolean socialCategoryPensioner = false;

    //@VersionControlKey
    @Column(name = "SOCIAL_CATEGORY_MULTI_CHILD_FAMILY")
    private Boolean socialCategoryMultiChildFamily = false;

    @Composition
    @OneToMany(mappedBy = "customer")
    private List<CustomerMayorsSubsidy> mayorsSubsidy;

    @Column(name = "SUBSIDY_SOCIAL_UPDATE_TYPE")
    private String subsidySocialUpdateType = "AUTOMATIC";

    @Column(name = "SUBSIDY_MULTI_CHILD_UPDATE_TYPE")
    private String subsidyMultiChildUpdateType = "AUTOMATIC";

    @Column(name = "SUBSIDY_PENSION_UPDATE_TYPE")
    private String subsidyPensionUpdateType = "AUTOMATIC";

    @Column(name = "SUBSIDY_SOCIAL_UPDATE_TYPE_DATE")
    @Temporal(TemporalType.DATE)
    private Date subsidySocialUpdateTypeDate;

    @Column(name = "SUBSIDY_MULTI_CHILD_UPDATE_TYPE_DATE")
    @Temporal(TemporalType.DATE)
    private Date subsidyMultiChildUpdateTypeDate;

    @Column(name = "SUBSIDY_PENSION_UPDATE_TYPE_DATE")
    @Temporal(TemporalType.DATE)
    private Date subsidyPensionUpdateTypeDate;

    @OneToMany(mappedBy = "customer")
    private List<CustomerAddress> addresses;

    @Column(name = "ADDRESS_TEXT")
    private String addressText;

    @Column(name = "STREET")
    private String street;

    @Column(name = "HOUSE")
    private String house;

    @Column(name = "BUILDING")
    private String building;

    @Column(name = "PORCH")
    private String porch;

    @Column(name = "FLATE")
    private String flate;

    @Column(name = "POST_INDEX")
    private String postIndex;

    @JoinColumn(name = "BUILDING_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private BuildingType buildingType;

    @Column(name = "IS_LEGAL")
    private Boolean isLegal;

    @Column(name = "REGISTER_CODE")
    private String registerCode;

    @JmixProperty
    @Transient
    private CustomerCategory categoryTmp;

    public CustomerCuttStatus getCutStatusTelasi() {
        return cutStatusTelasi == null ? null : CustomerCuttStatus.fromId(cutStatusTelasi);
    }

    public void setCutStatusTelasi(CustomerCuttStatus cutStatusTelasi) {
        this.cutStatusTelasi = cutStatusTelasi == null ? null : cutStatusTelasi.getId();
    }

    public Boolean getCutOffisPayed() {
        return cutOffisPayed;
    }

    public void setCutOffisPayed(Boolean cutOffisPayed) {
        this.cutOffisPayed = cutOffisPayed;
    }

    public BigDecimal getCutOffTelmicoDebt() {
        return cutOffTelmicoDebt;
    }

    public void setCutOffTelmicoDebt(BigDecimal cutOffTelmicoDebt) {
        this.cutOffTelmicoDebt = cutOffTelmicoDebt;
    }

    public BigDecimal getCutOffTelasiDebt() {
        return cutOffTelasiDebt;
    }

    public void setCutOffTelasiDebt(BigDecimal cutOffTelasiDebt) {
        this.cutOffTelasiDebt = cutOffTelasiDebt;
    }

    public Date getCutOfTypeDateTime() {
        return cutOfTypeDateTime;
    }

    public void setCutOfTypeDateTime(Date cutOfTypeDateTime) {
        this.cutOfTypeDateTime = cutOfTypeDateTime;
    }

    public CustomerCuttStatus getCutOffType() {
        return cutOffType == null ? null : CustomerCuttStatus.fromId(cutOffType);
    }

    public void setCutOffType(CustomerCuttStatus cutOffType) {
        this.cutOffType = cutOffType == null ? null : cutOffType.getId();
    }

    public Boolean getCutForElectricity() {
        return cutForElectricity;
    }

    public void setCutForElectricity(Boolean cutForElectricity) {
        this.cutForElectricity = cutForElectricity;
    }

    public Boolean getCutForGarbage() {
        return cutForGarbage;
    }

    public void setCutForGarbage(Boolean cutForGarbage) {
        this.cutForGarbage = cutForGarbage;
    }

    public Boolean getCutForWater() {
        return cutForWater;
    }

    public void setCutForWater(Boolean cutForWater) {
        this.cutForWater = cutForWater;
    }

    public Boolean getSocialMunicipality() {
        return socialMunicipality;
    }

    public void setSocialMunicipality(Boolean socialMunicipality) {
        this.socialMunicipality = socialMunicipality;
    }

    public String getAddressText() {
        return addressText;
    }

    public void setAddressText(String addressText) {
        this.addressText = addressText;
    }

    public String getRegisterCode() {
        return registerCode;
    }

    public void setRegisterCode(String registerCode) {
        this.registerCode = registerCode;
    }

    public Boolean getIsLegal() {
        return isLegal;
    }

    public void setIsLegal(Boolean isLegal) {
        this.isLegal = isLegal;
    }

    public BuildingType getBuildingType() {
        return buildingType;
    }

    public void setBuildingType(BuildingType buildingType) {
        this.buildingType = buildingType;
    }

    public String getPostIndex() {
        return postIndex;
    }

    public void setPostIndex(String postIndex) {
        this.postIndex = postIndex;
    }

    public String getFlate() {
        return flate;
    }

    public void setFlate(String flate) {
        this.flate = flate;
    }

    public String getPorch() {
        return porch;
    }

    public void setPorch(String porch) {
        this.porch = porch;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getHouse() {
        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public Boolean getIsPump() {
        return isPump;
    }

    public void setIsPump(Boolean isPump) {
        this.isPump = isPump;
    }

    public Customer getPumpParentCustomer() {
        return pumpParentCustomer;
    }

    public void setPumpParentCustomer(Customer pumpParentCustomer) {
        this.pumpParentCustomer = pumpParentCustomer;
    }

    public Date getEvatStartDate() {
        return evatStartDate;
    }

    public void setEvatStartDate(Date evatStartDate) {
        this.evatStartDate = evatStartDate;
    }

    public BigDecimal getDisputedDebt() {
        return disputedDebt;
    }

    public void setDisputedDebt(BigDecimal disputedDebt) {
        this.disputedDebt = disputedDebt;
    }

    public List<CustomerAddress> getAddresses() {
        return addresses;
    }

    public DelayerCustomerStatus getDelayerStatus() {
        return delayerStatus == null ? null : DelayerCustomerStatus.fromId(delayerStatus);
    }

    public void setDelayerStatus(DelayerCustomerStatus delayerStatus) {
        this.delayerStatus = delayerStatus == null ? null : delayerStatus.getId();
    }

    public Date getSubsidyPensionUpdateTypeDate() {
        return subsidyPensionUpdateTypeDate;
    }

    public void setSubsidyPensionUpdateTypeDate(Date subsidyPensionUpdateTypeDate) {
        this.subsidyPensionUpdateTypeDate = subsidyPensionUpdateTypeDate;
    }

    public Date getSubsidyMultiChildUpdateTypeDate() {
        return subsidyMultiChildUpdateTypeDate;
    }

    public void setSubsidyMultiChildUpdateTypeDate(Date subsidyMultiChildUpdateTypeDate) {
        this.subsidyMultiChildUpdateTypeDate = subsidyMultiChildUpdateTypeDate;
    }

    public Date getSubsidySocialUpdateTypeDate() {
        return subsidySocialUpdateTypeDate;
    }

    public void setSubsidySocialUpdateTypeDate(Date subsidySocialUpdateTypeDate) {
        this.subsidySocialUpdateTypeDate = subsidySocialUpdateTypeDate;
    }

    public SubsidyUpdateType getSubsidyPensionUpdateType() {
        return subsidyPensionUpdateType == null ? null : SubsidyUpdateType.fromId(subsidyPensionUpdateType);
    }

    public void setSubsidyPensionUpdateType(SubsidyUpdateType subsidyPensionUpdateType) {
        this.subsidyPensionUpdateType = subsidyPensionUpdateType == null ? null : subsidyPensionUpdateType.getId();
    }

    public SubsidyUpdateType getSubsidyMultiChildUpdateType() {
        return subsidyMultiChildUpdateType == null ? null : SubsidyUpdateType.fromId(subsidyMultiChildUpdateType);
    }

    public void setSubsidyMultiChildUpdateType(SubsidyUpdateType subsidyMultiChildUpdateType) {
        this.subsidyMultiChildUpdateType = subsidyMultiChildUpdateType == null ? null : subsidyMultiChildUpdateType.getId();
    }

    public SubsidyUpdateType getSubsidySocialUpdateType() {
        return subsidySocialUpdateType == null ? null : SubsidyUpdateType.fromId(subsidySocialUpdateType);
    }

    public void setSubsidySocialUpdateType(SubsidyUpdateType subsidySocialUpdateType) {
        this.subsidySocialUpdateType = subsidySocialUpdateType == null ? null : subsidySocialUpdateType.getId();
    }

    public void setCategoryTmp(CustomerCategory categoryTmp) {
        this.categoryTmp = categoryTmp;
    }

    public CustomerCategory getCategoryTmp() {
        return categoryTmp;
    }

    public List<CustomerMayorsSubsidy> getMayorsSubsidy() {
        return mayorsSubsidy;
    }

    public void setMayorsSubsidy(List<CustomerMayorsSubsidy> mayorsSubsidy) {
        this.mayorsSubsidy = mayorsSubsidy;
    }

    public void setSocialScore(SocialScore socialScore) {
        this.socialScore = socialScore == null ? null : socialScore.getId();
    }

    public SocialScore getSocialScore() {
        return socialScore == null ? null : SocialScore.fromId(socialScore);
    }

    public BigDecimal getLimitLeft() {
        return limitLeft;
    }

    public void setLimitLeft(BigDecimal limitLeft) {
        this.limitLeft = limitLeft;
    }

    public BigDecimal getMayorsLimit() {
        return mayorsLimit;
    }

    public void setMayorsLimit(BigDecimal mayorsLimit) {
        this.mayorsLimit = mayorsLimit;
    }

    public BigDecimal getSubsidyMultiChildAmount() {
        return subsidyMultiChildAmount;
    }

    public void setSubsidyMultiChildAmount(BigDecimal subsidyMultiChildAmount) {
        this.subsidyMultiChildAmount = subsidyMultiChildAmount;
    }

    public Boolean getSocialCategorySociallyUnsecured() {
        return socialCategorySociallyUnsecured;
    }

    public void setSocialCategorySociallyUnsecured(Boolean socialCategorySociallyUnsecured) {
        this.socialCategorySociallyUnsecured = socialCategorySociallyUnsecured;
    }

    public Boolean getSocialCategoryPensioner() {
        return socialCategoryPensioner;
    }

    public void setSocialCategoryPensioner(Boolean socialCategoryPensioner) {
        this.socialCategoryPensioner = socialCategoryPensioner;
    }

    public Boolean getSocialCategoryMultiChildFamily() {
        return socialCategoryMultiChildFamily;
    }

    public void setSocialCategoryMultiChildFamily(Boolean socialCategoryMultiChildFamily) {
        this.socialCategoryMultiChildFamily = socialCategoryMultiChildFamily;
    }

    public List<CustomerMessage> getMessages() {
        return messages;
    }

    public void setMessages(List<CustomerMessage> messages) {
        this.messages = messages;
    }

    public void setIndividualReconnections(List<IndividualReconnection> individualReconnections) {
        this.individualReconnections = individualReconnections;
    }

    public List<IndividualReconnection> getIndividualReconnections() {
        return individualReconnections;
    }

    public List<IndividualCutoff> getIndividualCutoffs() {
        return individualCutoffs;
    }

    public void setIndividualCutoffs(List<IndividualCutoff> individualCutoffs) {
        this.individualCutoffs = individualCutoffs;
    }

    public BigDecimal getCustKey() {
        return custKey;
    }

    public void setCustKey(BigDecimal custKey) {
        this.custKey = custKey;
    }

    public String getHashCode() {
        return hashCode;
    }

    public void setHashCode(String hashCode) {
        this.hashCode = hashCode;
    }

    public Category getCustCategory() {
        return custCategory;
    }

    public void setCustCategory(Category custCategory) {
        this.custCategory = custCategory;
    }

    public BeneficiaryInformation getBeneficiaryInformation() {
        return beneficiaryInformation;
    }

    public void setBeneficiaryInformation(BeneficiaryInformation beneficiaryInformation) {
        this.beneficiaryInformation = beneficiaryInformation;
    }

    public ProprietorInformation getProprietorInformation() {
        return proprietorInformation;
    }

    public void setProprietorInformation(ProprietorInformation proprietorInformation) {
        this.proprietorInformation = proprietorInformation;
    }

    public DebetStatus getDebetStatus() {
        return debetStatus;
    }

    public void setDebetStatus(DebetStatus debetStatus) {
        this.debetStatus = debetStatus;
    }

    public Boolean getEmailBill() {
        return emailBill;
    }

    public void setEmailBill(Boolean emailBill) {
        this.emailBill = emailBill;
    }

    public Boolean getSmsBill() {
        return smsBill;
    }

    public void setSmsBill(Boolean smsBill) {
        this.smsBill = smsBill;
    }

    public GiveType getGiveType() {
        return giveType;
    }

    public void setGiveType(GiveType giveType) {
        this.giveType = giveType;
    }

    public Boolean getWaterException() {
        return waterException;
    }

    public void setWaterException(Boolean waterException) {
        this.waterException = waterException;
    }

    public Boolean getTrashException() {
        return trashException;
    }

    public void setTrashException(Boolean trashException) {
        this.trashException = trashException;
    }

    public BigDecimal getWater() {
        return water;
    }

    public void setWater(BigDecimal water) {
        this.water = water;
    }

    public BigDecimal getTrash() {
        return trash;
    }

    public void setTrash(BigDecimal trash) {
        this.trash = trash;
    }

    public Boolean getCut() {
        return cut;
    }

    public void setCut(Boolean cut) {
        this.cut = cut;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(Date closeDate) {
        this.closeDate = closeDate;
    }

    public Integer getPaymentInterval() {
        return paymentInterval;
    }

    public void setPaymentInterval(Integer paymentInterval) {
        this.paymentInterval = paymentInterval;
    }

    public Boolean getMortgage() {
        return mortgage;
    }

    public void setMortgage(Boolean mortgage) {
        this.mortgage = mortgage;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public List<CustomerContract> getContracts() {
        return contracts;
    }

    public void setContracts(List<CustomerContract> contracts) {
        this.contracts = contracts;
    }

    public List<CustomerComment> getComments() {
        return comments;
    }

    public void setComments(List<CustomerComment> comments) {
        this.comments = comments;
    }

    public List<CustomerContact> getContacts() {
        return contacts;
    }

    public void setContacts(List<CustomerContact> contacts) {
        this.contacts = contacts;
    }

    public Boolean getNeedsSumEvat() {
        return needsSumEvat;
    }

    public void setNeedsSumEvat(Boolean needsSumEvat) {
        this.needsSumEvat = needsSumEvat;
    }

    public Boolean getNeedsEvat() {
        return needsEvat;
    }

    public void setNeedsEvat(Boolean needsEvat) {
        this.needsEvat = needsEvat;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Customer getParentCustomer() {
        return parentCustomer;
    }

    public void setParentCustomer(Customer parentCustomer) {
        this.parentCustomer = parentCustomer;
    }

    public Customer getPayerCustomer() {
        return payerCustomer;
    }

    public void setPayerCustomer(Customer payerCustomer) {
        this.payerCustomer = payerCustomer;
    }

    public Activity getActivity() {
        return activity;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public String getIdentificationNumber() {
        return identificationNumber;
    }

    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getNeedsElBill() {
        return needsElBill;
    }

    public void setNeedsElBill(Boolean needsElBill) {
        this.needsElBill = needsElBill;
    }

    public Boolean getWithContract() {
        return withContract;
    }

    public void setWithContract(Boolean withContract) {
        this.withContract = withContract;
    }

    public Boolean getIsSpecial() {
        return isSpecial;
    }

    public void setIsSpecial(Boolean isSpecial) {
        this.isSpecial = isSpecial;
    }

    public Boolean getWithoutVat() {
        return withoutVat;
    }

    public void setWithoutVat(Boolean withoutVat) {
        this.withoutVat = withoutVat;
    }

    public BusinessCenter getBusinessCenter() {
        return businessCenter;
    }

    public void setBusinessCenter(BusinessCenter businessCenter) {
        this.businessCenter = businessCenter;
    }

    public String getCommunalCompanyNumber() {
        return communalCompanyNumber;
    }

    public void setCommunalCompanyNumber(String communalCompanyNumber) {
        this.communalCompanyNumber = communalCompanyNumber;
    }

    public CustomerCategory getCategory() {
        return category;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PostConstruct
    public void postConstruct() {
        NumeratorService numeratorService = AppBeans.getBean(NumeratorService.class);
        setCustomerCode(
                numeratorService.getNumSeq(this.getClass())
        );
    }

    @PrePersist
    public void prePersist() {
        updateFullName();
        //checkIdentificationNumber();
    }

    @PreUpdate
    public void preUpdate() {
        updateFullName();
      //  checkIdentificationNumber();
    }

    public void updateFullName(){
        fullName = (name == null ? "" : name) + (lastname == null ? "" : (" " + lastname));
    }

    public void checkIdentificationNumber() {
        DataManager dataManager = AppBeans.getBean(DataManager.class);
        Messages messages = AppBeans.getBean(Messages.class);
        Customer customer = dataManager.load(Customer.class)
                .query("select e from prx_Customer e where e.identificationNumber = :identificationNumber and e.id <> :id")
                .parameter("identificationNumber", identificationNumber)
                .parameter("id", id)
                .optional().orElse(null);
        if(customer != null) {
            throw new RuntimeException(messages.formatMessage(this.getClass(), "identificationNumberAlreadyExists", identificationNumber));
        }
    }

    @InstanceName
    @DependsOnProperties({"customerCode", "fullName"})
    public String getInstanceName() {
        return String.format("%s %s", customerNumber, fullName);
    }

    @PostLoad
    public void postLoad() {
        super.postLoad();
    }

    public Object reflect(Field field) {
        try {
            return field.get(this);
        } catch (Exception e) {
            return null;
        }
    }

    @PostUpdate
    public void postUpdate() {
        super.postUpdate();
    }
}