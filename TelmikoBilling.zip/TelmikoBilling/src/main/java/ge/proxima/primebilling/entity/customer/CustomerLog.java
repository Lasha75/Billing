package ge.proxima.primebilling.entity.customer;

import ge.proxima.primebilling.entity.enums.SocialScore;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.java.entitylogger.LogEntity;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_LOG", indexes = {
        @Index(name = "IDX_CUSTOMERLOG_STATUS_ID", columnList = "STATUS_ID")
})
@Entity(name = "prx_CustomerLog")
public class CustomerLog implements LogEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @Column(name = "FROM_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fromDate;

    @Column(name = "CUSTOMER_NUMBER", length = 30)
    private String customerNumber;

    @Column(name = "ENTITY_ID")
    private UUID entityId;

    @Column(name = "TO_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date toDate;

    @Column(name = "IDENTIFICATION_NUMBER", length = 20)
    private String identificationNumber;

    @JoinColumn(name = "STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status status;

    @Column(name = "FULL_NAME")
    private String fullName;

    @Column(name = "SUBSIDY_MULTI_CHILD_AMOUNT", precision = 19, scale = 2)
    private BigDecimal subsidyMultiChildAmount;

    @Column(name = "SOCIAL_CATEGORY_MULTI_CHILD_FAMILY")
    private Boolean socialCategoryMultiChildFamily = false;

    @Column(name = "SOCIAL_CATEGORY_SOCIALLY_UNSECURED")
    private Boolean socialCategorySociallyUnsecured = false;

    @Column(name = "SOCIAL_SCORE")
    private String socialScore;

    @Column(name = "MAYORS_LIMIT", precision = 19, scale = 2)
    private BigDecimal mayorsLimit;

    @Column(name = "LIMIT_LEFT", precision = 19, scale = 2)
    private BigDecimal limitLeft;

    @Column(name = "SOCIAL_CATEGORY_PENSIONER")
    private Boolean socialCategoryPensioner = false;

    @Column(name = "WITHOUT_VAT")
    private Boolean withoutVat;

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public Boolean getWithoutVat() {
        return withoutVat;
    }

    public void setWithoutVat(Boolean withoutVat) {
        this.withoutVat = withoutVat;
    }

    public Boolean getSocialCategoryPensioner() {
        return socialCategoryPensioner;
    }

    public void setSocialCategoryPensioner(Boolean socialCategoryPensioner) {
        this.socialCategoryPensioner = socialCategoryPensioner;
    }

    public BigDecimal getLimitLeft() {
        return limitLeft;
    }

    public void setLimitLeft(BigDecimal limitLeft) {
        this.limitLeft = limitLeft;
    }

    public BigDecimal getMayorsLimit() {
        return mayorsLimit;
    }

    public void setMayorsLimit(BigDecimal mayorsLimit) {
        this.mayorsLimit = mayorsLimit;
    }

    public SocialScore getSocialScore() {
        return socialScore == null ? null : SocialScore.fromId(socialScore);
    }

    public void setSocialScore(SocialScore socialScore) {
        this.socialScore = socialScore == null ? null : socialScore.getId();
    }

    public Boolean getSocialCategorySociallyUnsecured() {
        return socialCategorySociallyUnsecured;
    }

    public void setSocialCategorySociallyUnsecured(Boolean socialCategorySociallyUnsecured) {
        this.socialCategorySociallyUnsecured = socialCategorySociallyUnsecured;
    }

    public Boolean getSocialCategoryMultiChildFamily() {
        return socialCategoryMultiChildFamily;
    }

    public void setSocialCategoryMultiChildFamily(Boolean socialCategoryMultiChildFamily) {
        this.socialCategoryMultiChildFamily = socialCategoryMultiChildFamily;
    }

    public BigDecimal getSubsidyMultiChildAmount() {
        return subsidyMultiChildAmount;
    }

    public void setSubsidyMultiChildAmount(BigDecimal subsidyMultiChildAmount) {
        this.subsidyMultiChildAmount = subsidyMultiChildAmount;
    }

    public UUID getEntityId() {
        return entityId;
    }

    public void setEntityId(UUID entityId) {
        this.entityId = entityId;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getIdentificationNumber() {
        return identificationNumber;
    }

    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}