package ge.proxima.primebilling.entity.customer;

import ge.proxima.primebilling.entity.customer.setup.DelayStatusChangeLog;
import ge.proxima.primebilling.entity.customer.setup.PermanentDelayStatus;
import ge.proxima.primebilling.entity.customer.setup.Reason;
import ge.proxima.primebilling.entity.enums.DelayerStatus;
import ge.proxima.primebilling.entity.enums.DelayerType;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.entitylogger.VersionControlledEntity;
import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import io.jmix.core.DeletePolicy;
import io.jmix.core.Messages;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import liquibase.repackaged.org.apache.commons.lang3.time.DateUtils;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_DELAYER", indexes = {
        @Index(name = "IDX_DELAYER_CUSTOMER_ID", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_DELAYER_REASON_ID", columnList = "REASON_ID"),
        @Index(name = "IDX_DELAYER", columnList = "PERMANENT_DELAY_STATUS_ID"),
        @Index(name = "IDX_PRX_DELAYER_debt", columnList = "CUSTOMER_ID, START_DATE, STATUS")
})
@Entity(name = "prx_Delayer")
public class Delayer extends VersionControlledEntity implements BaseUuidEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "USER_")
    private String user;

    @Column(name = "STATUS_GRANTING_OPERATOR_NAME")
    private String statusGrantingOperatorName;

    @JoinColumn(name = "REASON_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Reason reason;

    @JoinColumn(name = "PERMANENT_DELAY_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private PermanentDelayStatus permanentDelayStatus;

    @NotNull
    @Column(name = "DOC_NUM", nullable = false)
    private String docNum;

    @Column(name = "DOC_DATE")
    @Temporal(TemporalType.DATE)
    private Date docDate;

    @Column(name = "TYPE_")
    private String type;

    @Column(name = "TELASI_STATUS")
    private String telasiStatus;

    @Column(name = "AMOUNT", precision = 19, scale = 4)
    private BigDecimal amount;

    @Column(name = "INITIAL_AMOUNT")
    private BigDecimal initialPayment;

    @Temporal(TemporalType.DATE)
    @Column(name = "INITIAL_PAYMENT_DATE")
    private Date initialPaymentDate;

    @Column(name = "RETURNING_DOC_NUMBER")
    private String responseDocNumber;

    @Column(name = "CUSTOMER_DEBT", precision = 19, scale = 2)
    private BigDecimal customerDebt;

    @Column(name = "DELAY_QTY")
    private Integer delayQty;

    @Column(name = "APPROVED_DELAY_QTY")
    private Integer approvedDelayQty;

    @Column(name = "DEPOSIT_AMOUNT", precision = 19, scale = 2)
    private BigDecimal depositAmount;

    @Column(name = "RESPONSE_DOC_NUMBER_DATE")
    @Temporal(TemporalType.DATE)
    private Date responseDocNumberDate;

    @NotNull
    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @NotNull
    @Column(name = "START_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @NotNull
    @Column(name = "END_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @Column(name = "COMMENT_")
    @Lob
    private String comment;

    @NotNull
    @Column(name = "STATUS", nullable = false)
    private String status;

    @OnDeleteInverse(DeletePolicy.UNLINK)
    @Composition
    @OneToMany(mappedBy = "delay")
    private List<DelayStatusChangeLog> log;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public String getTelasiStatus() {
        return telasiStatus;
    }

    public void setTelasiStatus(String telasiStatus) {
        this.telasiStatus = telasiStatus;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public BigDecimal getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(BigDecimal depositAmount) {
        this.depositAmount = depositAmount;
    }

    public Integer getApprovedDelayQty() {
        return approvedDelayQty;
    }

    public void setApprovedDelayQty(Integer approvedDelayQty) {
        this.approvedDelayQty = approvedDelayQty;
    }

    public Integer getDelayQty() {
        return delayQty;
    }

    public void setDelayQty(Integer delayQty) {
        this.delayQty = delayQty;
    }

    public BigDecimal getCustomerDebt() {
        return customerDebt;
    }

    public void setCustomerDebt(BigDecimal customerDebt) {
        this.customerDebt = customerDebt;
    }

    public List<DelayStatusChangeLog> getLog() {
        return log;
    }

    public Date getDocDate() {
        return docDate;
    }

    public void setDocDate(Date docDate) {
        this.docDate = docDate;
    }

    public String getStatusGrantingOperatorName() {
        return statusGrantingOperatorName;
    }

    public void setStatusGrantingOperatorName(String statusGrantingOperatorName) {
        this.statusGrantingOperatorName = statusGrantingOperatorName;
    }

    public void setInitialPaymentDate(Date initialPaymentDate) {
        this.initialPaymentDate = initialPaymentDate;
    }

    public Date getInitialPaymentDate() {
        return initialPaymentDate;
    }

    public Date getResponseDocNumberDate() {
        return responseDocNumberDate;
    }

    public void setResponseDocNumberDate(Date responseDocNumberDate) {
        this.responseDocNumberDate = responseDocNumberDate;
    }

    public String getResponseDocNumber() {
        return responseDocNumber;
    }

    public void setResponseDocNumber(String responseDocNumber) {
        this.responseDocNumber = responseDocNumber;
    }

    public void setInitialPayment(BigDecimal initialPayment) {
        this.initialPayment = initialPayment;
    }

    public BigDecimal getInitialPayment() {
        return initialPayment;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public PermanentDelayStatus getPermanentDelayStatus() {
        return permanentDelayStatus;
    }

    public void setPermanentDelayStatus(PermanentDelayStatus permanentDelayStatus) {
        this.permanentDelayStatus = permanentDelayStatus;
    }

    public String getDocNum() {
        return docNum;
    }

    public void setDocNum(String docNum) {
        this.docNum = docNum;
    }

    public Reason getReason() {
        return reason;
    }

    public void setReason(Reason reason) {
        this.reason = reason;
    }

    public DelayerStatus getStatus() {
        return status == null ? null : DelayerStatus.fromId(status);
    }

    public void setStatus(DelayerStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public DelayerType getType() {
        return type == null ? null : DelayerType.fromId(type);
    }

    public void setType(DelayerType type) {
        this.type = type == null ? null : type.getId();
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PrePersist
    public void prePersist() {
        checkCrossing(getStartDate(), getEndDate());
    }

    @PreUpdate
    public void preUpdate() {
        checkCrossing(getStartDate(), getEndDate());
        setStatusChangeOperator();
    }

    private void checkCrossing(Date startDate, Date endDate) {
        Messages messages = AppBeans.getBean(Messages.class);
        if (!DelayerStatus.FINISHED.equals(getStatus())) {
            DataManager dataManager = AppBeans.getBean(DataManager.class);
            Delayer delayer = dataManager.load(Delayer.class)
                    .query("select e from prx_Delayer e where e.id <> :id and ((e.startDate >= :startDate and e.startDate <= :endDate) or " +
                            "(e.endDate >= :startDate and e.endDate <= :endDate) or (e.startDate >= :startDate and e.endDate <= :endDate)) " +
                            "and e.customer.id = :customerId and e.status = :status")
                    .parameter("id", getId())
                    .parameter("startDate", startDate)
                    .parameter("endDate", endDate)
                    .parameter("customerId", getCustomer().getId())
                    .parameter("status", DelayerStatus.ACTIVE)
                    .optional().orElse(null);

            if (delayer != null) throw new RuntimeException(messages.formatMessage(this.getClass(), "incorrectDates"));

        }

        Calendar calendar = Calendar.getInstance();
        Date date = getCreatedDate() != null ? getCreatedDate() : calendar.getTime();
        if (getStartDate().before(date) && !DateUtils.isSameDay(getStartDate(), date)) throw new RuntimeException(messages.getMessage("createDateAfter"));

    }

    private void setStatusChangeOperator() {
        setStatusGrantingOperatorName(getLastModifiedBy());
    }

    private void checkStartDateBeforeEnd() {
        Messages messages = AppBeans.getBean(Messages.class);
        if (getEndDate().before(getInitialPaymentDate())) throw new RuntimeException(messages.formatMessage(this.getClass(), "initialPaymentBeforeEnd"));
    }

    @InstanceName
    @DependsOnProperties({"customer", "type"})
    public String getInstanceName() {
        return String.format("%s %s", customer.getName(), type);
    }
}