package ge.proxima.primebilling.entity.customer;

import ge.proxima.primebilling.entity.customer.setup.SupplyContract;
import io.jmix.core.event.EntityChangedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import io.jmix.core.DataManager;
import org.joda.time.LocalDate;
import org.joda.time.Months;
import org.springframework.beans.factory.annotation.Autowired;


import java.util.Date;

@Component("prx_SupplyContractEventListener")
public class SupplyContractEventListener {
    @Autowired
    private DataManager dataManager;
    @EventListener
    public void onSupplyContractChangedBeforeCommit(EntityChangedEvent<SupplyContract> event) {
        SupplyContract contract;
        Date notifyDate;
        if (event.getType() != EntityChangedEvent.Type.DELETED)
        {
            contract=dataManager.load(event.getEntityId()).one();
            if(Months.monthsBetween(LocalDate.fromDateFields(contract.getPrevToDate()),LocalDate.fromDateFields(contract.getToDate())).getMonths()>3) {
                notifyDate=LocalDate.fromDateFields(contract.getToDate()).minusMonths(2).toDate();
            }
            else
            {
                notifyDate=LocalDate.fromDateFields(contract.getToDate()).minusMonths(1).toDate();
            }
            contract.setNotificationDate(notifyDate);
            dataManager.save(contract);
        }
    }
}