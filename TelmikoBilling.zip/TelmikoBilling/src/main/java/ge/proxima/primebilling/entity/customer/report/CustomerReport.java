package ge.proxima.primebilling.entity.customer.report;

import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.setup.PermanentDelayStatus;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_REPORT", indexes = {
        @Index(name = "IDX_CUSTOMERREPORT", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_CUSTOMERREPORT_BLOCK_ID", columnList = "BLOCK_ID"),
        @Index(name = "IDX_CUSTOMERREPORT", columnList = "PERMANENT_DELAY_STATUS_ID")
})
@Entity(name = "prx_CustomerReport")
public class CustomerReport {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "DEPOSIT")
    private Boolean deposit = false;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @Column(name = "EXCEPTIONAL")
    private Boolean exceptional = false;

    @JoinColumn(name = "PERMANENT_DELAY_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private PermanentDelayStatus permanentDelayStatus;

    @Column(name = "HAS_PHONE")
    private Boolean hasPhone = false;

    @Column(name = "PORTION_DUE_DATE_APPROACHING")
    private Boolean portionDueDateApproaching;

    @Column(name = "PORTION_PAYMENT_OVERDUE")
    private Boolean portionPaymentOverdue;

    @Column(name = "DELAYER_DUE_DATE_APPROACHING")
    private Boolean delayerDueDateApproaching;

    @Column(name = "DELAYER_OVERDUE")
    private Boolean delayerOverdue;

    @Column(name = "DEBT", precision = 19, scale = 2)
    private BigDecimal debt;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    public BigDecimal getDebt() {
        return debt;
    }

    public void setDebt(BigDecimal debt) {
        this.debt = debt;
    }

    public Boolean getDelayerOverdue() {
        return delayerOverdue;
    }

    public void setDelayerOverdue(Boolean delayerOverdue) {
        this.delayerOverdue = delayerOverdue;
    }

    public Boolean getDelayerDueDateApproaching() {
        return delayerDueDateApproaching;
    }

    public void setDelayerDueDateApproaching(Boolean delayerDueDateApproaching) {
        this.delayerDueDateApproaching = delayerDueDateApproaching;
    }

    public Boolean getPortionPaymentOverdue() {
        return portionPaymentOverdue;
    }

    public void setPortionPaymentOverdue(Boolean portionPaymentOverdue) {
        this.portionPaymentOverdue = portionPaymentOverdue;
    }

    public Boolean getPortionDueDateApproaching() {
        return portionDueDateApproaching;
    }

    public void setPortionDueDateApproaching(Boolean portionDueDateApproaching) {
        this.portionDueDateApproaching = portionDueDateApproaching;
    }

    public PermanentDelayStatus getPermanentDelayStatus() {
        return permanentDelayStatus;
    }

    public void setPermanentDelayStatus(PermanentDelayStatus permanentDelayStatus) {
        this.permanentDelayStatus = permanentDelayStatus;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Boolean getHasPhone() {
        return hasPhone;
    }

    public void setHasPhone(Boolean hasPhone) {
        this.hasPhone = hasPhone;
    }

    public Boolean getExceptional() {
        return exceptional;
    }

    public void setExceptional(Boolean exceptional) {
        this.exceptional = exceptional;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public Boolean getDeposit() {
        return deposit;
    }

    public void setDeposit(Boolean deposit) {
        this.deposit = deposit;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}