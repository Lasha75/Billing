package ge.proxima.primebilling.entity.customer.setup;

import ge.proxima.primebilling.entity.CustomerCategoryActivityChange;
import ge.proxima.primebilling.entity.counter.Counter;
import ge.proxima.primebilling.entity.tariff.Tariff;
import io.jmix.core.DeletePolicy;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_CATEGORY_ACTIVI_1", indexes = {
        @Index(name = "IDX_PRXCUSTOMERC_CUSTOMERCATE", columnList = "CUSTOMER_CATEGORY_ACTIVITY_CHANGE_ID"),
        @Index(name = "IDX_PRXCUSTOMERCATEGOR_COUNTER", columnList = "COUNTER_ID"),
        @Index(name = "IDX_PRXCUSTOMERCATE_NEXTTARIFF", columnList = "NEXT_TARIFF_ID"),
        @Index(name = "IDX_PRXCUSTOMERC_CURRENTTARIF", columnList = "CURRENT_TARIFF_ID")
})
@Entity(name = "prx_CustomerCategoryActivityChangeLine")
public class CustomerCategoryActivityChangeLine {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "COUNTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Counter counter;

    @JoinColumn(name = "CURRENT_TARIFF_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Tariff currentTariff;

    @JoinColumn(name = "NEXT_TARIFF_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Tariff nextTariff;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @OnDeleteInverse(DeletePolicy.CASCADE)
    @JoinColumn(name = "CUSTOMER_CATEGORY_ACTIVITY_CHANGE_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private CustomerCategoryActivityChange customerCategoryActivityChange;

    public Tariff getCurrentTariff() {
        return currentTariff;
    }

    public void setCurrentTariff(Tariff currentTariff) {
        this.currentTariff = currentTariff;
    }

    public Tariff getNextTariff() {
        return nextTariff;
    }

    public void setNextTariff(Tariff nextTariff) {
        this.nextTariff = nextTariff;
    }

    public Counter getCounter() {
        return counter;
    }

    public void setCounter(Counter counter) {
        this.counter = counter;
    }

    public CustomerCategoryActivityChange getCustomerCategoryActivityChange() {
        return customerCategoryActivityChange;
    }

    public void setCustomerCategoryActivityChange(CustomerCategoryActivityChange customerCategoryActivityChange) {
        this.customerCategoryActivityChange = customerCategoryActivityChange;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}