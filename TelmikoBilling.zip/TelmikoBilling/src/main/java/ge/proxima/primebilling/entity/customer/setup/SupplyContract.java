package ge.proxima.primebilling.entity.customer.setup;

import ge.proxima.primebilling.entity.SupplyCustomerCategory;
import ge.proxima.primebilling.entity.SupplyOwnership;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.AgreementType;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.entity.system.Parameters;
import ge.proxima.primebilling.java.entitylogger.VersionControlKey;
import ge.proxima.primebilling.java.entitylogger.VersionControlledEntity;
import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import io.jmix.core.Messages;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.lang.reflect.Field;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_SUPPLY_CONTRACT", indexes = {
        @Index(name = "IDX_SUPPLYCONTRACT", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_SUPPLYCONTRACT_STATUS_ID", columnList = "STATUS_ID")
})
@Entity(name = "prx_SupplyContract")
public class SupplyContract extends VersionControlledEntity implements BaseUuidEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @VersionControlKey
    @NotNull
    @JoinColumn(name = "STATUS_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Status status;

    @VersionControlKey
    @NotNull
    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @Column(name = "CUSTOMER_NAME")
    private String customerName;

    @Column(name = "IDENTIFICATION_NUMBER", length = 20)
    private String identificationNumber;

    @Column(name = "LEGAL_ADDRESS")
    private String legalAddress;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "SUPPLY_ADDRESS")
    private String supplyAddress;

    @Column(name = "SUPPLY_OWNERSHIP")
    private String supplyOwnership;

    @Column(name = "BANK_ACCOUNT_NUMBER")
    private String bankAccountNumber;

    @Column(name = "BANK_CODE")
    private String bankCode;

    @Column(name = "BANK_NAME")
    private String bankName;

    @Column(name = "TEL_NUMBER")
    private String telNumber;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "SUPPLY_CUSTOMER_CATEGORY")
    private String supplyCustomerCategory;

    @Column(name = "ALT_CONTACT_NAME")
    private String altContactName;

    @Column(name = "ALT_CONTACT_IDENTIFICATION_NUM", length = 20)
    private String altContactIdentificationNumber;

    @Column(name = "ALT_CONTACT_ADDRESS")
    private String altContactAddress;

    @Column(name = "ALT_CONTACT_TEL_NUMBER")
    private String altContactTelNumber;

    @Column(name = "ALT_CONTACT_EMAIL")
    private String altContactEmail;

    @Column(name = "PAYER_NAME")
    private String payerName;

    @Column(name = "PAYER_IDENTIFICATION_NUMBER", length = 20)
    private String payerIdentificationNumber;

    @Column(name = "PAYER_ADDRESS")
    private String payerAddress;

    @Column(name = "PAYER_TEL_NUMBE")
    private String payerTelNumbe;

    @Column(name = "PAYER_EMAIL")
    private String payerEmail;

    @Column(name = "INFO_SEND_BY_MATERIAL")
    private Boolean infoSendByMaterial;

    @Column(name = "INFO_SEND_BY_MATERIAL_ADDRESS")
    private String infoSendByMaterialAddress;

    @Column(name = "INFO_SEND_BY_EMAIL")
    private Boolean infoSendByEmail;

    @Column(name = "INFO_SEND_BY_EMAIL_ADDRESS")
    private String infoSendByEmailAddress;

    @Column(name = "INFO_SEND_BY_SMS")
    private Boolean infoSendBySMS;

    @Column(name = "INFO_SEND_BY_SMS_TEL_NUMBER")
    private String infoSendBySMSTelNumber;

    @VersionControlKey
    @NotNull
    @Column(name = "DOC_NUM", nullable = false)
    private String docNum;

    @VersionControlKey
    @Column(name = "AGREEMENT_TYPE")
    private String agreementType;

    @Column(name = "NOTE", length = 500)
    private String note;

    @VersionControlKey
    @NotNull
    @Column(name = "FROM_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fromDate;

    @VersionControlKey
    @NotNull
    @Column(name = "TO_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date toDate;

    @Column(name = "PREV_TO_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevToDate;

    @Column(name = "JOB_EXECUTED")
    private Boolean jobExecuted = false;

    @VersionControlKey
    @Column(name = "CONTRACT_PENALTY")
    private Boolean contractPenalty = false;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @Column(name = "NOTIFICATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date notificationDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public String getInfoSendBySMSTelNumber() {
        return infoSendBySMSTelNumber;
    }

    public void setInfoSendBySMSTelNumber(String infoSendBySMSTelNumber) {
        this.infoSendBySMSTelNumber = infoSendBySMSTelNumber;
    }

    public Boolean getInfoSendBySMS() {
        return infoSendBySMS;
    }

    public void setInfoSendBySMS(Boolean infoSendBySMS) {
        this.infoSendBySMS = infoSendBySMS;
    }

    public String getInfoSendByEmailAddress() {
        return infoSendByEmailAddress;
    }

    public void setInfoSendByEmailAddress(String infoSendByEmailAddress) {
        this.infoSendByEmailAddress = infoSendByEmailAddress;
    }

    public Boolean getInfoSendByEmail() {
        return infoSendByEmail;
    }

    public void setInfoSendByEmail(Boolean infoSendByEmail) {
        this.infoSendByEmail = infoSendByEmail;
    }

    public String getInfoSendByMaterialAddress() {
        return infoSendByMaterialAddress;
    }

    public void setInfoSendByMaterialAddress(String infoSendByMaterialAddress) {
        this.infoSendByMaterialAddress = infoSendByMaterialAddress;
    }

    public Boolean getInfoSendByMaterial() {
        return infoSendByMaterial;
    }

    public void setInfoSendByMaterial(Boolean infoSendByMaterial) {
        this.infoSendByMaterial = infoSendByMaterial;
    }

    public String getPayerEmail() {
        return payerEmail;
    }

    public void setPayerEmail(String payerEmail) {
        this.payerEmail = payerEmail;
    }

    public String getPayerTelNumbe() {
        return payerTelNumbe;
    }

    public void setPayerTelNumbe(String payerTelNumbe) {
        this.payerTelNumbe = payerTelNumbe;
    }

    public String getPayerAddress() {
        return payerAddress;
    }

    public void setPayerAddress(String payerAddress) {
        this.payerAddress = payerAddress;
    }

    public String getPayerIdentificationNumber() {
        return payerIdentificationNumber;
    }

    public void setPayerIdentificationNumber(String payerIdentificationNumber) {
        this.payerIdentificationNumber = payerIdentificationNumber;
    }

    public String getPayerName() {
        return payerName;
    }

    public void setPayerName(String payerName) {
        this.payerName = payerName;
    }

    public String getAltContactEmail() {
        return altContactEmail;
    }

    public void setAltContactEmail(String altContactEmail) {
        this.altContactEmail = altContactEmail;
    }

    public String getAltContactTelNumber() {
        return altContactTelNumber;
    }

    public void setAltContactTelNumber(String altContactTelNumber) {
        this.altContactTelNumber = altContactTelNumber;
    }

    public String getAltContactAddress() {
        return altContactAddress;
    }

    public void setAltContactAddress(String altContactAddress) {
        this.altContactAddress = altContactAddress;
    }

    public String getAltContactIdentificationNumber() {
        return altContactIdentificationNumber;
    }

    public void setAltContactIdentificationNumber(String altContactIdentificationNumber) {
        this.altContactIdentificationNumber = altContactIdentificationNumber;
    }

    public String getAltContactName() {
        return altContactName;
    }

    public void setAltContactName(String altContactName) {
        this.altContactName = altContactName;
    }

    public SupplyCustomerCategory getSupplyCustomerCategory() {
        return supplyCustomerCategory == null ? null : SupplyCustomerCategory.fromId(supplyCustomerCategory);
    }

    public void setSupplyCustomerCategory(SupplyCustomerCategory supplyCustomerCategory) {
        this.supplyCustomerCategory = supplyCustomerCategory == null ? null : supplyCustomerCategory.getId();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelNumber() {
        return telNumber;
    }

    public void setTelNumber(String telNumber) {
        this.telNumber = telNumber;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    public SupplyOwnership getSupplyOwnership() {
        return supplyOwnership == null ? null : SupplyOwnership.fromId(supplyOwnership);
    }

    public void setSupplyOwnership(SupplyOwnership supplyOwnership) {
        this.supplyOwnership = supplyOwnership == null ? null : supplyOwnership.getId();
    }

    public String getSupplyAddress() {
        return supplyAddress;
    }

    public void setSupplyAddress(String supplyAddress) {
        this.supplyAddress = supplyAddress;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLegalAddress() {
        return legalAddress;
    }

    public void setLegalAddress(String legalAddress) {
        this.legalAddress = legalAddress;
    }

    public String getIdentificationNumber() {
        return identificationNumber;
    }

    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Boolean getJobExecuted() {
        return jobExecuted;
    }

    public void setJobExecuted(Boolean jobExecuted) {
        this.jobExecuted = jobExecuted;
    }

    public Date getPrevToDate() {
        return prevToDate;
    }

    public void setPrevToDate(Date prevToDate) {
        this.prevToDate = prevToDate;
    }

    public Date getNotificationDate() {
        return notificationDate;
    }

    public void setNotificationDate(Date notificationDate) {
        this.notificationDate = notificationDate;
    }

    public AgreementType getAgreementType() {
        return agreementType == null ? null : AgreementType.fromId(agreementType);
    }

    public void setAgreementType(AgreementType agreementType) {
        this.agreementType = agreementType == null ? null : agreementType.getId();
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Boolean getContractPenalty() {
        return contractPenalty;
    }

    public void setContractPenalty(Boolean contractPenalty) {
        this.contractPenalty = contractPenalty;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public String getDocNum() {
        return docNum;
    }

    public void setDocNum(String docNum) {
        this.docNum = docNum;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PreUpdate
    public void preUpdate() {
        checkRanges();
        if(jobExecuted == null || !jobExecuted) {
            setPrevToDate(getFromDate());
        }
    }

    @PrePersist
    public void prePersist() {
        checkRanges();
        updateCustomerInfo();
        setPrevToDate(getFromDate());
    }

//    private void setContractPenalty() {
//        DataManager dataManager = AppBeans.getBean(DataManager.class);
//        Parameters parameters = dataManager.load(Parameters.class).all().one();
//        List<SupplyContractPenaltyCategories> categories = parameters.getSupplyContractPenaltyCustomerCatgeories();
//        if (!categories.isEmpty()) {
//            List<CustomerCategory> customerCategories = new LinkedList<>();
//            categories.forEach(item -> customerCategories.add(item.getCustomerCategories()));
//            if (getCustomer() != null && getCustomer().getCategory() != null && getContractPenalty() == null) {
//                if (customerCategories.contains(getCustomer().getCategory())) setContractPenalty(true);
//            }
//        }
//    }

    private void checkRanges() {
        DataManager dataManager = AppBeans.getBean(DataManager.class);
        Parameters parameters = dataManager.load(Parameters.class).all().one();
        SupplyContract supplyContract = dataManager.load(SupplyContract.class)
                .query("select e from prx_SupplyContract e where e.customer.id = :customerId and " +
                        "((e.fromDate >= :fromDate and e.toDate <= :toDate) or " +
                        "(e.toDate >= :fromDate and e.toDate <= :toDate) or " +
                        "(e.fromDate <= :toDate and e.fromDate >= :fromDate)) and e.id <> :id and e.status.id = :statusId")
                .parameter("customerId", getCustomer().getId())
                .parameter("fromDate", getFromDate())
                .parameter("toDate", getToDate())
                .parameter("id", getId())
                .parameter("statusId", parameters.getSupplyContractActiveStatus() != null ?
                        parameters.getSupplyContractActiveStatus().getId() : UUID.fromString(""))
                .optional().orElse(null);

        if (supplyContract != null) {
            Messages messages = AppBeans.getBean(Messages.class);
            throw new RuntimeException((messages.getMessage(this.getClass(), "rangesError")));
        }
    }

    private void updateCustomerInfo() {
        DataManager dataManager = AppBeans.getBean(DataManager.class);
        if (!getCustomer().getWithContract()) getCustomer().setWithContract(true);
        dataManager.save(getCustomer());
    }

    @PostUpdate
    public void postUpdate() {
//        super.postUpdate();
    }

    @PostLoad
    public void postLoad() {
        super.postLoad();
    }

    public Object reflect(Field field) {
        try {
            return field.get(this);
        } catch (Exception e) {
            return null;
        }
    }

    @InstanceName
    @DependsOnProperties({"docNum", "agreementType", "status"})
    public String getInstanceName() {
        return String.format("%s %s %s", docNum, agreementType, status);
    }
}