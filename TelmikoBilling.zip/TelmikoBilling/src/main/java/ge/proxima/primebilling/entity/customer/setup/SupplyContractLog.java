package ge.proxima.primebilling.entity.customer.setup;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.AgreementType;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.java.entitylogger.LogEntity;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_SUPPLY_CONTRACT_LOG")
@Entity(name = "prx_SupplyContractLog")
public class SupplyContractLog implements LogEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "ENTITY_ID")
    private UUID entityId;

    @NotNull
    @JoinColumn(name = "STATUS_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Status status;

    @NotNull
    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @NotNull
    @Column(name = "DOC_NUM", nullable = false)
    private String docNum;

    @Column(name = "AGREEMENT_TYPE")
    private String agreementType;

    @NotNull
    @Column(name = "FROM_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date fromDate;

    @NotNull
    @Column(name = "TO_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date toDate;

    @Column(name = "CONTRACT_PENALTY")
    private Boolean contractPenalty = false;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public Status getStatus() {
        return status;
    }

    public Customer getCustomer() {
        return customer;
    }

    public String getDocNum() {
        return docNum;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    @Override
    public UUID getEntityId() {
        return entityId;
    }

    public Boolean getContractPenalty() {
        return contractPenalty;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }


    public void setAgreementType(AgreementType agreementType) {
        this.agreementType = agreementType == null ? null : agreementType.getId();
    }

    public AgreementType getAgreementType() {
        return agreementType == null ? null : AgreementType.fromId(agreementType);
    }
    public void setStatus(Status status) {
        this.status = status;
    }


    public void setCustomer(Customer customer) {
        this.customer = customer;
    }


    public void setContractPenalty(Boolean contractPenalty) {
        this.contractPenalty = contractPenalty;
    }


    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    @Override
    public void setEntityId(UUID uuid) {
        this.entityId = uuid;
    }


    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }


    public void setDocNum(String docNum) {
        this.docNum = docNum;
    }

    @InstanceName
    @DependsOnProperties({"docNum", "fromDate", "status"})
    public String getInstanceName() {
        return String.format("%s %s %s", docNum, fromDate, status);
    }
}