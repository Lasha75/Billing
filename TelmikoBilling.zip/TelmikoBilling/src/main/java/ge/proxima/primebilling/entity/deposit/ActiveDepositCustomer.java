package ge.proxima.primebilling.entity.deposit;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_ActiveDepositCustomer")
public class ActiveDepositCustomer {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private String name;

    private BigDecimal depositAmount;

    private BigDecimal payedDepositAmount;

    @Temporal(TemporalType.DATE)
    private Date depositStartDate;

    @Temporal(TemporalType.DATE)
    private Date depositEndDate;

    private String code;

    private String identificationNumber;

    public Date getDepositEndDate() {
        return depositEndDate;
    }

    public void setDepositEndDate(Date depositEndDate) {
        this.depositEndDate = depositEndDate;
    }

    public Date getDepositStartDate() {
        return depositStartDate;
    }

    public void setDepositStartDate(Date depositStartDate) {
        this.depositStartDate = depositStartDate;
    }

    public BigDecimal getPayedDepositAmount() {
        return payedDepositAmount;
    }

    public void setPayedDepositAmount(BigDecimal payedDepositAmount) {
        this.payedDepositAmount = payedDepositAmount;
    }

    public BigDecimal getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(BigDecimal depositAmount) {
        this.depositAmount = depositAmount;
    }

    public String getIdentificationNumber() {
        return identificationNumber;
    }

    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"name", "code"})
    public String getInstanceName() {
        return String.format("%s %s", name, code);
    }
}