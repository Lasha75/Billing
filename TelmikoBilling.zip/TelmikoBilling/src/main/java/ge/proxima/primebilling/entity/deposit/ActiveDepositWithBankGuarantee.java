package ge.proxima.primebilling.entity.deposit;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.BankGuaranteeStatus;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import java.util.UUID;

@JmixEntity(name = "prx_ActiveDepositWithBankGuarantee")
public class ActiveDepositWithBankGuarantee {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private Customer customer;

    private String bankGuaranteeStatus;

    private String bankGuaranteeDocNumber;

    public String getBankGuaranteeDocNumber() {
        return bankGuaranteeDocNumber;
    }

    public void setBankGuaranteeDocNumber(String bankGuaranteeDocNumber) {
        this.bankGuaranteeDocNumber = bankGuaranteeDocNumber;
    }

    public BankGuaranteeStatus getBankGuaranteeStatus() {
        return bankGuaranteeStatus == null ? null : BankGuaranteeStatus.fromId(bankGuaranteeStatus);
    }

    public void setBankGuaranteeStatus(BankGuaranteeStatus bankGuaranteeStatus) {
        this.bankGuaranteeStatus = bankGuaranteeStatus == null ? null : bankGuaranteeStatus.getId();
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}