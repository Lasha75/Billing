package ge.proxima.primebilling.entity.deposit;

import ge.proxima.primebilling.entity.BankGuaranteeLine;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.BankGuaranteeStatus;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.entitylogger.VersionControlKey;
import ge.proxima.primebilling.java.entitylogger.VersionControlledEntity;
import io.jmix.core.DeletePolicy;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDelete;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_BANK_GUARANTEE", indexes = {
        @Index(name = "IDX_PRX_BANK_GUARANTEE_UNQ", columnList = "BANK_GUARANTEE_DOC_NUMBER", unique = true)
}, uniqueConstraints = {
        @UniqueConstraint(name = "IDX_BANKGUARANTEE_CUSTOMER_ID", columnNames = {"BANK_GUARANTEE_DOC_NUMBER", "CUSTOMER_ID"})
})
@Entity(name = "prx_BankGuarantee")
public class BankGuarantee extends VersionControlledEntity implements BaseUuidEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @VersionControlKey
    @Column(name = "BANK_GUARANTEE_DOC_NUMBER")
    private String docNumber;

    @VersionControlKey
    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @VersionControlKey
    @Column(name = "WRECKED_AMOUNT", precision = 19, scale = 4)
    private BigDecimal wreckedAmount;

    @VersionControlKey
    @Column(name = "START_DATE")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @VersionControlKey
    @Column(name = "END_DATE")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @VersionControlKey
    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @VersionControlKey
    @Column(name = "STATUS")
    private String status;

    @OnDelete(DeletePolicy.DENY)
    @Composition
    @OneToMany(mappedBy = "bankGuarantee")
    private List<BankGuaranteeLine> bankGuaranteeline;

    public List<BankGuaranteeLine> getBankGuaranteeline() {
        return bankGuaranteeline;
    }

    public void setBankGuaranteeline(List<BankGuaranteeLine> bankGuaranteeline) {
        this.bankGuaranteeline = bankGuaranteeline;
    }

    public void setWreckedAmount(BigDecimal wreckedAmount) {
        this.wreckedAmount = wreckedAmount;
    }

    public BigDecimal getWreckedAmount() {
        return wreckedAmount;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BankGuaranteeStatus getStatus() {
        return status == null ? null : BankGuaranteeStatus.fromId(status);
    }

    public void setStatus(BankGuaranteeStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getDocNumber() {
        return docNumber;
    }

    public void setDocNumber(String docNumber) {
        this.docNumber = docNumber;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PostUpdate
    public void postUpdate() {
        super.postUpdate();
    }

    @PostLoad
    public void postLoad() {
        super.postLoad();
    }

    @InstanceName
    @DependsOnProperties({"docNumber", "customer", "amount"})
    public String getInstanceName() {
        return String.format("%s - %s - %s", docNumber, customer.getInstanceName(), amount);
    }

    @PreRemove
    public void preRemove() {

    }
}