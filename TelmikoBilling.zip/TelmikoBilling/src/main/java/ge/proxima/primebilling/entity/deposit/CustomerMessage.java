package ge.proxima.primebilling.entity.deposit;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.setup.SmsSubject;
import ge.proxima.primebilling.entity.customer.setup.TelephoningResult;
import ge.proxima.primebilling.entity.enums.CustomerContactType;
import ge.proxima.primebilling.entity.enums.MessageSendStatus;
import ge.proxima.primebilling.entity.enums.MessageStatus;
import ge.proxima.primebilling.entity.enums.NotificationType;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_MESSAGE", indexes = {
        @Index(name = "IDX_CUSTOMERMESSAGE", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_CUSTOMERMESSAGE_SENDER_ID", columnList = "SENDER"),
        @Index(name = "IDX_CUSTOMERMESSAGE", columnList = "SMS_SUBJECT_ID"),
        @Index(name = "IDX_CUSTOMERMESSAGE", columnList = "TELEPHONING_RESULT_ID")
})
@Entity(name = "prx_CustomerMessage")
public class CustomerMessage {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "COMPLAINT")
    private Boolean complaint;

    @JoinColumn(name = "TELEPHONING_RESULT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TelephoningResult telephoningResult;

    @JoinColumn(name = "SMS_SUBJECT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private SmsSubject smsSubject;

    @Column(name = "ERROR_TEXT")
    @Lob
    private String errorText;

    @Column(name = "INITIAL_PAYMENT", precision = 19, scale = 8)
    private BigDecimal initialPayment;

    @Column(name = "MESSAGE_ID")
    private String messageId;

    @Column(name = "MESSAGE_STATUS")
    private String messageStatus;

    @Column(name = "DEBT", precision = 19, scale = 8)
    private BigDecimal debt;

    @Column(name = "LIMIT_")
    @Temporal(TemporalType.DATE)
    private Date limit;

    @Column(name = "REMARK")
    @Lob
    private String remark;

    @Column(name = "SENT_ADRESS")
    private String sentAddress;

    @Column(name = "DOC_NUM")
    private String docNum;

    @Column(name = "SENDER")
    private String sender;

    @Column(name = "SUBJECT")
    private String subject;

    @InstanceName
    @Column(name = "MESSAGE")
    @Lob
    private String message;

    @Column(name = "CONTACT")
    private String contact;

    @Column(name = "CONTACT_TYPE")
    private String contactType;

    @Column(name = "DATE_")
    @Temporal(TemporalType.TIMESTAMP)
    private Date date;

    @Column(name = "TYPE_")
    private String type;

    @Column(name = "CUSTOMER_BALANCE", precision = 19, scale = 2)
    private BigDecimal customerBalance;

    @Column(name = "STATUS")
    private String status;

    public Boolean getComplaint() {
        return complaint;
    }

    public void setComplaint(Boolean complaint) {
        this.complaint = complaint;
    }

    public BigDecimal getCustomerBalance() {
        return customerBalance;
    }

    public void setCustomerBalance(BigDecimal customerBalance) {
        this.customerBalance = customerBalance;
    }

    public TelephoningResult getTelephoningResult() {
        return telephoningResult;
    }

    public void setTelephoningResult(TelephoningResult telephoningResult) {
        this.telephoningResult = telephoningResult;
    }

    public SmsSubject getSmsSubject() {
        return smsSubject;
    }

    public void setSmsSubject(SmsSubject smsSubject) {
        this.smsSubject = smsSubject;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getSender() {
        return sender;
    }

    public String getErrorText() {
        return errorText;
    }

    public void setErrorText(String errorText) {
        this.errorText = errorText;
    }

    public Date getLimit() {
        return limit;
    }

    public void setLimit(Date limit) {
        this.limit = limit;
    }

    public BigDecimal getInitialPayment() {
        return initialPayment;
    }

    public void setInitialPayment(BigDecimal initialPayment) {
        this.initialPayment = initialPayment;
    }

    public void setMessageStatus(MessageStatus messageStatus) {
        this.messageStatus = messageStatus == null ? null : messageStatus.getId();
    }

    public MessageStatus getMessageStatus() {
        return messageStatus == null ? null : MessageStatus.fromId(messageStatus);
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public BigDecimal getDebt() {
        return debt;
    }

    public void setDebt(BigDecimal debt) {
        this.debt = debt;
    }

    public String getDocNum() {
        return docNum;
    }

    public void setDocNum(String docNum) {
        this.docNum = docNum;
    }

    public String getSentAddress() {
        return sentAddress;
    }

    public void setSentAddress(String sentAddress) {
        this.sentAddress = sentAddress;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public MessageSendStatus getStatus() {
        return status == null ? null : MessageSendStatus.fromId(status);
    }

    public void setStatus(MessageSendStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public CustomerContactType getContactType() {
        return contactType == null ? null : CustomerContactType.fromId(contactType);
    }

    public void setContactType(CustomerContactType contactType) {
        this.contactType = contactType == null ? null : contactType.getId();
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public NotificationType getType() {
        return type == null ? null : NotificationType.fromId(type);
    }

    public void setType(NotificationType type) {
        this.type = type == null ? null : type.getId();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}