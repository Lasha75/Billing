package ge.proxima.primebilling.entity.deposit;

import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.enums.DepositType;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.data.DbView;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@DbView
@JmixEntity
@Table(name = "prx_active_overdue_deposits", indexes = {
        @Index(name = "IDX_PRXACTIVEOVERDUEDEPO_BLOCK", columnList = "BLOCK_ID")
})
@Entity(name = "prx_DepositOverdueTransaction")
public class DepositOverdueTransaction {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "CUSTOMER_NUMBER")
    private String customerNumber;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @Column(name = "SETTLED_AMOUNT")
    private BigDecimal settledAmount;

    @Column(name = "CUSTOMER_CODE")
    private String customerCode;

    @Column(name = "DEPOSIT_TYPE")
    private String depositType;

    @Column(name = "CUSTOMER_NAME")
    private String customerName;

    @Column(name = "AMOUNT")
    private BigDecimal amount;

    @Column(name = "_DATE")
    @Temporal(TemporalType.DATE)
    private Date date;

    @Column(name = "DUE_DATE")
    @Temporal(TemporalType.DATE)
    private Date dueDate;

    @Column(name = "DEPOSIT_END_DATE")
    @Temporal(TemporalType.DATE)
    private Date depositEndDate;

    @Column(name = "ADDITIONAL_OVERDUES")
    private Long additionalOverdues;

    @Column(name = "CATEGORY")
    private String category;

    @Column(name = "ACTIVITY")
    private String activity;

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public Long getAdditionalOverdues() {
        return additionalOverdues;
    }

    public void setAdditionalOverdues(Long additionalOverdues) {
        this.additionalOverdues = additionalOverdues;
    }

    public Date getDepositEndDate() {
        return depositEndDate;
    }

    public void setDepositEndDate(Date depositEndDate) {
        this.depositEndDate = depositEndDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public BigDecimal getSettledAmount() {
        return settledAmount;
    }

    public void setSettledAmount(BigDecimal settledAmount) {
        this.settledAmount = settledAmount;
    }
    /*
        public Date getBankGuaranteeEndDate() {
            return bankGuaranteeEndDate;
        }

        public void setBankGuaranteeEndDate(Date bankGuaranteeEndDate) {
            this.bankGuaranteeEndDate = bankGuaranteeEndDate;
        }

        public Date getBankGuaranteeStartDate() {
            return bankGuaranteeStartDate;
        }

        public void setBankGuaranteeStartDate(Date bankGuaranteeStartDate) {
            this.bankGuaranteeStartDate = bankGuaranteeStartDate;
        }

        public String getBankGuaranteeNumber() {
            return bankGuaranteeNumber;
        }

        public void setBankGuaranteeNumber(String bankGuaranteeNumber) {
            this.bankGuaranteeNumber = bankGuaranteeNumber;
        }

        public String getCustomerCode() {
            return customerCode;
        }
    */
    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public DepositType getDepositType() {
        return depositType == null ? null : DepositType.fromId(depositType);
    }

    public void setDepositType(DepositType depositType) {
        this.depositType = depositType == null ? null : depositType.getId();
    }
    /*
        public OpenTransaction getRefTransaction() {
            return refTransaction;
        }

        public void setRefTransaction(OpenTransaction refTransaction) {
            this.refTransaction = refTransaction;
        }
    */
    public void setDate(Date date) {
        this.date = date;
    }

    public Date getDate() {
        return date;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    @InstanceName
    @DependsOnProperties({"customerNumber", "amount"})
    public String getInstanceName() {
        return String.format("%s %s", customerNumber, amount);
    }

}