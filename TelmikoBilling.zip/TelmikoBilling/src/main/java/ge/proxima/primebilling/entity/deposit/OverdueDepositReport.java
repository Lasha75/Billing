package ge.proxima.primebilling.entity.deposit;

import ge.proxima.primebilling.entity.transactions.transtypes.transactionsubtype.TransactionSubType;
import ge.proxima.primebilling.entity.transactions.transtypes.transactiontype.TransactionType;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_OverdueDepositReport")
public class OverdueDepositReport {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private String customerNumber;

    private String customerName;

    @Temporal(TemporalType.DATE)
    private Date depositStartDate;

    @Temporal(TemporalType.DATE)
    private Date depositEndDate;

    private BigDecimal amount;

    private Integer overduesAfterDepositStart;

    private TransactionType transType;

    private TransactionSubType transSubType;

    private BigDecimal amountNegate;

    @Temporal(TemporalType.DATE)
    private Date operationDate;

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public BigDecimal getAmountNegate() {
        return amountNegate;
    }

    public void setAmountNegate(BigDecimal amountNegate) {
        this.amountNegate = amountNegate;
    }

    public TransactionSubType getTransSubType() {
        return transSubType;
    }

    public void setTransSubType(TransactionSubType transSubType) {
        this.transSubType = transSubType;
    }

    public TransactionType getTransType() {
        return transType;
    }

    public void setTransType(TransactionType transType) {
        this.transType = transType;
    }

    public Integer getOverduesAfterDepositStart() {
        return overduesAfterDepositStart;
    }

    public void setOverduesAfterDepositStart(Integer overduesAfterDepositStart) {
        this.overduesAfterDepositStart = overduesAfterDepositStart;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Date getDepositEndDate() {
        return depositEndDate;
    }

    public void setDepositEndDate(Date depositEndDate) {
        this.depositEndDate = depositEndDate;
    }

    public Date getDepositStartDate() {
        return depositStartDate;
    }

    public void setDepositStartDate(Date depositStartDate) {
        this.depositStartDate = depositStartDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}