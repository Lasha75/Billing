package ge.proxima.primebilling.entity.deposit;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_OVERDUE_PAYMENT_REPORT", indexes = {
        @Index(name = "IDX_PRX_OVERDUE_PAYMENT_REPORT", columnList = "CUSTOMER_NUMBER"),
        @Index(name = "IDX_PRX_OVERDUE_PAYMENT_REPORT_1", columnList = "CUSTOMER, DUE_DATE"),
        @Index(name = "IDX_PRX_OVERDUE_PAYMENT_REPORT_2", columnList = "ID")
})
@Entity(name = "prx_OverduePaymentReport")
public class OverduePaymentReport {
    @Id
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    private UUID id;

    @Column(name = "CUSTOMER")
    private UUID customer;

    @Column(name = "CUSTOMER_NUMBER")
    private String customerNumber;

    @Column(name = "CUSTOMER_CODE")
    private String customerCode;

    @Column(name = "CUSTOMER_NAME")
    private String customerName;

    @Temporal(TemporalType.DATE)
    @Column(name = "PERIOD_END_DATE")
    private Date periodEndDate;

    @Column(name = "AMOUNT")
    private BigDecimal amount;

    @Temporal(TemporalType.DATE)
    @Column(name = "DUE_DATE")
    private Date dueDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "DATE")
    private Date date;

    @Column(name = "TRANS_DATE")
    @Temporal(TemporalType.DATE)
    private Date transDate;

    @Column(name = "NUMBER")
    private Integer number;

    @Column(name = "WARNING_SENT")
    private Boolean warningSent = false;

    @Column(name = "AVERAGE")
    private BigDecimal average;

    @Column(name = "EXCUSABLE")
    private Boolean excusable = false;

    @Column(name = "CATERORY")
    private String caterory;

    @Column(name = "CUST_CATEGORY")
    private String custCategory;

    @Column(name = "BLOCK")
    private String block;

    @Column(name = "BLOCK_ID")
    private UUID blockId;

    @Column(name = "ACTIVITY")
    private String activity;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    public Date getTransDate() {
        return transDate;
    }

    public void setTransDate(Date transDate) {
        this.transDate = transDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public UUID getBlockId() {
        return blockId;
    }

    public void setBlockId(UUID blockId) {
        this.blockId = blockId;
    }

    public void setCustomer(UUID customer) {
        this.customer = customer;
    }

    public UUID getCustomer() {
        return customer;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public String getCustCategory() {
        return custCategory;
    }

    public void setCustCategory(String custCategory) {
        this.custCategory = custCategory;
    }

    public String getCaterory() {
        return caterory;
    }

    public void setCaterory(String caterory) {
        this.caterory = caterory;
    }

    public Boolean getExcusable() {
        return excusable;
    }

    public void setExcusable(Boolean excusable) {
        this.excusable = excusable;
    }

    public BigDecimal getAverage() {
        return average;
    }

    public void setAverage(BigDecimal average) {
        this.average = average;
    }

    public Boolean getWarningSent() {
        return warningSent;
    }

    public void setWarningSent(Boolean warningSent) {
        this.warningSent = warningSent;
    }

    public Date getPeriodEndDate() {
        return periodEndDate;
    }

    public void setPeriodEndDate(Date periodEndDate) {
        this.periodEndDate = periodEndDate;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"amount", "customer", "excusable"})
    public String getInstanceName() {
        return String.format("%s %s %s", amount, customer, excusable);
    }
}