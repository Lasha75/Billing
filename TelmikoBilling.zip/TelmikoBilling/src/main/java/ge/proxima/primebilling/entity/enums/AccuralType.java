package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum AccuralType implements EnumClass<String> {

    NONE("NONE"),
    COUNTER("COUNTER");

    private String id;

    AccuralType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static AccuralType fromId(String id) {
        for (AccuralType at : AccuralType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}