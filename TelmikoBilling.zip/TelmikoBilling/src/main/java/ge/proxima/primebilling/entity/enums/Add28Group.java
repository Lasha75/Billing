package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum Add28Group implements EnumClass<String> {

    CORRECTION("CORRECTION"),
    ACT("ACT"),
    NONCIECULAR("NONCIECULAR");

    private String id;

    Add28Group(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static Add28Group fromId(String id) {
        for (Add28Group at : Add28Group.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}