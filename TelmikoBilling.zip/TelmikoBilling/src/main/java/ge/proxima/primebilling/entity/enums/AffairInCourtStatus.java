package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum AffairInCourtStatus implements EnumClass<String> {

    IN_PRODUCTION("IN_PRODUCTION"),
    REFUSAL("REFUSAL");

    private String id;

    AffairInCourtStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static AffairInCourtStatus fromId(String id) {
        for (AffairInCourtStatus at : AffairInCourtStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}