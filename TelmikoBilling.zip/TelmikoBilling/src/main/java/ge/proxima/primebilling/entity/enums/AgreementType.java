package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum AgreementType implements EnumClass<String> {

    TELMICOLASTALTERNATIVE("TELMICOLASTALTERNATIVE"),
    NONDOMESTIC("NONDOMESTIC"),
    DOMESTICUNIVERSAL("DOMESTICUNIVERSAL"),
    NONDOMESTICUNIVERSAL("NONDOMESTICUNIVERSAL");

    private String id;

    AgreementType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static AgreementType fromId(String id) {
        for (AgreementType at : AgreementType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}