package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum AppealToCourtStatus implements EnumClass<String> {

    SATISFIED("SATISFIED"),
    NON_SATISFIED("NON_SATISFIED"),
    CORRESPONDENCE("CORRESPONDENCE"),
    VERDICT("VERDICT"),
    APPEALED("APPEALED");

    private String id;

    AppealToCourtStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static AppealToCourtStatus fromId(String id) {
        for (AppealToCourtStatus at : AppealToCourtStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}