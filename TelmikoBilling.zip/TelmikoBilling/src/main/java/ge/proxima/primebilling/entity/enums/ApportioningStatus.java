package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ApportioningStatus implements EnumClass<String> {

    NEW("NEW"),
    PERMISSION_PROCESS("PERMISSION_PROCESS"),
    CONFIRMED("CONFIRMED"),
    FINISHED("FINISHED"),
    ABOLISHED("ABOLISHED");

    private String id;

    ApportioningStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ApportioningStatus fromId(String id) {
        for (ApportioningStatus at : ApportioningStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}