package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum BankGuaranteeStatus implements EnumClass<String> {

    LIMIT_PASSED("LIMIT_PASSED"),
    ACTIVE("ACTIVE");

    private String id;

    BankGuaranteeStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static BankGuaranteeStatus fromId(String id) {
        for (BankGuaranteeStatus at : BankGuaranteeStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}