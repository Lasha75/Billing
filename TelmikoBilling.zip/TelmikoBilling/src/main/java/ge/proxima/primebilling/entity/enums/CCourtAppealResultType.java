package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtAppealResultType implements EnumClass<String> {

    COMPLAINTACCEPTED("Complaint accepted"),
    COMPLAINTDISMISSED("Complaint Dismissed");

    private String id;

    CCourtAppealResultType(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtAppealResultType fromId(String id) {
        for (CCourtAppealResultType at : CCourtAppealResultType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}