package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ChargeType implements EnumClass<String> {

    NONE("NONE"),
    IMPORT("IMPORT"),
    CHARGE("CHARGE");

    private String id;

    ChargeType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ChargeType fromId(String id) {
        for (ChargeType at : ChargeType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}