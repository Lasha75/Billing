package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CircularAccuralType implements EnumClass<String> {

    CHARGED("CHARGED"),
    TO_BE_CHARGED("TO_BE_CHARGED");

    private String id;

    CircularAccuralType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CircularAccuralType fromId(String id) {
        for (CircularAccuralType at : CircularAccuralType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}