package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CounterSpeedCalculationType implements EnumClass<String> {

    PERCENT("PERCENT"),
    COEFFICIENT("COEFFICIENT");

    private String id;

    CounterSpeedCalculationType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CounterSpeedCalculationType fromId(String id) {
        for (CounterSpeedCalculationType at : CounterSpeedCalculationType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}