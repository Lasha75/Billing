package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CounterSpeedCorrectionType implements EnumClass<String> {

    SPEEDUP("SPEEDUP"),
    SLOWDOWN("SLOWDOWN");

    private String id;

    CounterSpeedCorrectionType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CounterSpeedCorrectionType fromId(String id) {
        for (CounterSpeedCorrectionType at : CounterSpeedCorrectionType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}