package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CourtCaseCategory implements EnumClass<String> {

    MUNICIPAL("MUNICIPAL"),
    ADMINISTRATIVE("ADMINISTRATIVE"),
    BLOOD("BLOOD"),
    LABOUR("LABOUR");

    private String id;

    CourtCaseCategory(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CourtCaseCategory fromId(String id) {
        for (CourtCaseCategory at : CourtCaseCategory.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}