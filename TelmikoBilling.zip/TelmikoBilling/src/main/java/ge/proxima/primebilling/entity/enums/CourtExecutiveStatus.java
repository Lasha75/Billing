package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CourtExecutiveStatus implements EnumClass<String> {

    FULFILLED("FULFILLED"),
    PARTIALLY_FULFILLED("PARTIALLY_FULFILLED"),
    NOT_FULFILLED("NOT_FULFILLED");

    private String id;

    CourtExecutiveStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CourtExecutiveStatus fromId(String id) {
        for (CourtExecutiveStatus at : CourtExecutiveStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}