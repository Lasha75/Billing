package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CourtSittingScheduleStatus implements EnumClass<String> {

    PLANNED("PLANNED"),
    WAS_HELD("WAS_HELD"),
    POSTPONE("POSTPONE");

    private String id;

    CourtSittingScheduleStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CourtSittingScheduleStatus fromId(String id) {
        for (CourtSittingScheduleStatus at : CourtSittingScheduleStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}