package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CourtSittingType implements EnumClass<String> {

    PREPORATION("PREPORATION"),
    MAIN("MAIN");

    private String id;

    CourtSittingType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CourtSittingType fromId(String id) {
        for (CourtSittingType at : CourtSittingType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}