package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CourtVerdictStatus implements EnumClass<String> {

    AGREEMENT("AGREEMENT"),
    CEASING("CEASING"),
    CALL_OUT("CALL_OUT"),
    NON_CONSIDERED("NON_CONSIDERED");

    private String id;

    CourtVerdictStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CourtVerdictStatus fromId(String id) {
        for (CourtVerdictStatus at : CourtVerdictStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}