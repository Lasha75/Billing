package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CustomerContactType implements EnumClass<String> {

    MOBILE_PHONE("MOBILE_PHONE"),
    HOME_PHONE("HOME_PHONE"),
    WORK_PHONE("WORK_PHONE"),
    EMAIL("EMAIL"),
    FAX("FAX"),
    CONTACT_PERSON("CONTACT_PERSON"),
    BY_POST("BY_POST");

    private String id;

    CustomerContactType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CustomerContactType fromId(String id) {
        for (CustomerContactType at : CustomerContactType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}