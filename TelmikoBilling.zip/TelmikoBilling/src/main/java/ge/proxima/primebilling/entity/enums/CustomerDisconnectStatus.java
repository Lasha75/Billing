package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CustomerDisconnectStatus implements EnumClass<String> {

    DRAFT("DRAFT"),
    DISCONNECTED("DISCONNECTED");

    private String id;

    CustomerDisconnectStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CustomerDisconnectStatus fromId(String id) {
        for (CustomerDisconnectStatus at : CustomerDisconnectStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}