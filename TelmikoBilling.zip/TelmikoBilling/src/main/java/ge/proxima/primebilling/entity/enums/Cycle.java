package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum Cycle implements EnumClass<String> {

    CIRCULAR("CIRCULAR"),
    NON_CIRCULAR("NON_CIRCULAR");

    private String id;

    Cycle(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static Cycle fromId(String id) {
        for (Cycle at : Cycle.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}