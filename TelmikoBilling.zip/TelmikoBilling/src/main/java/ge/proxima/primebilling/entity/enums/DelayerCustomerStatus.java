package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum DelayerCustomerStatus implements EnumClass<String> {

    TEMPORARY("TEMPORARY"),
    PERMANENT("PERMANENT");

    private String id;

    DelayerCustomerStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static DelayerCustomerStatus fromId(String id) {
        for (DelayerCustomerStatus at : DelayerCustomerStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}