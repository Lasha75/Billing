package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum DelayerStatus implements EnumClass<String> {

    NONE("NONE"),
    ACTIVE("ACTIVE"),
    FINISHED("FINISHED"),
    ON_CHECK("ON_CHECK"),
    INSTRUCTOR_AGREEMENT("INSTRUCTOR_AGREEMENT"),
    NO_AGREEMENT("NO_AGREEMENT"),
    DELAY_ABOLISHED("DELAY_ABOLISHED"),
    SENT_TO_CUT_OFF("SENT_TO_CUT_OFF");

    private String id;

    DelayerStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static DelayerStatus fromId(String id) {
        for (DelayerStatus at : DelayerStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}