package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum DelayerType implements EnumClass<String> {

    SHORT_TERM("SHORT_TERM"),
    PERMANENT("PERMANENT");

    private String id;

    DelayerType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static DelayerType fromId(String id) {
        for (DelayerType at : DelayerType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}