package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum DepositReportFilterType implements EnumClass<String> {

    TYPES_ALL("TYPES_ALL"),
    BANK_GUARANTEE("BANK_GUARANTEE"),
    BANK_GUARANTEE_TIMEOUT("BANK_GUARANTEE_TIMEOUT");

    private String id;

    DepositReportFilterType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static DepositReportFilterType fromId(String id) {
        for (DepositReportFilterType at : DepositReportFilterType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}