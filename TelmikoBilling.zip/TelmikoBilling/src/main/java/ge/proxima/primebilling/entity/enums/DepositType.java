package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum DepositType implements EnumClass<String> {

    HIGH_CONSUMPTION("HIGH_CONSUMPTION"),
    CUSTOMER_REQUEST("CUSTOMER_REQUEST"),
    OVERDUE("OVERDUE"),
    LEASEHOLDER("LEASEHOLDER"),
    DISCONNECT("DISCONNECT");

    private String id;

    DepositType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static DepositType fromId(String id) {
        for (DepositType at : DepositType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}