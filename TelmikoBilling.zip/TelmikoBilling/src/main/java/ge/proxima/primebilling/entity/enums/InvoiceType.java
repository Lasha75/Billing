package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum InvoiceType implements EnumClass<String> {

    NEW("NEW"),
    CORRECTION("CORRECTION"),
    TOBECANCELLED("TOBECANCELLED"),
    CORRECTIONASSTANDARD("CORRECTIONASSTANDARD"),
    MERGED("MERGED");

    private String id;

    InvoiceType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static InvoiceType fromId(String id) {
        for (InvoiceType at : InvoiceType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}