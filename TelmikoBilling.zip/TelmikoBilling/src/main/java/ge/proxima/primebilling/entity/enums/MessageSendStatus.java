package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum MessageSendStatus implements EnumClass<String> {

    DRAFT("DRAFT"),
    SENT("SENT"),
    FAILED("FAILED"),
    INTERNAL_ERROR("INTERNAL_ERROR"),
    INVALID_REQUEST("INVALID_REQUEST"),
    INVALID_QUERY("INVALID_QUERY"),
    EMPTY_MESSAGE("EMPTY_MESSAGE"),
    PREFIX_ERROR("PREFIX_ERROR"),
    MSISDN_ERROR("MSISDN_ERROR"),
    ERROR("ERROR");

    private String id;

    MessageSendStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static MessageSendStatus fromId(String id) {
        for (MessageSendStatus at : MessageSendStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}