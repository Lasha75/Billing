package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum MessageStatus implements EnumClass<String> {

    UNDEFINED("UNDEFINED"),
    DELIVERED_TO_PHONE("DELIVERED_TO_PHONE"),
    NOT_DELIVERED_TO_PHONE("NOT_DELIVERED_TO_PHONE"),
    QUEUED_ON_SMSC("QUEUED_ON_SMSC"),
    DELIVERED_TO_SMSC("DELIVERED_TO_SMSC"),
    NOT_DELIVERED_TO_SMSC("NOT_DELIVERED_TO_SMSC");

    private String id;

    MessageStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static MessageStatus fromId(String id) {
        for (MessageStatus at : MessageStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}