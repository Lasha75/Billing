package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum MessageTemplateType implements EnumClass<String> {

    NONE("NONE"),
    CUTOFF_WARNING("CUTOFF_WARNING"),
    PAYMENT_NOTIFICATION("PAYMENT_NOTIFICATION"),
    PAYMENT_NOTIFICATION_100("PAYMENT_NOTIFICATION_100"),
    DEPOSIT_MESSAGE("DEPOSIT_MESSAGE"),
    CATEGORY_MANUAL_DUE_DATE("CATEGORY_MANUAL_DUE_DATE"),
    DEPOSIT("DEPOSIT");

    private String id;

    MessageTemplateType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static MessageTemplateType fromId(String id) {
        for (MessageTemplateType at : MessageTemplateType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}