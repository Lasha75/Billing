package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum MessageType implements EnumClass<String> {

    EMAIL("Email"),
    SMS("Sms");

    private String id;

    MessageType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static MessageType fromId(String id) {
        for (MessageType at : MessageType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}