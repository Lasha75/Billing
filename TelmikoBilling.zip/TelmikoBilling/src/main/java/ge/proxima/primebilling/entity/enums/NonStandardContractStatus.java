package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum NonStandardContractStatus implements EnumClass<String> {

    ACTIVE("ACTIVE"),
    CANCELLED("CANCELLED");

    private String id;

    NonStandardContractStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static NonStandardContractStatus fromId(String id) {
        for (NonStandardContractStatus at : NonStandardContractStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}