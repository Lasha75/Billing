package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum NotificationType implements EnumClass<String> {

    DEPOSIT("DEPOSIT"),
    CUTOFF_WARNING("CUTOFF_WARNING"),
    BILL("BILL"),
    PAYMENT_NOTIFICATION("PAYMENT_NOTIFICATION"),
    INDIVIDUAL("INDIVIDUAL"),
    SUPPLY_CONTRACT("SUPPLY_CONTRACT"),
    CATEGORY_MANUAL_DUE_DATE("CATEGORY_MANUAL_DUE_DATE"),
    PRE_COURT("PRE_COURT");

    private String id;

    NotificationType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static NotificationType fromId(String id) {
        for (NotificationType at : NotificationType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}