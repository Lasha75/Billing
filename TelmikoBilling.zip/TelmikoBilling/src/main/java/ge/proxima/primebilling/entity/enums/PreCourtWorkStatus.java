package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum PreCourtWorkStatus implements EnumClass<String> {

    IN_PROCESS("IN_PROCESS"),
    FINISHED("FINISHED"),
    PASSED("PASSED"),
    PROCESSED("PROCESSED"),
    RETURNED("RETURNED"),
    UNIDENTIFIED("UNIDENTIFIED");

    private String id;

    PreCourtWorkStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static PreCourtWorkStatus fromId(String id) {
        for (PreCourtWorkStatus at : PreCourtWorkStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}