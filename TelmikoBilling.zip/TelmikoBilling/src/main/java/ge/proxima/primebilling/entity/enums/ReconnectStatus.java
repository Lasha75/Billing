package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ReconnectStatus implements EnumClass<String> {

    DRAFT("DRAFT"),
    RECONNECTED("RECONNECTED");

    private String id;

    ReconnectStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ReconnectStatus fromId(String id) {
        for (ReconnectStatus at : ReconnectStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}