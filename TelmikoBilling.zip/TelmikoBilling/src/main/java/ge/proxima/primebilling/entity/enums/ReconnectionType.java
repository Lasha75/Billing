package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ReconnectionType implements EnumClass<String> {

    AUTOMATIC("AUTOMATIC"),
    MANUAL("MANUAL");

    private String id;

    ReconnectionType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ReconnectionType fromId(String id) {
        for (ReconnectionType at : ReconnectionType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}