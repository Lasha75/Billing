package ge.proxima.primebilling.entity.enums;

import ge.proxima.primebilling.entity.RsInvoiceTempCategory;
import ge.proxima.primebilling.entity.RsInvoiceTempType;
import ge.proxima.primebilling.entity.customer.Customer;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_RS_INVOICE_TEMP_CALC", indexes = {
        @Index(name = "IDX_PRXRSINVOICETEMPC_CUSTOMER", columnList = "CUSTOMER_ID")
})
@Entity(name = "prx_RsInvoiceTempCalc")
public class RsInvoiceTempCalc {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "IDENTIFICATION_NUMBER", length = 20)
    private String identificationNumber;

    @InstanceName
    @Column(name = "NAME")
    private String name;

    @Column(name = "TYPE_")
    private String type;

    @Column(name = "CATEGORY")
    private String category;

    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @Column(name = "CUSTOMER_NUMBER")
    private String customerNumber;

    @Column(name = "WITH_OUT_VAT")
    private Boolean withOutVAT;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "KILOWATT_HOUR", precision = 19, scale = 2)
    private BigDecimal kilowattHour;

    @Column(name = "INVOICE_YEAR")
    private Integer invoiceYear;

    @Column(name = "INVOICE_MONTH")
    private Integer invoiceMonth;

    @Column(name = "INVOICE_DATE")
    private LocalDate invoiceDate;

    @Column(name = "OPERATION_DATE")
    private LocalDate operationDate;

    @Column(name = "CODE")
    private String code;

    @Column(name = "EXSISTRSINVOICE")
    private Boolean exsistrsinvoice;

    @Column(name = "LASTINVOICESTATUSCODE")
    private String lastinvoicestatuscode;

    @Column(name = "LASTINVOICECODE")
    private String lastinvoicecode;

    @Column(name = "LASTINVOICESEQUENCE")
    private String lastinvoicesequence;

    @Column(name = "LASTINVOICEINVOICEID")
    private Integer lastinvoiceinvoiceid;

    @Column(name = "LASTINVOICEID")
    private UUID lastinvoiceid;

    @Column(name = "DECSTATUS")
    private Integer decstatus;

    @Column(name = "LASTINVOICEYEAR")
    private Integer lastinvoiceyear;

    @Column(name = "LASTINVOICEMONTH")
    private Integer lastinvoicemonth;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdentificationNumber() {
        return identificationNumber;
    }

    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }

    public RsInvoiceTempCategory getCategory() {
        return category == null ? null : RsInvoiceTempCategory.fromId(category);
    }

    public void setCategory(RsInvoiceTempCategory category) {
        this.category = category == null ? null : category.getId();
    }

    public RsInvoiceTempType getType() {
        return type == null ? null : RsInvoiceTempType.fromId(type);
    }

    public void setType(RsInvoiceTempType type) {
        this.type = type == null ? null : type.getId();
    }

    public Integer getLastinvoicemonth() {
        return lastinvoicemonth;
    }

    public void setLastinvoicemonth(Integer lastinvoicemonth) {
        this.lastinvoicemonth = lastinvoicemonth;
    }

    public Integer getLastinvoiceyear() {
        return lastinvoiceyear;
    }

    public void setLastinvoiceyear(Integer lastinvoiceyear) {
        this.lastinvoiceyear = lastinvoiceyear;
    }

    public Integer getDecstatus() {
        return decstatus;
    }

    public void setDecstatus(Integer decstatus) {
        this.decstatus = decstatus;
    }

    public UUID getLastinvoiceid() {
        return lastinvoiceid;
    }

    public void setLastinvoiceid(UUID lastinvoiceid) {
        this.lastinvoiceid = lastinvoiceid;
    }

    public Integer getLastinvoiceinvoiceid() {
        return lastinvoiceinvoiceid;
    }

    public void setLastinvoiceinvoiceid(Integer lastinvoiceinvoiceid) {
        this.lastinvoiceinvoiceid = lastinvoiceinvoiceid;
    }

    public String getLastinvoicesequence() {
        return lastinvoicesequence;
    }

    public void setLastinvoicesequence(String lastinvoicesequence) {
        this.lastinvoicesequence = lastinvoicesequence;
    }

    public String getLastinvoicecode() {
        return lastinvoicecode;
    }

    public void setLastinvoicecode(String lastinvoicecode) {
        this.lastinvoicecode = lastinvoicecode;
    }

    public String getLastinvoicestatuscode() {
        return lastinvoicestatuscode;
    }

    public void setLastinvoicestatuscode(String lastinvoicestatuscode) {
        this.lastinvoicestatuscode = lastinvoicestatuscode;
    }

    public Boolean getExsistrsinvoice() {
        return exsistrsinvoice;
    }

    public void setExsistrsinvoice(Boolean exsistrsinvoice) {
        this.exsistrsinvoice = exsistrsinvoice;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public LocalDate getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(LocalDate operationDate) {
        this.operationDate = operationDate;
    }

    public LocalDate getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(LocalDate invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public Integer getInvoiceMonth() {
        return invoiceMonth;
    }

    public void setInvoiceMonth(Integer invoiceMonth) {
        this.invoiceMonth = invoiceMonth;
    }

    public Integer getInvoiceYear() {
        return invoiceYear;
    }

    public void setInvoiceYear(Integer invoiceYear) {
        this.invoiceYear = invoiceYear;
    }

    public BigDecimal getKilowattHour() {
        return kilowattHour;
    }

    public void setKilowattHour(BigDecimal kilowattHour) {
        this.kilowattHour = kilowattHour;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Boolean getWithOutVAT() {
        return withOutVAT;
    }

    public void setWithOutVAT(Boolean withOutVAT) {
        this.withOutVAT = withOutVAT;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}