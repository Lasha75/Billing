package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum ShowingPersonStatus implements EnumClass<String> {

    OWNER("OWNER"),
    ENTRUSTED("ENTRUSTED"),
    OBLIGING("OBLIGING");

    private String id;

    ShowingPersonStatus(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static ShowingPersonStatus fromId(String id) {
        for (ShowingPersonStatus at : ShowingPersonStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}