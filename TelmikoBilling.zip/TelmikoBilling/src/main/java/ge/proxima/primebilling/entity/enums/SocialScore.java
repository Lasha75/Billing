package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum SocialScore implements EnumClass<String> {

    X7000("A"),
    X15000("B");

    private String id;

    SocialScore(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static SocialScore fromId(String id) {
        for (SocialScore at : SocialScore.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}