package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum StatusType implements EnumClass<String> {

    CUSTOMER("CUSTOMER"),
    CONTRACT("CONTRACT"),
    METER("METER"),
    HATCH("HATCH"),
    TARIFF("TARIFF"),
    BLOCK("BLOCK"),
    ROUTE("ROUTE"),
    BENEFICIARYINFO("BENEFICIARYINFO"),
    SUPPLYCONTRACT("SUPPLYCONTRACT"),
    COURT("COURT");

    private String id;

    StatusType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static StatusType fromId(String id) {
        for (StatusType at : StatusType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}