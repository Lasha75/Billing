package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum SubsidyImportFailLogType implements EnumClass<String> {

    NOT_FOUND("NOT_FOUND"),
    WRONG_CATEGORY("WRONG_CATEGORY"),
    CUSTOMER_NOT_ACTIVE("CUSTOMER_NOT_ACTIVE"),
    ZERO_AMOUNT("ZERO_AMOUNT"),
    MANUAL_UPDATE_TYPE("MANUAL_UPDATE_TYPE"),
    SCHEDULE_NOT_FOUND("SCHEDULE_NOT_FOUND"),
    OTHER("OTHER");

    private String id;

    SubsidyImportFailLogType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static SubsidyImportFailLogType fromId(String id) {
        for (SubsidyImportFailLogType at : SubsidyImportFailLogType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}