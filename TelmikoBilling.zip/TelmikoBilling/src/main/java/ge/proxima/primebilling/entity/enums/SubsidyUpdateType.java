package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum SubsidyUpdateType implements EnumClass<String> {

    MANUAL("MANUAL"),
    AUTOMATIC("AUTOMATIC");

    private String id;

    SubsidyUpdateType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static SubsidyUpdateType fromId(String id) {
        for (SubsidyUpdateType at : SubsidyUpdateType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}