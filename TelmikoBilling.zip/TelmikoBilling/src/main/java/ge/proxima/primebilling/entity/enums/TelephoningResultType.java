package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum TelephoningResultType implements EnumClass<String> {

    AGREED("AGREED"),
    NOT_AGREED("NOT_AGREED"),
    DONT_ANSWERS("DONT_ANSWERS"),
    NO_NUMBER("NO_NUMBER"),
    OTHER("OTHER");

    private String id;

    TelephoningResultType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static TelephoningResultType fromId(String id) {
        for (TelephoningResultType at : TelephoningResultType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}