package ge.proxima.primebilling.entity.enums;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum TransactionCorrectionType implements EnumClass<String> {

    TARIFF("TARIFF"),
    COEFFICIENT("COEFFICIENT"),
    COUNTER_SPEED_ERROR("COUNTER_SPEED_ERROR"),
    CONTROL_READING("CONTROL_READING"),
    COUNTER_INSTALL_UNINSTALL("COUNTER_INSTALL_UNINSTALL"),
    READING_CORRECTION("READING_CORRECTION"),
    ADDITIONAL_ACCRUAL("ADDITIONAL_ACCRUAL"),
    AVERAGE_MONTHLY_ACCRUAL("AVERAGE_MONTHLY_ACCRUAL"),
    ACT_OR_VOUCHER("ACT_OR_VOUCHER"),
    DEBT_TRANSFER("DEBT_TRANSFER"),
    DEBT_CANCELATION("DEBT_CANCELATION"),
    AVERAGE("AVERAGE"),
    COMMUTATION("COMMUTATION");

    private String id;

    TransactionCorrectionType(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static TransactionCorrectionType fromId(String id) {
        for (TransactionCorrectionType at : TransactionCorrectionType.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}