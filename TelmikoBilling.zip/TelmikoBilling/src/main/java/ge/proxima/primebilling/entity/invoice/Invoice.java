package ge.proxima.primebilling.entity.invoice;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.setup.CustomerAddress;
import ge.proxima.primebilling.entity.enums.InvoiceType;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_INVOICE", indexes = {
        @Index(name = "IDX_INVOICE_CUSTOMER_ID", columnList = "CODE", unique = true),
        @Index(name = "IDX_INVOICE_STATUS_ID", columnList = "STATUS_ID"),
        @Index(name = "IDX_INVOICE_PARENT_INVOICE_ID", columnList = "PARENT_INVOICE_ID")
})
@Entity(name = "prx_Invoice")
public class Invoice {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @Column(name = "INVOICE_DATE")
    @Temporal(TemporalType.DATE)
    private Date invoiceDate;

    @JoinColumn(name = "CUSTOMER_ADDRESS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerAddress customerAddress;

    @Column(name = "CORRECTION_DATE")
    @Temporal(TemporalType.DATE)
    private Date correctionDate;

    @Column(name = "CORRECTED_INVOICE_FULL_AMOUNT", precision = 19, scale = 2)
    private BigDecimal correctedInvoiceAmount;

    @JoinColumn(name = "STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private InvoiceStatus status;

    @Column(name = "CORRECTED_INVOICE_NUMBER")
    private String correctedInvoiceNumber;

    @JoinColumn(name = "PARENT_INVOICE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Invoice parentInvoice;

    @OneToMany(mappedBy = "invoice")
    private List<InvoiceLine> invoiceLines;

    @Column(name = "IDENTIFICATION_CODE", length = 150)
    private String identificationCode;

    @Column(name = "OPERATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date operationDate;

    @NotNull
    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @NotNull
    @Column(name = "CODE", nullable = false, length = 90)
    private String code;

    @Column(name = "NAME")
    private String name;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "TYPE_")
    private String type;

    @Column(name = "INVOICE_SERIES")
    private String invoiceSeries;

    @Column(name = "INVOICE_NUMBER")
    private String invoiceNumber;

    @Column(name = "INVOICE_ID")
    private Long invoiceId;

    @Column(name = "CORRECTED_INVOICE_AMOUNT")
    private String correctedInvoiceSeries;

    @Column(name = "CORRECTED_ID")
    private Long correctedId;

    public void setCorrectedId(Long correctedId) {
        this.correctedId = correctedId;
    }

    public Long getCorrectedId() {
        return correctedId;
    }

    public void setCustomerAddress(CustomerAddress customerAddress) {
        this.customerAddress = customerAddress;
    }

    public CustomerAddress getCustomerAddress() {
        return customerAddress;
    }

    public BigDecimal getCorrectedInvoiceAmount() {
        return correctedInvoiceAmount;
    }

    public void setCorrectedInvoiceAmount(BigDecimal correctedInvoiceAmount) {
        this.correctedInvoiceAmount = correctedInvoiceAmount;
    }

    public Date getCorrectionDate() {
        return correctionDate;
    }

    public void setCorrectionDate(Date correctionDate) {
        this.correctionDate = correctionDate;
    }

    public Invoice getParentInvoice() {
        return parentInvoice;
    }

    public void setParentInvoice(Invoice parentInvoice) {
        this.parentInvoice = parentInvoice;
    }

    public String getIdentificationCode() {
        return identificationCode;
    }

    public void setIdentificationCode(String identificationCode) {
        this.identificationCode = identificationCode;
    }

    public InvoiceStatus getStatus() {
        return status;
    }

    public void setStatus(InvoiceStatus status) {
        this.status = status;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public List<InvoiceLine> getInvoiceLines() {
        return invoiceLines;
    }

    public void setInvoiceLines(List<InvoiceLine> invoiceLines) {
        this.invoiceLines = invoiceLines;
    }

    public String getCorrectedInvoiceNumber() {
        return correctedInvoiceNumber;
    }

    public void setCorrectedInvoiceNumber(String correctedInvoiceNumber) {
        this.correctedInvoiceNumber = correctedInvoiceNumber;
    }

    public String getCorrectedInvoiceSeries() {
        return correctedInvoiceSeries;
    }

    public void setCorrectedInvoiceSeries(String correctedInvoiceSeries) {
        this.correctedInvoiceSeries = correctedInvoiceSeries;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public String getInvoiceSeries() {
        return invoiceSeries;
    }

    public void setInvoiceSeries(String invoiceSeries) {
        this.invoiceSeries = invoiceSeries;
    }

    public InvoiceType getType() {
        return type == null ? null : InvoiceType.fromId(type);
    }

    public void setType(InvoiceType type) {
        this.type = type == null ? null : type.getId();
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"code"})
    public String getInstanceName() {
        return String.format("%s", code);
    }

    @PostUpdate
    public void postUpdate() {
//        if (getDeletedDate() != null) {
//            InvoiceService invoiceService = AppBeans.getBean(InvoiceService.class);
//            BaseInfo response = invoiceService.updateTransactionsAfterInvoiceRemoval(getId());
//            if (!response.isSuccess()) throw new RuntimeException(response.getMessage());
//        }
    }
}