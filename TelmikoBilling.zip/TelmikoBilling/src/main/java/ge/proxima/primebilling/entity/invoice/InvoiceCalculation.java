package ge.proxima.primebilling.entity.invoice;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.InvoiceType;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_InvoiceCalculation")
public class InvoiceCalculation {
    @InstanceName
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    @JmixProperty(mandatory = true)
    @NotNull
    private Customer customer;

    private String type;

    @Temporal(TemporalType.DATE)
    private Date invoiceStartDate;

    @Temporal(TemporalType.DATE)
    private Date invoiceEndDate;

    private BigDecimal kilowattHour;

    private BigDecimal amount;

    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Temporal(TemporalType.DATE)
    private Date endDate;

    public InvoiceType getType() {
        return type == null ? null : InvoiceType.fromId(type);
    }

    public void setType(InvoiceType type) {
        this.type = type == null ? null : type.getId();
    }

    public void setInvoiceStartDate(Date invoiceStartDate) {
        this.invoiceStartDate = invoiceStartDate;
    }

    public Date getInvoiceStartDate() {
        return invoiceStartDate;
    }

    public Date getInvoiceEndDate() {
        return invoiceEndDate;
    }

    public void setInvoiceEndDate(Date invoiceEndDate) {
        this.invoiceEndDate = invoiceEndDate;
    }

    public BigDecimal getKilowattHour() {
        return kilowattHour;
    }

    public void setKilowattHour(BigDecimal kilowattHour) {
        this.kilowattHour = kilowattHour;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}