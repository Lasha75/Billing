package ge.proxima.primebilling.entity.report.add26;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.setup.CustomerAddress;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_ADD26", indexes = {
        @Index(name = "IDX_PRX_ADD26_CUSTOMER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_PRX_ADD26_TYPE", columnList = "TYPE_ID")
})
@Entity(name = "prx_Add26")
public class Add26 {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "ACCOUNT_NUM")
    private String accountNum;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @JoinColumn(name = "ADDRESS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerAddress address;

    @Column(name = "START_BALANCE", precision = 19, scale = 2)
    private BigDecimal startBalance;

    @Column(name = "TRANS_DATE")
    @Temporal(TemporalType.DATE)
    private Date transDate;

    @Column(name = "ENTER_DATE")
    @Temporal(TemporalType.DATE)
    private Date enterDate;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "KILOWATT", precision = 19, scale = 2)
    private BigDecimal kilowatt;

    @Column(name = "END_BALANCE", precision = 19, scale = 2)
    private BigDecimal endBalance;

    @JoinColumn(name = "TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination type;

    @Column(name = "ITEM_NUM")
    private String itemNum;

    @Column(name = "PERSNAME")
    private String persname;

    @Column(name = "ACCRUAL_REMOVAL")
    private Boolean accrualRemoval;

    @Column(name = "ACCRUAL_CORRECTION")
    private Boolean accrualCorrection;

    @Column(name = "ADD_")
    private String add;

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public Boolean getAccrualCorrection() {
        return accrualCorrection;
    }

    public void setAccrualCorrection(Boolean accrualCorrection) {
        this.accrualCorrection = accrualCorrection;
    }

    public Boolean getAccrualRemoval() {
        return accrualRemoval;
    }

    public void setAccrualRemoval(Boolean accrualRemoval) {
        this.accrualRemoval = accrualRemoval;
    }

    public String getPersname() {
        return persname;
    }

    public void setPersname(String persname) {
        this.persname = persname;
    }

    public String getItemNum() {
        return itemNum;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public TransactionTypeCombination getType() {
        return type;
    }

    public void setType(TransactionTypeCombination type) {
        this.type = type;
    }

    public BigDecimal getEndBalance() {
        return endBalance;
    }

    public void setEndBalance(BigDecimal endBalance) {
        this.endBalance = endBalance;
    }

    public BigDecimal getKilowatt() {
        return kilowatt;
    }

    public void setKilowatt(BigDecimal kilowatt) {
        this.kilowatt = kilowatt;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Date getEnterDate() {
        return enterDate;
    }

    public void setEnterDate(Date enterDate) {
        this.enterDate = enterDate;
    }

    public Date getTransDate() {
        return transDate;
    }

    public void setTransDate(Date transDate) {
        this.transDate = transDate;
    }

    public BigDecimal getStartBalance() {
        return startBalance;
    }

    public void setStartBalance(BigDecimal startBalance) {
        this.startBalance = startBalance;
    }

    public void setAddress(CustomerAddress address) {
        this.address = address;
    }

    public CustomerAddress getAddress() {
        return address;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}