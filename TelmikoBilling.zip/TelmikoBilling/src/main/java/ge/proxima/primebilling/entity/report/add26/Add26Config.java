package ge.proxima.primebilling.entity.report.add26;

import ge.proxima.primebilling.entity.enums.Add28Group;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_ADD26_CONFIG", indexes = {
        @Index(name = "IDX_PRX_ADD26_CONFIG_TYPE", columnList = "TYPE_ID")
})
@Entity(name = "prx_Add26Config")
public class Add26Config {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination type;

    @Column(name = "ACCRUAL_CORRECTION")
    private Boolean accrualCorrection;

    @Column(name = "ACCRUAL_REMOVAL")
    private Boolean accrualRemoval;

    @Column(name = "ADD26")
    private Boolean add26;

    @Column(name = "ADD28")
    private Boolean add28;

    @Column(name = "CIRCULAR")
    private Boolean circular;

    @Column(name = "NONCIRCULAR")
    private Boolean noncircular;

    @Column(name = "GROUP_")
    private String group;

    public Add28Group getGroup() {
        return group == null ? null : Add28Group.fromId(group);
    }

    public void setGroup(Add28Group group) {
        this.group = group == null ? null : group.getId();
    }

    public Boolean getNoncircular() {
        return noncircular;
    }

    public void setNoncircular(Boolean noncircular) {
        this.noncircular = noncircular;
    }

    public Boolean getCircular() {
        return circular;
    }

    public void setCircular(Boolean circular) {
        this.circular = circular;
    }

    public Boolean getAdd28() {
        return add28;
    }

    public void setAdd28(Boolean add28) {
        this.add28 = add28;
    }

    public Boolean getAdd26() {
        return add26;
    }

    public void setAdd26(Boolean add26) {
        this.add26 = add26;
    }

    public Boolean getAccrualRemoval() {
        return accrualRemoval;
    }

    public void setAccrualRemoval(Boolean accrualRemoval) {
        this.accrualRemoval = accrualRemoval;
    }

    public Boolean getAccrualCorrection() {
        return accrualCorrection;
    }

    public void setAccrualCorrection(Boolean accrualCorrection) {
        this.accrualCorrection = accrualCorrection;
    }

    public TransactionTypeCombination getType() {
        return type;
    }

    public void setType(TransactionTypeCombination type) {
        this.type = type;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}