package ge.proxima.primebilling.entity.report.drs;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_DRS_GROUP")
@Entity(name = "prx_DrsGroup")
public class DrsGroup {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @InstanceName
    @Column(name = "NAME")
    private String name;

    @Column(name = "TOTAL_AMOUNT_GROUP")
    private Boolean totalAmountGroup;

    @Column(name = "CASH_INCOME_GROUP")
    private Boolean cashIncomeGroup;

    public Boolean getCashIncomeGroup() {
        return cashIncomeGroup;
    }

    public void setCashIncomeGroup(Boolean cashIncomeGroup) {
        this.cashIncomeGroup = cashIncomeGroup;
    }

    public Boolean getTotalAmountGroup() {
        return totalAmountGroup;
    }

    public void setTotalAmountGroup(Boolean totalAmountGroup) {
        this.totalAmountGroup = totalAmountGroup;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}