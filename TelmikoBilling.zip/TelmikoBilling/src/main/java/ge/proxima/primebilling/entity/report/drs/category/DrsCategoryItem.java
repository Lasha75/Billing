package ge.proxima.primebilling.entity.report.drs.category;

import ge.proxima.primebilling.entity.customer.CustomerCategory;
import io.jmix.core.DeletePolicy;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_DRS_CATEGORY_ITEM", indexes = {
        @Index(name = "IDX_PRXDRSCATEGORYITE_CATEGORY", columnList = "CATEGORY_ID"),
        @Index(name = "IDX_PRXDRSCATEGORY_DRSCATEGORY", columnList = "DRS_CATEGORY_ID")
})
@Entity(name = "prx_DrsCategoryItem")
public class DrsCategoryItem {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory category;

    @OnDeleteInverse(DeletePolicy.CASCADE)
    @JoinColumn(name = "DRS_CATEGORY_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private DrsCategory drsCategory;

    public DrsCategory getDrsCategory() {
        return drsCategory;
    }

    public void setDrsCategory(DrsCategory drsCategory) {
        this.drsCategory = drsCategory;
    }

    public CustomerCategory getCategory() {
        return category;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}