package ge.proxima.primebilling.entity.report.drs.report;

import ge.proxima.primebilling.entity.report.drs.DrsGroup;
import ge.proxima.primebilling.entity.report.drs.category.DrsCategory;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_DRS_REPORT", indexes = {
        @Index(name = "IDX_PRX_DRS_REPORT_GROUP", columnList = "GROUP_ID"),
        @Index(name = "IDX_PRX_DRS_REPORT_CATEGORY", columnList = "CATEGORY_ID")
})
@Entity(name = "prx_DrsReport")
public class DrsReport {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "GROUP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DrsGroup group;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private DrsCategory category;

    @JmixProperty
    @Transient
    private BigDecimal sum;

    @JmixProperty
    @Transient
    private BigDecimal column0 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column1 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column2 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column3 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column4 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column5 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column6 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column7 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column8 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column9 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column10 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column11 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column12 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column13 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column14 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column15 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column16 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column17 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column18 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column19 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column20 = BigDecimal.ZERO;

    @JmixProperty
    @Transient
    private BigDecimal column21 = BigDecimal.ZERO;

    public BigDecimal getSum() {
        return sum;
    }

    public void setSum(BigDecimal sum) {
        this.sum = sum;
    }

    public void updateSum() {
        sum = column0.add(column1).add(column2).add(column3).add(column4).add(column5).add(column6).add(column7).add(column8).add(column9).add(column10)
                .add(column11).add(column12).add(column13).add(column14).add(column15).add(column16).add(column17).add(column18).add(column19).add(column20).add(column21);
    }

    public DrsCategory getCategory() {
        return category;
    }

    public void setCategory(DrsCategory category) {
        this.category = category;
    }

    public DrsGroup getGroup() {
        return group;
    }

    public void setGroup(DrsGroup group) {
        this.group = group;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public BigDecimal getColumn0() {
        return column0;
    }

    public void setColumn0(BigDecimal column0) {
        this.column0 = column0;
    }

    public BigDecimal getColumn1() {
        return column1;
    }

    public void setColumn1(BigDecimal column1) {
        this.column1 = column1;
    }

    public BigDecimal getColumn2() {
        return column2;
    }

    public void setColumn2(BigDecimal column2) {
        this.column2 = column2;
    }

    public BigDecimal getColumn3() {
        return column3;
    }

    public void setColumn3(BigDecimal column3) {
        this.column3 = column3;
    }

    public BigDecimal getColumn4() {
        return column4;
    }

    public void setColumn4(BigDecimal column4) {
        this.column4 = column4;
    }

    public BigDecimal getColumn5() {
        return column5;
    }

    public void setColumn5(BigDecimal column5) {
        this.column5 = column5;
    }

    public BigDecimal getColumn6() {
        return column6;
    }

    public void setColumn6(BigDecimal column6) {
        this.column6 = column6;
    }

    public BigDecimal getColumn7() {
        return column7;
    }

    public void setColumn7(BigDecimal column7) {
        this.column7 = column7;
    }

    public BigDecimal getColumn8() {
        return column8;
    }

    public void setColumn8(BigDecimal column8) {
        this.column8 = column8;
    }

    public BigDecimal getColumn9() {
        return column9;
    }

    public void setColumn9(BigDecimal column9) {
        this.column9 = column9;
    }

    public BigDecimal getColumn10() {
        return column10;
    }

    public void setColumn10(BigDecimal column10) {
        this.column10 = column10;
    }

    public BigDecimal getColumn11() {
        return column11;
    }

    public void setColumn11(BigDecimal column11) {
        this.column11 = column11;
    }

    public BigDecimal getColumn12() {
        return column12;
    }

    public void setColumn12(BigDecimal column12) {
        this.column12 = column12;
    }

    public BigDecimal getColumn13() {
        return column13;
    }

    public void setColumn13(BigDecimal column13) {
        this.column13 = column13;
    }

    public BigDecimal getColumn14() {
        return column14;
    }

    public void setColumn14(BigDecimal column14) {
        this.column14 = column14;
    }

    public BigDecimal getColumn15() {
        return column15;
    }

    public void setColumn15(BigDecimal column15) {
        this.column15 = column15;
    }

    public BigDecimal getColumn16() {
        return column16;
    }

    public void setColumn16(BigDecimal column16) {
        this.column16 = column16;
    }

    public BigDecimal getColumn17() {
        return column17;
    }

    public void setColumn17(BigDecimal column17) {
        this.column17 = column17;
    }

    public BigDecimal getColumn18() {
        return column18;
    }

    public void setColumn18(BigDecimal column18) {
        this.column18 = column18;
    }

    public BigDecimal getColumn19() {
        return column19;
    }

    public void setColumn19(BigDecimal column19) {
        this.column19 = column19;
    }

    public BigDecimal getColumn20() {
        return column20;
    }

    public void setColumn20(BigDecimal column20) {
        this.column20 = column20;
    }

    public BigDecimal getColumn21() {
        return column21;
    }

    public void setColumn21(BigDecimal column21) {
        this.column21 = column21;
    }

    public void setValue(String method, BigDecimal value) throws Exception {
        this.getClass().getMethod(method, BigDecimal.class).invoke(this, value);
    }
}