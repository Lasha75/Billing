package ge.proxima.primebilling.entity.restructurization;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.ShowingPersonStatus;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_DebtRestructurisation")
public class DebtRestructurisation {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private String showingPersonStatus;

    private BigDecimal portionAmount;

    private BigDecimal amount;

    private BigDecimal initialAmount;

    private Integer monthCount;

    @Temporal(TemporalType.DATE)
    private Date initialPaymentDate;

    @Temporal(TemporalType.DATE)
    private Date nextPortionPaymentDate;

    private Customer customer;

    public Date getNextPortionPaymentDate() {
        return nextPortionPaymentDate;
    }

    public void setNextPortionPaymentDate(Date nextPortionPaymentDate) {
        this.nextPortionPaymentDate = nextPortionPaymentDate;
    }

    public BigDecimal getPortionAmount() {
        return portionAmount;
    }

    public void setPortionAmount(BigDecimal portionAmount) {
        this.portionAmount = portionAmount;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getInitialPaymentDate() {
        return initialPaymentDate;
    }

    public void setInitialPaymentDate(Date initialPaymentDate) {
        this.initialPaymentDate = initialPaymentDate;
    }

    public Integer getMonthCount() {
        return monthCount;
    }

    public void setMonthCount(Integer monthCount) {
        this.monthCount = monthCount;
    }

    public BigDecimal getInitialAmount() {
        return initialAmount;
    }

    public void setInitialAmount(BigDecimal initialAmount) {
        this.initialAmount = initialAmount;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public ShowingPersonStatus getShowingPersonStatus() {
        return showingPersonStatus == null ? null : ShowingPersonStatus.fromId(showingPersonStatus);
    }

    public void setShowingPersonStatus(ShowingPersonStatus showingPersonStatus) {
        this.showingPersonStatus = showingPersonStatus == null ? null : showingPersonStatus.getId();
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"amount", "monthCount"})
    public String getInstanceName() {
        return String.format("%s %s", amount, monthCount);
    }
}