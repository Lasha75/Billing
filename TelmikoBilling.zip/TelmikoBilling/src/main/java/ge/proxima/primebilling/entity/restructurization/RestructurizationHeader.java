package ge.proxima.primebilling.entity.restructurization;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.customer.CustomerContract;
import ge.proxima.primebilling.entity.enums.ApportioningStatus;
import ge.proxima.primebilling.entity.enums.DocumentStatus;
import ge.proxima.primebilling.entity.enums.ShowingPersonStatus;
import ge.proxima.primebilling.entity.reftables.BusinessCenter;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.numerator.NumeratorService;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_RESTRUCTURIZATION_HEADER", indexes = {
        @Index(name = "IDX_RESTRUCTURIZATIONHEADER", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_RESTRUCTURIZATIONHEADER", columnList = "BUSINESS_CENTER_ID"),
        @Index(name = "IDX_RESTRUCTURIZATIONHEADER", columnList = "CONTRACT_ID")
})
@Entity(name = "prx_RestructurizationHeader")
public class RestructurizationHeader implements BaseUuidEntity {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @NotNull
    @Column(name = "NUMBER_", nullable = false)
    private String number;

    @Column(name = "FIRST_PAYMENT", precision = 19, scale = 2)
    private BigDecimal firstPayment;

    @Column(name = "MESSAGE_SENT_DATE")
    @Temporal(TemporalType.DATE)
    private Date messageSentDate;

    @Column(name = "TERM")
    @Temporal(TemporalType.DATE)
    private Date term;

    @OneToMany(mappedBy = "restructurizationHeader")
    private List<RestructurizationLine> lines;

    @NotNull
    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @Column(name = "CUSTOMER_NAME")
    private String customerName;

    @Column(name = "SHOWING_PERSON_STATUS")
    private String showingPersonStatus;

    @JoinColumn(name = "CONSUMER_SECTOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory consumerSector;

    @JoinColumn(name = "BUSINESS_CENTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private BusinessCenter businessCenter;

    @Column(name = "DOCUMENT_NUMBER")
    private String documentNumber;

    @Column(name = "APPORTIONED_AMOUNT", precision = 19, scale = 2)
    private BigDecimal apportionedAmount;

    @Column(name = "NOTE")
    private String note;

    @JoinColumn(name = "CONTRACT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContract contract;

    @Column(name = "APPORTIONMENT_DATE")
    @Temporal(TemporalType.DATE)
    private Date apportionmentDate;

    @Column(name = "APPORTIONING_STATUS")
    private String apportioningStatus;

    @Column(name = "DOCUMENT_STATUS")
    private String documentStatus;

    @JmixProperty
    @Transient
    private Integer monthCount;

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Integer getMonthCount() {
        return lines == null ? 0 : lines.size();
    }

    public void setMonthCount(Integer monthCount) {

    }

    public BigDecimal getFirstPayment() {
        return firstPayment;
    }

    public void setFirstPayment(BigDecimal firstPayment) {
        this.firstPayment = firstPayment;
    }

    public Date getTerm() {
        return term;
    }

    public void setTerm(Date term) {
        this.term = term;
    }

    public Date getMessageSentDate() {
        return messageSentDate;
    }

    public void setMessageSentDate(Date messageSentDate) {
        this.messageSentDate = messageSentDate;
    }

    public List<RestructurizationLine> getLines() {
        return lines;
    }

    public void setLines(List<RestructurizationLine> lines) {
        this.lines = lines;
    }

    public void setConsumerSector(CustomerCategory consumerSector) {
        this.consumerSector = consumerSector;
    }

    public CustomerCategory getConsumerSector() {
        return consumerSector;
    }

    public DocumentStatus getDocumentStatus() {
        return documentStatus == null ? null : DocumentStatus.fromId(documentStatus);
    }

    public void setDocumentStatus(DocumentStatus documentStatus) {
        this.documentStatus = documentStatus == null ? null : documentStatus.getId();
    }

    public ApportioningStatus getApportioningStatus() {
        return apportioningStatus == null ? null : ApportioningStatus.fromId(apportioningStatus);
    }

    public void setApportioningStatus(ApportioningStatus apportioningStatus) {
        this.apportioningStatus = apportioningStatus == null ? null : apportioningStatus.getId();
    }

    public Date getApportionmentDate() {
        return apportionmentDate;
    }

    public void setApportionmentDate(Date apportionmentDate) {
        this.apportionmentDate = apportionmentDate;
    }

    public CustomerContract getContract() {
        return contract;
    }

    public void setContract(CustomerContract contract) {
        this.contract = contract;
    }

    public BigDecimal getApportionedAmount() {
        return apportionedAmount;
    }

    public void setApportionedAmount(BigDecimal apportionedAmount) {
        this.apportionedAmount = apportionedAmount;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public BusinessCenter getBusinessCenter() {
        return businessCenter;
    }

    public void setBusinessCenter(BusinessCenter businessCenter) {
        this.businessCenter = businessCenter;
    }

    public ShowingPersonStatus getShowingPersonStatus() {
        return showingPersonStatus == null ? null : ShowingPersonStatus.fromId(showingPersonStatus);
    }

    public void setShowingPersonStatus(ShowingPersonStatus showingPersonStatus) {
        this.showingPersonStatus = showingPersonStatus == null ? null : showingPersonStatus.getId();
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"apportionedAmount", "apportioningStatus"})
    public String getInstanceName() {
        return String.format("%s %s", apportionedAmount, apportioningStatus);
    }

    @PostConstruct
    public void postConstruct() {
        NumeratorService numeratorService = AppBeans.getBean(NumeratorService.class);
        setNumber(
                numeratorService.getNumSeq(this.getClass())
        );
    }

    @PostLoad
    public void postLoad() {
        monthCount = lines == null ? 0 : lines.size();
    }
}