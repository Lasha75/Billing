package ge.proxima.primebilling.entity.rs;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import java.util.UUID;

@JmixEntity(name = "prx_SellerInvoice")
public class SellerInvoice {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private String status;

    private String recId;

    private String seq_num_s;

    private String was_ref;

    private String f_series;

    private String f_number;

    private String reg_dt;

    private String operation_dt;

    private String s_user_id;

    private String sa_ident_no;

    private String doc_mos_nom_s;

    private String org_name;

    private String notes;

    private String tanxa;

    private String vat;

    private String agree_date;

    private String agree_s_user_id;

    private String ref_date;

    private String ref_s_user_id;

    private String buyer_un_id;

    public String getRecId() {
        return recId;
    }

    public void setRecId(String recId) {
        this.recId = recId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getSeq_num_s() {
        return seq_num_s;
    }

    public void setSeq_num_s(String seq_num_s) {
        this.seq_num_s = seq_num_s;
    }

    public String getWas_ref() {
        return was_ref;
    }

    public void setWas_ref(String was_ref) {
        this.was_ref = was_ref;
    }

    public String getF_series() {
        return f_series;
    }

    public void setF_series(String f_series) {
        this.f_series = f_series;
    }

    public String getF_number() {
        return f_number;
    }

    public void setF_number(String f_number) {
        this.f_number = f_number;
    }

    public String getReg_dt() {
        return reg_dt;
    }

    public void setReg_dt(String reg_dt) {
        this.reg_dt = reg_dt;
    }

    public String getOperation_dt() {
        return operation_dt;
    }

    public void setOperation_dt(String operation_dt) {
        this.operation_dt = operation_dt;
    }

    public String getS_user_id() {
        return s_user_id;
    }

    public void setS_user_id(String s_user_id) {
        this.s_user_id = s_user_id;
    }

    public String getSa_ident_no() {
        return sa_ident_no;
    }

    public void setSa_ident_no(String sa_ident_no) {
        this.sa_ident_no = sa_ident_no;
    }

    public String getDoc_mos_nom_s() {
        return doc_mos_nom_s;
    }

    public void setDoc_mos_nom_s(String doc_mos_nom_s) {
        this.doc_mos_nom_s = doc_mos_nom_s;
    }

    public String getOrg_name() {
        return org_name;
    }

    public void setOrg_name(String org_name) {
        this.org_name = org_name;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getTanxa() {
        return tanxa;
    }

    public void setTanxa(String tanxa) {
        this.tanxa = tanxa;
    }

    public String getVat() {
        return vat;
    }

    public void setVat(String vat) {
        this.vat = vat;
    }

    public String getAgree_date() {
        return agree_date;
    }

    public void setAgree_date(String agree_date) {
        this.agree_date = agree_date;
    }

    public String getAgree_s_user_id() {
        return agree_s_user_id;
    }

    public void setAgree_s_user_id(String agree_s_user_id) {
        this.agree_s_user_id = agree_s_user_id;
    }

    public String getRef_date() {
        return ref_date;
    }

    public void setRef_date(String ref_date) {
        this.ref_date = ref_date;
    }

    public String getRef_s_user_id() {
        return ref_s_user_id;
    }

    public void setRef_s_user_id(String ref_s_user_id) {
        this.ref_s_user_id = ref_s_user_id;
    }

    public String getBuyer_un_id() {
        return buyer_un_id;
    }

    public void setBuyer_un_id(String buyer_un_id) {
        this.buyer_un_id = buyer_un_id;
    }
}