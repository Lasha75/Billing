package ge.proxima.primebilling.entity.settlement;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.customer.CustomerContractType;
import ge.proxima.primebilling.entity.transactions.Transaction;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_SettleTransactionsTmp")
public class SettleTransactionsTmp {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private Integer priority;

    @InstanceName
    private UUID settlementConnectionUUID;

    private Transaction transaction;

    private Customer customer;

    private TransactionTypeCombination combination;

    private UUID accountTypeId;

    private String accountNumber;

    private CustomerContractType accountType;

    private String categoryName;

    private UUID categoryId;

    private CustomerCategory category;

    private Long settleId;

    @Temporal(TemporalType.DATE)
    private Date transDate;

    @Temporal(TemporalType.DATE)
    private Date dueDate;

    private Integer contractTypePriority;

    private UUID transactionId;

    private UUID openTransactionId;

    private Integer transTypePriority;

    private String customerNumber;

    private BigDecimal amount;

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public CustomerCategory getCategory() {
        return category;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public UUID getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(UUID categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public CustomerContractType getAccountType() {
        return accountType;
    }

    public void setAccountType(CustomerContractType accountType) {
        this.accountType = accountType;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public UUID getAccountTypeId() {
        return accountTypeId;
    }

    public void setAccountTypeId(UUID accountTypeId) {
        this.accountTypeId = accountTypeId;
    }

    public TransactionTypeCombination getCombination() {
        return combination;
    }

    public void setCombination(TransactionTypeCombination combination) {
        this.combination = combination;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public UUID getSettlementConnectionUUID() {
        return settlementConnectionUUID;
    }

    public void setSettlementConnectionUUID(UUID settlementConnectionUUID) {
        this.settlementConnectionUUID = settlementConnectionUUID;
    }

    public Long getSettleId() {
        return settleId;
    }

    public void setSettleId(Long settleId) {
        this.settleId = settleId;
    }

    public void setContractTypePriority(Integer contractTypePriority) {
        this.contractTypePriority = contractTypePriority;
    }

    public Integer getContractTypePriority() {
        return contractTypePriority;
    }

    public void setTransTypePriority(Integer transTypePriority) {
        this.transTypePriority = transTypePriority;
    }

    public Integer getTransTypePriority() {
        return transTypePriority;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Date getTransDate() {
        return transDate;
    }

    public void setTransDate(Date transDate) {
        this.transDate = transDate;
    }

    public UUID getOpenTransactionId() {
        return openTransactionId;
    }

    public void setOpenTransactionId(UUID openTransactionId) {
        this.openTransactionId = openTransactionId;
    }

    public UUID getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(UUID transactionId) {
        this.transactionId = transactionId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}