package ge.proxima.primebilling.entity.settlement;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum SettlementTypes implements EnumClass<String> {

    CUSTOMER("Customer"),
    BLOCK("Block"),
    ALL("All");

    private String id;

    SettlementTypes(String value) {
        this.id = value;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static SettlementTypes fromId(String id) {
        for (SettlementTypes at : SettlementTypes.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}