package ge.proxima.primebilling.entity.subsidy;

import ge.proxima.primebilling.entity.SubsidyType;
import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.setup.CustomerAddress;
import ge.proxima.primebilling.java.models.CustSubsidy;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CUSTOMER_MULTI_CHILD_SUBSIDY", indexes = {
        @Index(name = "IDX_CUSTOMERMULTICHILDSUBSIDY", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_CUSTOMERMULTICHILDSUBSIDY", columnList = "BLOCK_ID"),
        @Index(name = "IDX_CUSTOMERMULTICHILDSUBSIDY", columnList = "ADDRESS_ID")
})
@Entity(name = "prx_CustomerMultiChildSubsidy")
public class CustomerMultiChildSubsidy implements CustSubsidy {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "SUBSIDY_TYPE")
    private String subsidyType;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @JoinColumn(name = "ADDRESS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerAddress address;

    @Column(name = "KILOWATT", precision = 19, scale = 2)
    private BigDecimal kilowatt;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "SUBSIDY_AMOUNT", precision = 19, scale = 2)
    private BigDecimal subsidyAmount;

    @Column(name = "DATE_")
    @Temporal(TemporalType.DATE)
    private Date date;

    @Column(name = "LIMIT_", precision = 19, scale = 2)
    private BigDecimal limit;

    @Column(name = "SOCIAL_AMOUNT", precision = 19, scale = 2)
    private BigDecimal socialAmount;

    public void setAddress(CustomerAddress address) {
        this.address = address;
    }

    public CustomerAddress getAddress() {
        return address;
    }

    public BigDecimal getSocialAmount() {
        return socialAmount;
    }

    public void setSocialAmount(BigDecimal socialAmount) {
        this.socialAmount = socialAmount;
    }

    public BigDecimal getLimit() {
        return limit;
    }

    public void setLimit(BigDecimal limit) {
        this.limit = limit;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public BigDecimal getSubsidyAmount() {
        return subsidyAmount;
    }

    public void setSubsidyAmount(BigDecimal subsidyAmount) {
        this.subsidyAmount = subsidyAmount;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getKilowatt() {
        return kilowatt;
    }

    public void setKilowatt(BigDecimal kilowatt) {
        this.kilowatt = kilowatt;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public SubsidyType getSubsidyType() {
        return subsidyType == null ? null : SubsidyType.fromId(subsidyType);
    }

    public void setSubsidyType(SubsidyType subsidyType) {
        this.subsidyType = subsidyType == null ? null : subsidyType.getId();
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}