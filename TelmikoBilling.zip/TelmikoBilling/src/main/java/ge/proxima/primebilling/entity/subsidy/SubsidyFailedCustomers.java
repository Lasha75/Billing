package ge.proxima.primebilling.entity.subsidy;

import ge.proxima.primebilling.entity.SubsidyType;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.SubsidyImportFailLogType;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_SUBSIDY_FAILED_CUSTOMERS", indexes = {
        @Index(name = "IDX_SUBSIDYFAILEDCUSTOMERS", columnList = "CUSTOMER_ID")
})
@Entity(name = "prx_SubsidyFailedCustomers")
public class SubsidyFailedCustomers {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @Column(name = "SUBSIDY_TYPE")
    private String subsidyType;

    @Column(name = "REASON")
    private String reason;

    @Column(name = "DATE_")
    @Temporal(TemporalType.DATE)
    private Date date;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public SubsidyImportFailLogType getReason() {
        return reason == null ? null : SubsidyImportFailLogType.fromId(reason);
    }

    public void setReason(SubsidyImportFailLogType reason) {
        this.reason = reason == null ? null : reason.getId();
    }

    public SubsidyType getSubsidyType() {
        return subsidyType == null ? null : SubsidyType.fromId(subsidyType);
    }

    public void setSubsidyType(SubsidyType subsidyType) {
        this.subsidyType = subsidyType == null ? null : subsidyType.getId();
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}