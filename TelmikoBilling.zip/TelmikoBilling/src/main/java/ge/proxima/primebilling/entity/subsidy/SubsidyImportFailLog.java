package ge.proxima.primebilling.entity.subsidy;

import ge.proxima.primebilling.entity.SubsidyImportType;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.SocialScore;
import ge.proxima.primebilling.entity.enums.SubsidyImportFailLogType;
import ge.proxima.primebilling.entity.system.imports.ExcelImportTemplate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_SUBSIDY_IMPORT_FAIL_LOG", indexes = {
        @Index(name = "IDX_SUBSIDYIMPORTFAILLOG", columnList = "TEMPLATE_ID"),
        @Index(name = "IDX_SUBSIDYIMPORTFAILLOG", columnList = "CUSTOMER_REF_ID")
})
@Entity(name = "prx_SubsidyImportFailLog")
public class SubsidyImportFailLog {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "CUSTOMER")
    private String customer;

    @Column(name = "KEY_", length = 30)
    private String key;

    @Column(name = "DATE_")
    @Temporal(TemporalType.DATE)
    private Date date;

    @Column(name = "REASON")
    private String reason;

    @JoinColumn(name = "TEMPLATE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ExcelImportTemplate template;

    @JoinColumn(name = "CUSTOMER_REF_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customerRef;

    @Column(name = "SUBSIDY_IMPORT_TYPE")
    private String subsidyImportType;

    @Column(name = "SOCIAL_SCORE")
    private String socialScore;

    @Column(name = "SUCCESS")
    private Boolean success = false;

    @Column(name = "MAYORS_LIMIT")
    private BigDecimal mayorsLimit;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public void setMayorsLimit(BigDecimal mayorsLimit) {
        this.mayorsLimit = mayorsLimit;
    }

    public BigDecimal getMayorsLimit() {
        return mayorsLimit;
    }

    public SocialScore getSocialScore() {
        return socialScore == null ? null : SocialScore.fromId(socialScore);
    }

    public void setSocialScore(SocialScore socialScore) {
        this.socialScore = socialScore == null ? null : socialScore.getId();
    }

    public SubsidyImportType getSubsidyImportType() {
        return subsidyImportType == null ? null : SubsidyImportType.fromId(subsidyImportType);
    }

    public void setSubsidyImportType(SubsidyImportType subsidyImportType) {
        this.subsidyImportType = subsidyImportType == null ? null : subsidyImportType.getId();
    }

    public Customer getCustomerRef() {
        return customerRef;
    }

    public void setCustomerRef(Customer customerRef) {
        this.customerRef = customerRef;
    }

    public ExcelImportTemplate getTemplate() {
        return template;
    }

    public void setTemplate(ExcelImportTemplate template) {
        this.template = template;
    }

    public SubsidyImportFailLogType getReason() {
        return reason == null ? null : SubsidyImportFailLogType.fromId(reason);
    }

    public void setReason(SubsidyImportFailLogType reason) {
        this.reason = reason == null ? null : reason.getId();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}