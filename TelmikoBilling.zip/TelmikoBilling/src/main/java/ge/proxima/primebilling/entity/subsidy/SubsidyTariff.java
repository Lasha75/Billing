package ge.proxima.primebilling.entity.subsidy;

import ge.proxima.primebilling.entity.enums.SocialScore;
import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import io.jmix.core.DeletePolicy;
import io.jmix.core.FetchPlan;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDelete;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_SUBSIDY_TARIFF")
@Entity(name = "prx_SubsidyTariff")
public class SubsidyTariff {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @InstanceName
    @Column(name = "NAME")
    private String name;

    @OnDelete(DeletePolicy.CASCADE)
    @Composition
    @OneToMany(mappedBy = "subsidyTariff")
    private List<SubsidyTariffLine> lines;

    public List<SubsidyTariffLine> getLines() {
        return lines;
    }

    public void setLines(List<SubsidyTariffLine> lines) {
        this.lines = lines;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public BigDecimal calcAmount(BigDecimal kilowatt, BigDecimal cycleDayDiff, SocialScore score) {
        if(lines == null) {
            DataManager dataManager = AppBeans.getBean(DataManager.class);
            lines = dataManager.load(SubsidyTariffLine.class)
                    .query("select e from prx_SubsidyTariffLine e where e.subsidyTariff.id = :id")
                    .fetchPlan(FetchPlan.LOCAL)
                    .parameter("id", this.getId())
                    .list();
        }
        BigDecimal stepKwt = BigDecimal.ZERO;
        if(score == SocialScore.X7000 && cycleDayDiff != null && cycleDayDiff.compareTo(BigDecimal.valueOf(30)) == 1){
            stepKwt = kilowatt.divide(cycleDayDiff,2,RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(30));
        }
        else{
            stepKwt = kilowatt;
        }

        for(SubsidyTariffLine line : lines) {

            if(line.getStartKilowatt().compareTo(stepKwt) < 0 && line.getEndKilowatt().compareTo(stepKwt) >= 0) {
                if(line.getIsStatic()) {
                    return line.getValue();
                }
                return kilowatt.multiply(line.getValue());
            } else if(BigDecimal.ZERO.compareTo(stepKwt) == 0 && BigDecimal.ZERO.compareTo(line.getStartKilowatt()) == 0) {
                return kilowatt.multiply(line.getValue());
            }
        }
        return BigDecimal.ZERO;
    }
}