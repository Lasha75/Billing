package ge.proxima.primebilling.entity.subsidy;

import ge.proxima.primebilling.entity.enums.SocialScore;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_SubsidyTransReport")
public class SubsidyTransReport {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private String customerNumber;

    private String customerCode;

    private String customerName;

    @Temporal(TemporalType.DATE)
    private Date date;

    private String category;

    private BigDecimal subsidyAmount;

    private BigDecimal mayorsLimit;

    private BigDecimal gwp;

    private BigDecimal cleanup;

    private BigDecimal electricity;

    private String socialScore;

    private BigDecimal multichildLimit;

    private BigDecimal currentAmount;

    private BigDecimal currentKilowatt;

    private String address;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Date getDate() {
        return date;
    }

    public void setSubsidyAmount(BigDecimal subsidyAmount) {
        this.subsidyAmount = subsidyAmount;
    }

    public BigDecimal getSubsidyAmount() {
        return subsidyAmount;
    }

    public BigDecimal getCurrentKilowatt() {
        return currentKilowatt;
    }

    public void setCurrentKilowatt(BigDecimal currentKilowatt) {
        this.currentKilowatt = currentKilowatt;
    }

    public BigDecimal getCurrentAmount() {
        return currentAmount;
    }

    public void setCurrentAmount(BigDecimal currentAmount) {
        this.currentAmount = currentAmount;
    }

    public BigDecimal getMultichildLimit() {
        return multichildLimit;
    }

    public void setMultichildLimit(BigDecimal multichildLimit) {
        this.multichildLimit = multichildLimit;
    }

    public SocialScore getSocialScore() {
        return socialScore == null ? null : SocialScore.fromId(socialScore);
    }

    public void setSocialScore(SocialScore socialScore) {
        this.socialScore = socialScore == null ? null : socialScore.getId();
    }

    public BigDecimal getElectricity() {
        return electricity;
    }

    public void setElectricity(BigDecimal electricity) {
        this.electricity = electricity;
    }

    public BigDecimal getCleanup() {
        return cleanup;
    }

    public void setCleanup(BigDecimal cleanup) {
        this.cleanup = cleanup;
    }

    public BigDecimal getGwp() {
        return gwp;
    }

    public void setGwp(BigDecimal gwp) {
        this.gwp = gwp;
    }

    public BigDecimal getMayorsLimit() {
        return mayorsLimit;
    }

    public void setMayorsLimit(BigDecimal mayorsLimit) {
        this.mayorsLimit = mayorsLimit;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}