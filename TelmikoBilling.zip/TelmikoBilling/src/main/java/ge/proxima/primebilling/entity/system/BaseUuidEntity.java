package ge.proxima.primebilling.entity.system;

import java.util.UUID;

public interface BaseUuidEntity {
    UUID getId();
}
