package ge.proxima.primebilling.entity.system;

import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CORRECTED_TRANS_TYPE_COMBINATION", indexes = {
        @Index(name = "IDX_CORRECTEDTRANSTYPECOMBINATION", columnList = "TYPE_ID"),
        @Index(name = "IDX_CORRECTEDTRANSTYPECOMBINATION", columnList = "PARAMETERS_ID")
})
@Entity(name = "prx_CorrectedTransTypeCombination")
public class CorrectedTransTypeCombination {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination type;

    @Column(name = "YEAR_")
    private Integer year;

    @JoinColumn(name = "PARAMETERS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Parameters parameters;

    public Parameters getParameters() {
        return parameters;
    }

    public void setParameters(Parameters parameters) {
        this.parameters = parameters;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public TransactionTypeCombination getType() {
        return type;
    }

    public void setType(TransactionTypeCombination type) {
        this.type = type;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}