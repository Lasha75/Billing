package ge.proxima.primebilling.entity.system;

import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CORRECTION_TRANS_COMBINATION_TYPE", indexes = {
        @Index(name = "IDX_CORRECTIONTRANSCOMBINATIONTYPE", columnList = "TYPE_ID"),
        @Index(name = "IDX_CORRECTIONTRANSCOMBINATIONTYPE", columnList = "PARAMETERS_ID")
})
@Entity(name = "prx_CorrectionTransCombinationType")
public class CorrectionTransCombinationType {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @NotNull
    @JoinColumn(name = "TYPE_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private TransactionTypeCombination type;

    @NotNull
    @Column(name = "YEAR_", nullable = false)
    private Integer year;

    @JoinColumn(name = "PARAMETERS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Parameters parameters;

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Parameters getParameters() {
        return parameters;
    }

    public void setParameters(Parameters parameters) {
        this.parameters = parameters;
    }

    public TransactionTypeCombination getType() {
        return type;
    }

    public void setType(TransactionTypeCombination type) {
        this.type = type;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}