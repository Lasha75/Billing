package ge.proxima.primebilling.entity.system;

import ge.proxima.primebilling.entity.block.CutoffStatus;
import ge.proxima.primebilling.entity.customer.CustomerContractType;
import ge.proxima.primebilling.entity.customer.setup.DelayStatusChangeCategories;
import ge.proxima.primebilling.entity.customer.setup.OwnerType;
import ge.proxima.primebilling.entity.customer.setup.SupplyContractPenaltyCategories;
import ge.proxima.primebilling.entity.deposit.DepositTransactionTypeCombination;
import ge.proxima.primebilling.entity.invoice.InvoiceStatus;
import ge.proxima.primebilling.entity.invoice.InvoiceTransactionTypeCombination;
import ge.proxima.primebilling.entity.messages.MessageTemplate;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.restructurization.setup.NonStandardRestructurizationConfiguration;
import ge.proxima.primebilling.entity.rs.setup.RsUsersSetup;
import ge.proxima.primebilling.entity.subsidy.SubsidyTariff;
import ge.proxima.primebilling.entity.system.imports.ExcelImportTemplate;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import ge.proxima.primebilling.entity.transactions.transtypes.transactiontype.TransactionType;
import io.jmix.core.DeletePolicy;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDelete;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.Composition;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_PARAMETERS", indexes = {
        @Index(name = "IDX_PARAMETERS", columnList = "CUSTOMER_NUMERATOR_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "COUNTER_NUMERATOR_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "HATCH_NUMERATOR_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CUSTOMER_CONTRANT_NUMERATOR_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "DISTRIBUTION_TRANSACTION_OPERA"),
        @Index(name = "IDX_PARAMETERS", columnList = "DEPOSIT_TRANSACTION_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "ACCURAL_TRANSACTION_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CONTRACT_PENALTY_TRANS_TYPE_COMBINATION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CONTRACT_PENALTY_TRANS_TYPE_SELECTION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CONTRACT_PENALTY_CONTRACT_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CONTRACT_PENALTY_STATUS_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUPPLY_CONTRACT_ACTIVE_STATUS_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "DEPOSIT_COMPLETE_ACCURAL_TYPE_COMBINATION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "DEPOSIT_SUB_CUSTOMER_TYPE_COMBINATION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "INACTIVE_CUSTOMER_STATUS_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUPPLY_CONTRACT_CANCELED_STATUS_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "INVOICE_NUMERATOR_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "INVOICE_STATUS_APPROVED_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "INVOICE_STATUS_TO_BE_CONFIRMED_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CONTRACT_TYPE_TELASI_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CONTRACT_TYPE_DEPOSITE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CONTRACT_TYPE_TELMICO_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CONTRACT_TYPE_PENALTY_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CUSTOMER_CUTOFF_DEFAULT_STATUS_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_EXCEL_TEMPLATE_MULTI_CHILD_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_EXCEL_TEMPLATE7000_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_EXCEL_TEMPLATE15000_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_EXCEL_TEMPLATE_MAYORS_SUBSIDY_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_EXCEL_TEMPLATE_GWP_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_EXCEL_TEMPLATE_CLEANUP_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CUSTOMER_ACTIVE_STATUS_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_SOCIAL_TARIFF_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_SOCIAL_TARIFF_X15000_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_MULTI_CHILD_TARIFF_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_TRANSACTION_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CONSTACT_ACTIVE_STATUS_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_SOCIAL_TRANSACTION_COMBINATION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_MULTI_CHILD_TRANSACTION_COMBINATION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_MAYOR_TRANSACTION_COMBINATION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUBSIDY_CONTRACT_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CIRCULAR_ACCRUAL_ESTIMATE_ACCRUAL_TRANS_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CIRCULAR_ACCRUAL_REAL_ACCRUAL_TRANS_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CIRCULAR_ACCRUAL_CORRECTION_TRANS_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CIRCULAR_ACCRUAL_CORRECTED_TRANS_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CIRCULAR_ACCRUAL_CURRENT_ACCRUAL_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "COURT_ADMINISTRATION_NUMERATOR_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "COURT_STATUS_NEW_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "COURT_STATUS_RETURNED_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "COURT_STATUS_IS_IN_COURT_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "COURT_STATUS_APPEAL_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CIRCULAR_ACCRUAL_SUM_ACCRUAL_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "RESTRUCTURIZATION_NUMERATOR_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "RESTRUCTURIZATION_TRANSACTION_TYPE_COMBINATION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "PAYMENT_TRANSACTION_TYPE_COMBINATION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "RESTRUCTURIZATION_PORTION_PAYMENT_NOTIFICATION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "RESTRUCTURIZATION_PORTION_PAYMENT_DELAY_NOTIF_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "DELAY_ABOLISHED_STATUS_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "COUNTER_INSTALL_TRANS_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "COUNTER_UNINSTALL_TRANS_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "COUNTER_CONTROL_TRANS_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "PRE_COURT_WORK_CASE_ID_NUMERATOR_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "INVOICE_STATUS_LOADED_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "INVOICE_STATUS_DENIED_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "INVOICE_STATUS_TO_BE_LOADED_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_VOUCHER_TRANSACTION_COMBINATION", columnList = "VOUCHER_TRANSACTION_COMBINATION_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_CORRECTION_AKT_TRANSACTION_COMBINATION", columnList = "CORRECTION_AKT_TRANSACTION_COMBINATION_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "BILL_NUMERATOR_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "BILL_PAYMENT_TRANS_TYPE_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_DEPOSIT_WARNING_MESSAGE_TEMPLATE", columnList = "DEPOSIT_WARNING_MESSAGE_TEMPLATE_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_DEPOSIT_REQUEST_MESSAGE_TEMPLATE", columnList = "DEPOSIT_REQUEST_MESSAGE_TEMPLATE_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_DEPOSIT_WARNING_MESSAGE_TEMPLATE_GE", columnList = "DEPOSIT_WARNING_MESSAGE_TEMPLATE_GE_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_DEPOSIT_REQUEST_MESSAGE_TEMPLATE_GE", columnList = "DEPOSIT_REQUEST_MESSAGE_TEMPLATE_GE_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_CHARGE_TYPE", columnList = "CHARGE_TYPE_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_ESTIMATED_TRANSACTION_TYPE", columnList = "ESTIMATED_TRANSACTION_TYPE_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_COUNTER_OFF_TRANS_TYPE", columnList = "COUNTER_OFF_TRANS_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "DEPOSIT_OWNER_TYPE_LEASEHOLDER_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "DEPOSIT_CORRECTION_TRANSACTION_TYPE_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "CONTRACT_INACTIVE_STATUS_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_SUB_CUSTOMER_CHARGE_TYPE", columnList = "SUB_CUSTOMER_CHARGE_TYPE_ID"),
        @Index(name = "IDX_PRXPARAMETER_VOUCHERNUMER", columnList = "VOUCHER_NUMERATOR_ID"),
        @Index(name = "IDX_PRXPARAMETER_OTHERMIDDLEC", columnList = "OTHER_MIDDLE_CHARGE_ID"),
        @Index(name = "IDX_PRXPARAMETER_ADDITIONALCH", columnList = "ADDITIONAL_CHARGE_ID"),
        @Index(name = "IDX_PRXPARAMETER_TELASIBALANC", columnList = "TELASI_BALANCE_POWER_ID"),
        @Index(name = "IDX_PRXPARAMETER_TELASIBALNAC", columnList = "TELASI_BALNACE_REC_ID"),
        @Index(name = "IDX_PARAMETERS", columnList = "SUPPLY_CONTRACT_PENDING_STATUS"),
        @Index(name = "IDX_PRXPARAMETER_BILLPAYMENTT", columnList = "BILL_PAYMENT_TYPE_ID"),
        @Index(name = "IDX_PRXPARAMETER_BILLREQUESTE", columnList = "BILL_REQUESTED_DEPOSIT_ID"),
        @Index(name = "IDX_PRXPARAMETER_BILLRESTRUCT", columnList = "BILL_RESTRUCTURIZATION_TYPE_ID"),
        @Index(name = "IDX_PRXPARAMETER_BILLCREDITME", columnList = "BILL_CREDIT_MEMO_TYPE_ID"),
        @Index(name = "IDX_PRXPARAMETER_CUSTOMERCANC", columnList = "CUSTOMER_CANCELED_STATUS_ID"),
        @Index(name = "IDX_PRXPARAMETERS_MPPOWERTYPE", columnList = "MP_POWER_TYPE_ID"),
        @Index(name = "IDX_PRXPARAMETER_SALDIREBATYP", columnList = "SALDIREBA_TYPE_ID"),
        @Index(name = "IDX_PRXPARAMETER_DEPOSITCREDI", columnList = "DEPOSIT_CREDIT_MEMOTYPE_ID"),
        @Index(name = "IDX_PRXPARAMETER_DEBTINTERNAL", columnList = "DEBT_INTERNAL_ROTATION_ID"),
        @Index(name = "IDX_PRX_PARAMETERS_DEPOSIT_CREADIT_MEMO_IMP", columnList = "DEPOSIT_CREADIT_MEMO_IMP_ID")
})
@Entity(name = "prx_Parameters")
public class Parameters {
    @InstanceName
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @JoinColumn(name = "DEBT_INTERNAL_ROTATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination debtInternalRotation;

    @JoinColumn(name = "DEPOSIT_CREADIT_MEMO_IMP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ExcelImportTemplate depositCreaditMemoImp;

    @JoinColumn(name = "MP_POWER_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination mpPowerType;

    @JoinColumn(name = "SALDIREBA_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination saldirebaType;

    @JoinColumn(name = "BILL_CREDIT_MEMO_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionType billCreditMemoType;

    @JoinColumn(name = "DEPOSIT_CREDIT_MEMOTYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination depositCreditMemotype;

    @JoinColumn(name = "BILL_REQUESTED_DEPOSIT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination billRequestedDeposit;

    @JoinColumn(name = "BILL_RESTRUCTURIZATION_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination billRestructurizationType;

    @JoinColumn(name = "TELASI_BALANCE_EL_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination telasiBalanceEl;

    @JoinColumn(name = "TELASI_BALANCE_OLD_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination telasiBalanceOld;

    @JoinColumn(name = "TELASI_BALNACE_REC_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination telasiBalnaceRec;

    @JoinColumn(name = "TELASI_BALANCE_POWER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination telasiBalancePower;

    @JoinColumn(name = "ADDITIONAL_CHARGE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination additionalCharge;

    @JoinColumn(name = "OTHER_MIDDLE_CHARGE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination otherMiddleCharge;

    @JoinColumn(name = "VOUCHER_NUMERATOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator voucherNumerator;

    @JoinColumn(name = "SUB_CUSTOMER_CHARGE_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination subCustomerChargeType;

    @JoinColumn(name = "ESTIMATED_TRANSACTION_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination estimatedTransactionType;

    @OnDelete(DeletePolicy.CASCADE)
    @JoinColumn(name = "CONTRACT_INACTIVE_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status contractInactiveStatus;

    @JoinColumn(name = "CHARGE_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionType chargeType;

    @Column(name = "MIN_AMOUNT_FOR_CUTOFF", precision = 19, scale = 2)
    private BigDecimal minAmountForCutoff;

    @JoinColumn(name = "INVOICE_STATUS_TO_BE_LOADED_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private InvoiceStatus invoiceStatusToBeLoaded;

    @JoinColumn(name = "INVOICE_STATUS_LOADED_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private InvoiceStatus invoiceStatusLoaded;

    @JoinColumn(name = "INVOICE_STATUS_DENIED_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private InvoiceStatus invoiceStatusDenied;

    @Column(name = "PRE_COURT_WORK_NOTIFY_BEFORE")
    private Integer preCourtWorkNotifyBefore;

    @JoinColumn(name = "PRE_COURT_WORK_CASE_ID_NUMERATOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator preCourtWorkCaseIdNumerator;

    @Column(name = "PRE_COURT_WORK_LIMIT_LEGAL")
    private Integer preCourtWorkLimitLegal;

    @Column(name = "PRE_COURT_WORK_LIMIT_NON_LEGAL")
    private Integer preCourtWorkLimitNonLegal;

    @Column(name = "AUTHORIZATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date authorizationDate;

    @JoinColumn(name = "DELAY_ABOLISHED_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status delayAbolishedStatus;

    @JoinColumn(name = "RESTRUCTURIZATION_TRANSACTION_TYPE_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination restructurizationTransactionTypeCombination;

    @JoinColumn(name = "RESTRUCTURIZATION_PORTION_TRANS_TYPE_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination restructurizationPortionTransTypeCombination;

    @JoinColumn(name = "RESTRUCTURIZATION_DEBT_ABOLISHMENT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination restructurizationDebtAbolishmentTransTypeCombination;

    @JoinColumn(name = "CORRECTION_AKT_TRANSACTION_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination correctionAktTransactionCombination;

    @Column(name = "RESTRUCTURIZATION_PORTION_PAYMENT_DATE_CONTROL")
    private Integer restructurizationPortionPaymentDateControl;

    @JoinColumn(name = "RESTRUCTURIZATION_PORTION_PAYMENT_NOTIFICATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private MessageTemplate restructurizationPortionPaymentNotification;

    @JoinColumn(name = "RESTRUCTURIZATION_PORTION_PAYMENT_DELAY_NOTIF_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private MessageTemplate restructurizationPortionPaymentDelayNotif;

    @JoinColumn(name = "PAYMENT_TRANSACTION_TYPE_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination paymentTransactionTypeCombination;

    @Column(name = "MIN_AMOUNT_FOR_CUTOFF_LEGAL", precision = 19, scale = 2)
    private BigDecimal minAmountForCutoffLegal;

    @JoinColumn(name = "COURT_STATUS_NEW_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status courtStatusNew;

    @JoinColumn(name = "COURT_STATUS_IS_IN_COURT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status courtStatusIsInCourt;

    @JoinColumn(name = "COURT_STATUS_APPEAL_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status courtStatusAppeal;

    @JoinColumn(name = "COURT_STATUS_RETURNED_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status courtStatusReturned;

    @JoinColumn(name = "COURT_ADMINISTRATION_NUMERATOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator courtAdministrationNumerator;

    @JoinColumn(name = "RESTRUCTURIZATION_NUMERATOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator restructurizationNumerator;

    @OnDelete(DeletePolicy.CASCADE)
    @Composition
    @OneToMany(mappedBy = "parameters")
    private List<RsUsersSetup> rsUsersSetup;

    @Column(name = "RS_TIN")
    private String rsTin;

    @Column(name = "DELAY_CANCELLATION_TEXT")
    @Lob
    private String delayCancellationText;

    @OnDelete(DeletePolicy.CASCADE)
    @Composition
    @OneToMany(mappedBy = "parameters")
    private List<SupplyContractPenaltyCategories> supplyContractPenaltyCustomerCatgeories;

    @OnDelete(DeletePolicy.CASCADE)
    @Composition
    @OneToMany(mappedBy = "parameters")
    private List<NonStandardRestructurizationConfiguration> nonStandardRestructurizationConfiguration;

    @OnDelete(DeletePolicy.CASCADE)
    @Composition
    @OneToMany(mappedBy = "parameters")
    private List<DelayStatusChangeCategories> delayStatusChangeCategories;

    @JoinColumn(name = "CUSTOMER_ACTIVE_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status customerActiveStatus;

    @JoinColumn(name = "CUSTOMER_CANCELED_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status customerCanceledStatus;

    @JoinColumn(name = "CUSTOMER_CUTOFF_DEFAULT_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CutoffStatus customerCutoffDefaultStatus;

    @Column(name = "CONTRACT_PENALTY_START_DATE")
    @Temporal(TemporalType.DATE)
    private Date contractPenaltyStartDate;

    @Column(name = "RS_INTEGRATION_SERVICE", length = 350)
    private String rsIntegrationService;

    @JoinColumn(name = "INVOICE_NUMERATOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator invoiceNumerator;

    @OnDelete(DeletePolicy.CASCADE)
    @Composition
    @OneToMany(mappedBy = "parameters")
    private List<InvoiceTransactionTypeCombination> invoiceTransactionTypes;

    @JoinColumn(name = "INVOICE_STATUS_APPROVED_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private InvoiceStatus invoiceStatusConfirmed;

    @JoinColumn(name = "INVOICE_STATUS_TO_BE_CONFIRMED_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private InvoiceStatus invoiceStatusToBeConfirmed;

    @JoinColumn(name = "COUNTER_ACTIVE_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status counterActiveStatus;

    @JoinColumn(name = "CONTRACT_ACTIVE_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status contractActiveStatus;

    @JoinColumn(name = "SUBSIDY_SOCIAL_TRANSACTION_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination subsidySocialTransactionCombination;

    @JoinColumn(name = "SUBSIDY_CONTRACT_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType subsidyContractType;

    @JoinColumn(name = "SUBSIDY_MULTI_CHILD_TRANSACTION_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination subsidyMultiChildTransactionCombination;

    @JoinColumn(name = "SUBSIDY_MAYOR_TRANSACTION_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination subsidyMayorTransactionCombination;

    @JoinColumn(name = "SUPPLY_CONTRACT_CANCELED_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status supplyContractCanceledStatus;

    @Column(name = "SUPPLY_CONTRACT_EMAIL_TEXT")
    @Lob
    private String supplyContractEmailText;

    @Column(name = "SUPPLY_CONTRACT_SMS_TEXT")
    @Lob
    private String supplyContractSMSText;

    @JoinColumn(name = "SUPPLY_CONTRACT_ACTIVE_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status supplyContractActiveStatus;

    @JoinColumn(name = "SUPPLY_CONTRACT_PENDING_STATUS")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status supplyContractPendingStatus;

    @Column(name = "SUPPLY_CONTRACT_EXHAUST_DAYS")
    private Integer supplyContractExhaustDays;

    @JoinColumn(name = "CONTRACT_PENALTY_TRANS_TYPE_SELECTION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination contractPenaltyTransTypeCharge;

    @JoinColumn(name = "CONTRACT_PENALTY_CONTRACT_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType contractPenaltyContractType;

    @JoinColumn(name = "CONTRACT_PENALTY_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status contractPenaltyContractStatus;

    @JoinColumn(name = "CONTRACT_PENALTY_TRANS_TYPE_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination contractPenaltyTransactionType;

    @Column(name = "RESPECTFUL_DAYS")
    private Integer contractPenaltyRespectfulDays;

    @Column(name = "CONTRACT_PENALTY_PERCENTAGE")
    private Double contractPenaltyPercentage;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "CUSTOMER_NUMERATOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator customerNumerator;

    @JoinColumn(name = "CUSTOMER_CONTRANT_NUMERATOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator customerContrantNumerator;

    @JoinColumn(name = "COUNTER_NUMERATOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator counterNumerator;

    @JoinColumn(name = "HATCH_NUMERATOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator hatchNumerator;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "DISTRIBUTION_TRANSACTION_OPERA")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator distributionTransactionOperationNumerator;

    @Column(name = "DEPOSIT_AMOUNT", precision = 19, scale = 2)
    private BigDecimal depositAmount;

    @Column(name = "DEPOSIT_MONTH_NUMBER_FOR_AVERAGE")
    private Integer depositMonthNumberForAverage;

    @Column(name = "DEPOSIT_MONTH_NUM_FOR_AVG_FOR_OVERDUE")
    private Integer depositMonthNumForAvgForOverdue;

    @JoinColumn(name = "DEPOSIT_TRANSACTION_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination depositTransactionType;

    @Composition
    @OnDeleteInverse(DeletePolicy.UNLINK)
    @OnDelete(DeletePolicy.CASCADE)
    @OneToMany(mappedBy = "parameters")
    private List<DepositTransactionTypeCombination> depositTransactionTypeCombinations;

    @OnDelete(DeletePolicy.CASCADE)
    @OneToMany(mappedBy = "parameters")
    private List<CorrectionTransCombinationType> correctionTransTypeCombinations;

    @Column(name = "DEPOSIT_OVERDUE_DELAY")
    private Integer depositOverdueDelay;

    @JoinColumn(name = "DEPOSIT_COMPLETE_ACCURAL_TYPE_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination depositCompleteAccuralTypeCombination;

    @JoinColumn(name = "DEPOSIT_SUB_CUSTOMER_TYPE_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination depositSubCustomerTypeCombination;

    @JoinColumn(name = "DEPOSIT_WARNING_MESSAGE_TEMPLATE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private MessageTemplate depositWarningMessageTemplate;

    @JoinColumn(name = "DEPOSIT_WARNING_MESSAGE_TEMPLATE_GE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private MessageTemplate depositWarningMessageTemplateGE;

    @JoinColumn(name = "DEPOSIT_REQUEST_MESSAGE_TEMPLATE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private MessageTemplate depositRequestMessageTemplate;

    @JoinColumn(name = "DEPOSIT_REQUEST_MESSAGE_TEMPLATE_GE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private MessageTemplate depositRequestMessageTemplateGE;

    @JoinColumn(name = "VOUCHER_TRANSACTION_COMBINATION_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination voucherTransactionCombination;

    @Column(name = "DEPOSIT_DISCONNECTED_MONTH")
    private Integer depositDisconnectedMonth;

    @JoinColumn(name = "DEPOSIT_BANK_GUARANTEE_COMBINATION_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination depositBankGuaranteeCombinationType;

    @Column(name = "BANK_GUARANTEE_TIMEOUT_WEEK")
    private Integer bankGuaranteeTimeoutWeek;

    @JoinColumn(name = "TELMIKO_CONTRACT_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType telmikoContract;

    @JoinColumn(name = "ACCURAL_TRANSACTION_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionType accuralTransactionType;

    @JoinColumn(name = "INACTIVE_CUSTOMER_STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status inactiveCustomerStatus;

    @JoinColumn(name = "CONTRACT_TYPE_TELASI_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType contractTypeTelasi;

    @JoinColumn(name = "CONTRACT_TYPE_DEPOSITE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType contractTypeDeposite;

    @JoinColumn(name = "DEPOSIT_OWNER_TYPE_LEASEHOLDER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private OwnerType depositOwnerTypeLeaseholder;

    @JoinColumn(name = "DEPOSIT_CORRECTION_TRANSACTION_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination depositCorrectionTransactionType;

    @JoinColumn(name = "CONTRACT_TYPE_TELMICO_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType contractTypeTelmico;

    @JoinColumn(name = "CONTRACT_TYPE_PENALTY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType contractTypePenalty;

    @Column(name = "CUTOFF_DATE_ADJUSTMENT")
    private Integer cutoffDateAdjustment;

    @Column(name = "PAYMENT_NOTIFICATION_DATE_ADJUSTMENT")
    private Integer paymentNotificationDateAdjustment;

    @Column(name = "MIN_AMONT_FOR_NOTIFICATIONS", precision = 19, scale = 2)
    private BigDecimal minAmontForNotifications;

    @JoinColumn(name = "SUBSIDY_EXCEL_TEMPLATE_MULTI_CHILD_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ExcelImportTemplate subsidyExcelTemplateMultiChild;

    @JoinColumn(name = "SUBSIDY_EXCEL_TEMPLATE7000_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ExcelImportTemplate subsidyExcelTemplate7000;

    @JoinColumn(name = "SUBSIDY_EXCEL_TEMPLATE15000_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ExcelImportTemplate subsidyExcelTemplate15000;

    @JoinColumn(name = "SUBSIDY_EXCEL_TEMPLATE_MAYORS_SUBSIDY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ExcelImportTemplate subsidyExcelTemplateMayorsSubsidy;

    @JoinColumn(name = "SUBSIDY_EXCEL_TEMPLATE_GWP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ExcelImportTemplate subsidyExcelTemplateGwp;

    @Column(name = "SUBSIDY_EXCEL_TEMPLATE_GWP_AMOUNT", precision = 19, scale = 2)
    private BigDecimal subsidyExcelTemplateGwpAmount;

    @JoinColumn(name = "SUBSIDY_EXCEL_TEMPLATE_CLEANUP_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private ExcelImportTemplate subsidyExcelTemplateCleanup;

    @JoinColumn(name = "SUBSIDY_SOCIAL_SUBSIDY_TARIFF_X7000_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private SubsidyTariff subsidySocialTariffX7000;

    @JoinColumn(name = "SUBSIDY_SOCIAL_SUBSIDY_TARIFF_X15000_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private SubsidyTariff subsidySocialTariffX15000;

    @JoinColumn(name = "SUBSIDY_MULTI_CHILD_SUBSIDY_TARIFF_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private SubsidyTariff subsidyMultiChildTariff;

    @JoinColumn(name = "SUBSIDY_TRANSACTION_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionType subsidyTransactionType;

    @JoinColumn(name = "CIRCULAR_ACCRUAL_ESTIMATE_ACCRUAL_TRANS_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination circularAccrualEstimateAccrualTransType;

    @JoinColumn(name = "CIRCULAR_ACCRUAL_REAL_ACCRUAL_TRANS_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination circularAccrualRealAccrualTransType;

    @JoinColumn(name = "CIRCULAR_ACCRUAL_CORRECTION_TRANS_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination circularAccrualCorrectionTransType;

    @JoinColumn(name = "CIRCULAR_ACCRUAL_CORRECTED_TRANS_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination circularAccrualCorrectedTransType;

    @OnDelete(DeletePolicy.CASCADE)
    @OneToMany(mappedBy = "parameters")
    private List<CorrectedTransTypeCombination> correctedTransTypeCombinations;

    @JoinColumn(name = "CIRCULAR_ACCRUAL_CURRENT_ACCRUAL_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination circularAccrualCurrentAccrualType;

    @JoinColumn(name = "COUNTER_OFF_TRANS_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination counterOffTransType;

    @JoinColumn(name = "CIRCULAR_ACCRUAL_SUM_ACCRUAL_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination circularAccrualSumAccrualType;

    @JoinColumn(name = "COUNTER_INSTALL_TRANS_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination counterInstallTransType;

    @JoinColumn(name = "COUNTER_UNINSTALL_TRANS_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination counterUninstallTransType;

    @JoinColumn(name = "COUNTER_CONTROL_TRANS_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination counterControlTransType;

    @Column(name = "PAYMENT_DELAY_NOTIFICATION_DATE_CONTROL")
    private Integer paymentDelayNotificationDateControl;

    @Column(name = "COUNTER_ROTATION_COEFFICIENT", precision = 19, scale = 2)
    private BigDecimal counterRotationCoefficient;

    @JoinColumn(name = "BILL_NUMERATOR_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Numerator billNumerator;

    @JoinColumn(name = "BILL_PAYMENT_TRANS_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionType billPaymentTransType;

    @JoinColumn(name = "BILL_PAYMENT_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionType billPaymentType;

    @Column(name = "TELMIKO_FOR_CUSTOMERS_TEXT")
    @Lob
    private String telmikoForCustomersText;

    @Column(name = "TELMIKO_ADDRESSES")
    @Lob
    private String telmikoAddresses;

    @Column(name = "TELMIKO_ID", length = 30)
    private String telmikoId;

    @Column(name = "TELMIKO_WEB_PAGE", length = 30)
    private String telmikoWebPage;

    @Column(name = "TELMIKO_EMAIL", length = 30)
    private String telmikoEmail;

    @Column(name = "TELMIKO_CALLCENTER")
    private String telmikoCallcenter;

    @Column(name = "TELMIKO_SUPPLIER_NAME")
    private String telmikoSupplierName;

    @Column(name = "PAYMENT_NOTIFICATION_SMS")
    private Boolean paymentNotificationSms;

    @Column(name = "PAYMENT_NOTIFICATION_EMAIL")
    private Boolean paymentNotificationEmail;

    @Column(name = "WARNING_NOTIFICATION_SMS")
    private Boolean warningNotificationSms;

    @Column(name = "WARNING_NOTIFICATION_EMAIL")
    private Boolean warningNotificationEmail;

    public ExcelImportTemplate getDepositCreaditMemoImp() {
        return depositCreaditMemoImp;
    }

    public void setDepositCreaditMemoImp(ExcelImportTemplate depositCreaditMemoImp) {
        this.depositCreaditMemoImp = depositCreaditMemoImp;
    }

    public TransactionTypeCombination getDebtInternalRotation() {
        return debtInternalRotation;
    }

    public void setDebtInternalRotation(TransactionTypeCombination debtInternalRotation) {
        this.debtInternalRotation = debtInternalRotation;
    }

    public TransactionTypeCombination getDepositCreditMemotype() {
        return depositCreditMemotype;
    }

    public void setDepositCreditMemotype(TransactionTypeCombination depositCreditMemotype) {
        this.depositCreditMemotype = depositCreditMemotype;
    }

    public TransactionTypeCombination getSaldirebaType() {
        return saldirebaType;
    }

    public void setSaldirebaType(TransactionTypeCombination saldirebaType) {
        this.saldirebaType = saldirebaType;
    }

    public TransactionTypeCombination getMpPowerType() {
        return mpPowerType;
    }

    public void setMpPowerType(TransactionTypeCombination mpPowerType) {
        this.mpPowerType = mpPowerType;
    }

    public Boolean getWarningNotificationEmail() {
        return warningNotificationEmail;
    }

    public void setWarningNotificationEmail(Boolean warningNotificationEmail) {
        this.warningNotificationEmail = warningNotificationEmail;
    }

    public Boolean getWarningNotificationSms() {
        return warningNotificationSms;
    }

    public void setWarningNotificationSms(Boolean warningNotificationSms) {
        this.warningNotificationSms = warningNotificationSms;
    }

    public Boolean getPaymentNotificationEmail() {
        return paymentNotificationEmail;
    }

    public void setPaymentNotificationEmail(Boolean paymentNotificationEmail) {
        this.paymentNotificationEmail = paymentNotificationEmail;
    }

    public Boolean getPaymentNotificationSms() {
        return paymentNotificationSms;
    }

    public void setPaymentNotificationSms(Boolean paymentNotificationSms) {
        this.paymentNotificationSms = paymentNotificationSms;
    }

    public Status getCustomerCanceledStatus() {
        return customerCanceledStatus;
    }

    public void setCustomerCanceledStatus(Status customerCanceledStatus) {
        this.customerCanceledStatus = customerCanceledStatus;
    }

    public TransactionType getBillCreditMemoType() {
        return billCreditMemoType;
    }

    public void setBillCreditMemoType(TransactionType billCreditMemoType) {
        this.billCreditMemoType = billCreditMemoType;
    }

    public TransactionTypeCombination getBillRestructurizationType() {
        return billRestructurizationType;
    }

    public void setBillRestructurizationType(TransactionTypeCombination billRestructurizationType) {
        this.billRestructurizationType = billRestructurizationType;
    }

    public TransactionTypeCombination getBillRequestedDeposit() {
        return billRequestedDeposit;
    }

    public void setBillRequestedDeposit(TransactionTypeCombination billRequestedDeposit) {
        this.billRequestedDeposit = billRequestedDeposit;
    }

    public TransactionType getBillPaymentType() {
        return billPaymentType;
    }

    public void setBillPaymentType(TransactionType billPaymentType) {
        this.billPaymentType = billPaymentType;
    }

    public Status getSupplyContractPendingStatus() {
        return supplyContractPendingStatus;
    }

    public void setSupplyContractPendingStatus(Status supplyContractPendingStatus) {
        this.supplyContractPendingStatus = supplyContractPendingStatus;
    }

    public TransactionTypeCombination getTelasiBalancePower() {
        return telasiBalancePower;
    }

    public void setTelasiBalancePower(TransactionTypeCombination telasiBalancePower) {
        this.telasiBalancePower = telasiBalancePower;
    }

    public TransactionTypeCombination getTelasiBalnaceRec() {
        return telasiBalnaceRec;
    }

    public void setTelasiBalnaceRec(TransactionTypeCombination telasiBalnaceRec) {
        this.telasiBalnaceRec = telasiBalnaceRec;
    }

    public TransactionTypeCombination getTelasiBalanceOld() {
        return telasiBalanceOld;
    }

    public void setTelasiBalanceOld(TransactionTypeCombination telasiBalanceOld) {
        this.telasiBalanceOld = telasiBalanceOld;
    }

    public TransactionTypeCombination getTelasiBalanceEl() {
        return telasiBalanceEl;
    }

    public void setTelasiBalanceEl(TransactionTypeCombination telasiBalanceEl) {
        this.telasiBalanceEl = telasiBalanceEl;
    }

    public TransactionTypeCombination getAdditionalCharge() {
        return additionalCharge;
    }

    public void setAdditionalCharge(TransactionTypeCombination additionalCharge) {
        this.additionalCharge = additionalCharge;
    }

    public TransactionTypeCombination getOtherMiddleCharge() {
        return otherMiddleCharge;
    }

    public void setOtherMiddleCharge(TransactionTypeCombination otherMiddleCharge) {
        this.otherMiddleCharge = otherMiddleCharge;
    }

    public Numerator getVoucherNumerator() {
        return voucherNumerator;
    }

    public void setVoucherNumerator(Numerator voucherNumerator) {
        this.voucherNumerator = voucherNumerator;
    }

    public TransactionTypeCombination getSubCustomerChargeType() {
        return subCustomerChargeType;
    }

    public void setSubCustomerChargeType(TransactionTypeCombination subCustomerChargeType) {
        this.subCustomerChargeType = subCustomerChargeType;
    }

    public Status getContractInactiveStatus() {
        return contractInactiveStatus;
    }

    public void setContractInactiveStatus(Status contractInactiveStatus) {
        this.contractInactiveStatus = contractInactiveStatus;
    }

    public TransactionTypeCombination getCounterOffTransType() {
        return counterOffTransType;
    }

    public void setCounterOffTransType(TransactionTypeCombination counterOffTransType) {
        this.counterOffTransType = counterOffTransType;
    }

    public TransactionTypeCombination getEstimatedTransactionType() {
        return estimatedTransactionType;
    }

    public void setEstimatedTransactionType(TransactionTypeCombination estimatedTransactionType) {
        this.estimatedTransactionType = estimatedTransactionType;
    }

    public TransactionType getChargeType() {
        return chargeType;
    }

    public void setChargeType(TransactionType chargeType) {
        this.chargeType = chargeType;
    }

    public TransactionTypeCombination getDepositCorrectionTransactionType() {
        return depositCorrectionTransactionType;
    }

    public void setDepositCorrectionTransactionType(TransactionTypeCombination depositCorrectionTransactionType) {
        this.depositCorrectionTransactionType = depositCorrectionTransactionType;
    }

    public OwnerType getDepositOwnerTypeLeaseholder() {
        return depositOwnerTypeLeaseholder;
    }

    public void setDepositOwnerTypeLeaseholder(OwnerType depositOwnerTypeLeaseholder) {
        this.depositOwnerTypeLeaseholder = depositOwnerTypeLeaseholder;
    }

    public MessageTemplate getDepositRequestMessageTemplateGE() {
        return depositRequestMessageTemplateGE;
    }

    public void setDepositRequestMessageTemplateGE(MessageTemplate depositRequestMessageTemplateGE) {
        this.depositRequestMessageTemplateGE = depositRequestMessageTemplateGE;
    }

    public MessageTemplate getDepositWarningMessageTemplateGE() {
        return depositWarningMessageTemplateGE;
    }

    public void setDepositWarningMessageTemplateGE(MessageTemplate depositWarningMessageTemplateGE) {
        this.depositWarningMessageTemplateGE = depositWarningMessageTemplateGE;
    }

    public MessageTemplate getDepositRequestMessageTemplate() {
        return depositRequestMessageTemplate;
    }

    public void setDepositRequestMessageTemplate(MessageTemplate depositRequestMessageTemplate) {
        this.depositRequestMessageTemplate = depositRequestMessageTemplate;
    }

    public MessageTemplate getDepositWarningMessageTemplate() {
        return depositWarningMessageTemplate;
    }

    public void setDepositWarningMessageTemplate(MessageTemplate depositWarningMessageTemplate) {
        this.depositWarningMessageTemplate = depositWarningMessageTemplate;
    }

    public TransactionType getBillPaymentTransType() {
        return billPaymentTransType;
    }

    public void setBillPaymentTransType(TransactionType billPaymentTransType) {
        this.billPaymentTransType = billPaymentTransType;
    }

    public String getTelmikoSupplierName() {
        return telmikoSupplierName;
    }

    public void setTelmikoSupplierName(String telmikoSupplierName) {
        this.telmikoSupplierName = telmikoSupplierName;
    }

    public String getTelmikoCallcenter() {
        return telmikoCallcenter;
    }

    public void setTelmikoCallcenter(String telmikoCallcenter) {
        this.telmikoCallcenter = telmikoCallcenter;
    }

    public String getTelmikoEmail() {
        return telmikoEmail;
    }

    public void setTelmikoEmail(String telmikoEmail) {
        this.telmikoEmail = telmikoEmail;
    }

    public String getTelmikoWebPage() {
        return telmikoWebPage;
    }

    public void setTelmikoWebPage(String telmikoWebPage) {
        this.telmikoWebPage = telmikoWebPage;
    }

    public String getTelmikoId() {
        return telmikoId;
    }

    public void setTelmikoId(String telmikoId) {
        this.telmikoId = telmikoId;
    }

    public String getTelmikoAddresses() {
        return telmikoAddresses;
    }

    public void setTelmikoAddresses(String telmikoAddresses) {
        this.telmikoAddresses = telmikoAddresses;
    }

    public String getTelmikoForCustomersText() {
        return telmikoForCustomersText;
    }

    public void setTelmikoForCustomersText(String telmikoForCustomersText) {
        this.telmikoForCustomersText = telmikoForCustomersText;
    }

    public Numerator getBillNumerator() {
        return billNumerator;
    }

    public void setBillNumerator(Numerator billNumerator) {
        this.billNumerator = billNumerator;
    }

    public TransactionTypeCombination getCorrectionAktTransactionCombination() {
        return correctionAktTransactionCombination;
    }

    public void setCorrectionAktTransactionCombination(TransactionTypeCombination correctionAktTransactionCombination) {
        this.correctionAktTransactionCombination = correctionAktTransactionCombination;
    }

    public TransactionTypeCombination getVoucherTransactionCombination() {
        return voucherTransactionCombination;
    }

    public void setVoucherTransactionCombination(TransactionTypeCombination voucherTransactionCombination) {
        this.voucherTransactionCombination = voucherTransactionCombination;
    }

    public InvoiceStatus getInvoiceStatusToBeLoaded() {
        return invoiceStatusToBeLoaded;
    }

    public void setInvoiceStatusToBeLoaded(InvoiceStatus invoiceStatusToBeLoaded) {
        this.invoiceStatusToBeLoaded = invoiceStatusToBeLoaded;
    }

    public void setSubsidyMultiChildTariff(SubsidyTariff subsidyMultiChildTariff) {
        this.subsidyMultiChildTariff = subsidyMultiChildTariff;
    }

    public SubsidyTariff getSubsidyMultiChildTariff() {
        return subsidyMultiChildTariff;
    }

    public void setSubsidySocialTariffX15000(SubsidyTariff subsidySocialTariffX15000) {
        this.subsidySocialTariffX15000 = subsidySocialTariffX15000;
    }

    public SubsidyTariff getSubsidySocialTariffX15000() {
        return subsidySocialTariffX15000;
    }

    public void setSubsidySocialTariffX7000(SubsidyTariff subsidySocialTariffX7000) {
        this.subsidySocialTariffX7000 = subsidySocialTariffX7000;
    }

    public SubsidyTariff getSubsidySocialTariffX7000() {
        return subsidySocialTariffX7000;
    }

    public InvoiceStatus getInvoiceStatusDenied() {
        return invoiceStatusDenied;
    }

    public void setInvoiceStatusDenied(InvoiceStatus invoiceStatusDenied) {
        this.invoiceStatusDenied = invoiceStatusDenied;
    }

    public List<CorrectedTransTypeCombination> getCorrectedTransTypeCombinations() {
        return correctedTransTypeCombinations;
    }

    public void setCorrectedTransTypeCombinations(List<CorrectedTransTypeCombination> correctedTransTypeCombinations) {
        this.correctedTransTypeCombinations = correctedTransTypeCombinations;
    }

    public List<CorrectionTransCombinationType> getCorrectionTransTypeCombinations() {
        return correctionTransTypeCombinations;
    }

    public void setCorrectionTransTypeCombinations(List<CorrectionTransCombinationType> correctionTransTypeCombinations) {
        this.correctionTransTypeCombinations = correctionTransTypeCombinations;
    }

    public void setInvoiceStatusLoaded(InvoiceStatus invoiceStatusLoaded) {
        this.invoiceStatusLoaded = invoiceStatusLoaded;
    }

    public InvoiceStatus getInvoiceStatusLoaded() {
        return invoiceStatusLoaded;
    }

    public Integer getPreCourtWorkNotifyBefore() {
        return preCourtWorkNotifyBefore;
    }

    public void setPreCourtWorkNotifyBefore(Integer preCourtWorkNotifyBefore) {
        this.preCourtWorkNotifyBefore = preCourtWorkNotifyBefore;
    }

    public void setPreCourtWorkLimitNonLegal(Integer preCourtWorkLimitNonLegal) {
        this.preCourtWorkLimitNonLegal = preCourtWorkLimitNonLegal;
    }

    public Integer getPreCourtWorkLimitNonLegal() {
        return preCourtWorkLimitNonLegal;
    }

    public Integer getPreCourtWorkLimitLegal() {
        return preCourtWorkLimitLegal;
    }

    public void setPreCourtWorkLimitLegal(Integer preCourtWorkLimitLegal) {
        this.preCourtWorkLimitLegal = preCourtWorkLimitLegal;
    }

    public Numerator getPreCourtWorkCaseIdNumerator() {
        return preCourtWorkCaseIdNumerator;
    }

    public void setPreCourtWorkCaseIdNumerator(Numerator preCourtWorkCaseIdNumerator) {
        this.preCourtWorkCaseIdNumerator = preCourtWorkCaseIdNumerator;
    }

    public BigDecimal getCounterRotationCoefficient() {
        return counterRotationCoefficient;
    }

    public void setCounterRotationCoefficient(BigDecimal counterRotationCoefficient) {
        this.counterRotationCoefficient = counterRotationCoefficient;
    }

    public Date getAuthorizationDate() {
        return authorizationDate;
    }

    public void setAuthorizationDate(Date authorizationDate) {
        this.authorizationDate = authorizationDate;
    }

    public TransactionTypeCombination getCounterControlTransType() {
        return counterControlTransType;
    }

    public void setCounterControlTransType(TransactionTypeCombination counterControlTransType) {
        this.counterControlTransType = counterControlTransType;
    }

    public TransactionTypeCombination getCounterUninstallTransType() {
        return counterUninstallTransType;
    }

    public void setCounterUninstallTransType(TransactionTypeCombination counterUninstallTransType) {
        this.counterUninstallTransType = counterUninstallTransType;
    }

    public TransactionTypeCombination getCounterInstallTransType() {
        return counterInstallTransType;
    }

    public void setCounterInstallTransType(TransactionTypeCombination counterInstallTransType) {
        this.counterInstallTransType = counterInstallTransType;
    }

    public void setPaymentDelayNotificationDateControl(Integer paymentDelayNotificationDateControl) {
        this.paymentDelayNotificationDateControl = paymentDelayNotificationDateControl;
    }

    public Integer getPaymentDelayNotificationDateControl() {
        return paymentDelayNotificationDateControl;
    }

    public MessageTemplate getRestructurizationPortionPaymentDelayNotif() {
        return restructurizationPortionPaymentDelayNotif;
    }

    public void setRestructurizationPortionPaymentDelayNotif(MessageTemplate restructurizationPortionPaymentDelayNotif) {
        this.restructurizationPortionPaymentDelayNotif = restructurizationPortionPaymentDelayNotif;
    }

    public MessageTemplate getRestructurizationPortionPaymentNotification() {
        return restructurizationPortionPaymentNotification;
    }

    public void setRestructurizationPortionPaymentNotification(MessageTemplate restructurizationPortionPaymentNotification) {
        this.restructurizationPortionPaymentNotification = restructurizationPortionPaymentNotification;
    }

    public Integer getRestructurizationPortionPaymentDateControl() {
        return restructurizationPortionPaymentDateControl;
    }

    public void setRestructurizationPortionPaymentDateControl(Integer restructurizationPortionPaymentDateControl) {
        this.restructurizationPortionPaymentDateControl = restructurizationPortionPaymentDateControl;
    }

    public TransactionTypeCombination getPaymentTransactionTypeCombination() {
        return paymentTransactionTypeCombination;
    }

    public void setPaymentTransactionTypeCombination(TransactionTypeCombination paymentTransactionTypeCombination) {
        this.paymentTransactionTypeCombination = paymentTransactionTypeCombination;
    }

    public Status getDelayAbolishedStatus() {
        return delayAbolishedStatus;
    }

    public void setDelayAbolishedStatus(Status delayAbolishedStatus) {
        this.delayAbolishedStatus = delayAbolishedStatus;
    }

    public void setRestructurizationDebtAbolishmentTransTypeCombination(TransactionTypeCombination restructurizationDebtAbolishmentTransTypeCombination) {
        this.restructurizationDebtAbolishmentTransTypeCombination = restructurizationDebtAbolishmentTransTypeCombination;
    }

    public TransactionTypeCombination getRestructurizationDebtAbolishmentTransTypeCombination() {
        return restructurizationDebtAbolishmentTransTypeCombination;
    }

    public void setRestructurizationPortionTransTypeCombination(TransactionTypeCombination restructurizationPortionTransTypeCombination) {
        this.restructurizationPortionTransTypeCombination = restructurizationPortionTransTypeCombination;
    }

    public TransactionTypeCombination getRestructurizationPortionTransTypeCombination() {
        return restructurizationPortionTransTypeCombination;
    }

    public TransactionTypeCombination getRestructurizationTransactionTypeCombination() {
        return restructurizationTransactionTypeCombination;
    }

    public void setRestructurizationTransactionTypeCombination(TransactionTypeCombination restructurizationTransactionTypeCombination) {
        this.restructurizationTransactionTypeCombination = restructurizationTransactionTypeCombination;
    }

    public Numerator getRestructurizationNumerator() {
        return restructurizationNumerator;
    }

    public void setRestructurizationNumerator(Numerator restructurizationNumerator) {
        this.restructurizationNumerator = restructurizationNumerator;
    }

    public List<NonStandardRestructurizationConfiguration> getNonStandardRestructurizationConfiguration() {
        return nonStandardRestructurizationConfiguration;
    }

    public void setNonStandardRestructurizationConfiguration(List<NonStandardRestructurizationConfiguration> nonStandardRestructurizationConfiguration) {
        this.nonStandardRestructurizationConfiguration = nonStandardRestructurizationConfiguration;
    }

    public TransactionTypeCombination getCircularAccrualSumAccrualType() {
        return circularAccrualSumAccrualType;
    }

    public void setCircularAccrualSumAccrualType(TransactionTypeCombination circularAccrualSumAccrualType) {
        this.circularAccrualSumAccrualType = circularAccrualSumAccrualType;
    }

    public BigDecimal getMinAmountForCutoffLegal() {
        return minAmountForCutoffLegal;
    }

    public void setMinAmountForCutoffLegal(BigDecimal minAmountForCutoffLegal) {
        this.minAmountForCutoffLegal = minAmountForCutoffLegal;
    }

    public Status getCourtStatusAppeal() {
        return courtStatusAppeal;
    }

    public void setCourtStatusAppeal(Status courtStatusAppeal) {
        this.courtStatusAppeal = courtStatusAppeal;
    }

    public Status getCourtStatusIsInCourt() {
        return courtStatusIsInCourt;
    }

    public void setCourtStatusIsInCourt(Status courtStatusIsInCourt) {
        this.courtStatusIsInCourt = courtStatusIsInCourt;
    }

    public Status getCourtStatusReturned() {
        return courtStatusReturned;
    }

    public void setCourtStatusReturned(Status courtStatusReturned) {
        this.courtStatusReturned = courtStatusReturned;
    }

    public Status getCourtStatusNew() {
        return courtStatusNew;
    }

    public void setCourtStatusNew(Status courtStatusNew) {
        this.courtStatusNew = courtStatusNew;
    }

    public Numerator getCourtAdministrationNumerator() {
        return courtAdministrationNumerator;
    }

    public void setCourtAdministrationNumerator(Numerator courtAdministrationNumerator) {
        this.courtAdministrationNumerator = courtAdministrationNumerator;
    }

    public TransactionTypeCombination getCircularAccrualCurrentAccrualType() {
        return circularAccrualCurrentAccrualType;
    }

    public void setCircularAccrualCurrentAccrualType(TransactionTypeCombination circularAccrualCurrentAccrualType) {
        this.circularAccrualCurrentAccrualType = circularAccrualCurrentAccrualType;
    }

    public void setCircularAccrualEstimateAccrualTransType(TransactionTypeCombination circularAccrualEstimateAccrualTransType) {
        this.circularAccrualEstimateAccrualTransType = circularAccrualEstimateAccrualTransType;
    }

    public TransactionTypeCombination getCircularAccrualEstimateAccrualTransType() {
        return circularAccrualEstimateAccrualTransType;
    }

    public TransactionTypeCombination getCircularAccrualCorrectedTransType() {
        return circularAccrualCorrectedTransType;
    }

    public void setCircularAccrualCorrectedTransType(TransactionTypeCombination circularAccrualCorrectedTransType) {
        this.circularAccrualCorrectedTransType = circularAccrualCorrectedTransType;
    }

    public TransactionTypeCombination getCircularAccrualCorrectionTransType() {
        return circularAccrualCorrectionTransType;
    }

    public void setCircularAccrualCorrectionTransType(TransactionTypeCombination circularAccrualCorrectionTransType) {
        this.circularAccrualCorrectionTransType = circularAccrualCorrectionTransType;
    }

    public TransactionTypeCombination getCircularAccrualRealAccrualTransType() {
        return circularAccrualRealAccrualTransType;
    }

    public void setCircularAccrualRealAccrualTransType(TransactionTypeCombination circularAccrualRealAccrualTransType) {
        this.circularAccrualRealAccrualTransType = circularAccrualRealAccrualTransType;
    }

    public List<RsUsersSetup> getRsUsersSetup() {
        return rsUsersSetup;
    }

    public void setRsUsersSetup(List<RsUsersSetup> rsUsersSetup) {
        this.rsUsersSetup = rsUsersSetup;
    }

    public String getRsTin() {
        return rsTin;
    }

    public void setRsTin(String rsTin) {
        this.rsTin = rsTin;
    }

    public String getDelayCancellationText() {
        return delayCancellationText;
    }

    public void setDelayCancellationText(String delayCancellationText) {
        this.delayCancellationText = delayCancellationText;
    }

    public List<DelayStatusChangeCategories> getDelayStatusChangeCategories() {
        return delayStatusChangeCategories;
    }

    public void setDelayStatusChangeCategories(List<DelayStatusChangeCategories> delayStatusChangeCategories) {
        this.delayStatusChangeCategories = delayStatusChangeCategories;
    }

    public void setSupplyContractPenaltyCustomerCatgeories(List<SupplyContractPenaltyCategories> supplyContractPenaltyCustomerCatgeories) {
        this.supplyContractPenaltyCustomerCatgeories = supplyContractPenaltyCustomerCatgeories;
    }

    public List<SupplyContractPenaltyCategories> getSupplyContractPenaltyCustomerCatgeories() {
        return supplyContractPenaltyCustomerCatgeories;
    }

    public void setInvoiceTransactionTypes(List<InvoiceTransactionTypeCombination> invoiceTransactionTypes) {
        this.invoiceTransactionTypes = invoiceTransactionTypes;
    }

    public List<InvoiceTransactionTypeCombination> getInvoiceTransactionTypes() {
        return invoiceTransactionTypes;
    }

    public void setSubsidyMayorTransactionCombination(TransactionTypeCombination subsidyMayorTransactionCombination) {
        this.subsidyMayorTransactionCombination = subsidyMayorTransactionCombination;
    }

    public TransactionTypeCombination getSubsidyMayorTransactionCombination() {
        return subsidyMayorTransactionCombination;
    }

    public void setSubsidyMultiChildTransactionCombination(TransactionTypeCombination subsidyMultiChildTransactionCombination) {
        this.subsidyMultiChildTransactionCombination = subsidyMultiChildTransactionCombination;
    }

    public TransactionTypeCombination getSubsidyMultiChildTransactionCombination() {
        return subsidyMultiChildTransactionCombination;
    }

    public CustomerContractType getSubsidyContractType() {
        return subsidyContractType;
    }

    public void setSubsidyContractType(CustomerContractType subsidyContractType) {
        this.subsidyContractType = subsidyContractType;
    }

    public TransactionTypeCombination getSubsidySocialTransactionCombination() {
        return subsidySocialTransactionCombination;
    }

    public void setSubsidySocialTransactionCombination(TransactionTypeCombination subsidySocialTransactionCombination) {
        this.subsidySocialTransactionCombination = subsidySocialTransactionCombination;
    }

    public void setContractActiveStatus(Status contractActiveStatus) {
        this.contractActiveStatus = contractActiveStatus;
    }

    public Status getContractActiveStatus() {
        return contractActiveStatus;
    }

    public TransactionType getSubsidyTransactionType() {
        return subsidyTransactionType;
    }

    public void setSubsidyTransactionType(TransactionType subsidyTransactionType) {
        this.subsidyTransactionType = subsidyTransactionType;
    }

    public Status getCustomerActiveStatus() {
        return customerActiveStatus;
    }

    public void setCustomerActiveStatus(Status customerActiveStatus) {
        this.customerActiveStatus = customerActiveStatus;
    }

    public BigDecimal getSubsidyExcelTemplateGwpAmount() {
        return subsidyExcelTemplateGwpAmount == null ? BigDecimal.ZERO : subsidyExcelTemplateGwpAmount;
    }

    public void setSubsidyExcelTemplateGwpAmount(BigDecimal subsidyExcelTemplateGwpAmount) {
        this.subsidyExcelTemplateGwpAmount = subsidyExcelTemplateGwpAmount;
    }

    public ExcelImportTemplate getSubsidyExcelTemplateCleanup() {
        return subsidyExcelTemplateCleanup;
    }

    public void setSubsidyExcelTemplateCleanup(ExcelImportTemplate subsidyExcelTemplateCleanup) {
        this.subsidyExcelTemplateCleanup = subsidyExcelTemplateCleanup;
    }

    public ExcelImportTemplate getSubsidyExcelTemplateGwp() {
        return subsidyExcelTemplateGwp;
    }

    public void setSubsidyExcelTemplateGwp(ExcelImportTemplate subsidyExcelTemplateGwp) {
        this.subsidyExcelTemplateGwp = subsidyExcelTemplateGwp;
    }

    public ExcelImportTemplate getSubsidyExcelTemplateMayorsSubsidy() {
        return subsidyExcelTemplateMayorsSubsidy;
    }

    public void setSubsidyExcelTemplateMayorsSubsidy(ExcelImportTemplate subsidyExcelTemplateMayorsSubsidy) {
        this.subsidyExcelTemplateMayorsSubsidy = subsidyExcelTemplateMayorsSubsidy;
    }

    public ExcelImportTemplate getSubsidyExcelTemplate15000() {
        return subsidyExcelTemplate15000;
    }

    public void setSubsidyExcelTemplate15000(ExcelImportTemplate subsidyExcelTemplate15000) {
        this.subsidyExcelTemplate15000 = subsidyExcelTemplate15000;
    }

    public ExcelImportTemplate getSubsidyExcelTemplate7000() {
        return subsidyExcelTemplate7000;
    }

    public void setSubsidyExcelTemplate7000(ExcelImportTemplate subsidyExcelTemplate7000) {
        this.subsidyExcelTemplate7000 = subsidyExcelTemplate7000;
    }

    public ExcelImportTemplate getSubsidyExcelTemplateMultiChild() {
        return subsidyExcelTemplateMultiChild;
    }

    public void setSubsidyExcelTemplateMultiChild(ExcelImportTemplate subsidyExcelTemplateMultiChild) {
        this.subsidyExcelTemplateMultiChild = subsidyExcelTemplateMultiChild;
    }

    public Integer getPaymentNotificationDateAdjustment() {
        return paymentNotificationDateAdjustment;
    }

    public void setPaymentNotificationDateAdjustment(Integer paymentNotificationDateAdjustment) {
        this.paymentNotificationDateAdjustment = paymentNotificationDateAdjustment;
    }

    public BigDecimal getMinAmontForNotifications() {
        return minAmontForNotifications;
    }

    public void setMinAmontForNotifications(BigDecimal minAmontForNotifications) {
        this.minAmontForNotifications = minAmontForNotifications;
    }

    public CutoffStatus getCustomerCutoffDefaultStatus() {
        return customerCutoffDefaultStatus;
    }

    public void setCustomerCutoffDefaultStatus(CutoffStatus customerCutoffDefaultStatus) {
        this.customerCutoffDefaultStatus = customerCutoffDefaultStatus;
    }

    public Integer getCutoffDateAdjustment() {
        return cutoffDateAdjustment;
    }

    public void setCutoffDateAdjustment(Integer cutoffDateAdjustment) {
        this.cutoffDateAdjustment = cutoffDateAdjustment;
    }

    public CustomerContractType getContractTypePenalty() {
        return contractTypePenalty;
    }

    public void setContractTypePenalty(CustomerContractType contractTypePenalty) {
        this.contractTypePenalty = contractTypePenalty;
    }

    public CustomerContractType getContractTypeTelmico() {
        return contractTypeTelmico;
    }

    public void setContractTypeTelmico(CustomerContractType contractTypeTelmico) {
        this.contractTypeTelmico = contractTypeTelmico;
    }

    public CustomerContractType getContractTypeDeposite() {
        return contractTypeDeposite;
    }

    public void setContractTypeDeposite(CustomerContractType contractTypeDeposite) {
        this.contractTypeDeposite = contractTypeDeposite;
    }

    public String getSupplyContractSMSText() {
        return supplyContractSMSText;
    }

    public void setSupplyContractSMSText(String supplyContractSMSText) {
        this.supplyContractSMSText = supplyContractSMSText;
    }

    public String getSupplyContractEmailText() {
        return supplyContractEmailText;
    }

    public void setSupplyContractEmailText(String supplyContractEmailText) {
        this.supplyContractEmailText = supplyContractEmailText;
    }

    public Date getContractPenaltyStartDate() {
        return contractPenaltyStartDate;
    }

    public void setContractPenaltyStartDate(Date contractPenaltyStartDate) {
        this.contractPenaltyStartDate = contractPenaltyStartDate;
    }

    public Status getSupplyContractActiveStatus() {
        return supplyContractActiveStatus;
    }

    public void setSupplyContractActiveStatus(Status supplyContractActiveStatus) {
        this.supplyContractActiveStatus = supplyContractActiveStatus;
    }

    public Integer getSupplyContractExhaustDays() {
        return supplyContractExhaustDays;
    }

    public void setSupplyContractExhaustDays(Integer supplyContractExhaustDays) {
        this.supplyContractExhaustDays = supplyContractExhaustDays;
    }

    public Status getContractPenaltyContractStatus() {
        return contractPenaltyContractStatus;
    }

    public void setContractPenaltyContractStatus(Status contractPenaltyContractStatus) {
        this.contractPenaltyContractStatus = contractPenaltyContractStatus;
    }

    public CustomerContractType getContractPenaltyContractType() {
        return contractPenaltyContractType;
    }

    public void setContractPenaltyContractType(CustomerContractType contractPenaltyContractType) {
        this.contractPenaltyContractType = contractPenaltyContractType;
    }

    public TransactionTypeCombination getContractPenaltyTransTypeCharge() {
        return contractPenaltyTransTypeCharge;
    }

    public void setContractPenaltyTransTypeCharge(TransactionTypeCombination contractPenaltyTransTypeCharge) {
        this.contractPenaltyTransTypeCharge = contractPenaltyTransTypeCharge;
    }

    public void setContractPenaltyTransactionType(TransactionTypeCombination contractPenaltyTransactionType) {
        this.contractPenaltyTransactionType = contractPenaltyTransactionType;
    }

    public TransactionTypeCombination getContractPenaltyTransactionType() {
        return contractPenaltyTransactionType;
    }

    public Double getContractPenaltyPercentage() {
        return contractPenaltyPercentage;
    }

    public void setContractPenaltyPercentage(Double contractPenaltyPercentage) {
        this.contractPenaltyPercentage = contractPenaltyPercentage;
    }

    public Integer getContractPenaltyRespectfulDays() {
        return contractPenaltyRespectfulDays;
    }

    public void setContractPenaltyRespectfulDays(Integer contractPenaltyRespectfulDays) {
        this.contractPenaltyRespectfulDays = contractPenaltyRespectfulDays;
    }

    public CustomerContractType getContractTypeTelasi() {
        return contractTypeTelasi;
    }

    public void setContractTypeTelasi(CustomerContractType contractTypeTelasi) {
        this.contractTypeTelasi = contractTypeTelasi;
    }

    public InvoiceStatus getInvoiceStatusToBeConfirmed() {
        return invoiceStatusToBeConfirmed;
    }

    public void setInvoiceStatusToBeConfirmed(InvoiceStatus invoiceStatusToBeConfirmed) {
        this.invoiceStatusToBeConfirmed = invoiceStatusToBeConfirmed;
    }

    public InvoiceStatus getInvoiceStatusConfirmed() {
        return invoiceStatusConfirmed;
    }

    public void setInvoiceStatusConfirmed(InvoiceStatus invoiceStatusConfirmed) {
        this.invoiceStatusConfirmed = invoiceStatusConfirmed;
    }

    public BigDecimal getMinAmountForCutoff() {
        return minAmountForCutoff;
    }

    public void setMinAmountForCutoff(BigDecimal minAmountForCutoff) {
        this.minAmountForCutoff = minAmountForCutoff;
    }

    public String getRsIntegrationService() {
        return rsIntegrationService;
    }

    public void setRsIntegrationService(String rsIntegrationService) {
        this.rsIntegrationService = rsIntegrationService;
    }

    public Numerator getInvoiceNumerator() {
        return invoiceNumerator;
    }

    public void setInvoiceNumerator(Numerator invoiceNumerator) {
        this.invoiceNumerator = invoiceNumerator;
    }

    public void setCounterActiveStatus(Status counterActiveStatus) {
        this.counterActiveStatus = counterActiveStatus;
    }

    public Status getCounterActiveStatus() {
        return counterActiveStatus;
    }

    public Status getSupplyContractCanceledStatus() {
        return supplyContractCanceledStatus;
    }

    public void setSupplyContractCanceledStatus(Status supplyContractCanceledStatus) {
        this.supplyContractCanceledStatus = supplyContractCanceledStatus;
    }

    public Integer getBankGuaranteeTimeoutWeek() {
        return bankGuaranteeTimeoutWeek;
    }

    public void setBankGuaranteeTimeoutWeek(Integer bankGuaranteeTimeoutWeek) {
        this.bankGuaranteeTimeoutWeek = bankGuaranteeTimeoutWeek;
    }

    public void setDepositBankGuaranteeCombinationType(TransactionTypeCombination depositBankGuaranteeCombinationType) {
        this.depositBankGuaranteeCombinationType = depositBankGuaranteeCombinationType;
    }

    public TransactionTypeCombination getDepositBankGuaranteeCombinationType() {
        return depositBankGuaranteeCombinationType;
    }

    public Status getInactiveCustomerStatus() {
        return inactiveCustomerStatus;
    }

    public void setInactiveCustomerStatus(Status inactiveCustomerStatus) {
        this.inactiveCustomerStatus = inactiveCustomerStatus;
    }

    public Integer getDepositDisconnectedMonth() {
        return depositDisconnectedMonth;
    }

    public void setDepositDisconnectedMonth(Integer depositDisconnectedMonth) {
        this.depositDisconnectedMonth = depositDisconnectedMonth;
    }

    public TransactionTypeCombination getDepositSubCustomerTypeCombination() {
        return depositSubCustomerTypeCombination;
    }

    public void setDepositSubCustomerTypeCombination(TransactionTypeCombination depositSubCustomerTypeCombination) {
        this.depositSubCustomerTypeCombination = depositSubCustomerTypeCombination;
    }

    public TransactionTypeCombination getDepositCompleteAccuralTypeCombination() {
        return depositCompleteAccuralTypeCombination;
    }

    public void setDepositCompleteAccuralTypeCombination(TransactionTypeCombination depositCompleteAccuralTypeCombination) {
        this.depositCompleteAccuralTypeCombination = depositCompleteAccuralTypeCombination;
    }

    public Integer getDepositOverdueDelay() {
        return depositOverdueDelay;
    }

    public void setDepositOverdueDelay(Integer depositOverdueDelay) {
        this.depositOverdueDelay = depositOverdueDelay;
    }

    public Integer getDepositMonthNumForAvgForOverdue() {
        return depositMonthNumForAvgForOverdue;
    }

    public void setDepositMonthNumForAvgForOverdue(Integer depositMonthNumForAvgForOverdue) {
        this.depositMonthNumForAvgForOverdue = depositMonthNumForAvgForOverdue;
    }

    public TransactionType getAccuralTransactionType() {
        return accuralTransactionType;
    }

    public void setAccuralTransactionType(TransactionType accuralTransactionType) {
        this.accuralTransactionType = accuralTransactionType;
    }

    public void setTelmikoContract(CustomerContractType telmikoContract) {
        this.telmikoContract = telmikoContract;
    }

    public CustomerContractType getTelmikoContract() {
        return telmikoContract;
    }

    public List<DepositTransactionTypeCombination> getDepositTransactionTypeCombinations() {
        return depositTransactionTypeCombinations;
    }

    public void setDepositTransactionTypeCombinations(List<DepositTransactionTypeCombination> depositTransactionTypeCombinations) {
        this.depositTransactionTypeCombinations = depositTransactionTypeCombinations;
    }

    public void setDepositAmount(BigDecimal depositAmount) {
        this.depositAmount = depositAmount;
    }

    public BigDecimal getDepositAmount() {
        return depositAmount;
    }

    public TransactionTypeCombination getDepositTransactionType() {
        return depositTransactionType;
    }

    public void setDepositTransactionType(TransactionTypeCombination depositTransactionType) {
        this.depositTransactionType = depositTransactionType;
    }

    public Integer getDepositMonthNumberForAverage() {
        return depositMonthNumberForAverage;
    }

    public void setDepositMonthNumberForAverage(Integer depositMonthNumberForAverage) {
        this.depositMonthNumberForAverage = depositMonthNumberForAverage;
    }

    public Numerator getDistributionTransactionOperationNumerator() {
        return distributionTransactionOperationNumerator;
    }

    public void setDistributionTransactionOperationNumerator(Numerator distributionTransactionOperationNumerator) {
        this.distributionTransactionOperationNumerator = distributionTransactionOperationNumerator;
    }

    public Numerator getCustomerContrantNumerator() {
        return customerContrantNumerator;
    }

    public void setCustomerContrantNumerator(Numerator customerContrantNumerator) {
        this.customerContrantNumerator = customerContrantNumerator;
    }

    public Numerator getHatchNumerator() {
        return hatchNumerator;
    }

    public void setHatchNumerator(Numerator hatchNumerator) {
        this.hatchNumerator = hatchNumerator;
    }

    public Numerator getCounterNumerator() {
        return counterNumerator;
    }

    public void setCounterNumerator(Numerator counterNumerator) {
        this.counterNumerator = counterNumerator;
    }

    public Numerator getCustomerNumerator() {
        return customerNumerator;
    }

    public void setCustomerNumerator(Numerator customerNumerator) {
        this.customerNumerator = customerNumerator;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
    public TransactionTypeCombination getCorrectionTransCombinationType(@NotNull Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        if(correctionTransTypeCombinations == null) throw new RuntimeException("Correction trans type combination not found for " + year);
        for(CorrectionTransCombinationType i : correctionTransTypeCombinations) {
            if(i.getYear() == year) {
                return i.getType();
            }
        }
        throw new RuntimeException("Correction trans type combination not found for " + year);
    }
    public boolean containsCorrectionTransType(UUID id) {
        if(correctionTransTypeCombinations == null) throw new RuntimeException("Correction trans type combination not found for " + id.toString());
        for(CorrectionTransCombinationType i : correctionTransTypeCombinations) {
            if(i.getId().equals(id)) return true;
        }
        return false;
    }
    public TransactionTypeCombination getCorrectedTransCombinationType(@NotNull Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        if(correctedTransTypeCombinations == null) throw new RuntimeException("Corrected trans type combination not found for " + year);
        for(CorrectedTransTypeCombination i : correctedTransTypeCombinations) {
            if(i.getYear() == year) {
                return i.getType();
            }
        }
        throw new RuntimeException("Corrected trans type combination not found for " + year);
    }
    public boolean containsCorrectedTransType(UUID id) {
        if(correctedTransTypeCombinations == null) throw new RuntimeException("Corrected trans type combination not found for " + id.toString());
        for(CorrectedTransTypeCombination i : correctedTransTypeCombinations) {
            if(i.getId().equals(id)) return true;
        }
        return false;
    }
}