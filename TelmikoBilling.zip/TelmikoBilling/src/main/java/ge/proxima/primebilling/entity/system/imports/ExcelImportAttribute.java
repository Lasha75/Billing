package ge.proxima.primebilling.entity.system.imports;

import ge.proxima.primebilling.entity.ImportDataType;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_EXCEL_IMPORT_ATTRIBUTE", indexes = {
        @Index(name = "IDX_EXCELIMPORTATTRIBUTE", columnList = "EXCEL_IMPORT_TEMPLATE_ID")
})
@Entity(name = "prx_ExcelImportAttribute")
public class ExcelImportAttribute {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @Column(name = "COLUMN_")
    private String column;

    @Column(name = "FIELD")
    private String field;

    @Column(name = "TYPE_")
    private String type;

    @Column(name = "ASSOCIATION")
    private String association;

    @Column(name = "ASSOCIATION_COLUMN")
    private String associationColumn;

    @JoinColumn(name = "EXCEL_IMPORT_TEMPLATE_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private ExcelImportTemplate excelImportTemplate;

    @Column(name = "PRIMARY_")
    private Boolean primary = false;

    @Column(name = "SETTER", length = 30)
    private String setter;

    @Column(name = "GETTER", length = 30)
    private String getter;

    public String getAssociationColumn() {
        return associationColumn;
    }

    public void setAssociationColumn(String associationColumn) {
        this.associationColumn = associationColumn;
    }

    public String getGetter() {
        return getter;
    }

    public void setGetter(String getter) {
        this.getter = getter;
    }

    public String getSetter() {
        return setter;
    }

    public void setSetter(String setter) {
        this.setter = setter;
    }

    public Boolean getPrimary() {
        return primary;
    }

    public void setPrimary(Boolean primary) {
        this.primary = primary;
    }

    public ExcelImportTemplate getExcelImportTemplate() {
        return excelImportTemplate;
    }

    public void setExcelImportTemplate(ExcelImportTemplate excelImportTemplate) {
        this.excelImportTemplate = excelImportTemplate;
    }

    public String getAssociation() {
        return association;
    }

    public void setAssociation(String association) {
        this.association = association;
    }

    public ImportDataType getType() {
        return type == null ? null : ImportDataType.fromId(type);
    }

    public void setType(ImportDataType type) {
        this.type = type == null ? null : type.getId();
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PrePersist
    public void prePersist() {
        updateSetter();
    }

    private void updateSetter() {
        String s = field.substring(0, 1).toUpperCase() + field.substring(1);
        setter = "set" + s;
        getter = "get" + s;
    }

    @PreUpdate
    public void preUpdate() {
        updateSetter();
    }
}