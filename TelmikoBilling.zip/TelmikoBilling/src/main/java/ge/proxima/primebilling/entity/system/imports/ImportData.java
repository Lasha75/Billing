package ge.proxima.primebilling.entity.system.imports;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import java.util.UUID;

@JmixEntity(name = "prx_ImportData")
public class ImportData {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private byte[] file;

    private ExcelImportTemplate template;

    public ExcelImportTemplate getTemplate() {
        return template;
    }

    public void setTemplate(ExcelImportTemplate template) {
        this.template = template;
    }

    public byte[] getFile() {
        return file;
    }

    public void setFile(byte[] file) {
        this.file = file;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}