package ge.proxima.primebilling.entity.tariff;

import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.reftables.Activity;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.tariff.tariffline.TariffLine;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.dateservice.DateService;
import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_TARIFF", indexes = {
        @Index(name = "IDX_TARIFF_STATUS_ID", columnList = "STATUS_ID"),
        @Index(name = "IDX_PRX_TARIFF_UNQ", columnList = "CODE", unique = true),
        @Index(name = "IDX_PRX_TARIFF_CUSTOMER_CATEGORY", columnList = "CUSTOMER_CATEGORY_ID"),
        @Index(name = "IDX_PRX_TARIFF_ACTIVITY", columnList = "ACTIVITY_ID")
})
@Entity(name = "prx_Tariff")
public class Tariff {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "IS_STEP_TARIFF")
    private Boolean isStepTariff;

    @Column(name = "TELMIKO_CODE")
    private Integer telmikoCode;

    @JoinColumn(name = "ACTIVITY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Activity activity;

    @NotNull
    @Column(name = "CODE", nullable = false, length = 90)
    private String code;

    @Column(name = "VOLTAGE", length = 30)
    private String voltage;

    @JoinColumn(name = "CUSTOMER_CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory customerCategory;

    @Column(name = "NAME")
    private String name;

    @JoinColumn(name = "STATUS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Status status;

    @Column(name = "NON_DOMESTIC")
    private Boolean nonDomestic = false;

    @Column(name = "ACTIVATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date activationDate;

    @Column(name = "DEACTIVATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date deactivationDate;

    @OneToMany(mappedBy = "tariff")
    private List<TariffLine> lines;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public Boolean getIsStepTariff() {
        return isStepTariff;
    }

    public void setIsStepTariff(Boolean isStepTariff) {
        this.isStepTariff = isStepTariff;
    }

    public Activity getActivity() {
        return activity;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public Integer getTelmikoCode() {
        return telmikoCode;
    }

    public void setTelmikoCode(Integer telmikoCode) {
        this.telmikoCode = telmikoCode;
    }

    public CustomerCategory getCustomerCategory() {
        return customerCategory;
    }

    public void setCustomerCategory(CustomerCategory customerCategory) {
        this.customerCategory = customerCategory;
    }

    public String getVoltage() {
        return voltage;
    }

    public void setVoltage(String voltage) {
        this.voltage = voltage;
    }

    public List<TariffLine> getLines() {
        return lines;
    }

    public void setLines(List<TariffLine> lines) {
        this.lines = lines;
    }

    public Date getDeactivationDate() {
        return deactivationDate;
    }

    public void setDeactivationDate(Date deactivationDate) {
        this.deactivationDate = deactivationDate;
    }

    public Date getActivationDate() {
        return activationDate;
    }

    public void setActivationDate(Date activationDate) {
        this.activationDate = activationDate;
    }

    public Boolean getNonDomestic() {
        return nonDomestic;
    }

    public void setNonDomestic(Boolean nonDomestic) {
        this.nonDomestic = nonDomestic;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"code"})
    public String getInstanceName() {
        return String.format("%s", code);
    }

    public TariffLine getTariffLine(BigDecimal value) {
        if(lines == null) {
            DataManager dataManager = AppBeans.getBean(DataManager.class);
            lines = dataManager.load(TariffLine.class)
                    .query("select e from prx_TariffLine e where e.tariff.id = :id")
                    .fetchPlan(FetchPlan.LOCAL)
                    .parameter("id", this.getId())
                    .list();
        }

        for(TariffLine line : lines) {
            if(line.getStartKilowatt().compareTo(value) <= 0 && line.getEndKilowatt().compareTo(value) >= 0) {
                return line;
            }
        }
        return null;
    }

    @PreUpdate
    public void preUpdate() {
        DateService dateService = AppBeans.getBean(DateService.class);
        if (getDeactivationDate() == null) setDeactivationDate(dateService.getMaximumDate());
    }

    @PrePersist
    public void prePersist() {
        DateService dateService = AppBeans.getBean(DateService.class);
        if (getDeactivationDate() == null) setDeactivationDate(dateService.getMaximumDate());
    }
}