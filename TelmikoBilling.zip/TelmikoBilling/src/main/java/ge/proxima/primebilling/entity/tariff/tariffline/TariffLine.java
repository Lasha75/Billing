package ge.proxima.primebilling.entity.tariff.tariffline;

import ge.proxima.primebilling.entity.tariff.Tariff;
import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import io.jmix.core.Messages;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.NumberFormat;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_TARIFF_LINE", indexes = {
        @Index(name = "IDX_TARIFFLINE_TARIFF_ID", columnList = "TARIFF_ID"),
        @Index(name = "IDX_PRX_TARIFF_LINE_tariff_start_end", columnList = "TARIFF_ID, START_KILLOWAT, END_KILLOWAT"),
        @Index(name = "IDX_PRX_TARIFF_LINE_start_end", columnList = "START_KILLOWAT, END_KILLOWAT")
})
@Entity(name = "prx_TariffLine")
public class TariffLine {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "START_KILLOWAT", precision = 19, scale = 8)
    private BigDecimal startKilowatt;

    @Column(name = "END_KILLOWAT", precision = 19, scale = 8)
    private BigDecimal endKilowatt;

    @NumberFormat(pattern = "#,##0.0000000", decimalSeparator = ".", groupingSeparator = ",")
    @Column(name = "VALUE_", precision = 19, scale = 8)
    private BigDecimal value;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @NotNull
    @JoinColumn(name = "TARIFF_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Tariff tariff;

    public BigDecimal getStartKilowatt() {
        return startKilowatt;
    }

    public BigDecimal getEndKilowatt() {
        return endKilowatt;
    }

    public Tariff getTariff() {
        return tariff;
    }

    public void setTariff(Tariff tariff) {
        this.tariff = tariff;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public void setEndKilowatt(BigDecimal endKilowatt) {
        this.endKilowatt = endKilowatt;
    }

    public void setStartKilowatt(BigDecimal startKilowatt) {
        this.startKilowatt = startKilowatt;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }


    @PreUpdate
    public void preUpdate() {
        checkRanges();
    }

    @PrePersist
    public void prePersist() {
        checkRanges();
    }

    private void checkRanges() {
        DataManager dataManager = AppBeans.getBean(DataManager.class);
        TariffLine tariffLine = dataManager.load(TariffLine.class)
                .query("select e from prx_TariffLine e where e.tariff.id = :tariffId and " +
                        "((e.startKilowatt > :startKilowatt and e.endKilowatt < :endKilowatt) or " +
                        "(e.endKilowatt > :startKilowatt and e.endKilowatt < :endKilowatt) or " +
                        "(e.startKilowatt < :startKilowatt and e.endKilowatt > :endKilowatt)) and e.id <> :id")
                .parameter("tariffId", getTariff().getId())
                .parameter("startKilowatt", getStartKilowatt())
                .parameter("endKilowatt", getEndKilowatt())
                .parameter("id", getId())
                .optional().orElse(null);

        if (tariffLine != null) {
            Messages messages = AppBeans.getBean(Messages.class);
            throw new RuntimeException((messages.getMessage(this.getClass(), "rangesError")));
        }
    }

    @InstanceName
    @DependsOnProperties({"startKilowatt", "endKilowatt", "value"})
    public String getInstanceName() {
        return String.format("%s - %s; %s", startKilowatt, endKilowatt, value);
    }
}