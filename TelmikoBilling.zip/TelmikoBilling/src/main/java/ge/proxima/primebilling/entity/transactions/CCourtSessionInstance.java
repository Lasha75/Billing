package ge.proxima.primebilling.entity.transactions;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum CCourtSessionInstance implements EnumClass<String> {

    FIRSTINSTANCE("FirstInstance"),
    APPEALINSTANCE("AppealInstance"),
    CASSATION("Cassation");

    private String id;

    CCourtSessionInstance(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    @Nullable
    public static CCourtSessionInstance fromId(String id) {
        for (CCourtSessionInstance at : CCourtSessionInstance.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}