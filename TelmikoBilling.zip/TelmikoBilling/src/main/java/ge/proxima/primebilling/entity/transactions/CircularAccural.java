package ge.proxima.primebilling.entity.transactions;

import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerContractType;
import ge.proxima.primebilling.entity.enums.CircularAccuralType;
import ge.proxima.primebilling.entity.tariff.Tariff;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_CIRCULAR_ACCURAL", indexes = {
        @Index(name = "IDX_CIRCULARACCURAL", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_CIRCULARACCURAL_BLOCK_ID", columnList = "BLOCK_ID"),
        @Index(name = "IDX_CIRCULARACCURAL", columnList = "PREV_READ_TYPE_ID"),
        @Index(name = "IDX_CIRCULARACCURAL", columnList = "READ_TYPE_ID"),
        @Index(name = "IDX_PRX_CIRCULAR_ACCURAL_fullamount", columnList = "FULL_AMOUNT"),
        @Index(name = "IDX_PRX_CIRCULAR_ACCURAL_TARIFF", columnList = "TARIFF_ID"),
        @Index(name = "IDX_PRX_CIRCULAR_ACCURAL_ACCOUNT_TYPE", columnList = "ACCOUNT_TYPE_ID"),
        @Index(name = "IDX_PRX_CIRCULAR_ACCURAL_CHILED_CUSTOMER", columnList = "CHILED_CUSTOMER_ID"),
        @Index(name = "IDX_PRX_CIRCULAR_ACCURAL_PARENT_CUSTOMER", columnList = "PARENT_CUSTOMER_ID")
})
@Entity(name = "prx_CircularAccural")
public class CircularAccural {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "CYCLE_DAY_DIFF", precision = 19, scale = 0)
    private BigDecimal cycleDayDiff;

    @Column(name = "STEP_KWT", precision = 19, scale = 2)
    private BigDecimal stepKwt;

    @Column(name = "PREV_BLOCK_READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevBlockReadDate;

    @Column(name = "CREATE_TIME_STAMP", length = 100)
    private String createTimeStamp;

    @Column(name = "IS_PARENT_COUNTER")
    private Boolean isParentCounter;

    @Column(name = "NEED_SUM_CHARGE")
    private Boolean needSumCharge;

    @Column(name = "IS_CURRENT_CORRECTION")
    private Boolean isCurrentCorrection;

    @JoinColumn(name = "PARENT_CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer parentCustomer;

    @Column(name = "IS_SUB_CUSTOMER_RECORDS")
    private Boolean isSubCustomerRecords;

    @JoinColumn(name = "CHILED_CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer chiledCustomer;

    @Column(name = "NOTE")
    private String note;

    @JoinColumn(name = "ACCOUNT_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType accountType;

    @Column(name = "ACCOUNT_NUMBER", length = 30)
    private String accountNumber;

    @Column(name = "REAL_READ_DIFF_KWT", precision = 19, scale = 2)
    private BigDecimal realReadDiffKWT;

    @Column(name = "ESTIMATE_RECORD")
    private Boolean estimateRecord;

    @Column(name = "COUNTER_OFF_RECORD")
    private Boolean counterOffRecord;

    @Column(name = "REAL_TO_EST")
    private Boolean realToEst;

    @Column(name = "IS_CUSTOM_RECORD")
    private Boolean isCustomRecord;

    @Column(name = "CUSTOM_READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date customReadDate;

    @Column(name = "CUSTOM_PREV_READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date customPrevReadDate;

    @JoinColumn(name = "TARIFF_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Tariff tariff;

    @Column(name = "CUSTOM_INVOICE_DATE")
    @Temporal(TemporalType.DATE)
    private Date customInvoiceDate;

    @Column(name = "COUNTER_ID")
    private UUID counterId;

    @Column(name = "CHILED_COUNTER_ID")
    private UUID chiledCounterId;

    @Column(name = "TELASI_ACCOUNT_ID", length = 40)
    private String telasiAccountId;

    @Column(name = "TELASI_ACCOUNT_CHILED_ID", length = 40)
    private String telasiAccountChiledId;

    @Column(name = "PARENT_COUNTER_ID")
    private UUID parentCounterId;

    @Column(name = "NEED_COEFICIENT_CHANGE")
    private Boolean needCoeficientChange;

    @Column(name = "NEED_TARIFF_CHANGE")
    private Boolean needTariffChange;

    @Column(name = "SUM_KWT", precision = 19, scale = 2)
    private BigDecimal sumKWT;

    @Column(name = "ONE_DAY_KWT", precision = 19, scale = 10)
    private BigDecimal oneDayKwt;

    @Column(name = "VOUCHER", length = 50)
    private String voucher;

    @Column(name = "TARRIFF_VAUE", precision = 19, scale = 8)
    private BigDecimal tarriffVaue;

    @Column(name = "FULL_AMOUNT", precision = 19, scale = 2)
    private BigDecimal fullAmount;

    @Column(name = "IS_LEGAL")
    private Boolean isLegal;

    @Column(name = "REAL_TO_REAL")
    private Boolean realToReal;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @Column(name = "ADDRESS", length = 511)
    private String address;

    @Column(name = "COUNTER_NUMBER", length = 30)
    private String counterNumber;

    @Column(name = "NEW_READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date newReadDate;

    @Column(name = "NEW_READING", precision = 19, scale = 2)
    private BigDecimal newReading;

    @Column(name = "NEW_KILOWATT", precision = 19, scale = 2)
    private BigDecimal newKilowatt;

    @Column(name = "PREV_READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevReadDate;

    @Column(name = "PREV_READ", precision = 19, scale = 2)
    private BigDecimal prevRead;

    @JoinColumn(name = "PREV_READ_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination prevReadType;

    @Column(name = "STATUS")
    private String status;

    @JoinColumn(name = "READ_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination readType;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "PREV_REAL_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevRealDate;

    @Column(name = "PREV_REAL_READING", precision = 19, scale = 2)
    private BigDecimal prevRealReading;

    @Column(name = "ENTER_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date enterDateTime;

    public String getTelasiAccountChiledId() {
        return telasiAccountChiledId;
    }

    public void setTelasiAccountChiledId(String telasiAccountChiledId) {
        this.telasiAccountChiledId = telasiAccountChiledId;
    }

    public String getTelasiAccountId() {
        return telasiAccountId;
    }

    public void setTelasiAccountId(String telasiAccountId) {
        this.telasiAccountId = telasiAccountId;
    }

    public UUID getChiledCounterId() {
        return chiledCounterId;
    }

    public void setChiledCounterId(UUID chiledCounterId) {
        this.chiledCounterId = chiledCounterId;
    }

    public BigDecimal getStepKwt() {
        return stepKwt;
    }

    public void setStepKwt(BigDecimal stepKwt) {
        this.stepKwt = stepKwt;
    }

    public BigDecimal getCycleDayDiff() {
        return cycleDayDiff;
    }

    public void setCycleDayDiff(BigDecimal cycleDayDiff) {
        this.cycleDayDiff = cycleDayDiff;
    }

    public String getVoucher() {
        return voucher;
    }

    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }

    public Date getEnterDateTime() {
        return enterDateTime;
    }

    public void setEnterDateTime(Date enterDateTime) {
        this.enterDateTime = enterDateTime;
    }

    public Date getPrevBlockReadDate() {
        return prevBlockReadDate;
    }

    public void setPrevBlockReadDate(Date prevBlockReadDate) {
        this.prevBlockReadDate = prevBlockReadDate;
    }

    public String getCreateTimeStamp() {
        return createTimeStamp;
    }

    public void setCreateTimeStamp(String createTimeStamp) {
        this.createTimeStamp = createTimeStamp;
    }

    public Boolean getNeedSumCharge() {
        return needSumCharge;
    }

    public void setNeedSumCharge(Boolean needSumCharge) {
        this.needSumCharge = needSumCharge;
    }

    public Boolean getIsParentCounter() {
        return isParentCounter;
    }

    public void setIsParentCounter(Boolean isParentCounter) {
        this.isParentCounter = isParentCounter;
    }

    public Customer getParentCustomer() {
        return parentCustomer;
    }

    public void setParentCustomer(Customer parentCustomer) {
        this.parentCustomer = parentCustomer;
    }

    public Boolean getIsSubCustomerRecords() {
        return isSubCustomerRecords;
    }

    public void setIsSubCustomerRecords(Boolean isSubCustomerRecords) {
        this.isSubCustomerRecords = isSubCustomerRecords;
    }

    public Boolean getIsCurrentCorrection() {
        return isCurrentCorrection;
    }

    public void setIsCurrentCorrection(Boolean isCurrentCorrection) {
        this.isCurrentCorrection = isCurrentCorrection;
    }

    public Customer getChiledCustomer() {
        return chiledCustomer;
    }

    public void setChiledCustomer(Customer chiledCustomer) {
        this.chiledCustomer = chiledCustomer;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public CustomerContractType getAccountType() {
        return accountType;
    }

    public void setAccountType(CustomerContractType accountType) {
        this.accountType = accountType;
    }

    public Boolean getCounterOffRecord() {
        return counterOffRecord;
    }

    public void setCounterOffRecord(Boolean counterOffRecord) {
        this.counterOffRecord = counterOffRecord;
    }

    public Boolean getEstimateRecord() {
        return estimateRecord;
    }

    public void setEstimateRecord(Boolean estimateRecord) {
        this.estimateRecord = estimateRecord;
    }

    public BigDecimal getRealReadDiffKWT() {
        return realReadDiffKWT;
    }

    public void setRealReadDiffKWT(BigDecimal realReadDiffKWT) {
        this.realReadDiffKWT = realReadDiffKWT;
    }

    public Date getCustomInvoiceDate() {
        return customInvoiceDate;
    }

    public void setCustomInvoiceDate(Date customInvoiceDate) {
        this.customInvoiceDate = customInvoiceDate;
    }

    public Tariff getTariff() {
        return tariff;
    }

    public void setTariff(Tariff tariff) {
        this.tariff = tariff;
    }

    public Date getCustomPrevReadDate() {
        return customPrevReadDate;
    }

    public void setCustomPrevReadDate(Date customPrevReadDate) {
        this.customPrevReadDate = customPrevReadDate;
    }

    public Date getCustomReadDate() {
        return customReadDate;
    }

    public void setCustomReadDate(Date customReadDate) {
        this.customReadDate = customReadDate;
    }

    public Boolean getIsCustomRecord() {
        return isCustomRecord;
    }

    public void setIsCustomRecord(Boolean isCustomRecord) {
        this.isCustomRecord = isCustomRecord;
    }

    public Boolean getRealToEst() {
        return realToEst;
    }

    public void setRealToEst(Boolean realToEst) {
        this.realToEst = realToEst;
    }

    public UUID getParentCounterId() {
        return parentCounterId;
    }

    public void setParentCounterId(UUID parentCounterId) {
        this.parentCounterId = parentCounterId;
    }

    public UUID getCounterId() {
        return counterId;
    }

    public void setCounterId(UUID counterId) {
        this.counterId = counterId;
    }

    public BigDecimal getFullAmount() {
        return fullAmount;
    }

    public void setFullAmount(BigDecimal fullAmount) {
        this.fullAmount = fullAmount;
    }

    public BigDecimal getTarriffVaue() {
        return tarriffVaue;
    }

    public void setTarriffVaue(BigDecimal tarriffVaue) {
        this.tarriffVaue = tarriffVaue;
    }

    public BigDecimal getOneDayKwt() {
        return oneDayKwt;
    }

    public void setOneDayKwt(BigDecimal oneDayKwt) {
        this.oneDayKwt = oneDayKwt;
    }

    public Boolean getRealToReal() {
        return realToReal;
    }

    public void setRealToReal(Boolean realToReal) {
        this.realToReal = realToReal;
    }

    public Boolean getIsLegal() {
        return isLegal;
    }

    public void setIsLegal(Boolean isLegal) {
        this.isLegal = isLegal;
    }

    public BigDecimal getSumKWT() {
        return sumKWT;
    }

    public void setSumKWT(BigDecimal sumKWT) {
        this.sumKWT = sumKWT;
    }

    public Boolean getNeedTariffChange() {
        return needTariffChange;
    }

    public void setNeedTariffChange(Boolean needTariffChange) {
        this.needTariffChange = needTariffChange;
    }

    public Boolean getNeedCoeficientChange() {
        return needCoeficientChange;
    }

    public void setNeedCoeficientChange(Boolean needCoeficientChange) {
        this.needCoeficientChange = needCoeficientChange;
    }

    public BigDecimal getPrevRealReading() {
        return prevRealReading;
    }

    public void setPrevRealReading(BigDecimal prevRealReading) {
        this.prevRealReading = prevRealReading;
    }

    public Date getPrevRealDate() {
        return prevRealDate;
    }

    public void setPrevRealDate(Date prevRealDate) {
        this.prevRealDate = prevRealDate;
    }

    public void setReadType(TransactionTypeCombination readType) {
        this.readType = readType;
    }

    public TransactionTypeCombination getReadType() {
        return readType;
    }

    public void setPrevReadType(TransactionTypeCombination prevReadType) {
        this.prevReadType = prevReadType;
    }

    public TransactionTypeCombination getPrevReadType() {
        return prevReadType;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public CircularAccuralType getStatus() {
        return status == null ? null : CircularAccuralType.fromId(status);
    }

    public void setStatus(CircularAccuralType status) {
        this.status = status == null ? null : status.getId();
    }

    public BigDecimal getPrevRead() {
        return prevRead;
    }

    public void setPrevRead(BigDecimal prevRead) {
        this.prevRead = prevRead;
    }

    public Date getPrevReadDate() {
        return prevReadDate;
    }

    public void setPrevReadDate(Date prevReadDate) {
        this.prevReadDate = prevReadDate;
    }

    public BigDecimal getNewKilowatt() {
        return newKilowatt;
    }

    public void setNewKilowatt(BigDecimal newKilowatt) {
        this.newKilowatt = newKilowatt;
    }

    public BigDecimal getNewReading() {
        return newReading;
    }

    public void setNewReading(BigDecimal newReading) {
        this.newReading = newReading;
    }

    public Date getNewReadDate() {
        return newReadDate;
    }

    public void setNewReadDate(Date newReadDate) {
        this.newReadDate = newReadDate;
    }

    public String getCounterNumber() {
        return counterNumber;
    }

    public void setCounterNumber(String counterNumber) {
        this.counterNumber = counterNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}