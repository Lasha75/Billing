package ge.proxima.primebilling.entity.transactions;

import ge.proxima.primebilling.entity.counter.CounterCoefficient;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_CoefficientTmp")
public class CoefficientTmp {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Temporal(TemporalType.DATE)
    private Date endDate;

    private CounterCoefficient coefficient;

    public CounterCoefficient getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(CounterCoefficient coefficient) {
        this.coefficient = coefficient;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}