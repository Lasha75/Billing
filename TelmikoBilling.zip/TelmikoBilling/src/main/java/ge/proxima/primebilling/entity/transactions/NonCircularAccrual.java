package ge.proxima.primebilling.entity.transactions;

import ge.proxima.primebilling.entity.NonCircularTransactionStatus;
import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_NON_CIRCULAR_ACCRUAL", indexes = {
        @Index(name = "IDX_NONCIRCULARACCRUAL", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_NONCIRCULARACCRUAL", columnList = "BLOCK_ID"),
        @Index(name = "IDX_NONCIRCULARACCRUAL", columnList = "READ_TYPE_ID"),
        @Index(name = "IDX_NONCIRCULARACCRUAL", columnList = "PREV_REAL_TYPE_ID"),
        @Index(name = "IDX_PRX_NON_CIRCULAR_ACCRUAL_hash", columnList = "HASHCODE"),
        @Index(name = "IDX_PRXNONCIRCULARACC_PREVTYPE", columnList = "PREV_TYPE_ID"),
        @Index(name = "IDX_PRX_NON_CIRCULAR_ACCRUAL", columnList = "CUSTOMER_ID, COUNTER_NUMBER, CREATE_TIME_STAMP")
})
@Entity(name = "prx_NonCircularAccrual")
public class NonCircularAccrual {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "WITH_GEL")
    private Boolean withGel;

    @Column(name = "STEP")
    private Integer step;

    @Column(name = "INVOICE_DATE")
    @Temporal(TemporalType.DATE)
    private Date invoiceDate;

    @Column(name = "TARIFF_VALUE", precision = 19, scale = 2)
    private BigDecimal tariffValue;

    @Column(name = "ERROR_TEXT")
    private String errorText;

    @Column(name = "CREATE_TIME_STAMP", length = 100)
    private String createTimeStamp;

    @Column(name = "PREV_BLOCK_READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevBlockReadDate;

    @Column(name = "HASHCODE")
    private String hashcode;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JoinColumn(name = "CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer customer;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @Column(name = "ADDRESS", length = 511)
    private String address;

    @Column(name = "COUNTER_NUMBER", length = 30)
    private String counterNumber;

    @Column(name = "ITEM_DATE")
    @Temporal(TemporalType.DATE)
    private Date itemDate;

    @Column(name = "READING", precision = 19, scale = 5)
    private BigDecimal reading;

    @Column(name = "KILOWATT", precision = 19, scale = 2)
    private BigDecimal kilowatt;

    @Column(name = "BILL_OPER_KEY")
    private String billOperKey;

    @Column(name = "ENTER_DATE")
    @Temporal(TemporalType.DATE)
    private Date enterDate;

    @Column(name = "ENTER_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date enterDateTime;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "VOUCHER")
    private String voucher;

    @Column(name = "NOTE", length = 1000)
    private String note;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "PREV_READ", precision = 19, scale = 5)
    private BigDecimal prevRead;

    @JoinColumn(name = "READ_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination readType;

    @Column(name = "NEW_READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date newReadDate;

    @Column(name = "PREV_READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevReadDate;

    @JoinColumn(name = "PREV_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination prevType;

    @Column(name = "PREV_REAL_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevRealDate;

    @Column(name = "PREV_REAL_READING", precision = 19, scale = 5)
    private BigDecimal prevRealReading;

    @Column(name = "NEW_REAL_DATE")
    @Temporal(TemporalType.DATE)
    private Date newRealDate;

    @JoinColumn(name = "PREV_REAL_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionTypeCombination prevRealType;

    @Column(name = "TRANS_ID")
    private UUID transId;

    @Column(name = "PARANT_ID")
    private UUID parantId;

    public Integer getStep() {
        return step;
    }

    public void setStep(Integer step) {
        this.step = step;
    }

    public Boolean getWithGel() {
        return withGel;
    }

    public void setWithGel(Boolean withGel) {
        this.withGel = withGel;
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public void setEnterDateTime(Date enterDateTime) {
        this.enterDateTime = enterDateTime;
    }

    public Date getEnterDateTime() {
        return enterDateTime;
    }

    public BigDecimal getTariffValue() {
        return tariffValue;
    }

    public void setTariffValue(BigDecimal tariffValue) {
        this.tariffValue = tariffValue;
    }

    public String getErrorText() {
        return errorText;
    }

    public void setErrorText(String errorText) {
        this.errorText = errorText;
    }

    public TransactionTypeCombination getPrevType() {
        return prevType;
    }

    public void setPrevType(TransactionTypeCombination prevType) {
        this.prevType = prevType;
    }

    public Date getPrevBlockReadDate() {
        return prevBlockReadDate;
    }

    public void setPrevBlockReadDate(Date prevBlockReadDate) {
        this.prevBlockReadDate = prevBlockReadDate;
    }

    public String getCreateTimeStamp() {
        return createTimeStamp;
    }

    public void setCreateTimeStamp(String createTimeStamp) {
        this.createTimeStamp = createTimeStamp;
    }

    public String getHashcode() {
        return hashcode;
    }

    public void setHashcode(String hashcode) {
        this.hashcode = hashcode;
    }

    public UUID getParantId() {
        return parantId;
    }

    public void setParantId(UUID parantId) {
        this.parantId = parantId;
    }

    public UUID getTransId() {
        return transId;
    }

    public void setTransId(UUID transId) {
        this.transId = transId;
    }

    public TransactionTypeCombination getPrevRealType() {
        return prevRealType;
    }

    public void setPrevRealType(TransactionTypeCombination prevRealType) {
        this.prevRealType = prevRealType;
    }

    public void setPrevRead(BigDecimal prevRead) {
        this.prevRead = prevRead;
    }

    public BigDecimal getPrevRead() {
        return prevRead;
    }

    public Date getNewRealDate() {
        return newRealDate;
    }

    public void setNewRealDate(Date newRealDate) {
        this.newRealDate = newRealDate;
    }

    public BigDecimal getPrevRealReading() {
        return prevRealReading;
    }

    public void setPrevRealReading(BigDecimal prevRealReading) {
        this.prevRealReading = prevRealReading;
    }

    public Date getPrevRealDate() {
        return prevRealDate;
    }

    public void setPrevRealDate(Date prevRealDate) {
        this.prevRealDate = prevRealDate;
    }

    public Date getPrevReadDate() {
        return prevReadDate;
    }

    public void setPrevReadDate(Date prevReadDate) {
        this.prevReadDate = prevReadDate;
    }

    public Date getNewReadDate() {
        return newReadDate;
    }

    public void setNewReadDate(Date newReadDate) {
        this.newReadDate = newReadDate;
    }

    public TransactionTypeCombination getReadType() {
        return readType;
    }

    public void setReadType(TransactionTypeCombination readType) {
        this.readType = readType;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public void setStatus(NonCircularTransactionStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public NonCircularTransactionStatus getStatus() {
        return status == null ? null : NonCircularTransactionStatus.fromId(status);
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getVoucher() {
        return voucher;
    }

    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }

    public Date getEnterDate() {
        return enterDate;
    }

    public void setEnterDate(Date enterDate) {
        this.enterDate = enterDate;
    }

    public String getBillOperKey() {
        return billOperKey;
    }

    public void setBillOperKey(String billOperKey) {
        this.billOperKey = billOperKey;
    }

    public BigDecimal getKilowatt() {
        return kilowatt;
    }

    public void setKilowatt(BigDecimal kilowatt) {
        this.kilowatt = kilowatt;
    }

    public BigDecimal getReading() {
        return reading;
    }

    public void setReading(BigDecimal reading) {
        this.reading = reading;
    }

    public Date getItemDate() {
        return itemDate;
    }

    public void setItemDate(Date itemDate) {
        this.itemDate = itemDate;
    }

    public String getCounterNumber() {
        return counterNumber;
    }

    public void setCounterNumber(String counterNumber) {
        this.counterNumber = counterNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"amount", "voucher", "customer"})
    public String getInstanceName() {
        return String.format("%s %s %s", amount, voucher, customer);
    }
}