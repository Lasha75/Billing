package ge.proxima.primebilling.entity.transactions;

import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.block.route.Route;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.customer.CustomerContractType;
import ge.proxima.primebilling.entity.enums.ChargeType;
import ge.proxima.primebilling.entity.enums.DepositType;
import ge.proxima.primebilling.entity.tariff.Tariff;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.DeletePolicy;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_OPEN_TRANSACTION", indexes = {
        @Index(name = "IDX_OPENTRANSACTION", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_OPENTRANSACTION_BLOCK_ID", columnList = "BLOCK_ID"),
        @Index(name = "IDX_OPENTRANSACTION_ROUTE_ID", columnList = "ROUTE_ID"),
        @Index(name = "IDX_OPENTRANSACTION", columnList = "TRANS_TYPE_COMBINATION_ID"),
        @Index(name = "IDX_OPENTRANSACTION", columnList = "TRANSACTION_ID"),
        @Index(name = "IDX_OPENTRANSACTION", columnList = "CATEGORY_ID"),
        @Index(name = "IDX_OPENTRANSACTION", columnList = "ACCOUNT_TYPE_ID"),
        @Index(name = "IDX_OPENTRANSACTION_TARIFF_ID", columnList = "TARIFF_ID"),
        @Index(name = "IDX_PRX_OPEN_TRANSACTION_debt", columnList = "DUE_DATE, DELETED_BY, USED_IN_BILL, ACCOUNT_TYPE_ID, CUSTOMER_ID"),
        @Index(name = "IDX_PRX_OPEN_TRANSACTION_Settlement", columnList = "ACCOUNT_TYPE_ID, TRANS_TYPE_COMBINATION_ID, AMOUNT, CUSTOMER_NUMBER"),
        @Index(name = "IDX_PRX_OPEN_TRANSACTION_dep", columnList = "CUSTOMER_ID, USED_IN_BILL, INVOICE_DATE, DELETED_DATE"),
        @Index(name = "IDX_PRX_OPEN_TRANSACTION", columnList = "TRANSACTION_ID, AMOUNT, DELETED_BY")
})
@Entity(name = "prx_OpenTransaction")
public class OpenTransaction {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "CREATE_TIME_STAMP", length = 100)
    private String createTimeStamp;

    @Column(name = "USED_IN_BILL")
    private Boolean usedInBill = false;

    @JoinColumn(name = "TARIFF_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Tariff tariff;

    @Column(name = "INVOICE_DATE")
    @Temporal(TemporalType.DATE)
    private Date invoiceDate;

    @Column(name = "KILOWATT_HOUR", precision = 19, scale = 2)
    private BigDecimal kilowattHour = BigDecimal.ZERO;

    @Column(name = "VALUE_", precision = 19, scale = 2)
    private BigDecimal value;

    @Column(name = "USED_IN_CHECK")
    private Boolean usedInCheck = false;

    @JoinColumn(name = "ACCOUNT_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType accountType;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory category;

    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @Column(name = "ACCOUNT_NUMBER", length = 100)
    private String accountNumber;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "CATEGORY_NAME", length = 200)
    private String categoryName;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @Column(name = "BLOCK_NAME", length = 200)
    private String blockName;

    @JoinColumn(name = "ROUTE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Route route;

    @Column(name = "ROUTE_NAME", length = 350)
    private String routeName;

    @Column(name = "TRANS_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    @NotNull
    private Date transDate;

    @Column(name = "DUE_DATE")
    @Temporal(TemporalType.DATE)
    private Date dueDate;

    @NotNull
    @JoinColumn(name = "TRANS_TYPE_COMBINATION_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private TransactionTypeCombination transTypeCombination;

    @Column(name = "CHARGE_TYPE")
    private String chargeType;

    @OnDeleteInverse(DeletePolicy.UNLINK)
    @JoinColumn(name = "TRANSACTION_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Transaction transaction;

    @Column(name = "CUSTOMER_NUMBER", length = 100)
    private String customerNumber;

    @Column(name = "DEPOSIT_TYPE")
    private String depositType;

    @Column(name = "BANK_GUARANTEE_START_DATE")
    @Temporal(TemporalType.DATE)
    private Date bankGuaranteeStartDate;

    @Column(name = "BANK_GUARANTEE_END_DATE")
    @Temporal(TemporalType.DATE)
    private Date bankGuaranteeEndDate;

    @Column(name = "BANK_GUARANTEE_NUMBER")
    private String bankGuaranteeNumber;

    @Column(name = "BLOCKED")
    private Boolean blocked = false;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public String getCreateTimeStamp() {
        return createTimeStamp;
    }

    public void setCreateTimeStamp(String createTimeStamp) {
        this.createTimeStamp = createTimeStamp;
    }

    public void setDepositType(DepositType depositType) {
        this.depositType = depositType == null ? null : depositType.getId();
    }

    public DepositType getDepositType() {
        return depositType == null ? null : DepositType.fromId(depositType);
    }

    public Boolean getBlocked() {
        return blocked;
    }

    public void setBlocked(Boolean blocked) {
        this.blocked = blocked;
    }

    public UUID getId() {
        return id;
    }

    public CustomerContractType getAccountType() {
        return accountType;
    }

    public CustomerCategory getCategory() {
        return category;
    }

    public Customer getCustomer() {
        return customer;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public Block getBlock() {
        return block;
    }

    public String getBlockName() {
        return blockName;
    }

    public Route getRoute() {
        return route;
    }

    public String getRouteName() {
        return routeName;
    }

    public Date getTransDate() {
        return transDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public TransactionTypeCombination getTransTypeCombination() {
        return transTypeCombination;
    }

    public String getChargeType() {
        return chargeType;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public Date getBankGuaranteeStartDate() {
        return bankGuaranteeStartDate;
    }

    public Date getBankGuaranteeEndDate() {
        return bankGuaranteeEndDate;
    }

    public String getBankGuaranteeNumber() {
        return bankGuaranteeNumber;
    }

    public Integer getVersion() {
        return version;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public BigDecimal getKilowattHour() {
        return kilowattHour;
    }

    public void setKilowattHour(BigDecimal kilowattHour) {
        this.kilowattHour = kilowattHour;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public Tariff getTariff() {
        return tariff;
    }

    public void setTariff(Tariff tariff) {
        this.tariff = tariff;
    }

    public Boolean getUsedInBill() {
        return usedInBill;
    }

    public Boolean getUsedInCheck() {
        return usedInCheck;
    }

    public void setUsedInCheck(Boolean usedInCheck) {
        this.usedInCheck = usedInCheck;
    }

    public void setUsedInBill(Boolean usedInBill) {
        this.usedInBill = usedInBill;
    }

    public void setBankGuaranteeNumber(String bankGuaranteeNumber) {
        this.bankGuaranteeNumber = bankGuaranteeNumber;
    }

    public void setBankGuaranteeEndDate(Date bankGuaranteeEndDate) {
        this.bankGuaranteeEndDate = bankGuaranteeEndDate;
    }

    public void setBankGuaranteeStartDate(Date bankGuaranteeStartDate) {
        this.bankGuaranteeStartDate = bankGuaranteeStartDate;
    }

    public void setAccountType(CustomerContractType accountType) {
        this.accountType = accountType;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public void setChargeType(ChargeType chargeType) {
        this.chargeType = chargeType == null ? null : chargeType.getId();
    }

    public void setTransTypeCombination(TransactionTypeCombination transTypeCombination) {
        this.transTypeCombination = transTypeCombination;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public void setTransDate(Date transDate) {
        this.transDate = transDate;
    }

    public void setRouteName(String routeName) {
        this.routeName = routeName;
    }

    public void setRoute(Route route) {
        this.route = route;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}