package ge.proxima.primebilling.entity.transactions;

import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.block.route.Route;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.customer.CustomerContractType;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import io.jmix.core.metamodel.annotation.JmixProperty;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_SETTLE_TRANSACTION", indexes = {
        @Index(name = "IDX_SETTLETRANSACTION", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_SETTLETRANSACTION", columnList = "BLOCK_ID"),
        @Index(name = "IDX_SETTLETRANSACTION", columnList = "ROUTE_ID"),
        @Index(name = "IDX_SETTLETRANSACTION", columnList = "TRANS_TYPE_COMBINATION_ID"),
        @Index(name = "IDX_SETTLETRANSACTION", columnList = "CONNECTED_TRANS_ID"),
        @Index(name = "IDX_SETTLETRANSACTION", columnList = "TRANSACTION_ID"),
        @Index(name = "IDX_SETTLETRANSACTION", columnList = "CATEGORY_ID"),
        @Index(name = "IDX_SETTLETRANSACTION", columnList = "ACCOUNT_TYPE_ID"),
        @Index(name = "IDX_PRX_SETTLE_TRANSACTION", columnList = "CUSTOMER_ID, DELETED_BY, TRANS_DATE, ACCOUNT_TYPE_ID")
})
@Entity(name = "prx_SettleTransaction")
public class SettleTransaction {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @NotNull
    @Column(name = "CONNECTION_UUID", nullable = false)
    private UUID connectionUUID;

    @JoinColumn(name = "ACCOUNT_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType accountType;

    @Column(name = "SETTLEMENT_CONNECTION_ID")
    private Long settlementConnectionId;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory category;

    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @Column(name = "CUSTOMER_NUMBER", length = 100)
    private String customerNumber;

    @Column(name = "ACCOUNT_NUMBER", length = 100)
    private String accountNumber;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "CATEGORY_NAME", length = 200)
    private String categoryName;

    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @Column(name = "BLOCK_NAME", length = 200)
    private String blockName;

    @JoinColumn(name = "ROUTE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Route route;

    @Column(name = "ROUTE_NAME", length = 200)
    private String routeName;

    @NotNull
    @Column(name = "TRANS_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date transDate;

    @Column(name = "DUE_DATE")
    @Temporal(TemporalType.DATE)
    private Date dueDate;

    @NotNull
    @JoinColumn(name = "TRANS_TYPE_COMBINATION_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private TransactionTypeCombination transTypeCombination;

    @Column(name = "SETTLE_DATE")
    @Temporal(TemporalType.DATE)
    private Date settleDate;

    @Column(name = "IS_REVERSED")
    private Boolean isReversed = false;

    @JoinColumn(name = "CONNECTED_TRANS_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private SettleTransaction connectedTrans;

    @JoinColumn(name = "TRANSACTION_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Transaction transaction;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @JmixProperty
    @Transient
    private Boolean mark = false;

    public Boolean getMark() {
        return mark;
    }

    public void setMark(Boolean mark) {
        this.mark = mark;
    }

    public UUID getConnectionUUID() {
        return connectionUUID;
    }

    public void setConnectionUUID(UUID connectionUUID) {
        this.connectionUUID = connectionUUID;
    }

    public Long getSettlementConnectionId() {
        return settlementConnectionId;
    }

    public void setSettlementConnectionId(Long settlementConnectionId) {
        this.settlementConnectionId = settlementConnectionId;
    }

    public void setAccountType(CustomerContractType accountType) {
        this.accountType = accountType;
    }

    public CustomerContractType getAccountType() {
        return accountType;
    }

    public CustomerCategory getCategory() {
        return category;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public SettleTransaction getConnectedTrans() {
        return connectedTrans;
    }

    public void setConnectedTrans(SettleTransaction connectedTrans) {
        this.connectedTrans = connectedTrans;
    }

    public Boolean getIsReversed() {
        return isReversed;
    }

    public void setIsReversed(Boolean isReversed) {
        this.isReversed = isReversed;
    }

    public Date getSettleDate() {
        return settleDate;
    }

    public void setSettleDate(Date settleDate) {
        this.settleDate = settleDate;
    }

    public TransactionTypeCombination getTransTypeCombination() {
        return transTypeCombination;
    }

    public void setTransTypeCombination(TransactionTypeCombination transTypeCombination) {
        this.transTypeCombination = transTypeCombination;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Date getTransDate() {
        return transDate;
    }

    public void setTransDate(Date transDate) {
        this.transDate = transDate;
    }

    public String getRouteName() {
        return routeName;
    }

    public void setRouteName(String routeName) {
        this.routeName = routeName;
    }

    public Route getRoute() {
        return route;
    }

    public void setRoute(Route route) {
        this.route = route;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @InstanceName
    @DependsOnProperties({"accountNumber", "accountType", "amount"})
    public String getInstanceName() {
        return String.format("%s %s %s", accountNumber, accountType, amount);
    }
}