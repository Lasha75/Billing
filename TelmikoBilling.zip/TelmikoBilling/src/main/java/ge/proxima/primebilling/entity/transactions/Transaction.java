package ge.proxima.primebilling.entity.transactions;

import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.block.route.Route;
import ge.proxima.primebilling.entity.counter.Counter;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.customer.CustomerContractType;
import ge.proxima.primebilling.entity.enums.ChargeType;
import ge.proxima.primebilling.entity.enums.Cycle;
import ge.proxima.primebilling.entity.enums.DepositType;
import ge.proxima.primebilling.entity.tariff.Tariff;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.DeletePolicy;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_TRANSACTION", indexes = {
        @Index(name = "IDX_TRANSACTION_CUSTOMER_ID", columnList = "CUSTOMER_ID"),
        @Index(name = "IDX_TRANSACTION_BLOCK_ID", columnList = "BLOCK_ID"),
        @Index(name = "IDX_TRANSACTION", columnList = "TRANS_TYPE_COMBINATION_ID"),
        @Index(name = "IDX_TRANSACTION_CATEGORY_ID", columnList = "CATEGORY_ID"),
        @Index(name = "IDX_TRANSACTION", columnList = "ACCOUNT_TYPE_ID"),
        @Index(name = "IDX_TRANSACTION_TARIFF_ID", columnList = "TARIFF_ID"),
        @Index(name = "IDX_TRANSACTION_INVOICE_ID_ID", columnList = "INVOICE_ID"),
        @Index(name = "IDX_PRX_TRANSACTION_cust_Createdate_Delete", columnList = "CUSTOMER_ID, CREATED_DATE, DELETED_DATE, TL_ITEM_KEY"),
        @Index(name = "IDX_PRX_TRANSACTION_trans_cust", columnList = "CUSTOMER_ID, TRANS_TYPE_COMBINATION_ID, CREATED_DATE, DELETED_DATE"),
        @Index(name = "IDX_PRX_TRANSACTION_CHILED_COUNTER", columnList = "CHILED_COUNTER_ID"),
        @Index(name = "IDX_PRX_TRANSACTION_bank", columnList = "BANK_CODE, PAYMENT_DOC_NUMBER"),
        @Index(name = "IDX_PRX_TRANSACTION_counter", columnList = "COUNTER_NUMBER"),
        @Index(name = "IDX_PRX_TRANSACTION_customer", columnList = "CUSTOMER_NUMBER"),
        @Index(name = "IDX_PRX_TRANSACTION_tlitemkey", columnList = "TL_ITEM_KEY"),
        @Index(name = "IDX_PRXTRANSACTI_CHILEDCUSTOM", columnList = "CHILED_CUSTOMER_ID"),
        @Index(name = "IDX_PRX_TRANSACTION_OVERDUE", columnList = "CUSTOMER_ID, INVOICE_DATE, USED_IN_BILL, TRANS_TYPE_COMBINATION_ID"),
        @Index(name = "IDX_PRX_TRANSACTION", columnList = "CUSTOMER_ID, DELETED_BY, COUNTER_NUMBER, READ_DATE, TRANS_TYPE_COMBINATION_ID"),
        @Index(name = "IDX_PRX_TRANSACTION_1", columnList = "TELASI_ACCCOUNT_ID, CUSTOMER_ID, ACCOUNT_TYPE_ID"),
        @Index(name = "IDX_PRX_TRANSACTION_2", columnList = "ACCOUNT_TYPE_ID, CUSTOMER_ID"),
        @Index(name = "IDX_PRX_TRANSACTION_3", columnList = "CUSTOMER_ID, COUNTER_NUMBER")
})
@Entity(name = "prx_Transaction")
public class Transaction {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "STEP")
    private Integer step;

    @Column(name = "IS_MP_CHARGE")
    private Boolean isMPCharge;

    @Column(name = "WITH_GEL")
    private Boolean withGel;

    @Column(name = "TELASI_ACCCOUNT_ID", length = 40)
    private String telasiAcccountId;

    @Column(name = "TELASI_CHILED_ACCOUNT_ID", length = 40)
    private String telasiChiledAccountId;

    @JoinColumn(name = "CHILED_CUSTOMER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Customer chiledCustomer;

    @Column(name = "CYCLE_DAY_DIFFERENCE", precision = 19, scale = 0)
    private BigDecimal cycleDayDifference;

    @Column(name = "ENTER_DATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date enterDateTime;

    @Column(name = "IS_CORRECTED")
    private Boolean isCorrected;

    @JoinColumn(name = "CHILED_COUNTER_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Counter chiledCounter;

    @Column(name = "USED_IN_BILL")
    private Boolean usedInBill = false;

    @Column(name = "PAYMENT_PURPOSE")
    private String paymentPurpose;

    @Column(name = "INVOICE_ID")
    private UUID invoiceId;

    @Column(name = "CREATE_TIME_STAMP", length = 100)
    private String createTimeStamp;

    @Column(name = "PREV_REAL_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevRealDate;

    @Column(name = "VOUCHER", length = 50)
    private String voucher;

    @Column(name = "READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date readDate;

    @Column(name = "USED_IN_CHECK")
    private Boolean usedInCheck = false;

    @Column(name = "INVOICE_DATE")
    @Temporal(TemporalType.DATE)
    private Date invoiceDate;

    @JoinColumn(name = "CATEGORY_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerCategory category;

    @Column(name = "KILOWATT_HOUR", precision = 19, scale = 2)
    private BigDecimal kilowattHour = BigDecimal.ZERO;

    @Column(name = "INVOICE_IS_WRITTEN")
    private Boolean invoiceIsWritten = false;

    @JoinColumn(name = "CUSTOMER_ID", nullable = false)
    @NotNull
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Customer customer;

    @Column(name = "CUSTOMER_NUMBER", length = 100)
    private String customerNumber;

    @Column(name = "ACCOUNT_NUMBER", length = 100)
    private String accountNumber;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "ACCOUNT_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType accountType;

    @Column(name = "AMOUNT", precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(name = "CONSUMPTION")
    private Double consumption;

    @Column(name = "BANK_CODE", length = 200)
    private String bankCode;

    @Column(name = "BANK_TRANS_CODE", length = 300)
    private String bankTransCode;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "BLOCK_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Block block;

    @Column(name = "BLOCK_NAME", length = 100)
    private String blockName;

    @Column(name = "CATEGORY_NAME", length = 100)
    private String categoryName;

    @Column(name = "CHATGE_TYPE")
    private String chargeType;

    @Column(name = "TRANS_DATE", nullable = false)
    @Temporal(TemporalType.DATE)
    @NotNull
    private Date transDate;

    @Column(name = "DUE_DATE")
    @Temporal(TemporalType.DATE)
    private Date dueDate;

    @Column(name = "COUNTER_NUMBER", length = 90)
    private String counterNumber;

    @Column(name = "COUNTER_READING_VALUE")
    private BigDecimal counterReadingValue;

    @Column(name = "COUNTER_PREV_READING_VALUE")
    private BigDecimal counterPrevReadingValue;

    @Column(name = "COUNTER_SERIAL_NUMBER", length = 200)
    private String counterSerialNumber;

    @Column(name = "PARENT_CUSTOMER_NUMBER", length = 100)
    private String parentCustomerNumber;

    @Column(name = "PAYMENT_DOC_NUMBER", length = 250)
    private String paymentDocNumber;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "ROUTE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Route route;

    @Column(name = "ROUTE_NAME", length = 300)
    private String routeName;

    @Column(name = "TARIFF_NUMBER", length = 100)
    private String tariffNumber;

    @OnDeleteInverse(DeletePolicy.DENY)
    @NotNull
    @JoinColumn(name = "TRANS_TYPE_COMBINATION_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private TransactionTypeCombination transTypeCombination;

    @Column(name = "COMMENT_", length = 800)
    private String comment;

    @Column(name = "DEPOSIT_TYPE")
    private String depositType;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @OnDeleteInverse(DeletePolicy.DENY)
    @JoinColumn(name = "TARIFF_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private Tariff tariff;

    @Column(name = "VALUE_", precision = 19, scale = 2)
    private BigDecimal value;

    @Column(name = "BANK_GUARANTEE_START_DATE")
    @Temporal(TemporalType.DATE)
    private Date bankGuaranteeStartDate;

    @Column(name = "BANK_GUARANTEE_END_DATE")
    @Temporal(TemporalType.DATE)
    private Date bankGuaranteeEndDate;

    @Column(name = "BANK_GUARANTEE_NUMBER")
    private String bankGuaranteeNumber;

    @Column(name = "TL_BILL_OPER_KEY", precision = 8, scale = 0)
    private BigDecimal tlBillOperKey;

    @Column(name = "TL_ACC_KEY", precision = 8, scale = 0)
    private BigDecimal tlAccKey;

    @Column(name = "TL_CUST_KEY", precision = 8, scale = 0)
    private BigDecimal tlCustKey;

    @Column(name = "TL_SCHED_KEY", precision = 8, scale = 0)
    private BigDecimal tlSchedKey;

    @Column(name = "TL_PERS_KEY", precision = 8, scale = 0)
    private BigDecimal tlPersKey;

    @Column(name = "TL_SIGN_KEY", precision = 8, scale = 0)
    private BigDecimal tlSignKey;

    @Column(name = "TL_ITEM_DATE")
    @Temporal(TemporalType.DATE)
    private Date tlItemDate;

    @Column(name = "TL_ITEM_NUMBER", length = 60)
    private String tlItemNumber;

    @Column(name = "TL_READING", precision = 14, scale = 6)
    private BigDecimal tlReading;

    @Column(name = "TL_KWT", precision = 13, scale = 3)
    private BigDecimal tlKwt;

    @Column(name = "TL_AMOUNT", precision = 10, scale = 2)
    private BigDecimal tlAmount;

    @Column(name = "TL_BALANCE", precision = 10, scale = 2)
    private BigDecimal tlBalance;

    @Column(name = "TL_ENTER_DATE")
    @Temporal(TemporalType.DATE)
    private Date tlEnterDate;

    @Column(name = "TL_ITEM_CAT_KEY", precision = 1, scale = 0)
    private BigDecimal tlItemCatKey;

    @Column(name = "TL_NOTE_KEY", precision = 8, scale = 0)
    private BigDecimal tlNoteKey;

    @Column(name = "CYCLE_TYPE")
    private String cycleType;

    @Column(name = "PREV_READ_DATE")
    @Temporal(TemporalType.DATE)
    private Date prevReadDate;

    @Column(name = "PARENT_ID")
    private UUID parentId;

    @Column(name = "TL_ITEM_KEY", precision = 12, scale = 0)
    private BigDecimal tlItemKey;

    @Column(name = "TL_ACC_TAR_KEY", precision = 8, scale = 0)
    private BigDecimal tlAccTarKey;

    public Integer getStep() {
        return step;
    }

    public void setStep(Integer step) {
        this.step = step;
    }

    public Boolean getIsMPCharge() {
        return isMPCharge;
    }

    public void setIsMPCharge(Boolean isMPCharge) {
        this.isMPCharge = isMPCharge;
    }

    public Boolean getWithGel() {
        return withGel;
    }

    public void setWithGel(Boolean withGel) {
        this.withGel = withGel;
    }

    public Customer getChiledCustomer() {
        return chiledCustomer;
    }

    public void setChiledCustomer(Customer chiledCustomer) {
        this.chiledCustomer = chiledCustomer;
    }

    public String getTelasiChiledAccountId() {
        return telasiChiledAccountId;
    }

    public void setTelasiChiledAccountId(String telasiChiledAccountId) {
        this.telasiChiledAccountId = telasiChiledAccountId;
    }

    public String getTelasiAcccountId() {
        return telasiAcccountId;
    }

    public void setTelasiAcccountId(String telasiAcccountId) {
        this.telasiAcccountId = telasiAcccountId;
    }

    public BigDecimal getCycleDayDifference() {
        return cycleDayDifference;
    }

    public void setCycleDayDifference(BigDecimal cycleDayDifference) {
        this.cycleDayDifference = cycleDayDifference;
    }

    public Date getEnterDateTime() {
        return enterDateTime;
    }

    public void setEnterDateTime(Date enterDateTime) {
        this.enterDateTime = enterDateTime;
    }

    public Boolean getIsCorrected() {
        return isCorrected;
    }

    public void setIsCorrected(Boolean isCorrected) {
        this.isCorrected = isCorrected;
    }

    public String getVoucher() {
        return voucher;
    }

    public void setVoucher(String voucher) {
        this.voucher = voucher;
    }

    public Counter getChiledCounter() {
        return chiledCounter;
    }

    public void setChiledCounter(Counter chiledCounter) {
        this.chiledCounter = chiledCounter;
    }

    public String getCreateTimeStamp() {
        return createTimeStamp;
    }

    public void setCreateTimeStamp(String createTimeStamp) {
        this.createTimeStamp = createTimeStamp;
    }

    public String getPaymentPurpose() {
        return paymentPurpose;
    }

    public void setPaymentPurpose(String paymentPurpose) {
        this.paymentPurpose = paymentPurpose;
    }

    public BigDecimal getTlNoteKey() {
        return tlNoteKey;
    }

    public void setTlNoteKey(BigDecimal tlNoteKey) {
        this.tlNoteKey = tlNoteKey;
    }

    public BigDecimal getTlItemCatKey() {
        return tlItemCatKey;
    }

    public void setTlItemCatKey(BigDecimal tlItemCatKey) {
        this.tlItemCatKey = tlItemCatKey;
    }

    public Date getTlEnterDate() {
        return tlEnterDate;
    }

    public void setTlEnterDate(Date tlEnterDate) {
        this.tlEnterDate = tlEnterDate;
    }

    public BigDecimal getTlBalance() {
        return tlBalance;
    }

    public void setTlBalance(BigDecimal tlBalance) {
        this.tlBalance = tlBalance;
    }

    public BigDecimal getTlAmount() {
        return tlAmount;
    }

    public void setTlAmount(BigDecimal tlAmount) {
        this.tlAmount = tlAmount;
    }

    public BigDecimal getTlKwt() {
        return tlKwt;
    }

    public void setTlKwt(BigDecimal tlKwt) {
        this.tlKwt = tlKwt;
    }

    public BigDecimal getTlReading() {
        return tlReading;
    }

    public void setTlReading(BigDecimal tlReading) {
        this.tlReading = tlReading;
    }

    public String getTlItemNumber() {
        return tlItemNumber;
    }

    public void setTlItemNumber(String tlItemNumber) {
        this.tlItemNumber = tlItemNumber;
    }

    public Date getTlItemDate() {
        return tlItemDate;
    }

    public void setTlItemDate(Date tlItemDate) {
        this.tlItemDate = tlItemDate;
    }

    public BigDecimal getTlSignKey() {
        return tlSignKey;
    }

    public void setTlSignKey(BigDecimal tlSignKey) {
        this.tlSignKey = tlSignKey;
    }

    public BigDecimal getTlPersKey() {
        return tlPersKey;
    }

    public void setTlPersKey(BigDecimal tlPersKey) {
        this.tlPersKey = tlPersKey;
    }

    public BigDecimal getTlSchedKey() {
        return tlSchedKey;
    }

    public void setTlSchedKey(BigDecimal tlSchedKey) {
        this.tlSchedKey = tlSchedKey;
    }

    public BigDecimal getTlCustKey() {
        return tlCustKey;
    }

    public void setTlCustKey(BigDecimal tlCustKey) {
        this.tlCustKey = tlCustKey;
    }

    public BigDecimal getTlAccKey() {
        return tlAccKey;
    }

    public void setTlAccKey(BigDecimal tlAccKey) {
        this.tlAccKey = tlAccKey;
    }

    public BigDecimal getTlBillOperKey() {
        return tlBillOperKey;
    }

    public void setTlBillOperKey(BigDecimal tlBillOperKey) {
        this.tlBillOperKey = tlBillOperKey;
    }

    public BigDecimal getTlAccTarKey() {
        return tlAccTarKey;
    }

    public void setTlAccTarKey(BigDecimal tlAccTarKey) {
        this.tlAccTarKey = tlAccTarKey;
    }

    public BigDecimal getTlItemKey() {
        return tlItemKey;
    }

    public void setTlItemKey(BigDecimal tlItemKey) {
        this.tlItemKey = tlItemKey;
    }

    public UUID getParentId() {
        return parentId;
    }

    public void setParentId(UUID parentId) {
        this.parentId = parentId;
    }

    public void setInvoiceId(UUID invoiceId) {
        this.invoiceId = invoiceId;
    }

    public UUID getInvoiceId() {
        return invoiceId;
    }

    public Date getPrevRealDate() {
        return prevRealDate;
    }

    public void setPrevRealDate(Date prevRealDate) {
        this.prevRealDate = prevRealDate;
    }

    public Date getPrevReadDate() {
        return prevReadDate;
    }

    public void setPrevReadDate(Date prevReadDate) {
        this.prevReadDate = prevReadDate;
    }

    public Date getReadDate() {
        return readDate;
    }

    public void setReadDate(Date readDate) {
        this.readDate = readDate;
    }

    public Cycle getCycleType() {
        return cycleType == null ? null : Cycle.fromId(cycleType);
    }

    public void setCycleType(Cycle cycleType) {
        this.cycleType = cycleType == null ? null : cycleType.getId();
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public Tariff getTariff() {
        return tariff;
    }

    public void setTariff(Tariff tariff) {
        this.tariff = tariff;
    }

    public Boolean getUsedInBill() {
        return usedInBill;
    }

    public void setUsedInBill(Boolean usedInBill) {
        this.usedInBill = usedInBill;
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public Boolean getUsedInCheck() {
        return usedInCheck;
    }

    public void setUsedInCheck(Boolean usedInCheck) {
        this.usedInCheck = usedInCheck;
    }

    public BigDecimal getKilowattHour() {
        return kilowattHour;
    }

    public void setKilowattHour(BigDecimal kilowattHour) {
        this.kilowattHour = kilowattHour;
    }

    public Boolean getInvoiceIsWritten() {
        return invoiceIsWritten;
    }

    public void setInvoiceIsWritten(Boolean invoiceIsWritten) {
        this.invoiceIsWritten = invoiceIsWritten;
    }

    public Date getBankGuaranteeStartDate() {
        return bankGuaranteeStartDate;
    }

    public void setBankGuaranteeStartDate(Date bankGuaranteeStartDate) {
        this.bankGuaranteeStartDate = bankGuaranteeStartDate;
    }

    public Date getBankGuaranteeEndDate() {
        return bankGuaranteeEndDate;
    }

    public void setBankGuaranteeEndDate(Date bankGuaranteeEndDate) {
        this.bankGuaranteeEndDate = bankGuaranteeEndDate;
    }

    public String getBankGuaranteeNumber() {
        return bankGuaranteeNumber;
    }

    public void setBankGuaranteeNumber(String bankGuaranteeNumber) {
        this.bankGuaranteeNumber = bankGuaranteeNumber;
    }

    public DepositType getDepositType() {
        return depositType == null ? null : DepositType.fromId(depositType);
    }

    public void setDepositType(DepositType depositType) {
        this.depositType = depositType == null ? null : depositType.getId();
    }

    public void setCounterReadingValue(BigDecimal counterReadingValue) {
        this.counterReadingValue = counterReadingValue;
    }

    public BigDecimal getCounterReadingValue() {
        return counterReadingValue;
    }

    public void setCounterPrevReadingValue(BigDecimal counterPrevReadingValue) {
        this.counterPrevReadingValue = counterPrevReadingValue;
    }

    public BigDecimal getCounterPrevReadingValue() {
        return counterPrevReadingValue;
    }

    public void setAccountType(CustomerContractType accountType) {
        this.accountType = accountType;
    }

    public CustomerContractType getAccountType() {
        return accountType;
    }

    public CustomerCategory getCategory() {
        return category;
    }

    public void setCategory(CustomerCategory category) {
        this.category = category;
    }

    public TransactionTypeCombination getTransTypeCombination() {
        return transTypeCombination;
    }

    public void setTransTypeCombination(TransactionTypeCombination transTypeCombination) {
        this.transTypeCombination = transTypeCombination;
    }

    public String getTariffNumber() {
        return tariffNumber;
    }

    public void setTariffNumber(String tariffNumber) {
        this.tariffNumber = tariffNumber;
    }

    public String getRouteName() {
        return routeName;
    }

    public void setRouteName(String routeName) {
        this.routeName = routeName;
    }

    public Route getRoute() {
        return route;
    }

    public void setRoute(Route route) {
        this.route = route;
    }

    public String getPaymentDocNumber() {
        return paymentDocNumber;
    }

    public void setPaymentDocNumber(String paymentDocNumber) {
        this.paymentDocNumber = paymentDocNumber;
    }

    public String getParentCustomerNumber() {
        return parentCustomerNumber;
    }

    public void setParentCustomerNumber(String parentCustomerNumber) {
        this.parentCustomerNumber = parentCustomerNumber;
    }

    public String getCounterSerialNumber() {
        return counterSerialNumber;
    }

    public void setCounterSerialNumber(String counterSerialNumber) {
        this.counterSerialNumber = counterSerialNumber;
    }

    public String getCounterNumber() {
        return counterNumber;
    }

    public void setCounterNumber(String counterNumber) {
        this.counterNumber = counterNumber;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Date getTransDate() {
        return transDate;
    }

    public void setTransDate(Date transDate) {
        this.transDate = transDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public ChargeType getChargeType() {
        return chargeType == null ? null : ChargeType.fromId(chargeType);
    }

    public void setChargeType(ChargeType chargeType) {
        this.chargeType = chargeType == null ? null : chargeType.getId();
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public Block getBlock() {
        return block;
    }

    public void setBlock(Block block) {
        this.block = block;
    }

    public String getBankTransCode() {
        return bankTransCode;
    }

    public void setBankTransCode(String bankTransCode) {
        this.bankTransCode = bankTransCode;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public Double getConsumption() {
        return consumption;
    }

    public void setConsumption(Double consumption) {
        this.consumption = consumption;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }


    @PreUpdate
    public void preUpdate() {
        if (getCustomer() != null) {
            setCustomerNumber(getCustomer().getCustomerNumber());
        }

        if (getTransTypeCombination() != null) {
            setAccountType(getTransTypeCombination().getContractType());
        }
    }

    @DependsOnProperties({"accountNumber", "accountType", "amount", "transDate", "transTypeCombination"})
    public String getInstanceName() {
        return String.format("%s %s %s %s %s", accountNumber, accountType, amount, transDate, transTypeCombination);
    }
}