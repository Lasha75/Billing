package ge.proxima.primebilling.entity.transactions;

import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import ge.proxima.primebilling.entity.transactions.transtypes.transactiontype.TransactionType;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_TRANSACTION_CREATOR_SETUP", indexes = {
        @Index(name = "IDX_TRANSACTIONCREATORSETUP", columnList = "TRANSACTION_COMBINATION_ID"),
        @Index(name = "IDX_TRANSACTIONCREATORSETUP", columnList = "TRANSACTION_TYPE_ID")
})
@Entity(name = "prx_TransactionCreatorSetup")
public class TransactionCreatorSetup {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    @NotNull
    @InstanceName
    @Column(name = "NAME", nullable = false)
    private String name;

    @Column(name = "WRECKING")
    private Boolean wrecking = false;

    @NotNull
    @JoinColumn(name = "TRANSACTION_COMBINATION_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private TransactionTypeCombination transactionCombination;

    @JoinColumn(name = "TRANSACTION_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private TransactionType transactionType;

    @Column(name = "COUNTER_NUMBER")
    private Boolean counterNumber = false;

    @Column(name = "READING")
    private Boolean reading = false;

    @Column(name = "KILOWATT")
    private Boolean kilowatt = false;

    @Column(name = "TARIFF")
    private Boolean tariff = false;

    @Column(name = "AMOUNT")
    private Boolean amount = false;

    @Column(name = "CUSTOMER_CODE_RECEIVER")
    private Boolean customerCodeReceiver = false;

    @Column(name = "CONTRACT_NUMBER_RECEIVER")
    private Boolean contractNumberReceiver = false;

    @Column(name = "AMOUNT_RECEIVER")
    private Boolean amountReceiver = false;

    @Column(name = "DEBT")
    private Boolean debt = false;

    public Boolean getDebt() {
        return debt;
    }

    public void setDebt(Boolean debt) {
        this.debt = debt;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public Boolean getWrecking() {
        return wrecking;
    }

    public void setWrecking(Boolean wrecking) {
        this.wrecking = wrecking;
    }

    public Boolean getAmountReceiver() {
        return amountReceiver;
    }

    public void setAmountReceiver(Boolean amountReceiver) {
        this.amountReceiver = amountReceiver;
    }

    public Boolean getContractNumberReceiver() {
        return contractNumberReceiver;
    }

    public void setContractNumberReceiver(Boolean contractNumberReceiver) {
        this.contractNumberReceiver = contractNumberReceiver;
    }

    public Boolean getCustomerCodeReceiver() {
        return customerCodeReceiver;
    }

    public void setCustomerCodeReceiver(Boolean customerCodeReceiver) {
        this.customerCodeReceiver = customerCodeReceiver;
    }

    public Boolean getAmount() {
        return amount;
    }

    public void setAmount(Boolean amount) {
        this.amount = amount;
    }

    public Boolean getTariff() {
        return tariff;
    }

    public void setTariff(Boolean tariff) {
        this.tariff = tariff;
    }

    public Boolean getKilowatt() {
        return kilowatt;
    }

    public void setKilowatt(Boolean kilowatt) {
        this.kilowatt = kilowatt;
    }

    public Boolean getReading() {
        return reading;
    }

    public void setReading(Boolean reading) {
        this.reading = reading;
    }

    public Boolean getCounterNumber() {
        return counterNumber;
    }

    public void setCounterNumber(Boolean counterNumber) {
        this.counterNumber = counterNumber;
    }

    public TransactionTypeCombination getTransactionCombination() {
        return transactionCombination;
    }

    public void setTransactionCombination(TransactionTypeCombination transactionCombination) {
        this.transactionCombination = transactionCombination;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}