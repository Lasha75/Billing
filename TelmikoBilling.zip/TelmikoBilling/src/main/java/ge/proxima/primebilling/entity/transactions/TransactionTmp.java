package ge.proxima.primebilling.entity.transactions;

import ge.proxima.primebilling.entity.enums.Cycle;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.JmixId;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity(name = "prx_TransactionTmp")
public class TransactionTmp {
    @JmixGeneratedValue
    @JmixId
    private UUID id;

    private Boolean markCancel;

    private Boolean mark;

    @Temporal(TemporalType.DATE)
    private Date prevRealDate;

    private Boolean manuallyCreated;

    @Temporal(TemporalType.DATE)
    private Date operationDate;

    @Temporal(TemporalType.DATE)
    private Date readingDate;

    private BigDecimal kilowatt;

    private BigDecimal reading;

    @Temporal(TemporalType.DATE)
    private Date newPrevReadingDate;

    private BigDecimal prevReading;

    @Temporal(TemporalType.DATE)
    private Date prevReadingDate;

    private BigDecimal amount;

    private String cycleType;

    private Transaction transaction;

    @Temporal(TemporalType.DATE)
    private Date cycleStartDate;

    @Temporal(TemporalType.DATE)
    private Date cycleEndDate;

    private BigDecimal readingDifference;

    private BigDecimal sumTransKilowatt;

    private BigDecimal sumTransAmount;

    private Transaction sumTrans;

    private BigDecimal newSumTransKilowatt;

    private BigDecimal newSumTransAmount;

    private BigDecimal newKilowatt;

    private BigDecimal newAmount;

    private TransactionTypeCombination transactionCombinationType;

    private Boolean isLegal = false;

    public Boolean getMarkCancel() {
        return markCancel;
    }

    public void setMarkCancel(Boolean markCancel) {
        this.markCancel = markCancel;
    }

    public void setNewPrevReadingDate(Date newPrevReadingDate) {
        this.newPrevReadingDate = newPrevReadingDate;
    }

    public Date getNewPrevReadingDate() {
        return newPrevReadingDate;
    }

    public Date getPrevRealDate() {
        return prevRealDate;
    }

    public void setPrevRealDate(Date prevRealDate) {
        this.prevRealDate = prevRealDate;
    }

    public Boolean getManuallyCreated() {
        return manuallyCreated;
    }

    public void setManuallyCreated(Boolean manuallyCreated) {
        this.manuallyCreated = manuallyCreated;
    }

    public Boolean getIsLegal() {
        return isLegal;
    }

    public void setIsLegal(Boolean isLegal) {
        this.isLegal = isLegal;
    }

    public void setSumTrans(Transaction sumTrans) {
        this.sumTrans = sumTrans;
    }

    public Transaction getSumTrans() {
        return sumTrans;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public Date getPrevReadingDate() {
        return prevReadingDate;
    }

    public void setPrevReadingDate(Date prevReadingDate) {
        this.prevReadingDate = prevReadingDate;
    }

    public TransactionTypeCombination getTransactionCombinationType() {
        return transactionCombinationType;
    }

    public void setTransactionCombinationType(TransactionTypeCombination transactionCombinationType) {
        this.transactionCombinationType = transactionCombinationType;
    }

    public Boolean getMark() {
        return mark;
    }

    public void setMark(Boolean mark) {
        this.mark = mark;
    }

    public void setNewSumTransKilowatt(BigDecimal newSumTransKilowatt) {
        this.newSumTransKilowatt = newSumTransKilowatt;
    }

    public BigDecimal getNewSumTransKilowatt() {
        return newSumTransKilowatt;
    }

    public BigDecimal getNewSumTransAmount() {
        return newSumTransAmount;
    }

    public void setNewSumTransAmount(BigDecimal newSumTransAmount) {
        this.newSumTransAmount = newSumTransAmount;
    }

    public BigDecimal getReadingDifference() {
        return readingDifference;
    }

    public void setReadingDifference(BigDecimal readingDifference) {
        this.readingDifference = readingDifference;
    }

    public BigDecimal getSumTransAmount() {
        return sumTransAmount;
    }

    public void setSumTransAmount(BigDecimal sumTransAmount) {
        this.sumTransAmount = sumTransAmount;
    }

    public BigDecimal getPrevReading() {
        return prevReading;
    }

    public void setPrevReading(BigDecimal prevReading) {
        this.prevReading = prevReading;
    }

    public BigDecimal getNewAmount() {
        return newAmount;
    }

    public void setNewAmount(BigDecimal newAmount) {
        this.newAmount = newAmount;
    }

    public BigDecimal getNewKilowatt() {
        return newKilowatt;
    }

    public void setNewKilowatt(BigDecimal newKilowatt) {
        this.newKilowatt = newKilowatt;
    }

    public BigDecimal getSumTransKilowatt() {
        return sumTransKilowatt;
    }

    public void setSumTransKilowatt(BigDecimal sumTransKilowatt) {
        this.sumTransKilowatt = sumTransKilowatt;
    }

    public Date getCycleEndDate() {
        return cycleEndDate;
    }

    public void setCycleEndDate(Date cycleEndDate) {
        this.cycleEndDate = cycleEndDate;
    }

    public Date getCycleStartDate() {
        return cycleStartDate;
    }

    public void setCycleStartDate(Date cycleStartDate) {
        this.cycleStartDate = cycleStartDate;
    }

    public Cycle getCycleType() {
        return cycleType == null ? null : Cycle.fromId(cycleType);
    }

    public void setCycleType(Cycle cycleType) {
        this.cycleType = cycleType == null ? null : cycleType.getId();
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getReading() {
        return reading;
    }

    public void setReading(BigDecimal reading) {
        this.reading = reading;
    }

    public BigDecimal getKilowatt() {
        return kilowatt;
    }

    public void setKilowatt(BigDecimal kilowatt) {
        this.kilowatt = kilowatt;
    }

    public Date getReadingDate() {
        return readingDate;
    }

    public void setReadingDate(Date readingDate) {
        this.readingDate = readingDate;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}