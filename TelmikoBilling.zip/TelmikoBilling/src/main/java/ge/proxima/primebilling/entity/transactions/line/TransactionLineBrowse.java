package ge.proxima.primebilling.entity.transactions.line;

import ge.proxima.primebilling.screen.customer.customer.CustomerEdit;
import ge.proxima.primebilling.screen.transactions.transactionsdisplay.TransactionsDisplayScreen;
import io.jmix.ui.Screens;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.transactions.line.TransactionLine;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("prx_TransactionLine.browse")
@UiDescriptor("transaction-line-browse.xml")
@LookupComponent("transactionLinesTable")
public class TransactionLineBrowse extends StandardLookup<TransactionLine> {


    @Autowired
    private Screens screens;
    @Autowired
    private CollectionLoader<TransactionLine> transactionLinesDl;

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        setScreenAppearance();
    }

    private void setScreenAppearance() {
        Object[] breadcrumbs = screens.getOpenedScreens().getCurrentBreadcrumbs().toArray();
        if(breadcrumbs.length >= 1 && breadcrumbs[0] instanceof TransactionsDisplayScreen transactionsDisplayScreen) {
            transactionLinesDl.setParameter("transactionId", transactionsDisplayScreen.getUUID());
            transactionLinesDl.load();
        }
    }
}