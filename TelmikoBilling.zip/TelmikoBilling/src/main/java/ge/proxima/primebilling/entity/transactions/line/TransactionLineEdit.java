package ge.proxima.primebilling.entity.transactions.line;

import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.transactions.line.TransactionLine;

@UiController("prx_TransactionLine.edit")
@UiDescriptor("transaction-line-edit.xml")
@EditedEntityContainer("transactionLineDc")
public class TransactionLineEdit extends StandardEditor<TransactionLine> {
}