package ge.proxima.primebilling.entity.transactions.transtypes;

import ge.proxima.primebilling.entity.BCourtCaseEventTable;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Entity;

@JmixEntity
@Entity(name = "prx_BCourtReturnPreTrial")
public class BCourtReturnPreTrial extends BCourtCaseEventTable {
}