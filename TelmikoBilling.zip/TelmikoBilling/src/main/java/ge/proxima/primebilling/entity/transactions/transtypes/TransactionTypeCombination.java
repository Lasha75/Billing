package ge.proxima.primebilling.entity.transactions.transtypes;

import ge.proxima.primebilling.entity.customer.CustomerContractType;
import ge.proxima.primebilling.entity.transactions.transtypes.transactionsubtype.TransactionSubType;
import ge.proxima.primebilling.entity.transactions.transtypes.transactiontype.TransactionType;
import io.jmix.core.DeletePolicy;
import io.jmix.core.annotation.DeletedBy;
import io.jmix.core.annotation.DeletedDate;
import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.entity.annotation.OnDeleteInverse;
import io.jmix.core.metamodel.annotation.DependsOnProperties;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "PRX_TRANSACTION_TYPE_COMBINATI", indexes = {
        @Index(name = "IDX_TRANSACTIONTYPECOMBINATION", columnList = "TYPE_ID"),
        @Index(name = "IDX_TRANSACTIONTYPECOMBINATION", columnList = "TRANSACTION_SUB_TYPE_ID"),
        @Index(name = "IDX_TRANSACTIONTYPECOMBINATION", columnList = "CONTRACT_TYPE_ID"),
        @Index(name = "IDX_PRX_TRANSACTION_TYPE_COMBINATION", columnList = "OPERATION_KEY"),
        @Index(name = "IDX_PRX_TRANSACTION_TYPE_COMBINATION_UNQ", columnList = "TRANSACTION_SUB_TYPE_ID, TRANSACTION_TYPE_ID, CONTRACT_TYPE_ID", unique = true)
})
@Entity(name = "prx_TransactionTypeCombination")
public class TransactionTypeCombination {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;

    @Column(name = "BILL_PREV_TEXT", length = 100)
    private String billPrevText;

    @Column(name = "TELASI_OPER_KEY")
    private Integer telasiOperKey;

    @Column(name = "ORDER_LEVEL")
    private Integer orderLevel;

    @Column(name = "IS_PAYMENT")
    private Boolean isPayment;

    @JoinColumn(name = "CONTRACT_TYPE_ID")
    @ManyToOne(fetch = FetchType.LAZY)
    private CustomerContractType contractType;

    @OnDeleteInverse(DeletePolicy.DENY)
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "TRANSACTION_TYPE_ID", nullable = false)
    @NotNull
    private TransactionType transactionType;

    @Column(name = "IS_CANCELED")
    private Boolean isCanceled = false;

    @OnDeleteInverse(DeletePolicy.DENY)
    @NotNull
    @JoinColumn(name = "TRANSACTION_SUB_TYPE_ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private TransactionSubType transactionSubType;

    @Column(name = "VERSION", nullable = false)
    @Version
    private Integer version;

    @CreatedBy
    @Column(name = "CREATED_BY")
    private String createdBy;

    @CreatedDate
    @Column(name = "CREATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name = "PRIORITY")
    private Integer priority;

    @Column(name = "OPERATION_KEY", precision = 19, scale = 2)
    private BigDecimal operationKey;

    @Column(name = "DEBIT_ACCOUNT_NUMBER", length = 100)
    private String debitAccountNumber;

    @Column(name = "CREDIT_ACCOUNT_NUMBER", length = 100)
    private String creditAccountNumber;

    @LastModifiedBy
    @Column(name = "LAST_MODIFIED_BY")
    private String lastModifiedBy;

    @LastModifiedDate
    @Column(name = "LAST_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastModifiedDate;

    @DeletedBy
    @Column(name = "DELETED_BY")
    private String deletedBy;

    @DeletedDate
    @Column(name = "DELETED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedDate;

    public String getBillPrevText() {
        return billPrevText;
    }

    public void setBillPrevText(String billPrevText) {
        this.billPrevText = billPrevText;
    }

    public Integer getTelasiOperKey() {
        return telasiOperKey;
    }

    public void setTelasiOperKey(Integer telasiOperKey) {
        this.telasiOperKey = telasiOperKey;
    }

    public Integer getOrderLevel() {
        return orderLevel;
    }

    public void setOrderLevel(Integer orderLevel) {
        this.orderLevel = orderLevel;
    }

    public String getCreditAccountNumber() {
        return creditAccountNumber;
    }

    public void setCreditAccountNumber(String creditAccountNumber) {
        this.creditAccountNumber = creditAccountNumber;
    }

    public String getDebitAccountNumber() {
        return debitAccountNumber;
    }

    public void setDebitAccountNumber(String debitAccountNumber) {
        this.debitAccountNumber = debitAccountNumber;
    }

    public Boolean getIsPayment() {
        return isPayment;
    }

    public void setIsPayment(Boolean isPayment) {
        this.isPayment = isPayment;
    }

    public BigDecimal getOperationKey() {
        return operationKey;
    }

    public void setOperationKey(BigDecimal operationKey) {
        this.operationKey = operationKey;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public CustomerContractType getContractType() {
        return contractType;
    }

    public void setContractType(CustomerContractType contractType) {
        this.contractType = contractType;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public Boolean getIsCanceled() {
        return isCanceled;
    }

    public void setIsCanceled(Boolean isCanceled) {
        this.isCanceled = isCanceled;
    }

    public TransactionSubType getTransactionSubType() {
        return transactionSubType;
    }

    public void setTransactionSubType(TransactionSubType transactionSubType) {
        this.transactionSubType = transactionSubType;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @PrePersist
    public void prePersist() {
        checkUniqueness();
    }

    @PreUpdate
    public void preUpdate() {
        checkUniqueness();
    }

    private void checkUniqueness() {
       /* DataManager dataManager = AppBeans.getBean(DataManager.class);
        TransactionTypeCombination transactionTypeCombination = dataManager.load(TransactionTypeCombination.class)
                .query("select e from prx_TransactionTypeCombination e where e.transactionType.code = " +
                        ":transType and e.transactionSubType.code = :transSubType and e.isCanceled = false and e.id <> :id")
                .parameter("transType", getTransactionType().getCode())
                .parameter("transSubType", getTransactionSubType().getCode())
                .parameter("id", getId())
                .optional().orElse(null);

        if (transactionTypeCombination != null) {
            Messages messages = AppBeans.getBean(Messages.class);
            throw new RuntimeException(messages.getMessage(this.getClass(), "uniquenessError"));
        }*/
    }

    @InstanceName
    @DependsOnProperties({"transactionType", "transactionSubType"})
    public String getInstanceName() {
        return String.format("%s %s", transactionType == null ? " - " : transactionType.getName() == null ? transactionType.getId().toString() : transactionType.getName(),
                transactionSubType == null ? " - " : transactionSubType.getName() == null ? transactionSubType.getId().toString() : transactionSubType.getName());
    }
}