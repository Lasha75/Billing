package ge.proxima.primebilling.entity.transcorrection;

import ge.proxima.primebilling.entity.NonCircularTransactionStatus;
import ge.proxima.primebilling.entity.counter.Counter;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.enums.CounterSpeedCalculationType;
import ge.proxima.primebilling.entity.enums.CounterSpeedCorrectionType;
import ge.proxima.primebilling.entity.enums.TransactionCorrectionType;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.util.Date;

@JmixEntity(name = "prx_TransactionCorrection")
public class TransactionCorrection {
    private Customer customer;

    private Counter counter;

    private Counter installedCounter;

    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Temporal(TemporalType.DATE)
    private Date endDate;

    private String counterSpeedCorrectionType;

    private String counterSpeedCalculationType;

    private BigDecimal counterSpeedCorrectionValue;

    @Temporal(TemporalType.DATE)
    private Date prevYearPeriodStart;

    @Temporal(TemporalType.DATE)
    private Date prevYearPeriodEnd;

    private BigDecimal averageUsage;

    private TransactionTypeCombination accrualType;

    private Boolean chargeFromAbove;

    private String nonCircularTransaStatus;

    private String operationType;

    private BigDecimal additionalKilowatt;

    public void setNonCircularTransaStatus(NonCircularTransactionStatus nonCircularTransaStatus) {
        this.nonCircularTransaStatus = nonCircularTransaStatus == null ? null : nonCircularTransaStatus.getId();
    }

    public NonCircularTransactionStatus getNonCircularTransaStatus() {
        return nonCircularTransaStatus == null ? null : NonCircularTransactionStatus.fromId(nonCircularTransaStatus);
    }

    public BigDecimal getAdditionalKilowatt() {
        return additionalKilowatt;
    }

    public void setAdditionalKilowatt(BigDecimal additionalKilowatt) {
        this.additionalKilowatt = additionalKilowatt;
    }

    public Counter getInstalledCounter() {
        return installedCounter;
    }

    public void setInstalledCounter(Counter installedCounter) {
        this.installedCounter = installedCounter;
    }

    public TransactionCorrectionType getOperationType() {
        return operationType == null ? null : TransactionCorrectionType.fromId(operationType);
    }

    public void setOperationType(TransactionCorrectionType operationType) {
        this.operationType = operationType == null ? null : operationType.getId();
    }

    public BigDecimal getCounterSpeedCorrectionValue() {
        return counterSpeedCorrectionValue;
    }

    public void setCounterSpeedCorrectionValue(BigDecimal counterSpeedCorrectionValue) {
        this.counterSpeedCorrectionValue = counterSpeedCorrectionValue;
    }

    public CounterSpeedCalculationType getCounterSpeedCalculationType() {
        return counterSpeedCalculationType == null ? null : CounterSpeedCalculationType.fromId(counterSpeedCalculationType);
    }

    public void setCounterSpeedCalculationType(CounterSpeedCalculationType counterSpeedCalculationType) {
        this.counterSpeedCalculationType = counterSpeedCalculationType == null ? null : counterSpeedCalculationType.getId();
    }

    public CounterSpeedCorrectionType getCounterSpeedCorrectionType() {
        return counterSpeedCorrectionType == null ? null : CounterSpeedCorrectionType.fromId(counterSpeedCorrectionType);
    }

    public void setCounterSpeedCorrectionType(CounterSpeedCorrectionType counterSpeedCorrectionType) {
        this.counterSpeedCorrectionType = counterSpeedCorrectionType == null ? null : counterSpeedCorrectionType.getId();
    }

    public Boolean getChargeFromAbove() {
        return chargeFromAbove;
    }

    public void setChargeFromAbove(Boolean chargeFromAbove) {
        this.chargeFromAbove = chargeFromAbove;
    }

    public TransactionTypeCombination getAccrualType() {
        return accrualType;
    }

    public void setAccrualType(TransactionTypeCombination accrualType) {
        this.accrualType = accrualType;
    }

    public BigDecimal getAverageUsage() {
        return averageUsage;
    }

    public void setAverageUsage(BigDecimal averageUsage) {
        this.averageUsage = averageUsage;
    }

    public Date getPrevYearPeriodEnd() {
        return prevYearPeriodEnd;
    }

    public void setPrevYearPeriodEnd(Date prevYearPeriodEnd) {
        this.prevYearPeriodEnd = prevYearPeriodEnd;
    }

    public Date getPrevYearPeriodStart() {
        return prevYearPeriodStart;
    }

    public void setPrevYearPeriodStart(Date prevYearPeriodStart) {
        this.prevYearPeriodStart = prevYearPeriodStart;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Counter getCounter() {
        return counter;
    }

    public void setCounter(Counter counter) {
        this.counter = counter;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}