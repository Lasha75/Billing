package ge.proxima.primebilling.java.aggregation;

import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.Messages;
import io.jmix.ui.component.data.aggregation.AggregationStrategy;

import java.math.BigDecimal;
import java.util.Collection;

public class OpenTransactionsAggregation implements AggregationStrategy<BigDecimal, String> {
    @Override
    public String aggregate(Collection<BigDecimal> propertyValues) {

        Messages messages = AppBeans.getBean(Messages.class);

        BigDecimal total = BigDecimal.ZERO;

        for (BigDecimal item : propertyValues) {
            total = total.add(item == null ? BigDecimal.ZERO : item);
        }
        return messages.formatMessage(getClass(), "sum", total.toString());
    }

    @Override
    public Class<String> getResultClass() {
        return String.class;
    }
}
