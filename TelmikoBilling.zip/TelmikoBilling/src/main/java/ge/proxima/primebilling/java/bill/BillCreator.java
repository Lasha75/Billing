package ge.proxima.primebilling.java.bill;

import ge.proxima.primebilling.entity.bill.Bill;
import ge.proxima.primebilling.java.models.Properties;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.numerator.NumeratorService;
import io.jmix.core.TimeSource;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;

import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

public class BillCreator {
    private Connection connection;
    private TimeSource timeSource;
    private CurrentUserSubstitution currentUserSubstitution;
    private PreparedStatement preparedStatement;
    private NumeratorService numeratorService;
    private java.sql.Date sqlDate;
    private String username;

    public BillCreator() throws SQLException {
        timeSource = AppBeans.getBean(TimeSource.class);
        currentUserSubstitution = AppBeans.getBean(CurrentUserSubstitution.class);
        numeratorService = AppBeans.getBean(NumeratorService.class);

        Properties properties = AppBeans.getBean(Properties.class);

        sqlDate = new java.sql.Date(timeSource.currentTimeMillis());
        username = currentUserSubstitution.getAuthenticatedUser().getUsername();

        connection = DriverManager.getConnection(properties.get("main.datasource.url"), properties.get("main.datasource.username"), properties.get("main.datasource.password"));
        preparedStatement = connection.prepareStatement(
                "INSERT INTO PRX_BILL (ID," +
                        "VERSION," +
                        "CREATED_BY," +
                        "CREATED_DATE," +
                        "BILL_NUMBER," +
                        "PAYMENT_DATE," +
                        "BILL_CREATION_DATE," +
                        "CUSTOMER_NUMBER," +
                        "CUSTOMER_FULL_NAME," +
                        "CUSTOMER_ADDRESS," +
                        "AMOUNT," +
                        "ILLEGAL_USE_CHARGE_AMOUNT," +
                        "RECORDING_KNOT_CHECK," +
                        "ADVANCE_PAID_AMOUNT," +
                        "CURRENT_ACCRUAL," +
                        "PREVIOUS_AMOUNT," +
                        "DEPOSIT_AMOUNT," +
                        "CORRECTION_AMOUNT," +
                        "COUNTER_SERIAL_NUMBER," +
                        "COEFFICIENT," +
                        "TARIFF_VALUE," +
                        "DATE_," +
                        "READING_TYPE," +
                        "READING," +
                        "KILOWATT," +
                        "EXPENSE_AMOUNT_GEL," +
                        "PAYED_AMOUNT," +
                        "SUPPLY_SERVICE_AMOUNT," +
                        "DISTRIBUTION_SERVICE_AMOUNT," +
                        "TRANSMISSION_SERVICE_AMOUNT," +
                        "SUPPLY_RENEWAL_AMOUNT," +
                        "VAT," +
                        "SERVICE_QUALITY_COMPENSATION," +
                        "REQUESTED_DEPOSIT," +
                        "RESTRUCTURED_DEBT," +
                        "CONTRACT_PENALTY," +
                        "HIGHLAND_SETTLEMENTS_SUBSIDY," +
                        "TARIFF_SUBSIDY," +
                        "MULTICHILD_SUBSIDY," +
                        "OTHER," +
                        "PREVIOUS_BILL_LEFT_AMOUNT," +
                        "NETWORK_DELIVERED_KILOWATT," +
                        "NETWORK_ACCESSION," +
                        "DEDUCTED_KILOWATT," +
                        "POSITIVE_BALANCE_KILOWATT," +
                        "PURCHASED_ELECTRICITY_AMOUNT," +
                        "DISPUTED_DEBT," +
                        "RESTRUCTURED_AMOUNT_LEFT," +
                        "LEFT_OLD_AMOUNT," +
                        "OPERATOR_RESTRUCTURED_AMOUNT_LEFT," +
                        "OPERATOR_RESTRUCTURED_AMOUNT_LEFT_OLD," +
                        "AVAILABLE_DEPOSIT," +
                        "SUPPLIER_NAME," +
                        "SERVICE_CENTER_ADDRESS," +
                        "IDENTIFICATION_NUMBER," +
                        "WEBPAGE," +
                        "EMAIL," +
                        "CALLCENTER," +
                        "SUPPLIER_ACCOUNT_NUMBER," +
                        "SOCIAL_COMMISSIO_COMMENT," +
                        "COMMISSIO_COMMENT," +
                        "AMOUNT_WITH_VAT," +
                        "KITOWATT_HOUR," +
                        "PREVIOUS_YEAR_AMOUNT_WITH_VAT," +
                        "PREVIOUS_YEAR_KILIWATT_HOUR) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    }

    public void add(Date paymentDate,
                    Date billCreationDate,
                    String customerNumber,
                    String customerFullName,
                    String customerAddress,
                    BigDecimal amount,
                    BigDecimal illegalUseChargeAmount,
                    BigDecimal recordingKnotCheck,
                    BigDecimal advancePaidAmount,
                    BigDecimal currentAccrual,
                    BigDecimal previousAmount,
                    BigDecimal depositAmount,
                    BigDecimal correctionAmount,
                    String counterSerialNumber,
                    BigDecimal coefficient,
                    BigDecimal tariffValue,
                    Date date,
                    String readingType,
                    BigDecimal reading,
                    BigDecimal kilowatt,
                    BigDecimal expenseAmountGel,
                    BigDecimal payedAmount,
                    BigDecimal supplyServiceAmount,
                    BigDecimal distributionServiceAmount,
                    BigDecimal transmissionServiceAmount,
                    BigDecimal supplyRenewalAmount,
                    BigDecimal vat,
                    BigDecimal serviceQualityCompensation,
                    BigDecimal requestedDeposit,
                    BigDecimal restructuredDebt,
                    BigDecimal contractPenalty,
                    BigDecimal highlandSettlementsSubsidy,
                    BigDecimal tariffSubsidy,
                    BigDecimal multichildSubsidy,
                    BigDecimal other,
                    BigDecimal previousBillLeftAmount,
                    BigDecimal networkDeliveredKilowatt,
                    BigDecimal networkAccession,
                    BigDecimal deductedKilowatt,
                    BigDecimal positiveBalanceKilowatt,
                    BigDecimal purchasedElectricityAmount,
                    BigDecimal disputedDebt,
                    BigDecimal restructuredAmountLeft,
                    BigDecimal leftOldAmount,
                    BigDecimal operatorRestructuredAmountLeft,
                    BigDecimal operatorRestructuredAmountLeftOld,
                    BigDecimal availableDeposit,
                    String supplierName,
                    String serviceCenterAddress,
                    String identificationNumber,
                    String webpage,
                    String email,
                    String callcenter,
                    String supplierAccountNumber,
                    String socialCommissioComment,
                    String commissioComment,
                    BigDecimal amountWithVat,
                    BigDecimal kitowattHour,
                    BigDecimal previousYearAmountWithVat,
                    BigDecimal previousYearKiliwattHour
    ) throws SQLException {
        Object uuid = UUID.randomUUID();
        preparedStatement.setObject(1, uuid);
        preparedStatement.setInt(2, 1);
        preparedStatement.setString(3, username);
        preparedStatement.setDate(4, sqlDate);
        preparedStatement.setString(5, numeratorService.getNumSeq(Bill.class));

        preparedStatement.setDate(6, new java.sql.Date(paymentDate.getTime()));
        preparedStatement.setDate(7, new java.sql.Date(billCreationDate.getTime()));
        preparedStatement.setString(8, customerNumber);
        preparedStatement.setString(9, customerFullName);
        preparedStatement.setString(10, customerAddress);
        preparedStatement.setBigDecimal(11, amount);
        preparedStatement.setBigDecimal(12, illegalUseChargeAmount);
        preparedStatement.setBigDecimal(13, recordingKnotCheck);
        preparedStatement.setBigDecimal(14, advancePaidAmount);
        preparedStatement.setBigDecimal(15, currentAccrual);
        preparedStatement.setBigDecimal(16, previousAmount);
        preparedStatement.setBigDecimal(17, depositAmount);
        preparedStatement.setBigDecimal(18, correctionAmount);
        preparedStatement.setString(19, counterSerialNumber);
        preparedStatement.setBigDecimal(20, coefficient);
        preparedStatement.setBigDecimal(21, tariffValue);
        preparedStatement.setDate(22, new java.sql.Date(date.getTime()));
        preparedStatement.setString(23, readingType);
        preparedStatement.setBigDecimal(24, reading);
        preparedStatement.setBigDecimal(25, kilowatt);
        preparedStatement.setBigDecimal(26, expenseAmountGel);
        preparedStatement.setBigDecimal(27, payedAmount);
        preparedStatement.setBigDecimal(28, supplyServiceAmount);
        preparedStatement.setBigDecimal(29, distributionServiceAmount);
        preparedStatement.setBigDecimal(30, transmissionServiceAmount);
        preparedStatement.setBigDecimal(31, supplyRenewalAmount);
        preparedStatement.setBigDecimal(32, vat);
        preparedStatement.setBigDecimal(33, serviceQualityCompensation);
        preparedStatement.setBigDecimal(34, requestedDeposit);
        preparedStatement.setBigDecimal(35, restructuredDebt);
        preparedStatement.setBigDecimal(36, contractPenalty);
        preparedStatement.setBigDecimal(37, highlandSettlementsSubsidy);
        preparedStatement.setBigDecimal(38, tariffSubsidy);
        preparedStatement.setBigDecimal(39, multichildSubsidy);
        preparedStatement.setBigDecimal(40, other);
        preparedStatement.setBigDecimal(41, previousBillLeftAmount);
        preparedStatement.setBigDecimal(42, networkDeliveredKilowatt);
        preparedStatement.setBigDecimal(43, networkAccession);
        preparedStatement.setBigDecimal(44, deductedKilowatt);
        preparedStatement.setBigDecimal(45, positiveBalanceKilowatt);
        preparedStatement.setBigDecimal(46, purchasedElectricityAmount);
        preparedStatement.setBigDecimal(47, disputedDebt);
        preparedStatement.setBigDecimal(48, restructuredAmountLeft);
        preparedStatement.setBigDecimal(49, leftOldAmount);
        preparedStatement.setBigDecimal(50, operatorRestructuredAmountLeft);
        preparedStatement.setBigDecimal(51, operatorRestructuredAmountLeftOld);
        preparedStatement.setBigDecimal(52, availableDeposit);
        preparedStatement.setString(53, supplierName);
        preparedStatement.setString(54, serviceCenterAddress);
        preparedStatement.setString(55, identificationNumber);
        preparedStatement.setString(56, webpage);
        preparedStatement.setString(57, email);
        preparedStatement.setString(58, callcenter);
        preparedStatement.setString(59, supplierAccountNumber);
        preparedStatement.setString(60, socialCommissioComment);
        preparedStatement.setString(61, commissioComment);
        preparedStatement.setBigDecimal(62, amountWithVat);
        preparedStatement.setBigDecimal(63, kitowattHour);
        preparedStatement.setBigDecimal(64, previousYearAmountWithVat);
        preparedStatement.setBigDecimal(65, previousYearKiliwattHour);

        preparedStatement.addBatch();
        preparedStatement.executeBatch();
    }
}
