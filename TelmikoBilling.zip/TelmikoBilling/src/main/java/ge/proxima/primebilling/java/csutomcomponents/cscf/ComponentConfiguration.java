package ge.proxima.primebilling.java.csutomcomponents.cscf;

import io.jmix.ui.sys.registration.ComponentRegistration;
import io.jmix.ui.sys.registration.ComponentRegistrationBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ComponentConfiguration {
    @Bean
    public ComponentRegistration customerSuggestionField() {
        return ComponentRegistrationBuilder.create(CustomerSuggestionField.NAME)
                .withComponentClass(CustomerSuggestionField.class)
                .withComponentLoaderClass(CustomerSuggestionFieldLoader.class)
                .build();
    }
}
