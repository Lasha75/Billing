package ge.proxima.primebilling.java.csutomcomponents.cscf;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import io.jmix.core.FetchPlan;
import io.jmix.core.common.event.Subscription;
import io.jmix.ui.component.*;
import io.jmix.ui.component.data.ValueSource;
import io.jmix.ui.component.validation.Validator;
import io.jmix.ui.icon.Icons;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.function.Consumer;

@CompositeDescriptor("customer-suggestion-field.xml")
public class CustomerSuggestionField extends CompositeComponent<CssLayout> implements Field<Customer>,
        CompositeWithCaption,
        CompositeWithHtmlCaption,
        CompositeWithHtmlDescription,
        CompositeWithIcon,
        CompositeWithContextHelp
{
    public static final String NAME = "customerSuggestionField";
    protected EntitySuggestionField<Customer> suggestionField;
    protected CssLayout rootBox;

    public CustomerSuggestionField() {
        addCreateListener(this::onCreate);
    }

    private void onCreate(CreateEvent createEvent) {
        suggestionField = getInnerComponent("customerSuggestionField");
        rootBox = (CssLayout) suggestionField.getParent();

        DataManager dataManager = AppBeans.getBean(DataManager.class);
        suggestionField.setSearchExecutor((searchString, searchParams) -> dataManager.load(Customer.class).query("select e from prx_Customer e " +
                        "where e.customerNumber like '%"+searchString +"%'")
                .fetchPlan(FetchPlan.INSTANCE_NAME)
                .maxResults(10).list());
        suggestionField.setAsyncSearchDelayMs(200);
        suggestionField.setMinSearchStringLength(4);
    }

    @Override
    public boolean isEditable() {
        return suggestionField.isEditable();
    }

    @Override
    public void setEditable(boolean editable) {
        suggestionField.setEditable(editable);
    }

    @Nullable
    @Override
    public Customer getValue() {
        return suggestionField.getValue();
    }

    @Override
    public void setValue(@Nullable Customer value) {
        suggestionField.setValue(value);
    }

    @Override
    public Subscription addValueChangeListener(Consumer<ValueChangeEvent<Customer>> listener) {
        return suggestionField.addValueChangeListener(listener);
    }

    @Nullable
    @Override
    public String getCaption() {
        return rootBox.getCaption();
    }

    @Override
    public void setCaption(@Nullable String caption) {
        rootBox.setCaption(caption);
    }

    @Nullable
    @Override
    public String getDescription() {
        return rootBox.getDescription();
    }

    @Override
    public void setDescription(@Nullable String description) {
        rootBox.setDescription(description);
    }

    @Nullable
    @Override
    public String getIcon() {
        return rootBox.getIcon();
    }

    @Override
    public void setIcon(@Nullable String icon) {
        rootBox.setIcon(icon);
    }

    @Override
    public void setIconFromSet(@Nullable Icons.Icon icon) {
        rootBox.setIconFromSet(icon);
    }

    @Nullable
    @Override
    public String getContextHelpText() {
        return rootBox.getContextHelpText();
    }

    @Override
    public void setContextHelpText(@Nullable String contextHelpText) {
        rootBox.setContextHelpText(contextHelpText);
    }

    @Override
    public boolean isContextHelpTextHtmlEnabled() {
        return rootBox.isContextHelpTextHtmlEnabled();
    }

    @Override
    public void setContextHelpTextHtmlEnabled(boolean enabled) {
        rootBox.setContextHelpTextHtmlEnabled(enabled);
    }

    @Nullable
    @Override
    public Consumer<ContextHelpIconClickEvent> getContextHelpIconClickHandler() {
        return rootBox.getContextHelpIconClickHandler();
    }

    @Override
    public void setContextHelpIconClickHandler(@Nullable Consumer<ContextHelpIconClickEvent> handler) {
        rootBox.setContextHelpIconClickHandler(handler);
    }

    @Override
    public boolean isCaptionAsHtml() {
        return rootBox.isCaptionAsHtml();
    }

    @Override
    public void setCaptionAsHtml(boolean captionAsHtml) {
        rootBox.setCaptionAsHtml(captionAsHtml);
    }

    @Override
    public boolean isDescriptionAsHtml() {
        return rootBox.isDescriptionAsHtml();
    }

    @Override
    public void setDescriptionAsHtml(boolean descriptionAsHtml) {
        rootBox.setDescriptionAsHtml(descriptionAsHtml);
    }

    @Override
    public void addValidator(Validator<? super Customer> validator) {
        suggestionField.addValidator(validator);
    }

    @Override
    public void removeValidator(Validator<Customer> validator) {
        suggestionField.removeValidator(validator);
    }

    @Override
    public Collection<Validator<Customer>> getValidators() {
        return suggestionField.getValidators();
    }

    @Override
    public boolean isRequired() {
        return rootBox.isRequiredIndicatorVisible();
    }

    @Override
    public void setRequired(boolean required) {
        //suggestionField.setRequired(required);
        suggestionField.setRequired(false);
        rootBox.setRequiredIndicatorVisible(required);
    }

    @Nullable
    @Override
    public String getRequiredMessage() {
        return suggestionField.getRequiredMessage();
    }

    @Override
    public void setRequiredMessage(@Nullable String msg) {
        suggestionField.setRequiredMessage(msg);
    }

    @Override
    public boolean isValid() {
        if(rootBox.isRequiredIndicatorVisible() && suggestionField.getValue() == null) {
            suggestionField.setRequired(true);
        }
        return suggestionField.isValid();
    }

    @Override
    public void validate() throws ValidationException {
        suggestionField.validate();
    }

    @Override
    public void setValueSource(@Nullable ValueSource<Customer> valueSource) {
        suggestionField.setValueSource(valueSource);
    }

    @Nullable
    @Override
    public ValueSource<Customer> getValueSource() {
        return suggestionField.getValueSource();
    }

    @Override
    public void setHeightAuto() {
        suggestionField.setHeightAuto();
    }

    @Override
    public void setHeightFull() {
        suggestionField.setHeightFull();
    }

    @Override
    public boolean isEditableWithParent() {
        return suggestionField.isEditableWithParent();
    }

    @Override
    public void setWidthAuto() {
        suggestionField.setWidthAuto();
    }

    @Override
    public void setWidthFull() {
        suggestionField.setWidthFull();
    }

    @Override
    public void setSizeFull() {
        suggestionField.setSizeFull();
    }

    @Override
    public void setSizeAuto() {
        suggestionField.setSizeAuto();
    }
}
