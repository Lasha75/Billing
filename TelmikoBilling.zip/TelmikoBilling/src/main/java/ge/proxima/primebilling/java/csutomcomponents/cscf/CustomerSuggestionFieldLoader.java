package ge.proxima.primebilling.java.csutomcomponents.cscf;

import io.jmix.ui.xml.layout.loader.AbstractFieldLoader;

public class CustomerSuggestionFieldLoader extends AbstractFieldLoader<CustomerSuggestionField> {
    @Override
    public void createComponent() {
        resultComponent = factory.create(CustomerSuggestionField.class);
        loadId(resultComponent, element);
    }

    @Override
    public void loadComponent() {
        super.loadComponent();
    }
}