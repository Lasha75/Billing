package ge.proxima.primebilling.java.entitylogger;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class EntityField implements Serializable {
    private String field;
    public String getter;
    public String setter;
    private Object prevValue;
    private Object newValue;
    private Object entity;
    private Class<?> logEntity;


    public EntityField(Field field, Object entity, Class<?> log) throws Exception {
        this.entity = entity;
        this.logEntity = log;
        this.field = field.getName();
        String fieldName = field.getName();
        fieldName = fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);

        setter = "set" + fieldName;
        getter = "get" + fieldName;

        prevValue = getter().invoke(entity);
    }

    public boolean isChanged() throws Exception {
        this.newValue = getter().invoke(entity);
        return (prevValue == null && newValue != null) || (prevValue != null && !prevValue.equals(newValue));
    }

    public void setValue(Object log) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException, NoSuchFieldException {
        newValue = getter().invoke(entity);
        setter().invoke(log, newValue);
    }

    public Class<?> getLogEntity() {
        return logEntity;
    }

    public Method setter() throws NoSuchMethodException {
        return logEntity.getMethod(setter, logEntity.getMethod(getter).getReturnType());
        //return logEntity.getMethod(setter, field.getType());
    }

    public Method getter() throws NoSuchMethodException {
        return entity.getClass().getMethod(getter);
    }

    public void updateValue() {
        prevValue = newValue;
    }
}
