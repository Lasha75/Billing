package ge.proxima.primebilling.java.entitylogger;

import java.util.Date;
import java.util.UUID;

public interface LogEntity {
    Date getFromDate();
    Date getToDate();
    UUID getEntityId();
    void setFromDate(Date date);
    void setToDate(Date date);
    void setEntityId(UUID uuid);

}
