package ge.proxima.primebilling.java.entitylogger;

import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.java.system.StaticValues;
import ge.proxima.primebilling.services.logservice.LoggerService;
import io.jmix.core.DataManager;
import io.jmix.core.Metadata;
import io.jmix.core.SaveContext;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.PostLoad;
import javax.persistence.PostUpdate;
import java.lang.reflect.Field;
import java.util.*;

@JmixEntity(name = "prx_VersionControlledEntity")
public abstract class VersionControlledEntity {
    private List<EntityField> list = new ArrayList<>();

    @PostLoad
    public void postLoad() {

        try {
            Class<?> clazz = Class.forName(this.getClass().getName() + "Log");
            for (Field field : this.getClass().getDeclaredFields()) {
                if (field.isAnnotationPresent(VersionControlKey.class)) {
                    list.add(new EntityField(field, this, clazz));
                }
            }
        } catch (Exception e) {
            LoggerService loggerService = AppBeans.getBean(LoggerService.class);
            loggerService.createLogFromException(e, getClass().getSimpleName() + " " +"postLoad");
        }
    }
    @PostUpdate
    public void postUpdate() {
        createLog();
    }

    private void createLog() {
        try {
            if (checkForChanges()) {
                Metadata metadata = AppBeans.getBean(Metadata.class);
                DataManager dataManager = AppBeans.getBean(DataManager.class);
                LogEntity entity = (LogEntity) metadata.create(list.get(0).getLogEntity());

                for (EntityField entityField : list) {
                    entityField.setValue(entity);
                }

                SaveContext saveContext = new SaveContext();
                saveContext.setJoinTransaction(false);
                LogEntity previous = (LogEntity) dataManager.load(entity.getClass())
                        .query("select e from prx_" + entity.getClass().getSimpleName() + " e where e.entityId = :entityId order by e.fromDate desc")
                        .parameter("entityId", getId())
                        .optional().orElse(null);

                Date currentDate = Calendar.getInstance().getTime();
                if(previous != null) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(currentDate);
                    calendar.add(Calendar.SECOND, -1);
                    previous.setToDate(calendar.getTime());
                    saveContext.saving(previous);
                }

                entity.setFromDate(currentDate);
                entity.setToDate(StaticValues.DATE_MAX);
                entity.setEntityId(getId());
                saveContext.saving(entity);
                dataManager.save(saveContext);
                list.forEach(EntityField::updateValue);
            }
        } catch (Exception e) {
            LoggerService loggerService = AppBeans.getBean(LoggerService.class);
            loggerService.createLogFromException(e, getClass().getSimpleName() + " createLog");
            String a = "";
        }
    }

    private boolean checkForChanges() throws Exception {
        for(EntityField entityField : list) {
            if(entityField.isChanged()) return true;
        }
        return false;
    }

    public abstract UUID getId();
}
