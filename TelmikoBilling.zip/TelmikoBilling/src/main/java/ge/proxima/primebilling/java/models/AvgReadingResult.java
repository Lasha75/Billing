package ge.proxima.primebilling.java.models;

import java.math.BigDecimal;

public class AvgReadingResult extends BaseInfo {

    private BigDecimal value;

    public AvgReadingResult() {}

    public AvgReadingResult(boolean success, String message) {
        super(success, message);
    }

    public AvgReadingResult(boolean success, String message, BigDecimal value) {
        super(success, message);
        this.value = value;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }
}
