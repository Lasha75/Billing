package ge.proxima.primebilling.java.models;

import java.io.Serializable;

public class BaseInfo implements Serializable {
    protected boolean success;
    protected String message;

    public BaseInfo(){}

    public BaseInfo(boolean success, String message){
        this.success = success;
        this.message = message;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
