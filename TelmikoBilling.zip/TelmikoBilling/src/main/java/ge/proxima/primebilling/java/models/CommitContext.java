package ge.proxima.primebilling.java.models;


import javax.swing.text.html.parser.Entity;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CommitContext implements Serializable {
    private List<Object> persist = new ArrayList<>();
    private List<Object> merge = new ArrayList<>();
    private List<Object> remove = new ArrayList<>();

    public void persist(Object entity){
        persist.add(entity);
    }

    public void merge(Object entity) {
        merge.add(entity);
    }

    public void remove(Object entity) {
        remove.add(entity);
    }

    public void persistAll(List<Object> list){
        persist.addAll(list);
    }

    public void mergeAll(List<Object> list) {
        merge.addAll(list);
    }

    public void removeAll(List<Object> list) {
        remove.addAll(list);
    }

    public List<Object> getPersistList(){
        return persist;
    }

    public List<Object> getMergeList(){
        return merge;
    }

    public List<Object> getRemoveList(){
        return remove;
    }

    public void add(CommitContext commitContext) {
        persist.addAll(commitContext.getPersistList());
        merge.addAll(commitContext.getMergeList());
        remove.addAll(commitContext.getRemoveList());
    }

    public boolean isEmpty(){
        return persist.isEmpty() && merge.isEmpty();
    }
}
