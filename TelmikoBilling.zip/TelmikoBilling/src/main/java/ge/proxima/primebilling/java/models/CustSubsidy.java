package ge.proxima.primebilling.java.models;

import ge.proxima.primebilling.entity.customer.Customer;

import java.math.BigDecimal;

public interface CustSubsidy {
    Customer getCustomer();
    BigDecimal getSubsidyAmount();
}
