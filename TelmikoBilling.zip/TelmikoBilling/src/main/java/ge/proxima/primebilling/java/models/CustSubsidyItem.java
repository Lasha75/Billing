package ge.proxima.primebilling.java.models;

import ge.proxima.primebilling.entity.customer.Customer;

import java.math.BigDecimal;

public class CustSubsidyItem {
    public Customer customer;
    public BigDecimal subsidyAmount;
}
