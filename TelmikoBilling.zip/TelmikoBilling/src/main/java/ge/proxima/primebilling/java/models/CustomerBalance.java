package ge.proxima.primebilling.java.models;

import ge.proxima.primebilling.entity.customer.Customer;

import java.math.BigDecimal;
import java.util.Date;

public class CustomerBalance {
    public Date dueDate;
    public Date periodEndDate;
    public BigDecimal amount;

    public CustomerBalance(Date dueDate, Date periodEndDate, BigDecimal amount) {
        this.dueDate = dueDate;
        this.amount = amount;
        this.periodEndDate = periodEndDate;
    }
}
