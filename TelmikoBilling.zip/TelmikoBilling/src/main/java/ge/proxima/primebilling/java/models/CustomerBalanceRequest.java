package ge.proxima.primebilling.java.models;

import java.io.Serializable;

public class CustomerBalanceRequest implements Serializable {
    public String customerNumber;
}