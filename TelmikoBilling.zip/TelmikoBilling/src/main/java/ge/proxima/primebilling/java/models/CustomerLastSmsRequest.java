package ge.proxima.primebilling.java.models;

import java.io.Serializable;

public class CustomerLastSmsRequest implements Serializable {
    public String customerNumber;
    public String mobile;
}
