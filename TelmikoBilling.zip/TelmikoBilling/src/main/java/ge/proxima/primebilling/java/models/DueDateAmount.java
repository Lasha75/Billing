package ge.proxima.primebilling.java.models;

import java.math.BigDecimal;
import java.util.Date;

public class DueDateAmount {
    public BigDecimal amount;
    public Date dueDate;

    public String number;
    public Date startDate;
    public Date endDate;

    public DueDateAmount(BigDecimal amount, Date dueDate) {
        this.amount = amount;
        this.dueDate = dueDate;
    }

    public DueDateAmount(BigDecimal amount, Date dueDate, String number, Date startDate, Date endDate) {
        this.amount = amount;
        this.dueDate = dueDate;
        this.number = number;
        this.startDate = startDate;
        this.endDate = endDate;
    }
}
