package ge.proxima.primebilling.java.models;

import java.util.List;

public class EntityListBaseInfo extends BaseInfo {
    private List<Object> list;

    public EntityListBaseInfo(boolean success, String message) {
        super(success, message);
    }

    public EntityListBaseInfo(boolean success, String message, List<Object> list) {
        super(success, message);
        this.list = list;
    }


    public List<Object> getList() {
        return list;
    }

    public void setList(List<Object> list) {
        this.list = list;
    }
}
