package ge.proxima.primebilling.java.models;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class GetBalanceResponse extends BaseInfo implements Serializable {
    protected BigDecimal balance;
    protected String date;

    public GetBalanceResponse(boolean success, String message) {
        super(success, message);
    }

    public GetBalanceResponse(boolean success, String message, BigDecimal balance, String date) {
        super(success, message);
        this.balance = balance;
        this.date = date;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
