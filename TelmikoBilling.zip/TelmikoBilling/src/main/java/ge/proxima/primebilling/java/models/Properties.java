package ge.proxima.primebilling.java.models;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Scope("singleton")
public class Properties {
    private Map<String, String> map;

    public Properties() {
        map = new HashMap<>();
    }

    public String get(String key) {
        return map.get(key);
    }

    public void set(String key, String value) {
        map.put(key, value);
    }
}
