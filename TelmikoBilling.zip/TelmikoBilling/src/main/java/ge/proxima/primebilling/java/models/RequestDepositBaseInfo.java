package ge.proxima.primebilling.java.models;

import ge.proxima.primebilling.entity.deposit.DepositCustTable;

public class RequestDepositBaseInfo extends BaseInfo {
    protected DepositCustTable depositCustTable;

    public RequestDepositBaseInfo(boolean success, String message) {
        super(success, message);
    }

    public RequestDepositBaseInfo(boolean success, String message, DepositCustTable depositCustTable) {
        super(success, message);
        this.depositCustTable = depositCustTable;
    }

    public DepositCustTable getDepositCustTable() {
        return depositCustTable;
    }

    public void setDepositCustTable(DepositCustTable depositCustTable) {
        this.depositCustTable = depositCustTable;
    }
}
