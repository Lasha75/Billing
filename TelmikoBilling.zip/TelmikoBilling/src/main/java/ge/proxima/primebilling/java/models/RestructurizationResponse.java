package ge.proxima.primebilling.java.models;

import ge.proxima.primebilling.entity.restructurization.RestructurizationLine;

import java.math.BigDecimal;
import java.util.List;

public class RestructurizationResponse extends BaseInfo {
    public List<RestructurizationLine> line;
    public BigDecimal prepaymentAmount;

    public RestructurizationResponse(){}

    public RestructurizationResponse(boolean success, String message) {
        super(success, message);
    }
}
