package ge.proxima.primebilling.java.models;

import io.jmix.core.SaveContext;

public class SaveContextBaseInfo extends BaseInfo {

    private SaveContext saveContext;

    public SaveContextBaseInfo(boolean success, String message) {
        super(success, message);
    }

    public SaveContextBaseInfo(boolean success, String message, SaveContext saveContext) {
        super(success, message);
        this.saveContext = saveContext;
    }


    public SaveContext getSaveContext() {
        return saveContext;
    }

    public void setSaveContext(SaveContext saveContext) {
        this.saveContext = saveContext;
    }
}
