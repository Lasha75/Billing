package ge.proxima.primebilling.java.models;

import ge.proxima.primebilling.entity.transactions.Transaction;
import ge.proxima.primebilling.entity.transactions.TransactionTmp;

import java.util.List;

public class TransactionCorrectionResult extends BaseInfo {
    private List<TransactionTmp> transactions;
    private List<Transaction> resultTransactions;

    public TransactionCorrectionResult() {}

    public TransactionCorrectionResult(boolean success, String message) {
        super(success, message);
    }

    public TransactionCorrectionResult(boolean success, String message, List<TransactionTmp> transactions, List<Transaction> resultTransactions) {
        super(success, message);
        this.transactions = transactions;
        this.resultTransactions = resultTransactions;
    }

    public List<TransactionTmp> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<TransactionTmp> transactions) {
        this.transactions = transactions;
    }

    public List<Transaction> getResultTransactions() {
        return resultTransactions;
    }

    public void setResultTransactions(List<Transaction> resultTransactions) {
        this.resultTransactions = resultTransactions;
    }
}
