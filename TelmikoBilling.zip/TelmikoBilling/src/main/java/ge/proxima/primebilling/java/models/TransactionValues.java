package ge.proxima.primebilling.java.models;

import com.ibm.icu.util.ULocale;
import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.enums.Cycle;
import ge.proxima.primebilling.entity.enums.DepositType;
import ge.proxima.primebilling.entity.tariff.Tariff;
import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import org.apache.tools.ant.taskdefs.Local;
import org.eclipse.persistence.jpa.jpql.parser.DateTime;

import javax.persistence.EntityManager;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

public class TransactionValues {
    private EntityManager entityManager;
    private final DataManager dataManager = AppBeans.getBean(DataManager.class);
    private UUID id;
    private UUID customer;
    private String customerName;
    private String customerNumber;
    private UUID block;
    private String blockName;
    private UUID category;
    private String categoryName;
    private UUID transactionTypeCombination;
    private String comment;
    private String accountNumber;
    private UUID accountType;

    public String getPaymentDocNumber() {
        return paymentDocNumber;
    }

    public void setPaymentDocNumber(String paymentDocNumber) {
        this.paymentDocNumber = paymentDocNumber;
    }

    private String paymentDocNumber;
    private Date operationDate;
    private Date payingDate;
    private Date invoiceDate;
    private String counterNumber;
    private String counterSerial;
    private BigDecimal counterReading;
    private BigDecimal amount;
    private DepositType depositType;
    private Date bankGuaranteeStartDate;
    private Date bankGuaranteeEndDate;
    private boolean usedInBill = false;
    private String bankGuaranteeNumber;
    private UUID tariff;
    private String tariffNumber;
    private BigDecimal value;
    private BigDecimal kilowattHour;
    private Date prevReadDate;
    private Date readDate;
    private Date prevRealDate;

    private String bankId;
    private  String bankTransCode;
    private Cycle cycleType;

    private UUID parentId = null;

    private String paymentPurpose = null;

    private BigDecimal counterPrevReadingValue;

    private Timestamp enterDateTime;

    private Timestamp created_date;
    private String created_by;

    private boolean withGel;

    private Integer step;


    public TransactionValues() {}

    public TransactionValues(EntityManager entityManager, UUID customer, String customerNumber, String customerName, UUID block, String blockName, UUID category, String categoryName,
                             UUID transactionTypeCombination, String comment, String accountNumber, UUID accountType, Date operationDate, Date payingDate, Date invoiceDate,
                             String counterNumber, String counterSerial, BigDecimal counterReading, BigDecimal amount, DepositType depositType, Date bankGuaranteeStartDate,
                             Date bankGuaranteeEndDate, boolean usedInBill, String bankGuaranteeNumber, UUID tariff, String tariffNumber, BigDecimal value,
                             BigDecimal kilowattHour, Date prevReadDate, Date readDate, Date prevRealDate, Cycle cycleType) {
        this.entityManager = entityManager;
        this.customer = customer;
        this.customerNumber = customerNumber;
        this.customerName = customerName;
        this.block = block;
        this.blockName = blockName;
        this.category = category;
        this.categoryName = categoryName;
        this.transactionTypeCombination = transactionTypeCombination;
        this.comment = comment;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.operationDate = operationDate;
        this.payingDate = payingDate;
        this.invoiceDate = invoiceDate;
        this.counterNumber = counterNumber;
        this.counterSerial = counterSerial;
        this.counterReading = counterReading;
        this.amount = amount;
        this.depositType = depositType;
        this.bankGuaranteeStartDate = bankGuaranteeStartDate;
        this.bankGuaranteeEndDate = bankGuaranteeEndDate;
        this.usedInBill = usedInBill;
        this.bankGuaranteeNumber = bankGuaranteeNumber;
        this.tariff = tariff;
        this.tariffNumber = tariffNumber;
        this.value = value;
        this.kilowattHour = kilowattHour;
        this.prevReadDate = prevReadDate;
        this.readDate = readDate;
        this.prevRealDate = prevRealDate;
        this.cycleType = cycleType;
    }

    public TransactionValues(EntityManager entityManager, UUID id, UUID customer, String customerNumber, String customerName, UUID block, String blockName, UUID category, String categoryName,
                             UUID transactionTypeCombination, String comment, String accountNumber, UUID accountType, Date operationDate, Date payingDate, Date invoiceDate,
                             String counterNumber, String counterSerial, BigDecimal counterReading, BigDecimal amount, DepositType depositType, Date bankGuaranteeStartDate,
                             Date bankGuaranteeEndDate, boolean usedInBill, String bankGuaranteeNumber, UUID tariff, String tariffNumber, BigDecimal value,
                             BigDecimal kilowattHour, Date prevReadDate, Date readDate, Date prevRealDate, Cycle cycleType) {
        this(entityManager, customer, customerNumber, customerName, block, blockName, category, categoryName,
                transactionTypeCombination, comment, accountNumber, accountType, operationDate, payingDate, invoiceDate,
                counterNumber, counterSerial, counterReading, amount, depositType, bankGuaranteeStartDate,
                bankGuaranteeEndDate, usedInBill, bankGuaranteeNumber, tariff, tariffNumber, value,
                kilowattHour, prevReadDate, readDate, prevRealDate, cycleType);
        this.id = id;
    }

    public TransactionValues(EntityManager entityManager, UUID id, UUID customer, String customerNumber, String customerName, UUID block, String blockName, UUID category, String categoryName,
                             UUID transactionTypeCombination, String comment, String accountNumber, UUID accountType, Date operationDate, Date payingDate, Date invoiceDate,
                             String counterNumber, String counterSerial, BigDecimal counterReading, BigDecimal amount, DepositType depositType, Date bankGuaranteeStartDate,
                             Date bankGuaranteeEndDate, boolean usedInBill, String bankGuaranteeNumber, UUID tariff, String tariffNumber, BigDecimal value,
                             BigDecimal kilowattHour, Date prevReadDate, Date readDate, Date prevRealDate, Cycle cycleType, UUID parentId,String paymentPurpose) {
        this(entityManager, id, customer, customerNumber, customerName, block, blockName, category, categoryName,
                transactionTypeCombination, comment, accountNumber, accountType, operationDate, payingDate, invoiceDate,
                counterNumber, counterSerial, counterReading, amount, depositType, bankGuaranteeStartDate,
                bankGuaranteeEndDate, usedInBill, bankGuaranteeNumber, tariff, tariffNumber, value,
                kilowattHour, prevReadDate, readDate, prevRealDate, cycleType);
        this.parentId = parentId;
        this.paymentPurpose = paymentPurpose;
    }

    public DataManager getDataManager() {
        return dataManager;
    }

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public Cycle getCycleType() {
        return cycleType;
    }

    public void setCycleType(Cycle cycleType) {
        this.cycleType = cycleType;
    }

    public UUID getCustomer() {
        return customer;
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public String getCustomerNumber() {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
        this.customerNumber = customerNumber;
    }

    public void setCustomer(UUID customer) {
        this.customer = customer;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public UUID getBlock() {
        return block;
    }

    public void setBlock(UUID block) {
        this.block = block;
    }

    public String getBlockName() {
        return blockName;
    }

    public void setBlockName(String blockName) {
        this.blockName = blockName;
    }

    public UUID getCategory() {
        return category;
    }

    public void setCategory(UUID category) {
        this.category = category;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public UUID getTransactionTypeCombination() {
        return transactionTypeCombination;
    }

    public void setTransactionTypeCombination(UUID transactionTypeCombination) {
        this.transactionTypeCombination = transactionTypeCombination;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public UUID getAccountType() {
        return accountType;
    }

    public void setAccountType(UUID accountType) {
        this.accountType = accountType;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public Date getPayingDate() {
        return payingDate;
    }

    public void setPayingDate(Date payingDate) {
        this.payingDate = payingDate;
    }

    public String getCounterNumber() {
        return counterNumber;
    }

    public void setCounterNumber(String counterNumber) {
        this.counterNumber = counterNumber;
    }

    public String getCounterSerial() {
        return counterSerial;
    }

    public void setCounterSerial(String counterSerial) {
        this.counterSerial = counterSerial;
    }

    public BigDecimal getCounterReading() {
        return counterReading;
    }

    public void setCounterReading(BigDecimal counterReading) {
        this.counterReading = counterReading;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public DepositType getDepositType() {
        return depositType;
    }

    public void setDepositType(DepositType depositType) {
        this.depositType = depositType;
    }

    public Date getBankGuaranteeStartDate() {
        return bankGuaranteeStartDate;
    }

    public void setBankGuaranteeStartDate(Date bankGuaranteeStartDate) {
        this.bankGuaranteeStartDate = bankGuaranteeStartDate;
    }

    public Date getBankGuaranteeEndDate() {
        return bankGuaranteeEndDate;
    }

    public void setBankGuaranteeEndDate(Date bankGuaranteeEndDate) {
        this.bankGuaranteeEndDate = bankGuaranteeEndDate;
    }

    public boolean isUsedInBill() {
        return usedInBill;
    }

    public void setUsedInBill(boolean usedInBill) {
        this.usedInBill = usedInBill;
    }

    public Boolean getUsedInBill() {
        return this.usedInBill;
    }

    public String getBankGuaranteeNumber() {
        return bankGuaranteeNumber;
    }

    public void setBankGuaranteeNumber(String bankGuaranteeNumber) {
        this.bankGuaranteeNumber = bankGuaranteeNumber;
    }

    public UUID getTariff() {
        return tariff;
    }

    public void setTariff(UUID tariff) {
        this.tariff = tariff;
    }

    public String getTariffNumber() {
        return tariffNumber;
    }

    public void setTariffNumber(String tariffNumber) {
        this.tariffNumber = tariffNumber;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public BigDecimal getKilowattHour() {
        return kilowattHour;
    }

    public void setKilowattHour(BigDecimal kilowattHour) {
        this.kilowattHour = kilowattHour;
    }

    public UUID getParentId() {
        return parentId;
    }

    public void setParentId(UUID parentId) {
        this.parentId = parentId;
    }

    public  void setBankId(String bankid){this.bankId = bankid;}
    public  String getBankId(){return this.bankId;}

    public  void setBankTransCode(String bankTransCode){this.bankTransCode = bankTransCode;}
    public  String getBankTransCode(){return bankTransCode;}

    public  void setPaymentPurpose(String paymentPurpose){this.paymentPurpose = paymentPurpose;}

    public String getPaymentPurpose() {
        return paymentPurpose;
    }

    public  BigDecimal getCounterPrevReadValue(){
        return counterPrevReadingValue;
    }

    public  void setCounterPrevReadValue(BigDecimal _counterPrevReadingValue){
        this.counterPrevReadingValue = _counterPrevReadingValue;
    }

    public void setEnterDateTime(Timestamp enterDateTime){
        this.enterDateTime = enterDateTime;
    }

    public Timestamp getEnterDateTime(){
        return enterDateTime;
    }

    public void add(PreparedStatement preparedStatement, PreparedStatement preparedStatementOpen, String user, java.sql.Timestamp current, Map<UUID, CustomerCategory> categoryMap, Map<UUID, Block> blockMap, Map<UUID, Tariff> tariffMap) throws Exception {
        loadBlanks(categoryMap, blockMap, tariffMap);

        Object uuid = id == null ? UUID.randomUUID() : id;
        preparedStatement.setObject(1, uuid);
        preparedStatement.setObject(2, category);//CATEGORY_ID;
        preparedStatement.setString(3, categoryName);//CATEGORY_NAME;
        preparedStatement.setObject(4, customer);//CUSTOMER_ID;
        preparedStatement.setString(5, customerNumber);//CUSTOMER_NUMBER;
        preparedStatement.setObject(6, block);//BLOCK_ID;
        preparedStatement.setString(7, blockName);//BLOCK_NAME;
        preparedStatement.setString(8, counterSerial);//COUNTER_SERIAL_NUMBER;
        preparedStatement.setString(9, counterNumber);//COUNTER_NUMBER;
        preparedStatement.setBigDecimal(10, counterReading);//COUNTER_READING_VALUE;
        preparedStatement.setObject(11, tariff);//TARIFF_ID;
        preparedStatement.setString(12, tariffNumber);//TARIFF_NUMBER;
        preparedStatement.setBigDecimal(13, value);//VALUE_;
        preparedStatement.setString(14, accountNumber);//ACCOUNT_NUMBER;
        preparedStatement.setObject(15, accountType);//ACCOUNT_TYPE_ID;
        preparedStatement.setBigDecimal(16, kilowattHour);//KILOWATT_HOUR;
        preparedStatement.setObject(17, transactionTypeCombination);//TRANS_TYPE_COMBINATION_ID;
        if(payingDate != null) preparedStatement.setDate(18, new java.sql.Date(payingDate.getTime()));//DUE_DATE;
        if(operationDate != null) preparedStatement.setDate(19, new java.sql.Date(operationDate.getTime()));//TRANS_DATE;
        if(invoiceDate != null) preparedStatement.setDate(20, new java.sql.Date(invoiceDate.getTime()));//INVOICE_DATE;
        preparedStatement.setString(21, comment);//COMMENT_;
        preparedStatement.setBigDecimal(22, amount);//AMOUNT;
        preparedStatement.setString(23, depositType == null ? null : depositType.getId());//DEPOSIT_TYPE;
        preparedStatement.setDate(24, bankGuaranteeStartDate == null ? null : new java.sql.Date(bankGuaranteeStartDate.getTime()));//BANK_GUARANTEE_START_DATE;
        preparedStatement.setDate(25, bankGuaranteeEndDate == null ? null : new java.sql.Date(bankGuaranteeEndDate.getTime()));//BANK_GUARANTEE_END_DATE;
        preparedStatement.setString(26, bankGuaranteeNumber);//BANK_GUARANTEE_NUMBER;
        preparedStatement.setBoolean(27, usedInBill);//USED_IN_BILL;
        preparedStatement.setDate(28, prevReadDate == null ? null : new java.sql.Date(prevReadDate.getTime()));
        preparedStatement.setDate(29, readDate == null ? null : new java.sql.Date(readDate.getTime()));
        preparedStatement.setDate(30, prevRealDate == null ? null : new java.sql.Date(prevRealDate.getTime()));
        preparedStatement.setInt(31, 1);
        preparedStatement.setString(32, user);
        preparedStatement.setTimestamp(33, current);
        preparedStatement.setString(34,bankId);
        preparedStatement.setString(35,bankTransCode);
        preparedStatement.setString(36, paymentDocNumber);//PAYMENT_DOC_NUMBER
        preparedStatement.setString(37, cycleType == null ? "" : cycleType.getId());//CYCLE_TYPE
        preparedStatement.setObject(38, parentId);
        preparedStatement.setObject(39,paymentPurpose);
        preparedStatement.setTimestamp(40, enterDateTime);
        preparedStatement.setObject(41,withGel);
        preparedStatement.setObject(42,step);
        preparedStatement.addBatch();

        preparedStatementOpen.setObject(1, UUID.randomUUID());
        preparedStatementOpen.setObject(2, category);//CATEGORY_ID;
        preparedStatementOpen.setString(3, categoryName);//CATEGORY_NAME;
        preparedStatementOpen.setObject(4, customer);//CUSTOMER_ID;
        preparedStatementOpen.setString(5, customerNumber);//CUSTOMER_NUMBER;
        preparedStatementOpen.setObject(6, block);//BLOCK_ID;
        preparedStatementOpen.setString(7, blockName);//BLOCK_NAME;
        preparedStatementOpen.setObject(8, tariff);//TARIFF_ID;
        preparedStatementOpen.setBigDecimal(9, value);//VALUE_;
        preparedStatementOpen.setString(10, accountNumber);//ACCOUNT_NUMBER;
        preparedStatementOpen.setObject(11, accountType);//ACCOUNT_TYPE_ID;
        preparedStatementOpen.setBigDecimal(12, kilowattHour);//KILOWATT_HOUR;
        preparedStatementOpen.setObject(13, transactionTypeCombination);//TRANS_TYPE_COMBINATION_ID;
        if(payingDate != null) preparedStatementOpen.setDate(14, new java.sql.Date(payingDate.getTime()));//DUE_DATE;
        if(operationDate != null) preparedStatementOpen.setDate(15, new java.sql.Date(operationDate.getTime()));//TRANS_DATE;
        if(invoiceDate != null) preparedStatementOpen.setDate(16, new java.sql.Date(invoiceDate.getTime()));//INVOICE_DATE;
        preparedStatementOpen.setBigDecimal(17, amount);//AMOUNT;
        preparedStatementOpen.setString(18, depositType == null ? null : depositType.getId());//DEPOSIT_TYPE;
        preparedStatementOpen.setDate(19, bankGuaranteeStartDate == null ? null : new java.sql.Date(bankGuaranteeStartDate.getTime()));//BANK_GUARANTEE_START_DATE;
        preparedStatementOpen.setDate(20, bankGuaranteeEndDate == null ? null : new java.sql.Date(bankGuaranteeEndDate.getTime()));//BANK_GUARANTEE_END_DATE;
        preparedStatementOpen.setString(21, bankGuaranteeNumber);//BANK_GUARANTEE_NUMBER;
        preparedStatementOpen.setBoolean(22, usedInBill);//USED_IN_BILL;
        preparedStatementOpen.setObject(23, uuid);//TRANSACTION_ID;
        preparedStatementOpen.setInt(24, 1);
        preparedStatementOpen.setString(25, user);
        preparedStatementOpen.setTimestamp(26, current);
       // preparedStatement.setTimestamp(27, enterDateTime);
        preparedStatementOpen.addBatch();
    }

    private void loadBlanks(Map<UUID, CustomerCategory> categoryMap, Map<UUID, Block> blockMap, Map<UUID, Tariff> tariffMap) {
        if(customerName == null || customerNumber == null || category == null || categoryName == null) {
            Object[] customerResult = (Object[]) entityManager.createQuery("select e.fullName, e.customerNumber, e.category.id from prx_Customer e where e.id = :id")
                    .setParameter("id", customer)
                    .getSingleResult();
            if(customerName == null) customerName = (String) customerResult[0];
            if(customerNumber == null) customerNumber = (String) customerResult[1];
            if(category == null) category = (UUID) customerResult[2];
            if(categoryName == null) categoryName = categoryMap.get(category).getName();
        }

        if(tariff != null && tariffMap != null) {
            if(tariffNumber == null) tariffNumber = tariffMap.get(tariff).getName();
        }

        if(block != null && blockName == null) {
            blockName = blockMap.get(block).getName();
        }
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public Date getPrevReadDate() {
        return prevReadDate;
    }

    public void setPrevReadDate(Date prevReadDate) {
        this.prevReadDate = prevReadDate;
    }

    public Date getReadDate() {
        return readDate;
    }

    public void setReadDate(Date readDate) {
        this.readDate = readDate;
    }

    public Date getPrevRealDate() {
        return prevRealDate;
    }

    public void setPrevRealDate(Date prevRealDate) {
        this.prevRealDate = prevRealDate;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public  void setCreated_date(Timestamp created_date ) {this.created_date = created_date;}
    public  void setCreated_by(String created_by){this.created_by = created_by;}

    public TransactionValues duplicate() {
        TransactionValues t = new TransactionValues();
        t.setId(UUID.randomUUID());
        t.setEntityManager(this.getEntityManager());
        t.setCustomerNumber(this.getCustomerNumber());
        t.setCustomer(this.getCustomer());
        t.setCustomerName(this.getCustomerName());
        t.setBlock(this.getBlock());
        t.setBlockName(this.getBlockName());
        t.setCategory(this.getCategory());
        t.setCategoryName(this.getCategoryName());
        t.setTransactionTypeCombination(this.getTransactionTypeCombination());
        t.setComment(this.getComment());
        t.setAccountNumber(this.getAccountNumber());
        t.setAccountType(this.getAccountType());
        t.setOperationDate(this.getOperationDate());
        t.setPayingDate(this.getPayingDate());
        t.setCounterNumber(this.getCounterNumber());
        t.setCounterSerial(this.getCounterSerial());
        t.setCounterReading(this.getCounterReading());
        t.setAmount(this.getAmount());
        t.setDepositType(this.getDepositType());
        t.setBankGuaranteeStartDate(this.getBankGuaranteeStartDate());
        t.setBankGuaranteeEndDate(this.getBankGuaranteeEndDate());
        t.setUsedInBill(this.getUsedInBill());
        t.setBankGuaranteeNumber(this.getBankGuaranteeNumber());
        t.setTariff(this.getTariff());
        t.setTariffNumber(this.getTariffNumber());
        t.setValue(this.getValue());
        t.setKilowattHour(this.getKilowattHour());
        t.setInvoiceDate(this.getInvoiceDate());
        t.setPrevReadDate(this.getPrevReadDate());
        t.setReadDate(this.getReadDate());
        t.setPrevRealDate(this.getPrevRealDate());
        t.setBankId(this.getBankId());
        t.setBankTransCode(this.getBankTransCode());
        t.setPaymentDocNumber(this.getPaymentDocNumber());
        t.setCycleType(this.getCycleType());
        t.setParentId(this.getParentId());
        return t;
    }

    public boolean isWithGel() {
        return withGel;
    }

    public void setWithGel(boolean withGel) {
        this.withGel = withGel;
    }

    public int getStep() {
        return step;
    }

    public void setStep(Integer step) {
        this.step = step;
    }
}
