package ge.proxima.primebilling.java.system;

import java.text.SimpleDateFormat;
import java.util.Date;

public class StaticValues {
    public static Date DATE_MAX;

    public static void initValues() {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
            StaticValues.DATE_MAX = simpleDateFormat.parse("01/01/2200");
        } catch (Exception ignored){}
    }
}
