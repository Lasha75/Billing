package ge.proxima.primebilling.java.system;

public class TextVariables {
    public static String CUSTOMER_FIRSTNAME = "[CustomerFirstname]";
    public static String CUSTOMER_LASTNAME = "[CustomerLastname]";
    public static String CUSTOMER_NUMBER = "[CustomerNumber]";
    public static String CURRENT_AMOUNT = "[CurrentAmount]";
    public static String PAYMENT_DATE = "[PaymentDate]";
    public static String CUTOFF_DATE = "[CutoffDate]";
    public static String OVERDUE_DATES_ENG = "[OverdueDatesEng]";
    public static String OVERDUE_DATES_GE = "[OverdueDatesGe]";
}
