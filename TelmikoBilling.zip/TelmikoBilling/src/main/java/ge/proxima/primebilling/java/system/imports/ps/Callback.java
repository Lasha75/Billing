package ge.proxima.primebilling.java.system.imports.ps;

import ge.proxima.primebilling.entity.system.imports.ExcelImportAttribute;
import ge.proxima.primebilling.entity.system.imports.ExcelImportTemplate;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;

public interface Callback {
    Object invoke(Class<?> clazz, ExcelImportAttribute primaryAttribute, ExcelImportTemplate template, Map<String, Integer> keys, List<Object> data, PreparedStatement preparedStatement) throws Exception;
}
