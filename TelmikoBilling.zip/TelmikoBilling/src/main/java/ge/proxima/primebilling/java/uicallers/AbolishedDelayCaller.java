package ge.proxima.primebilling.java.uicallers;

import ge.proxima.primebilling.entity.enums.DelayerStatus;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.screen.customer.delayer.DelayerBrowse;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.menu.MenuItem;
import io.jmix.ui.menu.MenuItemRunnable;
import io.jmix.ui.screen.FrameOwner;
import io.jmix.ui.screen.OpenMode;

public class AbolishedDelayCaller implements MenuItemRunnable {

    @Override
    public void run(FrameOwner frameOwner, MenuItem menuItem) {
        ScreenBuilders screenBuilders = AppBeans.getBean(ScreenBuilders.class);

        DelayerBrowse screen = screenBuilders.screen(frameOwner)
                .withScreenClass(DelayerBrowse.class)
                .withOpenMode(OpenMode.NEW_TAB)
                .build();
        screen.setStatus(DelayerStatus.DELAY_ABOLISHED);
        screen.show();
    }
}
