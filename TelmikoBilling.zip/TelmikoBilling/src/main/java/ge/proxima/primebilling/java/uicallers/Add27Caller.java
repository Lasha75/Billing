package ge.proxima.primebilling.java.uicallers;

import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import io.jmix.reports.entity.Report;
import io.jmix.reportsui.runner.ParametersDialogShowMode;
import io.jmix.reportsui.runner.UiReportRunner;
import io.jmix.ui.menu.MenuItem;
import io.jmix.ui.menu.MenuItemRunnable;
import io.jmix.ui.screen.FrameOwner;

public class Add27Caller implements MenuItemRunnable {
    @Override
    public void run(FrameOwner origin, MenuItem menuItem) {
        DataManager dataManager = AppBeans.getBean(DataManager.class);
        UiReportRunner uiReportRunner = AppBeans.getBean(UiReportRunner.class);
        uiReportRunner.byReportEntity(
                        dataManager.load(Report.class)
                                .query("select e from report_Report e where e.code = 'ADD27'")
                                .one()
                )
                .withParametersDialogShowMode(ParametersDialogShowMode.YES)
                .runAndShow();
    }
}
