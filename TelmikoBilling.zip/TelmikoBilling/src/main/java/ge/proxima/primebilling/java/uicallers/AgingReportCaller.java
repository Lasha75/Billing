package ge.proxima.primebilling.java.uicallers;

import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import io.jmix.reports.entity.Report;
import io.jmix.reportsui.runner.ParametersDialogShowMode;
import io.jmix.ui.menu.MenuItem;
import io.jmix.ui.menu.MenuItemRunnable;
import io.jmix.ui.screen.FrameOwner;
import io.jmix.reportsui.runner.UiReportRunner;

public class AgingReportCaller implements MenuItemRunnable {
    @Override
    public void run(FrameOwner origin, MenuItem menuItem) {
        UiReportRunner uiReportRunner = AppBeans.getBean(UiReportRunner.class);
        DataManager dataManager = AppBeans.getBean(DataManager.class);
        uiReportRunner.byReportEntity(
                        dataManager.load(Report.class)
                                .query("select e from report_Report e where e.code = 'AgingByBusinessCenter'")
                                .one()
                )
                .withParametersDialogShowMode(ParametersDialogShowMode.NO)
                .runAndShow();
    }
}
