package ge.proxima.primebilling.java.uicallers;

import ge.proxima.primebilling.entity.User;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.screen.bcourtsession.BCourtSessionBrowse;
import ge.proxima.primebilling.screen.ccourtsession.CCourtSessionBrowse;
import io.jmix.core.usersubstitution.CurrentUserSubstitution;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.menu.MenuItem;
import io.jmix.ui.menu.MenuItemRunnable;
import io.jmix.ui.screen.FrameOwner;
import io.jmix.ui.screen.OpenMode;

public class BCourtSessionMyCaller implements MenuItemRunnable {
    @Override
    public void run(FrameOwner origin, MenuItem menuItem) {
        ScreenBuilders screenBuilders = AppBeans.getBean(ScreenBuilders.class);
        CurrentUserSubstitution curUser = AppBeans.getBean(CurrentUserSubstitution.class);
        BCourtSessionBrowse screen = screenBuilders.screen(origin)
                .withScreenClass(BCourtSessionBrowse.class)
                .withOpenMode(OpenMode.NEW_TAB)
                .build();

        User user = (User) curUser.getSubstitutedUser();
        if (user == null) {
            user = (User) curUser.getEffectiveUser();
        }
        if (user == null) {
            user = (User) curUser.getAuthenticatedUser();
        }
        screen.setCurrUser(user);
        screen.show();
    }
}
