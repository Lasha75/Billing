package ge.proxima.primebilling.java.uicallers;

import ge.proxima.primebilling.entity.enums.ApportioningStatus;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.screen.restructurization.RestructurizationScreen;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.menu.MenuItem;
import io.jmix.ui.menu.MenuItemRunnable;
import io.jmix.ui.screen.FrameOwner;
import io.jmix.ui.screen.OpenMode;

public class ConfirmedRestructurizationCaller implements MenuItemRunnable {

    @Override
    public void run(FrameOwner frameOwner, MenuItem menuItem) {
        ScreenBuilders screenBuilders = AppBeans.getBean(ScreenBuilders.class);

        RestructurizationScreen screen = screenBuilders.screen(frameOwner)
                .withScreenClass(RestructurizationScreen.class)
                .withOpenMode(OpenMode.NEW_TAB)
                .build();
        screen.setApportioningStatus(ApportioningStatus.CONFIRMED);
        screen.show();
    }
}
