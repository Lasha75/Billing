package ge.proxima.primebilling.java.uicallers;

import ge.proxima.primebilling.entity.system.Parameters;
import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.menu.MenuItem;
import io.jmix.ui.menu.MenuItemRunnable;
import io.jmix.ui.screen.FrameOwner;

public class ParametersCaller implements MenuItemRunnable {
    @Override
    public void run(FrameOwner origin, MenuItem menuItem) {
        DataManager dataManager = AppBeans.getBean(DataManager.class);
        ScreenBuilders screenBuilders = AppBeans.getBean(ScreenBuilders.class);
        Parameters parameters = dataManager.load(Parameters.class)
                .query("select e from prx_Parameters e")
                //.fetchPlan("parameters-fetch-plan")
                .optional().orElse(null);
        if(parameters == null) {
            screenBuilders.editor(Parameters.class, origin)
                    .newEntity()
                    .build().show();
        } else {
            screenBuilders.editor(Parameters.class, origin)
                    .editEntity(parameters)
                    .build().show();
        }
    }
}
