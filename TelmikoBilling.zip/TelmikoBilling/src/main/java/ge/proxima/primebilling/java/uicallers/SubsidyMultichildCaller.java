package ge.proxima.primebilling.java.uicallers;

import ge.proxima.primebilling.entity.system.Parameters;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.screen.subsidytransreport.SubsidyTransReportBrowse;
import io.jmix.core.DataManager;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.menu.MenuItem;
import io.jmix.ui.menu.MenuItemRunnable;
import io.jmix.ui.screen.FrameOwner;
import io.jmix.ui.screen.OpenMode;

public class SubsidyMultichildCaller implements MenuItemRunnable {
    @Override
    public void run(FrameOwner frameOwner, MenuItem menuItem) {
        ScreenBuilders screenBuilders = AppBeans.getBean(ScreenBuilders.class);
        DataManager dataManager = AppBeans.getBean(DataManager.class);
        Parameters parameters = dataManager.load(Parameters.class)
                .query("select e from prx_Parameters e")
                .fetchPlan("parameters-fetch-plan")
                .one();
        SubsidyTransReportBrowse screen = screenBuilders.screen(frameOwner)
                .withScreenClass(SubsidyTransReportBrowse.class)
                .withOpenMode(OpenMode.NEW_TAB)
                .build();

        screen.setType(parameters.getSubsidyMultiChildTransactionCombination().getId());
        screen.setParameters(parameters);
        screen.show();
    }
}