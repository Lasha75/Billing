package ge.proxima.primebilling.java.uidecorators;

public interface ScreenDecorator {
    void init();
}
