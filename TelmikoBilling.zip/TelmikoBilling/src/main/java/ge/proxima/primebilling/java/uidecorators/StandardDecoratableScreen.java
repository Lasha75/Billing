package ge.proxima.primebilling.java.uidecorators;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;

public interface StandardDecoratableScreen {
    BaseUuidEntity getSelected(String key);
}
