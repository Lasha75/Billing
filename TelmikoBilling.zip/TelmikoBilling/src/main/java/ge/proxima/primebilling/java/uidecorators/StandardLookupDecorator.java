package ge.proxima.primebilling.java.uidecorators;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import io.jmix.ui.screen.StandardLookup;

public abstract class StandardLookupDecorator <T extends BaseUuidEntity> extends StandardLookup<T> implements StandardDecoratableScreen {
    protected void init(ScreenDecorator... screenDecorators){
        for(ScreenDecorator screenDecorator : screenDecorators){
            screenDecorator.init();
        }
    }

    public abstract BaseUuidEntity getSelected(String key);
}
