package ge.proxima.primebilling.java.uidecorators.decorators;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.entity.system.EntityAttachment;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.java.uidecorators.ScreenDecorator;
import ge.proxima.primebilling.java.uidecorators.StandardDecoratableScreen;
import ge.proxima.primebilling.java.uidecorators.StandardLookupDecorator;
import ge.proxima.primebilling.screen.system.entityattachment.EntityAttachmentBrowse;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.icon.Icons;
import io.jmix.ui.icon.JmixIcon;
import io.jmix.ui.screen.OpenMode;
import io.jmix.ui.screen.Screen;

public class AttachmentScreenDecorator<T extends BaseUuidEntity, S extends Screen & StandardDecoratableScreen> implements ScreenDecorator {

    private UiComponents uiComponents;
    private ScreenBuilders screenBuilders;
    private Icons icons;
    private ButtonsPanel buttonsPanel;
    private S screen;
    private String key;

    public AttachmentScreenDecorator(S screenOrigin, String key, ButtonsPanel buttonsPanel) {
        uiComponents = AppBeans.getBean(UiComponents.class);
        screenBuilders = AppBeans.getBean(ScreenBuilders.class);
        icons = AppBeans.getBean(Icons.class);
        this.buttonsPanel = buttonsPanel;
        this.screen = screenOrigin;
        this.key = key;
    }

    @Override
    public void init() {
        Button button = uiComponents.create(Button.class);
        button.setId("attachmentsButton"+key);
        button.setIcon(icons.get(JmixIcon.FOLDER_O));
        buttonsPanel.add(button);
        button.addClickListener(clickEvent -> {
            T entity = (T)screen.getSelected(key);
            if(entity != null) {
                EntityAttachmentBrowse screen = (EntityAttachmentBrowse) screenBuilders.lookup(EntityAttachment.class, this.screen)
                        .withOpenMode(OpenMode.DIALOG)
                        .build();
                screen.setEntityId(entity.getId());
                screen.setEntityName(entity.getClass().getSimpleName());
                screen.show();
            }
        });
    }
}
