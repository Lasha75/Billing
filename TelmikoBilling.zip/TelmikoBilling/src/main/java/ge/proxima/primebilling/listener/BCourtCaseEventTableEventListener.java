package ge.proxima.primebilling.listener;

import ge.proxima.primebilling.entity.BCourtCaseEventTable;
import io.jmix.core.event.EntityChangedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component("prx_BCourtCaseEventTableEventListener")
public class BCourtCaseEventTableEventListener {

    @EventListener
    public void onBCourtCaseEventTableChangedBeforeCommit(EntityChangedEvent<BCourtCaseEventTable> event) {

    }
}