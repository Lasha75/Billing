package ge.proxima.primebilling.listener;

import ge.proxima.primebilling.entity.BCourtCase;
import ge.proxima.primebilling.entity.BCourtCaseEventTable;
import ge.proxima.primebilling.entity.BCourtPrivateComplaint;
import ge.proxima.primebilling.entity.CCourtCaseStage;
import io.jmix.core.DataManager;
import io.jmix.core.Id;
import io.jmix.core.event.EntityChangedEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Date;

@Component("prx_BCourtPrivateComplaintEventListener")
public class BCourtPrivateComplaintEventListener {

    @Autowired
    private DataManager dataManager;

    @EventListener
    public void onBCourtPrivateComplaintChangedBeforeCommit(EntityChangedEvent<BCourtPrivateComplaint> event) {
        if(event.getType()== EntityChangedEvent.Type.CREATED)
        {

        }
        if(event.getType()==EntityChangedEvent.Type.DELETED)
        {
            Id<BCourtCase> bCase=event.getChanges().getOldReferenceId("courtCase");
            Id<BCourtCaseEventTable> caseEventTableId=event.getChanges().getOldReferenceId("Id");
            Date createDateTime=event.getChanges().getOldValue("createdDate");
            BCourtCaseEventTable eventTable= dataManager.load(BCourtCaseEventTable.class)
                    .query("select c from prx_BCourtCaseEventTable c " +
                            "where c.courtCase.id = :courtCaseId " +
                            "and c.createdDate > :createdDateTime " +
                            "and c.id <> :parmId").parameter("courtCaseId", bCase).parameter("createdDateTime", createDateTime).parameter("parmId", caseEventTableId).optional()
                    .orElse(null);
            if(eventTable!=null)
            {
                throw new Error("წაშლა შეუძლებელი!");
            }
            else
            {
                CCourtCaseStage caseStatus=event.getChanges().getOldValue("lastStatus");
                LocalDate caseStatusDate=event.getChanges().getOldValue("lastStatusDate");
                BCourtCase courtCase=dataManager.load(BCourtCase.class).id(bCase).one();
                courtCase.setCaseStatus(caseStatus);
                courtCase.setStatusDate(caseStatusDate);
                dataManager.save(courtCase);
            }
        }
    }
}