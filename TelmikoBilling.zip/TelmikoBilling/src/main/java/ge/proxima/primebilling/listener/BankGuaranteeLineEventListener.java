package ge.proxima.primebilling.listener;

import ge.proxima.primebilling.entity.BankGuaranteeLine;
import ge.proxima.primebilling.entity.deposit.BankGuarantee;
import ge.proxima.primebilling.services.notificationsservice.NotificationsService;
import io.jmix.core.DataManager;
import io.jmix.core.Id;
import io.jmix.core.SaveContext;
import io.jmix.core.event.EntityChangedEvent;
import io.jmix.core.event.EntityLoadingEvent;
import io.jmix.core.event.EntitySavingEvent;
import io.jmix.ui.Notifications;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.List;

import static io.jmix.emailtemplatesui.screen.emailtemplate.attachment.EmailTemplateAttachmentEdit.log;

@Component("prx_BankGuaranteeLineEventListener")
public class BankGuaranteeLineEventListener {


    @Autowired
    private DataManager dataManager;
   // private BankGuarantee bankGuarantee;
    @Autowired
    private NotificationsService notificationsService;

    @EventListener
    public void onBankGuaranteeLineLoading(EntityLoadingEvent<BankGuaranteeLine> event) {

    }
    @EventListener
    public void onBankGuaranteeLineSaving(EntitySavingEvent<BankGuaranteeLine> event) {

    }
    @EventListener
    public void onBankGuaranteeLineChangedBeforeCommit(EntityChangedEvent<BankGuaranteeLine> event) {
        BankGuarantee bankGuarantee;
        if(event.getType() == EntityChangedEvent.Type.DELETED)
        {
            Id<BankGuarantee> bankGuaranteeId=event.getChanges().getOldReferenceId("bankGuarantee");
            bankGuarantee=dataManager.load(bankGuaranteeId).one();
        }
        else
        {
            BankGuaranteeLine bankGuaranteeLine=dataManager.load(event.getEntityId()).one();
            bankGuarantee=bankGuaranteeLine.getBankGuarantee();
        }
        BigDecimal amount=bankGuarantee.getBankGuaranteeline().stream().map(
                line -> line.getAmount()
        ).reduce(BigDecimal.ZERO,BigDecimal::add);
        if(bankGuarantee.getAmount().compareTo(amount)==-1)
        {
            throw new ArithmeticException("დეპოზიტის ჯამური თანხა აღემატება საბანკო გარანტიის თანხას");
        }
        bankGuarantee.setWreckedAmount(amount);
        dataManager.save(bankGuarantee);
    }
    @TransactionalEventListener
    public void onBankGuaranteeLineChangedAfterCommit(EntityChangedEvent<BankGuaranteeLine> event) {

    }
}