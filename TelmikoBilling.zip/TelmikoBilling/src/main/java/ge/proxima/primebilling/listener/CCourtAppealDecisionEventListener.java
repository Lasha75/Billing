package ge.proxima.primebilling.listener;

import ge.proxima.primebilling.entity.*;
import io.jmix.core.DataManager;
import io.jmix.core.Id;
import io.jmix.core.event.EntityChangedEvent;
import org.apache.tools.ant.taskdefs.Local;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Date;

@Component("prx_CCourtAppealDecisionEventListener")
public class CCourtAppealDecisionEventListener {

    @Autowired
    private DataManager dataManager;
    private Object source;

    @EventListener
    public void onCCourtAppealDecisionChangedBeforeCommit(EntityChangedEvent<CCourtAppealDecision> event) {
        if(event.getType()== EntityChangedEvent.Type.CREATED)
        {
            CCourtAppealDecision appealDecision=dataManager.load(event.getEntityId()).one();
            CCourtCase cc=appealDecision.getCourtCase();

            cc.setCaseStatus(CCourtCaseStage.RESOLUTIONISSUEDAPPEAL);
            cc.setStatusDate(LocalDate.now());
            dataManager.save(cc);
        }
        if(event.getType()==EntityChangedEvent.Type.DELETED)
        {
            Id<CCourtCase> cCase=event.getChanges().getOldReferenceId("courtCase");
            Id<CCourtCaseEventTable> caseEventTableId=event.getChanges().getOldReferenceId("Id");
            Date createDateTime=event.getChanges().getOldValue("createdDate");
            //event.getChanges().getOldValue("createdDate");
            CCourtCaseEventTable eventTable= dataManager.load(CCourtCaseEventTable.class)
                    .query("select c from prx_CCourtCaseEventTable c " +
                            "where c.courtCase.id = :courtCaseId " +
                            "and c.createdDate > :createdDateTime " +
                            "and c.id <> :parmId").parameter("courtCaseId", cCase).parameter("createdDateTime", createDateTime).parameter("parmId", caseEventTableId).optional()
                    .orElse(null);
            if(eventTable!=null)
            {
                throw new Error("წაშლა შეუძლებელი!");
            }
            else
            {
                CCourtCaseStage caseStatus=event.getChanges().getOldValue("lastStatus");
                LocalDate caseStatusDate=event.getChanges().getOldValue("lastStatusDate");
                CCourtCase courtCase=dataManager.load(CCourtCase.class).id(cCase).one();
                courtCase.setCaseStatus(caseStatus);
                courtCase.setStatusDate(caseStatusDate);
                dataManager.save(courtCase);
            }
        }
    }
}