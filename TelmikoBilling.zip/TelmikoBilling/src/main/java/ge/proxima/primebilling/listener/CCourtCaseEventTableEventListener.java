package ge.proxima.primebilling.listener;

import ge.proxima.primebilling.entity.CCourtCase;
import ge.proxima.primebilling.entity.CCourtCaseEventTable;
import io.jmix.core.DataManager;
import io.jmix.core.Id;
import io.jmix.core.event.EntityChangedEvent;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Date;

@Component("prx_CCourtCaseEventTableEventListener")
public class CCourtCaseEventTableEventListener {
    @Autowired
    private DataManager dataManager;

    @EventListener
    public void onCCourtCaseEventTableChangedBeforeCommit(EntityChangedEvent<CCourtCaseEventTable> event)  {

    }
}