package ge.proxima.primebilling.listener;

import ge.proxima.primebilling.entity.CCourtCase;
import ge.proxima.primebilling.entity.CCourtCaseEventTable;
import ge.proxima.primebilling.entity.CCourtCaseStage;
import ge.proxima.primebilling.entity.CCourtConsolidatedCases;
import io.jmix.core.DataManager;
import io.jmix.core.EntitySet;
import io.jmix.core.Id;
import io.jmix.core.SaveContext;
import io.jmix.core.event.EntityChangedEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

@Component("prx_CCourtConsolidatedCasesEventListener")
public class CCourtConsolidatedCasesEventListener {

    @Autowired
    private DataManager dataManager;

    @EventListener
    public void onCCourtConsolidatedCasesChangedBeforeCommit(EntityChangedEvent<CCourtConsolidatedCases> event) {
        if(event.getType()== EntityChangedEvent.Type.CREATED)
        {
            SaveContext saveContext = new SaveContext();
            CCourtConsolidatedCases consolidatedCases=dataManager.load(event.getEntityId()).one();
            CCourtCase cc=consolidatedCases.getCourtCase();
            cc.setCaseStatus(CCourtCaseStage.CONSOLIDATEDCASES);
            cc.setStatusDate(LocalDate.now());
            cc.setConsolidateWithCase(consolidatedCases.getConsolidateWithCase());
            cc.setTotalDebt(consolidatedCases.getTotalDebt());
            cc.setTotalDebtPeriod(consolidatedCases.getDebtPeriod());
            saveContext.saving(cc);
            CCourtCase ccMain=consolidatedCases.getConsolidateWithCase();
            ccMain.setTotalDebtPeriod(consolidatedCases.getDebtPeriod());
            ccMain.setTotalDebt(consolidatedCases.getTotalDebt());
            saveContext.saving(ccMain);
            dataManager.save(saveContext);
        }
        if(event.getType()== EntityChangedEvent.Type.UPDATED)
        {
            SaveContext saveContext = new SaveContext();
            CCourtConsolidatedCases consolidatedCases=dataManager.load(event.getEntityId()).one();
            CCourtCase cc=consolidatedCases.getCourtCase();
            cc.setConsolidateWithCase(consolidatedCases.getConsolidateWithCase());
            cc.setTotalDebt(consolidatedCases.getTotalDebt());
            cc.setTotalDebtPeriod(consolidatedCases.getDebtPeriod());
            saveContext.saving(cc);
            CCourtCase ccMain=consolidatedCases.getConsolidateWithCase();
            ccMain.setTotalDebtPeriod(consolidatedCases.getDebtPeriod());
            ccMain.setTotalDebt(consolidatedCases.getTotalDebt());
            saveContext.saving(ccMain);
            dataManager.save(saveContext);
        }
        if(event.getType()==EntityChangedEvent.Type.DELETED)
        {
            Id<CCourtCase> cCase=event.getChanges().getOldReferenceId("courtCase");
            Id<CCourtCaseEventTable> caseEventTableId=event.getChanges().getOldReferenceId("Id");
            Date createDateTime=event.getChanges().getOldValue("createdDate");
            //event.getChanges().getOldValue("createdDate");
            CCourtCaseEventTable eventTable= dataManager.load(CCourtCaseEventTable.class)
                    .query("select c from prx_CCourtCaseEventTable c " +
                            "where c.courtCase.id = :courtCaseId " +
                            "and c.createdDate > :createdDateTime " +
                            "and c.id <> :parmId").parameter("courtCaseId", cCase).parameter("createdDateTime", createDateTime).parameter("parmId", caseEventTableId).optional()
                    .orElse(null);
            if(eventTable!=null)
            {
                throw new Error("წაშლა შეუძლებელი!");
            }
            else
            {
                SaveContext saveContext = new SaveContext();
                CCourtCaseStage caseStatus=event.getChanges().getOldValue("lastStatus");
                LocalDate caseStatusDate=event.getChanges().getOldValue("lastStatusDate");
                CCourtCase courtCase=dataManager.load(CCourtCase.class).id(cCase).one();
                courtCase.setCaseStatus(caseStatus);
                courtCase.setStatusDate(caseStatusDate);
                courtCase.setTotalDebt(BigDecimal.ZERO);
                courtCase.setTotalDebtPeriod("");
                CCourtCase courtCaseMain=courtCase.getConsolidateWithCase();
                courtCaseMain.setTotalDebt(BigDecimal.ZERO);
                courtCaseMain.setTotalDebtPeriod("");
                courtCase.setConsolidateWithCase(null);
                saveContext.saving(courtCase);
                saveContext.saving(courtCaseMain);
                dataManager.save(saveContext);
            }
        }
    }
}