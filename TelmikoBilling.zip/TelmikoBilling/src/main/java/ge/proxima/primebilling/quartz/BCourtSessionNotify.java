package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.entity.CCourtLawyer;
import ge.proxima.primebilling.entity.CCourtSession;
import ge.proxima.primebilling.entity.CCourtSessionNotifyConfig;
import ge.proxima.primebilling.entity.transactions.transtypes.BCourtSession;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.logservice.LoggerService;
import ge.proxima.primebilling.services.notificationsservice.NotificationsService;
import io.jmix.core.DataManager;
import io.jmix.core.Sort;
import io.jmix.core.TimeSource;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.core.security.Authenticated;
import io.jmix.email.EmailInfo;
import io.jmix.email.EmailInfoBuilder;
import io.jmix.email.Emailer;
import io.jmix.emailtemplates.EmailTemplates;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.util.List;

public class BCourtSessionNotify implements Job {
    @Autowired
    private DataManager dataManager;
    @Autowired
    private TimeSource timeSource;
    @Autowired
    private NotificationsService notificationsService;
    @Autowired
    private EmailTemplates emailTemplates;
    @Autowired
    private Emailer emailer;
    @Authenticated
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        try{
            List<CCourtLawyer> lawyer=dataManager.load(CCourtLawyer.class).condition(PropertyCondition.equal("isActivated",true)).list();
            if(lawyer!=null) {
                for (CCourtLawyer lawyers : lawyer) {
                    StringBuilder str=new StringBuilder();
                    boolean canSendEmail=false;
                    str.append(String.format("გამარჯობათ %s ,",lawyers.getFirstName()));
                    str.append("\n");
                    str.append("\n");
                    str.append("თქვენ გაქვთ შემდეგი სასამართლო სხდომები:");
                    str.append("\n");
                    List<CCourtSessionNotifyConfig> cConfig = dataManager.load(CCourtSessionNotifyConfig.class).all().sort(Sort.by("notifyBeforDay")).list();
                    if (cConfig != null) {
                        for (CCourtSessionNotifyConfig entity : cConfig) {
                            List<BCourtSession> cCourtSessions = dataManager.load(BCourtSession.class)
                                    .query("select c from prx_BCourtSession c " +
                                            "join c.courtCase co " +
                                            "where c.sessionDate = :sessionDateCalc " +
                                            "and co.lawayer = :courtCaseLawayer")
                                    .parameter("courtCaseLawayer", lawyers)
                                    .parameter("sessionDateCalc", LocalDate.now().plusDays(entity.getNotifyBeforDay()))
                                    .list();
                            if (cCourtSessions != null) {

                                for (BCourtSession session : cCourtSessions) {
                                    /*
                                    we need subject and text
                                    session.getCourtCase().getCaseNumber();
                                    session.getCourtCase().getLawayer();
                                    session.getSessionDate();
                                    */
                                    canSendEmail=true;
                                    if(entity.getNotifyBeforDay()==0){
                                        str.append(String.format("დღეს - "));
                                    }else {
                                        str.append(String.format("%s დღეში - ",entity.getNotifyBeforDay()));
                                    }
                                    str.append(String.format("საქმის ნომერი : %s , თარიღი : ",session.getCourtCase().getCaseNumber()));
                                    str.append(session.getSessionDate());

                                    switch (session.getSessionInstance()){
                                        case CASSATION -> str.append(", ინსტანცია : საკასაციო");
                                        case FIRSTINSTANCE -> str.append(", ინსტანცია : პირველი ინსტანცია");
                                        case APPEALINSTANCE -> str.append(", ინსტანცია : სააპელაციო");
                                    }
                                    str.append("\n");
                                }
                            }

                        }
                    }
                    if(canSendEmail == true) {
               /*         emailTemplates.buildFromTemplate("s")
                                        .setTo("tamurvelashvili@proxima.solutions")
                                                .setBodyParameter("textTest",str.toString()).sendEmail();*/
                        str.append("\n");
                        str.append("\n");
                        str.append("პატივისცემით,");
                        str.append("\n");
                        str.append("\n");
                        str.append("ბილინგის სისტემა");
                        EmailInfo emailInfo= EmailInfoBuilder.create()
                                .setAddresses("tamurvelashvili@proxima.solutions")
                                .setSubject("notify form court")
                                .setFrom(null)
                                .setBody(str.toString())
                                .build();
                        emailer.sendEmail(emailInfo);
                    }
                }
            }

        } catch (Exception e) {
            loggerService.createLogFromException(e, getClass().toString());
            throw new RuntimeException(e.getMessage());
        }
    }

}
