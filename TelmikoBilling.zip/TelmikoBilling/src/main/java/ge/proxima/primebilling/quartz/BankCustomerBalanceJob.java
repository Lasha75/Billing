package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.java.models.BaseInfo;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.customer.customer.BankBalanceUpdate;
import ge.proxima.primebilling.services.logservice.LoggerService;
import ge.proxima.primebilling.services.telasi.TelasiCustomerBalanceUpdate;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class BankCustomerBalanceJob implements Job {

    @Override
    @Authenticated
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        try
        {
            loggerService.createAndSaveLog("Start balance upd",true,"telasi balance");
              BankBalanceUpdate custbalance = AppBeans.getBean(BankBalanceUpdate.class);
              custbalance.updateBankCustomerBalance();
            loggerService.createAndSaveLog("end balance upd",true,"telasi balance");
        }
        catch (Exception e) {
            loggerService.createLogFromException(e, getClass().toString());
            throw new RuntimeException(e.getMessage());
        }
    }
}
