package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.entity.*;
import ge.proxima.primebilling.entity.transactions.transtypes.CCourtReturnPreTrial;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.customer.customer.CustomerBalanceService;
import ge.proxima.primebilling.services.logservice.LoggerService;
import io.jmix.core.DataManager;
import io.jmix.core.EntitySet;
import io.jmix.core.TimeSource;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Component("prx_CCourtCustomerDebtUpdate")
public class CCourtCustomerDebtUpdate implements Job {
    @Autowired
    private DataManager dataManager;
    @Autowired
    private TimeSource timeSource;
    @Autowired
    private CustomerBalanceService customerBalanceService;

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        try{
            List<CCourtCase> cc=dataManager.load(CCourtCase.class).all().list();
            if(cc!=null)
            {
                for(CCourtCase entity : cc) {

                    BigDecimal customerDebt = BigDecimal.ZERO;
                    customerDebt = customerBalanceService.getCustomerElectricityBalance(entity.getCustomer().getCustomerNumber(), timeSource.currentTimestamp());
                    entity.setCurrentDebt(customerDebt);

                    if (customerDebt.compareTo(BigDecimal.ZERO) != 1 && entity.getCaseStatus()!=CCourtCaseStage.RETURNPRETRIALPROCEEDINGS ) {
                        entity.setCaseStatus(CCourtCaseStage.RETURNPRETRIALPROCEEDINGS);
                        entity.setStatusDate(LocalDate.now());
                        CCourtReturnPreTrial ccReturn =dataManager.create(CCourtReturnPreTrial.class);
                        ccReturn.setEvent(CCourtCaseEvent.RETURNPRETRIALPROCEEDINGS);
                        ccReturn.setCourtCase(entity);
                        ccReturn.setReason(CCourtCaseReturnReason.DEBTPAIDBEFORE);
                        EntitySet savedEntities = dataManager.save(entity, ccReturn);
                    }
                    else {
                        dataManager.save(entity);
                    }


                }
            }
        } catch (Exception e) {
            loggerService.createLogFromException(e, getClass().toString());
            throw new RuntimeException(e.getMessage());
        }
    }
}