package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.entity.block.Block;
import ge.proxima.primebilling.entity.reftables.BusinessCenter;
import ge.proxima.primebilling.entity.system.Parameters;
import ge.proxima.primebilling.java.models.BaseInfo;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.circularaccural.CircularAccrualService;
import ge.proxima.primebilling.services.logservice.LoggerService;
import io.jmix.core.DataManager;
import io.jmix.core.TimeSource;
import io.jmix.core.security.Authenticated;
import io.jmix.core.security.SystemAuthenticator;
import io.jmix.notifications.NotificationManager;
import io.jmix.notifications.entity.ContentType;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CircularAccrualJob implements Job {

    @Override
    @Authenticated
    @ManagedOperation
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {

        NotificationManager notificationManager = AppBeans.getBean(NotificationManager.class);
        DataManager dataManager = AppBeans.getBean(DataManager.class);
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        TimeSource timeSource = AppBeans.getBean(TimeSource.class);
        CircularAccrualService circularAccrualService = AppBeans.getBean(CircularAccrualService.class);
        SystemAuthenticator systemAuthenticator = AppBeans.getBean(SystemAuthenticator.class);
        systemAuthenticator.withSystem(() -> {
            JobDataMap jobDataMap = jobExecutionContext.getJobDetail().getJobDataMap();
            List<String> users = new ArrayList<>();
            users.add((String)jobDataMap.get("user"));
            notificationManager.createNotification()
                    .withSubject("ციკლური დარიცხვები")
                    .withRecipientUsernames(users)
                    .toChannelsByNames("in-app")
                    .withContentType(ContentType.PLAIN)
                    .withBody("პროცესი დაიწყო.")
                    .send();
            List resultList = circularAccrualService.getTransactionIds(
                    jobDataMap.get("block") == null ? null : UUID.fromString((String)jobDataMap.get("block")),
                    jobDataMap.get("businessCenter") == null ? null : UUID.fromString((String)jobDataMap.get("businessCenter")));
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");

            String date = sdf.format(timeSource.currentTimestamp());
            int counter = 0;
            int successCounter = 0;
            int size = resultList.size();

            Parameters parameters = dataManager.load(Parameters.class)
                    .query("select e from prx_Parameters e")
                    .fetchPlan("parameters-fetch-plan")
                    .one();

            for (Object item : resultList) {
                BaseInfo result = circularAccrualService.generateTransactions((UUID) item,parameters);
                if(!result.isSuccess()) {
                    loggerService.createAndSaveLog("Circular Accrual " + date, false, result.getMessage() + " " + item.toString());
                } else {
                    successCounter++;
                }
                counter++;
                if(counter % 1000 == 0) {
                    loggerService.createAndSaveLog("Circular Accrual " + date, true, String.format("სულ: %s, დამუშავებული: %s, წარმატებული: %s", size, counter, successCounter));
                }
            }

            notificationManager.createNotification()
                    .withSubject("ციკლური დარიცხვები")
                    .withRecipientUsernames(users)
                    .toChannelsByNames("in-app")
                    .withContentType(ContentType.PLAIN)
                    .withBody("პროცესი დასრულდა. წარმატება " + successCounter + " / " + size)
                    .send();
            return "Done";
        });
    }
}
