package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.entity.court.CourtAdministration;
import ge.proxima.primebilling.entity.court.ReturnedPreCourtWork;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.system.Parameters;
import ge.proxima.primebilling.services.debtservice.DebtService;
import io.jmix.core.DataManager;
import io.jmix.core.Metadata;
import io.jmix.core.SaveContext;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class CourtAdministrationDebtRenewJob implements Job {

    @Autowired
    private DebtService debtService;

    @Autowired
    private DataManager dataManager;

    @Autowired
    private Metadata metadata;

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        debtService.updateCourtAdministrationDebts();
        removeUnnecessaryRecords();
    }

    private void removeUnnecessaryRecords() {
        SaveContext saveContext = new SaveContext();
        Parameters parameters = dataManager.load(Parameters.class).all().one();
        Status courtStatusReturned = parameters.getCourtStatusReturned();
        for (CourtAdministration administration : getDebtsBelowOrEqualToZero()) {
            administration.setStatus(courtStatusReturned);
            saveContext.saving(administration);
            saveContext.saving(createReturnedPreCourtWork(administration));
        }
        dataManager.save(saveContext);
    }

    private List<CourtAdministration> getDebtsBelowOrEqualToZero() {
        return dataManager.load(CourtAdministration.class)
                .query("select e from prx_CourtAdministration e where e.customerDebt <= 0")
                .list();
    }

    private ReturnedPreCourtWork createReturnedPreCourtWork(CourtAdministration administration) {
        ReturnedPreCourtWork returnedPreCourtWork = metadata.create(ReturnedPreCourtWork.class);
        returnedPreCourtWork.setCategory(administration.getCategory());
        returnedPreCourtWork.setCustomer(administration.getCustomer());
        returnedPreCourtWork.setCustomerActivity(administration.getCustomerActivity());
        returnedPreCourtWork.setConsumerCategory(administration.getConsumerCategory());
        returnedPreCourtWork.setCustomerAddress(administration.getCustomerAddress());
        returnedPreCourtWork.setCustomerCadastralCode(administration.getCustomerCadastralCode());
        returnedPreCourtWork.setCustomerDebt(administration.getCustomerDebt());
        returnedPreCourtWork.setCustomerGiveType(administration.getCustomerGiveType());
        returnedPreCourtWork.setCustomerIdentificationNumber(administration.getCustomerIdentificationNumber());
        returnedPreCourtWork.setCustomerName(administration.getCustomerName());
        returnedPreCourtWork.setLawyer(administration.getLawyer());
        returnedPreCourtWork.setCustomerCategory(administration.getCustomerCategory());
        return returnedPreCourtWork;
    }
}
