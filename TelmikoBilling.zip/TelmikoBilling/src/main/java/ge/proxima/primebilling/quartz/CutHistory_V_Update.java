package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.cutoff.CutHistory_V;
import ge.proxima.primebilling.services.invoiceservice.app.TelasiIntegTransactional;
import ge.proxima.primebilling.services.invoiceservice.app.TelasiIntegrationBean;
import ge.proxima.primebilling.services.logservice.LoggerService;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class CutHistory_V_Update implements Job {
    @Override
    @Authenticated
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        try
        {

            loggerService.createAndSaveLog("Start cut history",true,"telasi integration");
            CutHistory_V cutHistoryUpdate = AppBeans.getBean(CutHistory_V.class);
            cutHistoryUpdate.updateCustHistory_v();
            loggerService.createAndSaveLog("End cut history",true,"telasi integration");
        }
        catch (Exception e) {
            loggerService.createLogFromException(e, getClass().toString());
            throw new RuntimeException(e.getMessage());
        }
    }
}
