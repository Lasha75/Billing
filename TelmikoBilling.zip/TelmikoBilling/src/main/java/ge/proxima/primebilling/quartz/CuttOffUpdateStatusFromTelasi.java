package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.cutoff.CuttOffUpdateStatusFromTL;
import ge.proxima.primebilling.services.cutoff.UpdateCuttOffPayments;
import ge.proxima.primebilling.services.logservice.LoggerService;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class CuttOffUpdateStatusFromTelasi implements Job {

    @Override
    @Authenticated
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        try
        {
            CuttOffUpdateStatusFromTL cuttOff = AppBeans.getBean(CuttOffUpdateStatusFromTL.class);
          //  cuttOff.updateStatus();
           // cuttOff.updateRestoreInfo();
        }
        catch (Exception e) {
            loggerService.createLogFromException(e, getClass().toString());
            throw new RuntimeException(e.getMessage());
        }
    }
}
