package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.services.invoiceservice.app.OverduePaymentStatusChange;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

public class OverduePaymentStatusChangeJob implements Job {

    @Autowired
    private OverduePaymentStatusChange overdueService;

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
        BigDecimal res;
        try {
            overdueService.run();
        } catch(Exception e)  {
            System.out.println(e.getMessage());
        }
    }
}
