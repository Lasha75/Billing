package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.java.models.BaseInfo;
import ge.proxima.primebilling.services.debtservice.DebtService;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

public class PreCourtWorkLimitNotification  implements Job {

    @Autowired
    private DebtService debtService;

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        BaseInfo response = debtService.checkOverdueDeadlines();
        if (!response.isSuccess()) throw new RuntimeException(response.getMessage());
    }
}
