package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.invoiceservice.app.TelasiIntegTransactional;
import ge.proxima.primebilling.services.invoiceservice.app.TelasiIntegrationBean;
import ge.proxima.primebilling.services.logservice.LoggerService;
import ge.proxima.primebilling.services.rest.rs.service.RSHelpService;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class RSInvoiceInfoUpdate implements Job {
    @Override
    @Authenticated
    public void execute(JobExecutionContext context) throws JobExecutionException {

        try
        {
            RSHelpService rs = AppBeans.getBean(RSHelpService.class);
            rs.updateImportedInvoice();


        }
        catch (Exception e) {

            throw new RuntimeException(e.getMessage());
        }
    }
}
