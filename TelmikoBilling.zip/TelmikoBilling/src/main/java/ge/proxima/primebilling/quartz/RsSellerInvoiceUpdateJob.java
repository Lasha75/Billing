package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.entity.User;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.logservice.LoggerService;
import ge.proxima.primebilling.services.rest.rs.service.RSHelpService;
import io.jmix.core.DataManager;
import io.jmix.core.querycondition.PropertyCondition;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

@Component("prx_RsSellerInvoiceUpdateJob")
public class RsSellerInvoiceUpdateJob implements Job {
    @Autowired
    private RSHelpService rSHelpService;
    @Autowired
    private DataManager dataManager;

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        ZoneId defaultZoneId = ZoneId.systemDefault();
        Date s_dt=new Date();
        Date e_dt=new Date();
        s_dt=Date.from(LocalDate.now().minusMonths(1).atStartOfDay(defaultZoneId).toInstant());
        e_dt=Date.from(LocalDate.now().atStartOfDay(defaultZoneId).toInstant());

        try{
            User user=dataManager.load(User.class).condition(PropertyCondition.equal("username","admin")).one();
            rSHelpService.clearRsSellerInvoiceTable();
            rSHelpService.initInfoForQueartz(user);
            rSHelpService.getSellerInvoicesAndInsert(s_dt,e_dt,s_dt,e_dt,"","","","");
            rSHelpService.updateRsInvoicefromSellerTable();
            } catch (Exception e) {
            loggerService.createLogFromException(e, getClass().toString());
            throw new RuntimeException(e.getMessage());
            }
    }
}