package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.services.customer.customer.CustomerService;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

public class SendSocialCategoryDueDateMessages implements Job {
    @Autowired
    CustomerService customerService;

    @Override
    @Authenticated
    public void execute(JobExecutionContext context) throws JobExecutionException {
        customerService.sendSocialCategoryDueDateMessages();
    }
}
