package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerContact;
import ge.proxima.primebilling.entity.customer.setup.SupplyContract;
import ge.proxima.primebilling.entity.deposit.CustomerMessage;
import ge.proxima.primebilling.entity.enums.CustomerContactType;
import ge.proxima.primebilling.entity.enums.MessageSendStatus;
import ge.proxima.primebilling.entity.enums.NotificationType;
import ge.proxima.primebilling.entity.system.Parameters;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.logservice.LoggerService;
import ge.proxima.primebilling.services.mailservice.MailServiceBean;
import ge.proxima.primebilling.services.rest.messages.service.SendMessageService;
import io.jmix.core.DataManager;
import io.jmix.core.Metadata;
import io.jmix.core.SaveContext;
import io.jmix.core.TimeSource;
import io.jmix.core.security.Authenticated;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.email.EmailException;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.util.*;

public class SupplyContractDueDateNotifyJob implements Job {
    @Autowired
    private DataManager dataManager;
    @Autowired
    private TimeSource timeSource;
    @Autowired
    private SendMessageService sendMessageService;
    @Autowired
    private CurrentAuthentication currentAuthentication;
    @Override
    @Authenticated
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        try{
            Parameters parameters = dataManager.load(Parameters.class).all().one();
            List<SupplyContract> supplyContractList= dataManager.load(SupplyContract.class)
                    .query( "select s from prx_SupplyContract s " +
                        "where s.notificationDate = :currentDate " +
                        "and s.status = :status1")
                    .parameter("currentDate", timeSource.currentTimestamp())
                    .parameter("status1", parameters.getSupplyContractActiveStatus())
                    .list();
            for (SupplyContract entity : supplyContractList)
            {
                this.sendEmail(entity);
                this.sendSMS(entity);
            }
        } catch (Exception e) {
            loggerService.createLogFromException(e, getClass().toString());
            throw new RuntimeException(e.getMessage());
        }
    }
    private void sendEmail(SupplyContract _supplyContract)  {
        Parameters parameters = dataManager.load(Parameters.class).all().one();
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        SaveContext saveContext = new SaveContext();
        Calendar calendar=Calendar.getInstance();
        List<CustomerContact> customerEmail;
        customerEmail= dataManager.load(CustomerContact.class)
                .query("select c from prx_CustomerContact c " +
                        "where c.customer.id = :customerId " +
                        "and c.contactType = 'EMAIL'")
                .parameter("customerId", _supplyContract.getCustomer().getId())
                .list();

        for (CustomerContact entity : customerEmail) {
            try {
                //TODO email
                if (!entity.getContactInfo().equals("")) {
                    MailServiceBean mailServiceBean = AppBeans.getBean(MailServiceBean.class);
                    mailServiceBean.sendMessage(entity.getContactInfo(), null,
                            "მიწოდების ხელშეკრულების ვადის ამოწურვა", formMessageText(parameters.getSupplyContractEmailText(), _supplyContract, false, parameters));
                }
            }
            catch (Exception e)
            {
                loggerService.createLogFromException(e, getClass().toString());
                createSentNotification(entity.getCustomer(), entity.getContactInfo(), calendar.getTime(),
                        MessageSendStatus.FAILED, CustomerContactType.EMAIL, formMessageText(parameters.getSupplyContractEmailText(), _supplyContract, false, parameters));
                throw new RuntimeException(e.getMessage());

            }
            CustomerMessage emailMessage = createSentNotification(entity.getCustomer(), entity.getContactInfo(), calendar.getTime(),
                    MessageSendStatus.SENT, CustomerContactType.EMAIL, formMessageText(parameters.getSupplyContractEmailText(), _supplyContract, false, parameters));
            saveContext.saving(emailMessage);
        }

        dataManager.save(saveContext);
    }
    private void sendSMS(SupplyContract _supplyContract)
    {
        SaveContext saveContext = new SaveContext();
        List<CustomerContact> customerSMS;
        customerSMS= dataManager.load(CustomerContact.class)
                .query("select c from prx_CustomerContact c " +
                        "where c.customer.id = :customerId " +
                        "and c.contactType = 'MOBILE_PHONE'")
                .parameter("customerId", _supplyContract.getCustomer().getId())
                .list();
        for (CustomerContact entity : customerSMS) {
            //TODO SMS
            Parameters parameters = dataManager.load(Parameters.class).all().one();
            CustomerMessage smsMessage =
                    sendMessageService.sendAnySms(true, entity.getContactInfo(), formMessageText(parameters.getSupplyContractSMSText(), _supplyContract, true, parameters), NotificationType.SUPPLY_CONTRACT);
            smsMessage.setType(NotificationType.SUPPLY_CONTRACT);
            smsMessage.setCustomer(_supplyContract.getCustomer());
            saveContext.saving(smsMessage);
        }

        dataManager.save(saveContext);
    }
    private String formMessageText(String toFormat, SupplyContract supplyContract, boolean sms, Parameters parameters) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(supplyContract.getToDate());

        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(supplyContract.getToDate());
        calendar1.add(Calendar.DAY_OF_MONTH, getDaysBetween(supplyContract.getFromDate(), supplyContract.getToDate()));
        Date authorizationDate = parameters.getAuthorizationDate();
        if (authorizationDate != null && authorizationDate.before(calendar1.getTime())) calendar1.setTime(authorizationDate);
        return String.format(toFormat,
                calendar.get(Calendar.DAY_OF_MONTH) > 9 ? "0"+calendar.get(Calendar.DAY_OF_MONTH) : calendar.get(Calendar.DAY_OF_MONTH),
                calendar.get(Calendar.MONTH) + 1 > 9 ? "0"+calendar.get(Calendar.MONTH) + 1 : calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.YEAR),
                calendar1.get(Calendar.DAY_OF_MONTH) > 9 ? "0"+calendar1.get(Calendar.DAY_OF_MONTH) : calendar1.get(Calendar.DAY_OF_MONTH),
                calendar1.get(Calendar.MONTH) + 1 > 9 ? "0"+calendar1.get(Calendar.MONTH) + 1 : calendar1.get(Calendar.MONTH) + 1,
                calendar1.get(Calendar.YEAR));
    }
    private int getDaysBetween(Date date1, Date date2) {
        return Math.abs(Days.daysBetween(new DateTime(date1), new DateTime(date2)).getDays());
    }
    private CustomerMessage createSentNotification(Customer customer, String contactInfo, Date curDate,
                                                   MessageSendStatus status, CustomerContactType contactType, String text) {
        Metadata metadata = AppBeans.getBean(Metadata.class);
        CustomerMessage sentNotification = metadata.create(CustomerMessage.class);
        sentNotification.setCustomer(customer);
        sentNotification.setContact(contactInfo);
        sentNotification.setDate(curDate);
        sentNotification.setContactType(contactType);
        sentNotification.setMessage(text);
        sentNotification.setStatus(status);
        sentNotification.setType(NotificationType.SUPPLY_CONTRACT);
        sentNotification.setSender(currentAuthentication.getUser().getUsername());

        return sentNotification;
    }
}
