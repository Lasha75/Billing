package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerCategory;
import ge.proxima.primebilling.entity.customer.CustomerContact;
import ge.proxima.primebilling.entity.customer.setup.SupplyContract;
import ge.proxima.primebilling.entity.deposit.CustomerMessage;
import ge.proxima.primebilling.entity.enums.CustomerContactType;
import ge.proxima.primebilling.entity.enums.MessageSendStatus;
import ge.proxima.primebilling.entity.enums.NotificationType;
import ge.proxima.primebilling.entity.reftables.BusinessCenter;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.system.Parameters;
import ge.proxima.primebilling.entity.system.ResponsibleEmployee;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.mailservice.MailServiceBean;
import ge.proxima.primebilling.services.rest.messages.service.SendMessageService;
import io.jmix.core.DataManager;
import io.jmix.core.Metadata;
import io.jmix.core.SaveContext;
import io.jmix.core.TimeSource;
import io.jmix.core.security.Authenticated;
import io.jmix.core.security.CurrentAuthentication;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import ge.proxima.primebilling.services.logservice.LoggerService;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.*;

public class SupplyContractExhaustJob implements Job {

    @Autowired
    private DataManager dataManager;
    @PersistenceContext
    private EntityManager entityManager;
    @Autowired
    private SendMessageService sendMessageService;
    @Autowired
    private CurrentAuthentication currentAuthentication;

    @Override
    @Authenticated
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        try {
            Parameters parameters = dataManager.load(Parameters.class).all().one();
            TimeSource timeSource = AppBeans.getBean(TimeSource.class);

            HashMap<Customer, SupplyContract> latestSupplyContracts = getCustomerLatestSupplyContracts(parameters.getSupplyContractActiveStatus());
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(timeSource.currentTimestamp());
            SaveContext saveContext = new SaveContext();
            for (Customer customer : latestSupplyContracts.keySet()) {
                SupplyContract supplyContract = latestSupplyContracts.get(customer);
                if (supplyContract == null) continue;

                int leftDays = Math.abs(Days.daysBetween(new DateTime(supplyContract.getToDate()), new DateTime(calendar.getTime())).getDays()) + 1;

                Calendar startCalendar = Calendar.getInstance();
                startCalendar.setTime(supplyContract.getFromDate());
                Calendar endCalendar = Calendar.getInstance();
                endCalendar.setTime(supplyContract.getToDate());

                int months = (endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR)) * 12;
                months += endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
                if (endCalendar.get(Calendar.DAY_OF_MONTH) < startCalendar.get(Calendar.DAY_OF_MONTH)) {
                    months--;
                }

                int daysBefore = 61;
                if (months <= 3) daysBefore = 31;
                if (leftDays == daysBefore) {
//                    List<CustomerContact> customerContacts = getCustomerContacts(customer);

//                    for (CustomerContact customerContact : customerContacts) {
//                        if (customerContact.getContactType().equals(CustomerContactType.EMAIL)) {
                    List<String> customerPhoneNumbers =  new LinkedList<>();
                    String email = getCustomerEmail(customer, customerPhoneNumbers);
                            try {
                                if (!Objects.equals(email, "")) {
                                    MailServiceBean mailServiceBean = AppBeans.getBean(MailServiceBean.class);
                                    mailServiceBean.sendMessage(email, null,
                                            "მიწოდების ხელშეკრულების ვადის ამოწურვა", formMessageText(parameters.getSupplyContractEmailText(), supplyContract, false, parameters));
                                }

                            } catch (Exception e) {
                                loggerService.createLogFromException(e, getClass().toString());
                                createSentNotification(customer, email, calendar.getTime(),
                                        MessageSendStatus.FAILED, CustomerContactType.EMAIL, formMessageText(parameters.getSupplyContractEmailText(), supplyContract, false, parameters));
                                throw new RuntimeException(e.getMessage());
                            }

                    CustomerMessage emailMessage = createSentNotification(customer, email, calendar.getTime(),
                                    MessageSendStatus.SENT, CustomerContactType.EMAIL, formMessageText(parameters.getSupplyContractEmailText(), supplyContract, false, parameters));
                    saveContext.saving(emailMessage);

                    for (String phoneNumber : customerPhoneNumbers) {
                        CustomerMessage smsMessage =
                                sendMessageService.sendAnySms(true, phoneNumber, formMessageText(parameters.getSupplyContractSMSText(), supplyContract, true, parameters), NotificationType.SUPPLY_CONTRACT);
                        smsMessage.setType(NotificationType.SUPPLY_CONTRACT);
                        smsMessage.setCustomer(customer);
                        saveContext.saving(smsMessage);
                    }

                }
            }
            dataManager.save(saveContext);
        } catch (Exception e) {
            loggerService.createLogFromException(e, getClass().toString());
            throw new RuntimeException(e.getMessage());
        }
    }

    private String getCustomerEmail(Customer customer, List<String> customerPhoneNumbers) {
        String ans = "";
        for (CustomerContact contact : getCustomerContacts(customer)) {
            if (contact.getContactType().equals(CustomerContactType.EMAIL)) ans = contact.getContactInfo();
            if (contact.getContactType().equals(CustomerContactType.MOBILE_PHONE)) customerPhoneNumbers.add(contact.getContactInfo());
        }
        return ans;
//        BusinessCenter businessCenter = customer.getBusinessCenter();
//        CustomerCategory category = customer.getCategory();
//        ResponsibleEmployee responsibleEmployee = dataManager.load(ResponsibleEmployee.class)
//                .query("select e from prx_ResponsibleEmployee e where e.businessCenter.id = :businessCenterId and e.category.id = :categoryId")
//                .parameter("businessCenterId", businessCenter.getId())
//                .parameter("categoryId", category.getId())
//                .fetchPlan("responsibleEmployee-fetch-plan")
//                .optional().orElse(null);
//
//        if (responsibleEmployee != null) return responsibleEmployee.getUser().getEmail();
//        return "";
    }

    private HashMap<Customer, SupplyContract> getCustomerLatestSupplyContracts(Status supplyContractActiveStatus) {
        List<Object[]> latestSupplyContracts = entityManager.createNativeQuery("select s.CUSTOMER_ID, s.ID from PRX_SUPPLY_CONTRACT s " +
                        "join " +
                        "(select sc.CUSTOMER_ID as customer, max(sc.FROM_DATE) as date from PRX_SUPPLY_CONTRACT sc " +
                        "where sc.DELETED_BY is null and sc.STATUS_ID = #statusId " +
                        "group by sc.CUSTOMER_ID) contracts " +
                        "on contracts.date = s.FROM_DATE " +
                        "where s.DELETED_BY is null and s.STATUS_ID = #statusId")
                .setParameter("statusId", supplyContractActiveStatus.getId())
                .getResultList();

        HashMap<Customer, SupplyContract> res = new HashMap<>();
        latestSupplyContracts.forEach(item -> res.put(dataManager.load(Customer.class).id(item[0]).one(), dataManager.load(SupplyContract.class).id(item[1]).one()));
        return res;
    }

    private SupplyContract checkSupplyContractForCustomer(Customer customer) {
        List<SupplyContract> supplyContracts = dataManager.load(SupplyContract.class)
                .query("select e from prx_SupplyContract e where e.customer.id = :customerId")
                .parameter("customerId", customer.getId())
                .list();

        if (supplyContracts.isEmpty()) return null;
        supplyContracts.sort(Comparator.comparing(SupplyContract::getFromDate));
        return supplyContracts.get(supplyContracts.size() - 1);
    }

    private List<CustomerContact> getCustomerContacts(Customer customer) {
        return dataManager.load(CustomerContact.class)
                .query("select e from prx_CustomerContact e where e.customer.id = :customerId")
                .parameter("customerId", customer.getId())
                .list();
    }

    private CustomerMessage createSentNotification(Customer customer, String contactInfo, Date curDate,
                                        MessageSendStatus status, CustomerContactType contactType, String text) {
        Metadata metadata = AppBeans.getBean(Metadata.class);
        CustomerMessage sentNotification = metadata.create(CustomerMessage.class);
        sentNotification.setCustomer(customer);
        sentNotification.setContact(contactInfo);
        sentNotification.setDate(curDate);
        sentNotification.setContactType(contactType);
        sentNotification.setMessage(text);
        sentNotification.setStatus(status);
        sentNotification.setType(NotificationType.SUPPLY_CONTRACT);
        sentNotification.setSender(currentAuthentication.getUser().getUsername());

        return sentNotification;
    }

    private String formEmailText(String text, SupplyContract supplyContract) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(supplyContract.getToDate());
        return String.format(text, supplyContract.getCustomer().getIdentificationNumber(), Integer.toString(calendar.get(Calendar.YEAR)), Integer.toString(calendar.get(Calendar.DAY_OF_MONTH)), Integer.toString(calendar.get(Calendar.MONTH)));
    }

    private String formMessageText(String toFormat, SupplyContract supplyContract, boolean sms, Parameters parameters) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(supplyContract.getToDate());

        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(supplyContract.getToDate());
        calendar1.add(Calendar.DAY_OF_MONTH, getDaysBetween(supplyContract.getFromDate(), supplyContract.getToDate()));
        Date authorizationDate = parameters.getAuthorizationDate();
        if (authorizationDate != null && authorizationDate.before(calendar1.getTime())) calendar1.setTime(authorizationDate);
        return String.format(toFormat,
                calendar.get(Calendar.DAY_OF_MONTH),
                calendar.get(Calendar.MONTH) + 1,
                calendar.get(Calendar.YEAR),
                calendar1.get(Calendar.DAY_OF_MONTH),
                calendar1.get(Calendar.MONTH) + 1,
                calendar1.get(Calendar.YEAR));
    }

    private int getDaysBetween(Date date1, Date date2) {
        return Math.abs(Days.daysBetween(new DateTime(date1), new DateTime(date2)).getDays());
    }
}
