package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.setup.SupplyContract;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.system.Parameters;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.logservice.LoggerService;
import io.jmix.core.DataManager;
import io.jmix.core.SaveContext;
import io.jmix.core.TimeSource;
import io.jmix.core.security.Authenticated;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.*;

public class SupplyContractExtensionJob implements Job {

    @Autowired
    private DataManager dataManager;
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    @Authenticated
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        try {
            TimeSource timeSource = AppBeans.getBean(TimeSource.class);
            Parameters parameters = dataManager.load(Parameters.class).all().one();
            SaveContext saveContext = new SaveContext();
            Status supplyContractActiveStatus = parameters.getSupplyContractActiveStatus();
            HashMap<Customer, SupplyContract> latestSupplyContracts = getCustomerLatestSupplyContracts(supplyContractActiveStatus);

            Date curDate = timeSource.currentTimestamp();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(curDate);
            calendar.add(Calendar.DAY_OF_MONTH, -1);
            Date yesterday = calendar.getTime();
            Status supplyContractCanceledStatus = parameters.getSupplyContractCanceledStatus();

            for (Customer customer : latestSupplyContracts.keySet()) {
                SupplyContract lastSupplyContract = latestSupplyContracts.get(customer);
                boolean futureContract = hasActiveContractInFuture(customer, timeSource.currentTimestamp(), supplyContractActiveStatus);
                if (sameDay(lastSupplyContract.getToDate(), yesterday) && !futureContract) {
                    calendar.setTime(lastSupplyContract.getToDate());
                    calendar.add(Calendar.DAY_OF_MONTH, getDaysBetween(lastSupplyContract.getPrevToDate(), lastSupplyContract.getToDate()));
                    Date authorizationDate = parameters.getAuthorizationDate();
                    if (authorizationDate != null && authorizationDate.before(calendar.getTime())) calendar.setTime(authorizationDate);
                    lastSupplyContract.setPrevToDate(lastSupplyContract.getToDate());
                    lastSupplyContract.setJobExecuted(true);
                    lastSupplyContract.setToDate(calendar.getTime());
                    saveContext.saving(lastSupplyContract);
                    continue;
                }

                if (futureContract) {
                    SupplyContract supplyContract = dataManager.load(SupplyContract.class).id(lastSupplyContract.getId()).one();
                    supplyContract.setStatus(supplyContractCanceledStatus);
                    saveContext.saving(supplyContract);
                }
            }

            dataManager.save(saveContext);
        } catch (Exception e) {
            loggerService.createLogFromException(e, getClass().toString());
            throw new RuntimeException(e.getMessage());
        }
    }

    private SupplyContract getOtherActiveContract(Customer customer, Date date, Status activeStatus) {
        return dataManager.load(SupplyContract.class)
                .query("select e from prx_SupplyContract e " +
                        "where e.customer.id = :customerId and e.toDate = :date and e.status.id = :activeStatus")
                .parameter("customerId", customer.getId())
                .parameter("date", date)
                .parameter("activeStatus", activeStatus.getId())
                .optional().orElse(null);
    }

    int getDaysBetween(Date date1, Date date2) {
        return Math.abs(Days.daysBetween(new DateTime(date1), new DateTime(date2)).getDays());
    }

    boolean hasActiveContractInFuture(Customer customer, Date date, Status activeStatus) {
        return dataManager.load(SupplyContract.class)
                .query("select e from prx_SupplyContract e " +
                        "where e.customer.id = :customerId and e.fromDate >= :date and e.status.id = :activeStatus")
                .parameter("customerId", customer.getId())
                .parameter("date", date)
                .parameter("activeStatus", activeStatus.getId())
                .optional().orElse(null) != null;
    }

    boolean sameDay(Date date1, Date date2) {
        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTime(date1);

        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(date2);

        return calendar1.get(Calendar.DAY_OF_YEAR) == calendar2.get(Calendar.DAY_OF_YEAR) &&
                calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR);
    }

    private HashMap<Customer, SupplyContract> getCustomerLatestSupplyContracts(Status supplyContractActiveStatus) {
        try {
            List<Object[]> latestSupplyContracts = entityManager.createNativeQuery("select s.CUSTOMER_ID, s.ID from PRX_SUPPLY_CONTRACT s " +
                            "join " +
                            "(select sc.CUSTOMER_ID as customer, max(sc.FROM_DATE) as date from PRX_SUPPLY_CONTRACT sc " +
                            "where sc.DELETED_BY is null and sc.STATUS_ID = #statusId and sc.FROM_DATE < CURRENT_DATE " +
                            "group by sc.CUSTOMER_ID) contracts " +
                            "on contracts.date = s.FROM_DATE " +
                            "where s.DELETED_BY is null and s.STATUS_ID = #statusId")
                    .setParameter("statusId", supplyContractActiveStatus.getId())
                    .getResultList();

            HashMap<Customer, SupplyContract> res = new HashMap<>();
            latestSupplyContracts.forEach(item -> res.put(dataManager.load(Customer.class).id(item[0]).one(), dataManager.load(SupplyContract.class).id(item[1]).one()));
            return res;
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
