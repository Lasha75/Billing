package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.cutoff.TelasiCustomerBalance;
import ge.proxima.primebilling.services.logservice.LoggerService;
import ge.proxima.primebilling.services.telasi.TelasiCustomerBalanceUpdate;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class TelasiCustomerbalanceJob implements Job {

    @Override
    @Authenticated
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        try
        {
            loggerService.createAndSaveLog("Start telasi balance update",true,"telasi balance");
           // TelasiCustomerBalance custbalance = AppBeans.getBean(TelasiCustomerBalance.class);
          //  custbalance.getTelasiBalance();

            TelasiCustomerBalanceUpdate custbalance = AppBeans.getBean(TelasiCustomerBalanceUpdate.class);
            custbalance.updateBalance();
            loggerService.createAndSaveLog("End telasi balance update",true,"telasi balance");
        }
        catch (Exception e) {
            loggerService.createLogFromException(e, getClass().toString());
            throw new RuntimeException(e.getMessage());
        }
    }
}
