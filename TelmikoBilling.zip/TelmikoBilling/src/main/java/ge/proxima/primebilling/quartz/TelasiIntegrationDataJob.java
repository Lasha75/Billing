package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.services.invoiceservice.app.TelasiIntegTransactional;
import ge.proxima.primebilling.services.invoiceservice.app.TelasiIntegrationBean;
import ge.proxima.primebilling.java.system.AppBeans;
import ge.proxima.primebilling.services.logservice.LoggerService;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class TelasiIntegrationDataJob implements Job {

    @Override
    @Authenticated
    public void execute(JobExecutionContext context) throws JobExecutionException {
        LoggerService loggerService = AppBeans.getBean(LoggerService.class);
        try
        {

            loggerService.createAndSaveLog("Start telasi data integration",true,"telasi integration");
            TelasiIntegrationBean telasiIntegration = AppBeans.getBean(TelasiIntegrationBean.class);
             telasiIntegration.runIntegration();

            TelasiIntegTransactional telasiIntegTransactional = AppBeans.getBean(TelasiIntegTransactional.class);
            telasiIntegTransactional.runIntegration();

            loggerService.createAndSaveLog("End telasi data integration",true,"telasi integration");
        }
        catch (Exception e) {
        loggerService.createLogFromException(e, getClass().toString());
        throw new RuntimeException(e.getMessage());
     }
    }
}
