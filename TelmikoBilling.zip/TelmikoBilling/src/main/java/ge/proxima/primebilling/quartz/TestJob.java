package ge.proxima.primebilling.quartz;

import ge.proxima.primebilling.entity.counter.CounterCoefficient;
import ge.proxima.primebilling.entity.tariff.Tariff;
import ge.proxima.primebilling.entity.transactions.CoefficientTmp;
import ge.proxima.primebilling.entity.transactions.TariffTmp;
import ge.proxima.primebilling.services.tariffservice.TariffService;
import io.jmix.core.DataManager;
import io.jmix.core.Metadata;
import io.jmix.core.security.Authenticated;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class TestJob implements Job {

    private static final Logger log = org.slf4j.LoggerFactory.getLogger(TestJob.class);
    @Autowired
    private DataManager dataManager;
    @Autowired
    private Metadata metadata;
    @Autowired
    private TariffService tariffService;

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
        BigDecimal res;
        try {
            res = tariffService.coefficientChangeCalculation(createTestData(), BigDecimal.valueOf(100),
                    simpleDateFormat.parse("01/01/2023"), simpleDateFormat.parse("01/31/2023"), UUID.fromString("1bd5d897-d0e0-18ee-ccc5-f4ac1778a58b"));
            log.info(String.valueOf(res));
        } catch (ParseException e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    private List<CoefficientTmp> createTestData() throws ParseException {
//        TariffTmp tariffTmp = metadata.create(TariffTmp.class);
//        Calendar calendar = Calendar.getInstance();
//        calendar.set(Calendar.DAY_OF_MONTH, 1);
//        calendar.add(Calendar.DAY_OF_MONTH, -2);
//        tariffTmp.setStartDate(calendar.getTime());
//        calendar.add(Calendar.DAY_OF_MONTH, 2);
//        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
//        calendar.add(Calendar.DAY_OF_MONTH, 2);
//        tariffTmp.setEndDate(calendar.getTime());
//
//        Tariff tariff = dataManager.load(Tariff.class)
//                .query("select e from prx_Tariff e where e.code = :code")
//                .parameter("code", "001")
//                .optional().orElse(null);
//
//        tariffTmp.setTariff(tariff);
//
//        List<TariffTmp> res = new LinkedList<>();
//        res.add(tariffTmp);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");

        CoefficientTmp coefficientTmp1 = metadata.create(CoefficientTmp.class);
        coefficientTmp1.setStartDate(simpleDateFormat.parse("01/10/2023"));
        coefficientTmp1.setEndDate(simpleDateFormat.parse("01/13/2023"));
        coefficientTmp1.setCoefficient(getCoefficient("004"));

        CoefficientTmp coefficientTmp2 = metadata.create(CoefficientTmp.class);
        coefficientTmp2.setStartDate(simpleDateFormat.parse("01/23/2023"));
        coefficientTmp2.setEndDate(simpleDateFormat.parse("01/25/2023"));
        coefficientTmp2.setCoefficient(getCoefficient("005"));

        List<CoefficientTmp> res = new LinkedList<>();
        res.add(coefficientTmp1);
        res.add(coefficientTmp2);
        return res;
    }

    private CounterCoefficient getCoefficient(String code) {
        return dataManager.load(CounterCoefficient.class)
                .query("select e from prx_CounterCoefficient e where e.code = :code")
                .parameter("code", code)
                .optional().orElse(null);
    }
}
