package ge.proxima.primebilling.quartz;

import io.jmix.core.security.Authenticated;
import io.jmix.email.EmailException;
import io.jmix.emailtemplates.EmailTemplates;
import io.jmix.emailtemplates.exception.ReportParameterTypeChangedException;
import io.jmix.emailtemplates.exception.TemplateNotFoundException;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("prx_XMLReportJob")
public class XMLReportJob  implements Job {

    @Autowired
    private EmailTemplates emailTemplates;
    private static final Logger log = LoggerFactory.getLogger(XMLReportJob.class);

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        sendemail();
    }

    private void sendemail()
    {
        try {


            emailTemplates.buildFromTemplate("XMLReport")
                    .sendEmail(true);

        }
        catch (TemplateNotFoundException | EmailException |
               ReportParameterTypeChangedException e) {
            log.info(e.getMessage());
        }
    }


}