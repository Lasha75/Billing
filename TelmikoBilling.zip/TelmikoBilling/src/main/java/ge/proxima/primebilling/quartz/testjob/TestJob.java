package ge.proxima.primebilling.quartz.testjob;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.Extension;
import ge.proxima.primebilling.java.system.AppBeans;
import io.jmix.core.DataManager;
import io.jmix.core.Metadata;
import io.jmix.core.security.Authenticated;
import io.jmix.ui.Notifications;
import org.apache.juli.logging.Log;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Calendar;
import java.util.logging.Logger;

public class TestJob implements Job {

    @Autowired
    private DataManager dataManager;

    @Autowired
    private Metadata metadata;

    @Authenticated
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        Calendar calendar = Calendar.getInstance();
        Extension extension = metadata.create(Extension.class);
        extension.setOperationDate(calendar.getTime());
        extension.setCustomerNumber("01008058099");

        dataManager.save(extension);
    }
}
