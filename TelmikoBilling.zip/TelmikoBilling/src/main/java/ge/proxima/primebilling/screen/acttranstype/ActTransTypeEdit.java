package ge.proxima.primebilling.screen.acttranstype;

import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.ActTransType;

@UiController("prx_ActTransType.edit")
@UiDescriptor("act-trans-type-edit.xml")
@EditedEntityContainer("actTransTypeDc")
public class ActTransTypeEdit extends StandardEditor<ActTransType> {
}