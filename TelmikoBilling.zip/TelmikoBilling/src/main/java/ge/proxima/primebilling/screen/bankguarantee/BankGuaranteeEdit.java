package ge.proxima.primebilling.screen.bankguarantee;

import ge.proxima.primebilling.entity.BankGuaranteeLine;
import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.deposit.BankGuaranteeRecord;
import ge.proxima.primebilling.entity.enums.BankGuaranteeStatus;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.entity.system.Parameters;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import ge.proxima.primebilling.java.uidecorators.StandardEditorDecorator;
import ge.proxima.primebilling.java.uidecorators.decorators.AttachmentScreenDecorator;
import ge.proxima.primebilling.services.deposit.deposit.DepositService;
import io.jmix.audit.snapshot.EntitySnapshotManager;
import io.jmix.auditui.screen.snapshot.SnapshotDiffViewer;
import io.jmix.core.DataManager;
import io.jmix.core.EntityStates;
import io.jmix.core.Metadata;
import io.jmix.ui.Notifications;
import io.jmix.ui.action.Action;
import io.jmix.ui.action.list.RefreshAction;
import io.jmix.ui.component.*;
import io.jmix.ui.model.CollectionPropertyContainer;
import io.jmix.ui.model.DataContext;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.model.InstanceLoader;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.deposit.BankGuarantee;
import org.springframework.beans.factory.annotation.Autowired;

import javax.inject.Named;
import java.math.BigDecimal;
import java.util.*;

@UiController("prx_BankGuarantee.edit")
@UiDescriptor("bank-guarantee-edit.xml")
@EditedEntityContainer("bankGuaranteeDc")
public class BankGuaranteeEdit extends StandardEditorDecorator<BankGuarantee> {
    @Autowired
    private Notifications notifications;
    @Autowired
    private TextField<BigDecimal> amountField;
    @Autowired
    private TextField<BigDecimal> wreckedAmountField;
    @Autowired
    private EntityPicker<Customer> customerField;
    @Autowired
    private TextField<String> docNumberField;
    @Autowired
    private DateField<Date> startDateField;
    @Autowired
    private GroupBoxLayout bankGuaranteelineBox;
    @Autowired
    private ComboBox<BankGuaranteeStatus> statusField;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private Metadata metadata;
    @Autowired
    private DepositService depositService;
    @Autowired
    private CollectionPropertyContainer<BankGuaranteeLine> bankGuaranteelineDc;
    @Autowired
    private Table<BankGuaranteeLine> bankGuaranteelineTable;
    @Autowired
    private Button bankGuaranteelineTableRefreshBtn;
    @Named("bankGuaranteelineTable.refresh")
    private RefreshAction bankGuaranteelineTableRefresh;
    @Autowired
    private Form form;
    @Autowired
    private InstanceLoader<BankGuarantee> bankGuaranteeDl;
    @Autowired
    private DateField<Date> endDateField;
    @Autowired
    private EntityStates entityStates;
    @Autowired
    protected SnapshotDiffViewer snapshotDiff;
    @Autowired
    private EntitySnapshotManager entitySnapshotManager;
    @Autowired
    private InstanceContainer<BankGuarantee> bankGuaranteeDc;
    @Autowired
    private ButtonsPanel buttonPanel;

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
/*        if(!entityStates.isNew(getEditedEntity()))
        {
            snapshotDiff.loadVersions(getEditedEntity());
        }*/
    }



    @Subscribe
    public void onInitEntity(InitEntityEvent<BankGuarantee> event) {
        amountField.setEditable(true);
        wreckedAmountField.setEditable(false);
        customerField.setEditable(true);
        docNumberField.setEditable(true);
        startDateField.setEditable(true);
        bankGuaranteelineBox.setEnabled(false);
        event.getEntity().setStatus(BankGuaranteeStatus.ACTIVE);
    }

    @Subscribe
    public void onAfterCommitChanges(AfterCommitChangesEvent event) {
        bankGuaranteelineBox.setEnabled(true);
       // entitySnapshotManager.createSnapshot(getEditedEntity(), getEditedEntityContainer().getFetchPlan());
    }

    @Subscribe(target = Target.DATA_CONTEXT)
    public void onPostCommit(DataContext.PostCommitEvent event) {
        entitySnapshotManager.createSnapshot(getEditedEntity(), getEditedEntityContainer().getFetchPlan());
    }

    @Subscribe("tabSheet")
    public void onTabSheetSelectedTabChange(TabSheet.SelectedTabChangeEvent event) {
        if(!entityStates.isNew(getEditedEntity()))
        {
            snapshotDiff.loadVersions(getEditedEntity());
        }
    }



    private void getChiledCustomers()
    {
        Parameters parameters = dataManager.load(Parameters.class)
                .query("select e from prx_Parameters e")
                .fetchPlan("parameters-fetch-plan")
                .one();

        TransactionTypeCombination transactionTypeCombination = parameters.getDepositTransactionType();
        if (bankGuaranteeDc.getItem().getCustomer()!= null) {
            List<BankGuaranteeLine> childCustomerRecords =
                    generateRecords(depositService.getChildCustomerDepositAmounts(bankGuaranteeDc.getItem().getCustomer().getId(), transactionTypeCombination.getId()));
        }
    }
    private List<BankGuaranteeLine> generateRecords(List<Object[]> customerDepositAmounts) {
        List<BankGuaranteeLine> res = new LinkedList<>();
        for (Object[] obj : customerDepositAmounts) {
            Customer child = dataManager.load(Customer.class).id(obj[0]).one();
            BigDecimal amount = (BigDecimal) obj[1];
            BankGuaranteeLine bgl=dataManager.create(BankGuaranteeLine.class);
            bgl.setBankGuarantee(bankGuaranteeDc.getItem());
            bgl.setCustomer(child);
            bgl.setAmount(amount);dataManager.save(bgl);
        } return res;
    }
    private BankGuaranteeLine createRecord(Customer customer, BigDecimal amount) {
        BankGuaranteeLine record = metadata.create(BankGuaranteeLine.class);
        record.setCustomer(customer);
        record.setAmount(amount);
        return record;
    }

    @Subscribe("bankGuaranteelineTableGenBankGaranteeLineBtn")
    public void onBankGuaranteelineTableGenBankGaranteeLineBtnClick(Button.ClickEvent event) {
        bankGuaranteelineDc.mute();
        bankGuaranteelineDc.getMutableItems().clear();
        getChiledCustomers();
        bankGuaranteelineTableRefresh.execute();

    }

    @Subscribe(target = Target.DATA_CONTEXT)
    public void onPreCommit(DataContext.PreCommitEvent event) {
        if(endDateField.getValue().before(startDateField.getValue()))
        {
            event.preventCommit();
            notifications.create(Notifications.NotificationType.ERROR)
                    .withCaption("თარიღები არ არის სწორი!")
                    .show();
        }
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        init(new AttachmentScreenDecorator<>(this,"BankGuaranteeEdit", buttonPanel));
    }


    @Override
    public BaseUuidEntity getSelected(String key) {
        return getEditedEntity();
    }
}