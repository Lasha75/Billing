package ge.proxima.primebilling.screen.bankguaranteeline;

import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.BankGuaranteeLine;

@UiController("prx_BankGuaranteeLine.browse")
@UiDescriptor("bank-guarantee-line-browse.xml")
@LookupComponent("bankGuaranteeLinesTable")
public class BankGuaranteeLineBrowse extends StandardLookup<BankGuaranteeLine> {
}