package ge.proxima.primebilling.screen.bankguaranteeline;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.deposit.BankGuarantee;
import ge.proxima.primebilling.entity.transactions.Transaction;
import ge.proxima.primebilling.screen.customer.customer.CustomerBrowse;
import ge.proxima.primebilling.screen.customer.customer.CustomerFilterByBrowse;
import io.jmix.ui.component.EntityPicker;
import io.jmix.ui.component.TextField;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.BankGuaranteeLine;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

@UiController("prx_BankGuaranteeLine.edit")
@UiDescriptor("bank-guarantee-line-edit.xml")
@EditedEntityContainer("bankGuaranteeLineDc")
public class BankGuaranteeLineEdit extends StandardEditor<BankGuaranteeLine> {
    @Install(to = "customerField.entityLookup", subject = "screenConfigurer")
    private void customerFieldEntityLookupScreenConfigurer(Screen screen) {
        ((CustomerFilterByBrowse) screen).setParmIdentificationNumber(bankGuarantee.getCustomer().getIdentificationNumber());
    }

    public BankGuarantee bankGuarantee;
    @Autowired
    private EntityPicker<BankGuarantee> bankGuaranteeField;
    @Autowired
    private InstanceContainer<BankGuaranteeLine> bankGuaranteeLineDc;
    @Autowired
    private TextField<BigDecimal> amountField;
    @Autowired
    private EntityPicker<Customer> customerField;
    @Autowired
    private EntityPicker<Transaction> transactionField;

    public void setBankGuarantee(BankGuarantee bankGuarantee) {
        this.bankGuarantee = bankGuarantee;
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {

    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        bankGuaranteeField.setEditable(false);
        bankGuarantee=bankGuaranteeField.getValue();
        if (!transactionField.isEmpty()) {
            amountField.setEditable(false);
            customerField.setEditable(false);
        } else {
            amountField.setEditable(true);
            customerField.setEditable(true);
        }

    }






}