package ge.proxima.primebilling.screen.bankguaranteeline;

import ge.proxima.primebilling.entity.customer.Customer;
import ge.proxima.primebilling.entity.customer.CustomerContract;
import ge.proxima.primebilling.entity.customer.CustomerContractType;
import ge.proxima.primebilling.entity.deposit.BankGuarantee;
import ge.proxima.primebilling.entity.deposit.BankGuaranteeRecord;
import ge.proxima.primebilling.entity.reftables.Status;
import ge.proxima.primebilling.entity.settlement.SettlementTypes;
import ge.proxima.primebilling.entity.system.Parameters;
import ge.proxima.primebilling.entity.transactions.OpenTransaction;
import ge.proxima.primebilling.entity.transactions.Transaction;
import ge.proxima.primebilling.entity.transactions.transtypes.TransactionTypeCombination;
import ge.proxima.primebilling.screen.system.imp.ImportScreen;
import ge.proxima.primebilling.services.deposit.deposit.DepositService;
import ge.proxima.primebilling.services.notificationsservice.NotificationsService;
import ge.proxima.primebilling.services.settlement.SettlementService;
import ge.proxima.primebilling.services.settlement.SettlementSql;
import io.jmix.core.DataManager;
import io.jmix.core.Metadata;
import io.jmix.core.SaveContext;
import io.jmix.core.TimeSource;
import io.jmix.ui.Dialogs;
import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.Screens;
import io.jmix.ui.action.Action;
import io.jmix.ui.app.inputdialog.DialogActions;
import io.jmix.ui.app.inputdialog.DialogOutcome;
import io.jmix.ui.app.inputdialog.InputParameter;
import io.jmix.ui.component.*;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.model.DataContext;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.BankGuaranteeLine;
import io.jmix.ui.screen.LookupComponent;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.*;

@UiController("prx_BankGuaranteeLineedit.browse")
@UiDescriptor("bank-guarantee-lineEdit-browse.xml")
@LookupComponent("bankGuaranteeLinesTable")
public class BankGuaranteeLineEditBrowse extends StandardLookup<BankGuaranteeLine> {

    @Autowired
    private CollectionContainer<BankGuaranteeLine> bankGuaranteeLinesDc;
    @Autowired
    private CollectionLoader<BankGuaranteeLine> bankGuaranteeLinesDl;
    @Autowired
    private DateField endDateField;
    @Autowired
    private TextField amountField;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private Button createBtn;
    @Autowired
    private EntityPicker customerField;
    @Autowired
    private TextField docNumberField;
    @Autowired
    private Button editBtn;
    @Autowired
    private GroupTable<BankGuaranteeLine> bankGuaranteeLinesTable;
    @Autowired
    private DateField startDateField;
    @Autowired
    private ComboBox statusField;
    @Autowired
    private TextField wreckedAmountField;
    private BankGuarantee bankGuarantee;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private DepositService depositService;
    @Autowired
    private Metadata metadata;
    @Autowired
    private TimeSource timeSource;
    @Autowired
    private Dialogs dialogs;
    @Autowired
    private MessageBundle messageBundle;
    @Autowired
    private NotificationsService notificationsService;
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private Screens screens;
    @Autowired
    private SettlementService settlementService;
    @Autowired
    private SettlementSql settlementSql;
    @Autowired
    private Notifications notifications;

    public void setBankGuarantee(BankGuarantee bankGuarantee) {
        this.bankGuarantee = bankGuarantee;
    }



    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        if(bankGuarantee!= null)
        {
            bankGuaranteeLinesDl.setParameter("parmBankGuarantee",bankGuarantee);
            bankGuaranteeLinesDl.load();
            customerField.setValue(bankGuarantee.getCustomer());
            docNumberField.setValue(bankGuarantee.getDocNumber());
            startDateField.setValue(bankGuarantee.getStartDate());
            endDateField.setValue(bankGuarantee.getEndDate());
            statusField.setValue(bankGuarantee.getStatus());
            wreckedAmountField.setValue(bankGuarantee.getWreckedAmount());
            amountField.setValue(bankGuarantee.getAmount());

        }

    }

    private void getChiledCustomers()
    {
        Parameters parameters = dataManager.load(Parameters.class)
                .query("select e from prx_Parameters e")
                .fetchPlan("parameters-fetch-plan")
                .one();

        TransactionTypeCombination transactionTypeCombination = parameters.getDepositTransactionType();
        if (bankGuarantee.getCustomer()!= null) {
            List<BankGuaranteeLine> childCustomerRecords =
                    generateRecords(depositService.getChildCustomerDepositAmounts(bankGuarantee.getCustomer().getId(), transactionTypeCombination.getId()));
            List<BankGuaranteeLine> errorList = new ArrayList<>();
            StringBuilder errorStr = new StringBuilder();
            for(BankGuaranteeLine line : childCustomerRecords) {
                if(BigDecimal.ZERO.compareTo(line.getAmount()) >= 0) {
                    errorList.add(line);
                    errorStr.append(String.format("%s : %s\n", line.getCustomer().getCustomerNumber(), line.getAmount().toString()));
                }
            }

            if(errorList.size() > 0) {
                childCustomerRecords.removeAll(errorList);
                notifications.create()
                        .withType(Notifications.NotificationType.ERROR)
                        .withDescription(messageBundle.getMessage("wrongAmount")+"\n\n"+errorStr)
                        .show();
            }

            SaveContext saveContext = new SaveContext();
            saveContext.getEntitiesToSave().addAll(childCustomerRecords);
            dataManager.save(saveContext);
        }
    }

    @Subscribe(id = "bankGuaranteeLinesDc", target = Target.DATA_CONTAINER)
    public void onBankGuaranteeLinesDcCollectionChange(CollectionContainer.CollectionChangeEvent<BankGuaranteeLine> event) {
        bankGuarantee=dataManager.load(BankGuarantee.class).id(bankGuarantee.getId()).one();
        wreckedAmountField.setValue(bankGuarantee.getWreckedAmount());
    }

    private List<BankGuaranteeLine> generateRecords(List<Object[]> customerDepositAmounts) {
        List<BankGuaranteeLine> res = new LinkedList<>();
        for (Object[] obj : customerDepositAmounts) {
            Customer child = dataManager.load(Customer.class).id(obj[0]).one();
            BigDecimal amount = (BigDecimal) obj[1];
            BankGuaranteeLine bgl=dataManager.create(BankGuaranteeLine.class);
            bgl.setBankGuarantee(bankGuarantee);
            bgl.setCustomer(child);
            bgl.setAmount(amount);
            res.add(bgl);
        }
        return res;
    }
    private BankGuaranteeLine createRecord(Customer customer, BigDecimal amount) {
        BankGuaranteeLine record = metadata.create(BankGuaranteeLine.class);
        record.setBankGuarantee(bankGuarantee);
        record.setCustomer(customer);
        record.setAmount(amount);
        return record;
    }

    @Subscribe("bankGuaranteelineTableGenBankGaranteeLineBtn")
    public void onBankGuaranteelineTableGenBankGaranteeLineBtnClick(Button.ClickEvent event) {
        getChiledCustomers();
        bankGuaranteeLinesDl.load();
    }

    @Subscribe("btnCreateTransactions")
    public void onBtnCreateTransactionsClick(Button.ClickEvent event) {

        dialogs.createInputDialog(this)
                .withCaption(messageBundle.getMessage("chooseDateForTransaction"))
                .withParameter(InputParameter.dateParameter("date").withRequired(true).withCaption(messageBundle.getMessage("date")))
                .withActions(DialogActions.OK)
                .withCloseListener(inputDialogCloseEvent -> {
                    if (inputDialogCloseEvent.closedWith(DialogOutcome.OK)) {
                        Date date = inputDialogCloseEvent.getValue("date");
                        if (date != null) {
                            Parameters parameters = dataManager.load(Parameters.class)
                                    .query("select e from prx_Parameters e")
                                    .fetchPlan("parameters-fetch-plan")
                                    .one();

                            TransactionTypeCombination depositBankGuaranteeCombinationType = parameters.getDepositBankGuaranteeCombinationType();
                            CustomerContractType contractTypeDeposit = parameters.getContractTypeDeposite();
                            Status contractActiveStatus = parameters.getContractActiveStatus();
                            SaveContext saveContext = new SaveContext();

                            for (BankGuaranteeLine entity : bankGuaranteeLinesTable.getSelected()) {

                                String accountNumber = "";
                                if(entity.getTransaction() == null) {
                                    BankGuaranteeLine line=dataManager.load(BankGuaranteeLine.class).id(entity.getId()).one();
                                    if (entity.getCustomer() != null) {
                                        CustomerContract customerDepositContract = getCustomerDepositContract(entity.getCustomer(), contractTypeDeposit, contractActiveStatus);
                                        if (customerDepositContract != null) {
                                            accountNumber = customerDepositContract.getCode();
                                        } else {
                                            notificationsService.createAndShowNotification(Notifications.NotificationType.ERROR, messageBundle.getMessage("noActiveDepositContracr"));
                                            return;
                                        }
                                    }
                                    Transaction transaction = createTransactionForBankGuaranteeRecord(entity, date, depositBankGuaranteeCombinationType, accountNumber);
                                    //bankGuaranteeLinesDl.getContainer().getItem().setTransaction(transaction);
                                    saveContext.saving(transaction);
                                    saveContext.saving(createOpenTransactionForBankGuaranteeRecord(entity, date, depositBankGuaranteeCombinationType, transaction));
                                    line.setTransaction(transaction);
                                    saveContext.saving(line);
                                }
                                else
                                {
                                    notificationsService.createAndShowNotification(Notifications.NotificationType.TRAY, messageBundle.getMessage("გატარებული ჩანაწერი"));
                                }
                            }
                            //saveContext.saving(bankGuarantee);
                            //dataManager.save(saveContext);

                            //closeWithDefaultAction();
                            dataManager.save(saveContext);

                            for (BankGuaranteeLine entity : bankGuaranteeLinesTable.getSelected()) {
                                settlementSql.callSettlement(SettlementTypes.CUSTOMER, entity.getCustomer(), null, true);
                                settlementSql.callSettlement(SettlementTypes.CUSTOMER, entity.getCustomer(), null, false);
                            }
                            notificationsService.createAndShowNotification(Notifications.NotificationType.TRAY, messageBundle.getMessage("success"));
                            bankGuaranteeLinesDl.load();
                        }
                    }
                })
                .build()
                .show();
    }
    private Transaction createTransactionForBankGuaranteeRecord(BankGuaranteeLine record, Date date, TransactionTypeCombination depositBankGuaranteeCombinationType,
                                                                String accountNumber) {
        Transaction transaction = metadata.create(Transaction.class);
        transaction.setTransTypeCombination(depositBankGuaranteeCombinationType);
        transaction.setCustomer(record.getCustomer());
        transaction.setCustomerNumber(record.getCustomer() != null ? record.getCustomer().getCustomerNumber() : "");
        transaction.setAmount(record.getAmount().negate());
        transaction.setBankGuaranteeNumber(bankGuarantee != null ? bankGuarantee.getDocNumber() : "");
        transaction.setBankGuaranteeStartDate(bankGuarantee != null ? bankGuarantee.getStartDate() : timeSource.currentTimestamp());
        transaction.setBankGuaranteeEndDate(bankGuarantee != null ? bankGuarantee.getEndDate() : timeSource.currentTimestamp());
        transaction.setAccountType(depositBankGuaranteeCombinationType != null ? depositBankGuaranteeCombinationType.getContractType() : null);
        transaction.setTransDate(date);
        transaction.setInvoiceDate(date);
        transaction.setAccountNumber(accountNumber);
        return transaction;
    }

    private OpenTransaction createOpenTransactionForBankGuaranteeRecord(BankGuaranteeLine record, Date date, TransactionTypeCombination depositBankGuaranteeCombinationType, Transaction transaction) {
        OpenTransaction openTransaction = metadata.create(OpenTransaction.class);
        openTransaction.setTransTypeCombination(depositBankGuaranteeCombinationType);
        openTransaction.setCustomer(record.getCustomer());
        openTransaction.setCustomerNumber(record.getCustomer() != null ? record.getCustomer().getCustomerNumber() : "");
        openTransaction.setAmount(record.getAmount().negate());
        openTransaction.setBankGuaranteeNumber(bankGuarantee != null ? bankGuarantee.getDocNumber() : "");
        openTransaction.setBankGuaranteeStartDate(bankGuarantee != null ? bankGuarantee.getStartDate() : timeSource.currentTimestamp());
        openTransaction.setBankGuaranteeEndDate(bankGuarantee != null ? bankGuarantee.getEndDate() : timeSource.currentTimestamp());
        openTransaction.setAccountType(depositBankGuaranteeCombinationType != null ? depositBankGuaranteeCombinationType.getContractType() : null);
        openTransaction.setTransDate(date);
        openTransaction.setInvoiceDate(date);
        openTransaction.setTransaction(transaction);
        openTransaction.setAccountNumber(transaction.getAccountNumber());
        return openTransaction;
    }
    private CustomerContract getCustomerDepositContract(Customer customer, CustomerContractType depositType, Status activeStatus) {
        return dataManager.load(CustomerContract.class)
                .query("select e from prx_CustomerContract e where e.customer.id = :customerId and e.type.id = :typeId and e.status.id = :statusId")
                .parameter("customerId", customer.getId())
                .parameter("typeId", depositType.getId())
                .parameter("statusId", activeStatus.getId())
                .optional().orElse(null);
    }

    @Subscribe("importBtn")
    public void onImportBtnClick(Button.ClickEvent event) {
        screenBuilders.screen(this)
                .withScreenClass(ImportScreen.class)
                .build()
                .show();
        bankGuaranteeLinesDl.load();
    }

    @Subscribe("btnClose")
    public void onBtnCloseClick(Button.ClickEvent event) {
        this.closeWithDefaultAction();
    }

    @Subscribe("bankGuaranteeLinesTable.create")
    public void onBankGuaranteeLinesTableCreate(Action.ActionPerformedEvent event) {
      Screen lineEdit= screenBuilders.editor(bankGuaranteeLinesTable).newEntity()
              .withInitializer(s -> s.setBankGuarantee(bankGuarantee))
              .build()
              .show();

    }
}