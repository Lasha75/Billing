package ge.proxima.primebilling.screen.bcourtappealdecision;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.uidecorators.StandardLookupDecorator;
import ge.proxima.primebilling.java.uidecorators.decorators.AttachmentScreenDecorator;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.reftables.BCourtAppealDecision;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("prx_BCourtAppealDecision.browse")
@UiDescriptor("b-court-appeal-decision-browse.xml")
@LookupComponent("bCourtAppealDecisionsTable")
public class BCourtAppealDecisionBrowse extends StandardLookupDecorator<BCourtAppealDecision> {

    @Autowired
    private GroupTable<BCourtAppealDecision> bCourtAppealDecisionsTable;
    @Autowired
    private ButtonsPanel buttonsPanel;

    @Override
    public BaseUuidEntity getSelected(String key) {
        return bCourtAppealDecisionsTable.getSingleSelected();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        init(
                new AttachmentScreenDecorator<BaseUuidEntity, BCourtAppealDecisionBrowse>( this, "BCourtAppealDecisionBrowse", buttonsPanel)
        );
    }
    
}