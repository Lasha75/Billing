package ge.proxima.primebilling.screen.bcourtappealdecision;

import ge.proxima.primebilling.entity.CCourtCaseEvent;
import ge.proxima.primebilling.entity.CCourtResolutionMapping;
import ge.proxima.primebilling.entity.CCourtResolutionType;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.uidecorators.StandardEditorDecorator;
import ge.proxima.primebilling.java.uidecorators.decorators.AttachmentScreenDecorator;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.reftables.BCourtAppealDecision;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("prx_BCourtAppealDecision.edit")
@UiDescriptor("b-court-appeal-decision-edit.xml")
@EditedEntityContainer("bCourtAppealDecisionDc")
public class BCourtAppealDecisionEdit extends StandardEditorDecorator<BCourtAppealDecision> {
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private EntityComboBox<CCourtResolutionMapping> entityComboBox;
    @Autowired
    private CollectionLoader<CCourtResolutionMapping> cCourtResolutionMappingsDl;
    @Autowired
    private ComboBox<CCourtCaseEvent> eventField;
    @Autowired
    private ComboBox<CCourtResolutionType> resolutionTypeField;

    @Override
    public BaseUuidEntity getSelected(String key) {
        return getEditedEntity();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        init(new AttachmentScreenDecorator<>(this,"BCourtAppealDecisionEdit", buttonsPanel));
    }

    @Subscribe
    public void onInitEntity(InitEntityEvent<BCourtAppealDecision> event) {
        event.getEntity().setEvent(CCourtCaseEvent.DECISIONAPPEAL);
    }

    @Subscribe("resolutionTypeField")
    public void onResolutionTypeFieldValueChange(HasValue.ValueChangeEvent<CCourtResolutionType> event) {
        getParmsAndLoad();
    }


    private void getParmsAndLoad()
    {
        entityComboBox.clear();
        cCourtResolutionMappingsDl.setParameter("caseEvent",eventField.getValue());
        cCourtResolutionMappingsDl.setParameter("resolutionType",resolutionTypeField.getValue());
        cCourtResolutionMappingsDl.load();
    }
}