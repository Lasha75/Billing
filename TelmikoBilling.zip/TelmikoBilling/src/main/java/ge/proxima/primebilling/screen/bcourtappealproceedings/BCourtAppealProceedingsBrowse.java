package ge.proxima.primebilling.screen.bcourtappealproceedings;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.uidecorators.StandardLookupDecorator;
import ge.proxima.primebilling.java.uidecorators.decorators.AttachmentScreenDecorator;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.BCourtAppealProceedings;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("prx_BCourtAppealProceedings.browse")
@UiDescriptor("b-court-appeal-proceedings-browse.xml")
@LookupComponent("bCourtAppealProceedingsTable")
public class BCourtAppealProceedingsBrowse extends StandardLookupDecorator<BCourtAppealProceedings> {
    @Autowired
    private GroupTable<BCourtAppealProceedings> bCourtAppealProceedingsTable;
    @Autowired
    private ButtonsPanel buttonsPanel;

    @Override
    public BaseUuidEntity getSelected(String key) {
        return bCourtAppealProceedingsTable.getSingleSelected();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        init(
                new AttachmentScreenDecorator<BaseUuidEntity, BCourtAppealProceedingsBrowse>( this, "BCourtAppealProceedingsBrowse", buttonsPanel)
        );
    }
    
}