package ge.proxima.primebilling.screen.bcourtappealproceedings;

import ge.proxima.primebilling.entity.CCourtCaseEvent;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.uidecorators.StandardEditorDecorator;
import ge.proxima.primebilling.java.uidecorators.decorators.AttachmentScreenDecorator;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.BCourtAppealProceedings;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("prx_BCourtAppealProceedings.edit")
@UiDescriptor("b-court-appeal-proceedings-edit.xml")
@EditedEntityContainer("bCourtAppealProceedingsDc")
public class BCourtAppealProceedingsEdit extends StandardEditorDecorator<BCourtAppealProceedings> {
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Override
    public BaseUuidEntity getSelected(String key) {
        return getEditedEntity();
    }

    @Subscribe
    public void onInitEntity(InitEntityEvent<BCourtAppealProceedings> event) {
        event.getEntity().setEvent(CCourtCaseEvent.APPEALPROCEEDINGS);
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        init(new AttachmentScreenDecorator<>(this,"BCourtAppealProceedingsEdit", buttonsPanel));
    }

    
    
}