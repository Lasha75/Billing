package ge.proxima.primebilling.screen.bcourtcase;

import ge.proxima.primebilling.entity.User;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.uidecorators.StandardLookupDecorator;
import ge.proxima.primebilling.java.uidecorators.decorators.AttachmentScreenDecorator;
import ge.proxima.primebilling.screen.ccourtcase.CCourtCaseBrowse;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.BCourtCase;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("prx_BCourtCase.browse")
@UiDescriptor("b-court-case-browse.xml")
@LookupComponent("bCourtCasesTable")
public class BCourtCaseBrowse extends StandardLookupDecorator<BCourtCase> {
    private User currUser;
    @Autowired
    private GroupTable<BCourtCase> bCourtCasesTable;
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private CollectionContainer<BCourtCase> bCourtCasesDc;
    @Autowired
    private CollectionLoader<BCourtCase> bCourtCasesDl;

    public void setCurrUser(User currUser) {
        this.currUser = currUser;
    }

    @Override
    public BaseUuidEntity getSelected(String key) {
        return bCourtCasesTable.getSingleSelected();
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        bCourtCasesDl.setParameter("lawayerUser",currUser);
        bCourtCasesDl.load();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        init(
                new AttachmentScreenDecorator<BaseUuidEntity, BCourtCaseBrowse>( this, "BCourtCaseBrowse", buttonsPanel)
        );
    }


}