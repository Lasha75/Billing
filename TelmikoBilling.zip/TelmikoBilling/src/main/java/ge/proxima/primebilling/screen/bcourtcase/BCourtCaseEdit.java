package ge.proxima.primebilling.screen.bcourtcase;

import ge.proxima.primebilling.entity.*;
import ge.proxima.primebilling.entity.reftables.BCourtAppealDecision;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.entity.transactions.transtypes.BCourtReturnPreTrial;
import ge.proxima.primebilling.entity.transactions.transtypes.BCourtSession;
import ge.proxima.primebilling.entity.transactions.transtypes.CCourtReturnPreTrial;
import ge.proxima.primebilling.java.uidecorators.StandardEditorDecorator;
import ge.proxima.primebilling.java.uidecorators.decorators.AttachmentScreenDecorator;
import io.jmix.core.DataManager;
import io.jmix.core.EntityStates;
import io.jmix.core.Sort;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.EntityPicker;
import io.jmix.ui.model.CollectionChangeType;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.model.InstanceLoader;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;

@UiController("prx_BCourtCase.edit")
@UiDescriptor("b-court-case-edit.xml")
@EditedEntityContainer("bCourtCaseDc")
public class BCourtCaseEdit extends StandardEditorDecorator<BCourtCase> {
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private CollectionLoader<BCourtCaseEventTable> bCourtCaseEventTablesDl;
    @Autowired
    private CollectionLoader<BCourtCase> bCourtCasesChildDl;
    @Autowired
    private InstanceLoader<BCourtCase> bCourtCaseDl;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private EntityStates entityStates;
    @Autowired
    private EntityPicker<BCourtCase> childCase;
    @Autowired
    private ButtonsPanel mainButtonPanel;

    @Subscribe
    public void onInitEntity(InitEntityEvent<BCourtCase> event) {
        event.getEntity().setStatusDate(LocalDate.now());
        event.getEntity().setCaseStatus(CCourtCaseStage.NEW);
        BCourtCase cc=dataManager.load(BCourtCase.class).all()
                .sort(Sort.by(Sort.Direction.DESC,"createdDate")).optional().orElse(null);
        if(cc != null) {
            event.getEntity().setLawayer(cc.getLawayer().getNextLawyer());
        } else {
            event.getEntity().setLawayer(dataManager.load(CCourtLawyer.class).all().optional().orElse(null));
        }
    }

    @Subscribe
    public void onBeforeShow(BeforeShowEvent event) {
        if (!entityStates.isNew(getEditedEntity()) && getEditedEntity().getCaseStatus() == CCourtCaseStage.NEW) {
            getEditedEntity().setCaseStatus(CCourtCaseStage.INPROGRESS);
            dataManager.save(getEditedEntity());
        }
        bCourtCaseEventTablesDl.setParameter("parmCourtCase", getEditedEntity());
        bCourtCaseEventTablesDl.load();
        childCase.setValue(getChiledCaseNumber());
        if(!childCase.isEmpty())
        {
            childCase.setVisible(true);
        }
        else
        {
            childCase.setVisible(false);
        }

    }
    private BCourtCase getChiledCaseNumber()
    {
        BCourtCase cc=dataManager.load(BCourtCase.class).query("select e from prx_BCourtCase e " +
                "where e.consolidateWithCase.id = :consolidateWithCase1  ").parameter("consolidateWithCase1",getEditedEntity().getId()).optional().orElse(null);
        return cc;
    }

    @Subscribe("popupCreate.createConsolidatedCases")
    public void onPopupCreateCreateConsolidatedCases(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtConsolidatedCases.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                    bCourtCaseEventTablesDl.load();
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }
    @Subscribe("popupCreate.createPaymentOfStateDuty")
    public void onPopupCreateCreatePaymentOfStateDuty(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtPaymentOfStateDuty.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe("popupCreate.createPreparationDocuments")
    public void onPopupCreateCreatePreparationDocuments(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtDocumentPreparation.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe("popupCreate.createConsiderationFirstInstance")
    public void onPopupCreateCreateConsiderationFirstInstance(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtConsiderFirstInstance.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe("popupCreate.createResolutionIssuedFirstInstance")
    public void onPopupCreateCreateResolutionIssuedFirstInstance(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtResolIssuedFirst.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe("popupCreate.createAppealProceedings")
    public void onPopupCreateCreateAppealProceedings(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtAppealProceedings.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe("popupCreate.createDecisionAppeal")
    public void onPopupCreateCreateDecisionAppeal(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtAppealDecision.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe("popupCreate.createCassationProceedings")
    public void onPopupCreateCreateCassationProceedings(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtCassationProceedings.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe("popupCreate.createDecisionCassation")
    public void onPopupCreateCreateDecisionCassation(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtCassationDecision.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe("popupCreate.createEnforcementProceedings")
    public void onPopupCreateCreateEnforcementProceedings(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtEnforceProceedings.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe("popupCreate.createPrivateComplaint")
    public void onPopupCreateCreatePrivateComplaint(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtPrivateComplaint.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe("popupCreate.createCourtSessions")
    public void onPopupCreateCreateCourtSessions(Action.ActionPerformedEvent event) {
        Screen screen=  screenBuilders.editor(BCourtSession.class, this).newEntity()
                .withInitializer(casaEvenDocument -> {
                    casaEvenDocument.setCourtCase(getEditedEntity());
                })
                .build();
        screen.addAfterCloseListener(
                afterCloseEvent -> {
                    bCourtCaseEventTablesDl.load();
                    bCourtCaseDl.load();
                }
        );
        screen.show();
    }

    @Subscribe(id = "bCourtCaseEventTablesDc", target = Target.DATA_CONTAINER)
    public void onBCourtCaseEventTablesDcCollectionChange(CollectionContainer.CollectionChangeEvent<BCourtCaseEventTable> event) {
        if(event.getChangeType()== CollectionChangeType.REMOVE_ITEMS) {
            bCourtCaseDl.load();
        }
        if(event.getChangeType()==CollectionChangeType.SET_ITEM)
        {
            bCourtCaseDl.load();
        }
    }


    @Override
    public BaseUuidEntity getSelected(String key) {
        return getEditedEntity();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        init(new AttachmentScreenDecorator<>(this,"BCourtCaseEdit", mainButtonPanel));
    }

}