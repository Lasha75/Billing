package ge.proxima.primebilling.screen.bcourtcassationdecision;

import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.uidecorators.StandardLookupDecorator;
import ge.proxima.primebilling.java.uidecorators.decorators.AttachmentScreenDecorator;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.BCourtCassationDecision;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("prx_BCourtCassationDecision.browse")
@UiDescriptor("b-court-cassation-decision-browse.xml")
@LookupComponent("bCourtCassationDecisionsTable")
public class BCourtCassationDecisionBrowse extends StandardLookupDecorator<BCourtCassationDecision> {
    @Autowired
    private GroupTable<BCourtCassationDecision> bCourtCassationDecisionsTable;
    @Autowired
    private ButtonsPanel buttonsPanel;

    @Override
    public BaseUuidEntity getSelected(String key) {
        return bCourtCassationDecisionsTable.getSingleSelected();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        init(
                new AttachmentScreenDecorator<BaseUuidEntity, BCourtCassationDecisionBrowse>( this, "BCourtCassationDecisionBrowse", buttonsPanel)
        );
    }
    
}