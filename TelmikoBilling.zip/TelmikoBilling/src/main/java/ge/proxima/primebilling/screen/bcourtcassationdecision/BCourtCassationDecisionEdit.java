package ge.proxima.primebilling.screen.bcourtcassationdecision;

import ge.proxima.primebilling.entity.CCourtCaseEvent;
import ge.proxima.primebilling.entity.CCourtResolutionMapping;
import ge.proxima.primebilling.entity.CCourtResolutionType;
import ge.proxima.primebilling.entity.system.BaseUuidEntity;
import ge.proxima.primebilling.java.uidecorators.StandardEditorDecorator;
import ge.proxima.primebilling.java.uidecorators.decorators.AttachmentScreenDecorator;
import io.jmix.ui.component.ButtonsPanel;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.component.HasValue;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import ge.proxima.primebilling.entity.BCourtCassationDecision;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("prx_BCourtCassationDecision.edit")
@UiDescriptor("b-court-cassation-decision-edit.xml")
@EditedEntityContainer("bCourtCassationDecisionDc")
public class BCourtCassationDecisionEdit extends StandardEditorDecorator<BCourtCassationDecision> {
    @Autowired
    private ButtonsPanel buttonsPanel;
    @Autowired
    private EntityComboBox<CCourtResolutionMapping> entityComboBox;
    @Autowired
    private CollectionLoader<CCourtResolutionMapping> cCourtResolutionMappingsDl;
    @Autowired
    private ComboBox<CCourtCaseEvent> eventField;
    @Autowired
    private ComboBox<CCourtResolutionType> resolutionTypeField;

    @Override
    public BaseUuidEntity getSelected(String key) {
        return getEditedEntity();
    }

    @Subscribe
    public void onAfterShow(AfterShowEvent event) {
        init(new AttachmentScreenDecorator<>(this,"CCourtAppealDecisionEdit", buttonsPanel));
    }

    @Subscribe
    public void onInitEntity(InitEntityEvent<BCourtCassationDecision> event) {
        event.getEntity().setEvent(CCourtCaseEvent.DECISIONCASSATION);
    }

    private void getParmsAndLoad()
    {
        entityComboBox.clear();
        cCourtResolutionMappingsDl.setParameter("caseEvent",eventField.getValue());
        cCourtResolutionMappingsDl.setParameter("resolutionType",resolutionTypeField.getValue());
        cCourtResolutionMappingsDl.load();
    }

    @Subscribe("resolutionTypeField")
    public void onResolutionTypeFieldValueChange(HasValue.ValueChangeEvent<CCourtResolutionType> event) {
        getParmsAndLoad();
    }
    
}